/**
 *  @file    test.c
 *  @author  Nathan Baker
 *  @brief   Test code for Vgreen class
 *  @version $Id: test.c,v 1.10 2002/07/29 12:19:38 apbs Exp $
 *  @attention
 *  @verbatim
 *

 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (baker@biochem.wustl.edu)
 * Dept. of Biochemistry and Molecular Biophysics
 * Washington University in St. Louis
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 2002.  Washington University in St. Louis.
 * All Rights Reserved.
 *
 * Portions Copyright (c) 1999-2002.  The Regents of the University of
 * California.  
 * Portions Copyright (c) 1995.  Michael Holst.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE
 * AUTHORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED
 * HEREUNDER IS PROVIDED "AS IS".  THE AUTHORS HAVE NO OBLIGATION TO PROVIDE
 * MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.

 * @endverbatim
 */

#include "apbscfg.h"
#include "maloc/maloc.h"
#include "apbs/vatom.h"
#include "apbs/valist.h"
#include "apbs/vgreen.h"

VEMBED(rcsid="$Id: test.c,v 1.10 2002/07/29 12:19:38 apbs Exp $")

int main(int argc, char **argv) {

    char *pqr_path;
    int i;
    double h, x, y, z, xmin, xmax, ymin, ymax, zmin, zmax, pos[3];
    int nx = 96;
    int ny = 96;
    int nz = 96;
    
    Vgreen *green;
    Valist *alist;
    Vatom *atom;

    printf("main: Starting I/O.\n");
    Vio_start(); 

    if (argc != 2) {
        printf("\n*** Syntax error: got %d arguments, expected 2.\n", argc);
        printf("*** Usage: test1 <charge.pqr>\n\n");
        VASSERT(0);
    } else {
        pqr_path = argv[1];
    }

    Vnm_print(1,"main: Reading atomic data.\n");
    alist = Valist_ctor();
    Valist_readPQR(alist, "FILE", "ASC", VNULL, pqr_path);
    atom = Valist_getAtom(alist, 0);
    xmin = xmax = (Vatom_getPosition(atom))[0];
    ymin = ymax = (Vatom_getPosition(atom))[1];
    zmin = zmax = (Vatom_getPosition(atom))[2];
    for (i=1; i<Valist_getNumberAtoms(alist); i++) {
        atom = Valist_getAtom(alist, i);
        x = (Vatom_getPosition(atom))[0];
        y = (Vatom_getPosition(atom))[1];
        z = (Vatom_getPosition(atom))[2];
        if (x > xmax) xmax = x;
        if (y > ymax) ymax = y;
        if (z > zmax) zmax = z;
        if (x < xmin) xmin = x;
        if (y < ymin) ymin = y;
        if (z < zmin) zmin = z;
    }
    Vnm_print(1, "main: (xmin, xmax) = %4.3f, %4.3f\n", xmin, xmax);
    Vnm_print(1, "main: (ymin, ymax) = %4.3f, %4.3f\n", ymin, ymax);
    Vnm_print(1, "main: (zmin, zmax) = %4.3f, %4.3f\n", zmin, zmax);
    if (Valist_getNumberAtoms(alist) > 1) {
        x = (xmax - xmin);
        y = (ymax - ymin);
        z = (zmax - zmin);
        if ((x > y) && (x > z)) h = x/((double)(nx-1));
        else if ((y > x) && (y > z)) h = y/((double)(ny-1));
        else h = z/((double)(nz-1));
    } else h = 2*Vatom_getRadius(Valist_getAtom(alist,0))/(nx-1);

    Vnm_print(1,"main: Constructing Green's function object.\n");
    green = Vgreen_ctor(alist);

#if defined(USE_CXX_FMM)
    Vnm_print(1,"main: Initializing FMM (h = %4.3f, nx = %d, ny = %d, nz = %d).\n",
      h, nx, ny, nz);
    Vgreen_initFMM(green, h, nx, ny, nz, -0.5*h*(nx-1), -0.5*h*(ny-1),
      -0.5*h*(nx-1));
#endif

    Vnm_print(1,"main: Printing potentials.\n");
    for (i=0; i<50; i++) {
       pos[0] = (nx-1)*h*(double)rand()/(RAND_MAX+1.0) + xmin;
       pos[1] = (ny-1)*h*(double)rand()/(RAND_MAX+1.0) + ymin;
       pos[2] = (nz-1)*h*(double)rand()/(RAND_MAX+1.0) + zmin;
       
       Vnm_print(1, "main: Potential at (%4.3f, %4.3f, %4.3f) = %4.3f\n", pos[0], pos[1],
         pos[2], Vgreen_coulomb(green, pos, 3));
    }

    Vnm_print(1,"main: Destroying Vgreen object.\n");
    Vgreen_dtor(&green);

    Vnm_print(1,"main: Destroying Valist object.\n");
    Valist_dtor(&alist);

    return 0;
}
