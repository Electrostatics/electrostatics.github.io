/** 
 *  @file    cxxfmm.cc
 *  @ingroup Vgreen
 *  @author  Gary Huber (adapted to APBS by Nathan Baker)
 *  @brief   Class Vgreen C++ FMM methods
 *  @version $Id: cxxfmm.cc,v 1.3 2002/01/04 17:20:50 apbs Exp $
 */

#include "apbscfg.h"

#if defined(USE_CXX_FMM)

#include "apbs/vgreen.h"
#include "apbs/vatom.h"
#include "Coulombic_Cell_Multipole_Calculator_Vatom.hh"

VPUBLIC Coulombic_Cell_Multipole_Calculator_Vatom *ccmc;

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Vgreen_dtorCXXFMM
//
// Purpose:  Kill the C++ FMM object
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Vgreen_dtorCXXFMM(Vgreen *thee) { delete ccmc; }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Vgreen_initCXXFMM
//
// Purpose:  Initialize C++ FMM object
//
// Args:     spacing   FMM cell spacings
//           n[xyz]    Number of FMM cells in the specified directions
//           [xyz]low  Lower cordner of the mesh
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Vgreen_initCXXFMM(Vgreen *thee, double spacing, int nx, int ny,
  int nz, double xlow, double ylow, double zlow) {

    /* Construct the CCMC object */
    ccmc = new Coulombic_Cell_Multipole_Calculator_Vatom;

    /* Initialize the object */
    ccmc->Set_list(thee->alist->atoms, Valist_getNumberAtoms(thee->alist));
    ccmc->Set_cell_spacing(spacing);
    ccmc->Set_dimensions(nx, ny, nz);
    ccmc->Set_low_corner(xlow, ylow, zlow);
    ccmc->Update_geometry();
    ccmc->Update_particles();
    ccmc->Compute_far_fields();

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Vgreen_updateCXXFMM
//
// Purpose:  Update the C++ FMM object to reflect a change in atomic positions
//           or properties
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Vgreen_updateCXXFMM(Vgreen *thee) {

    ccmc->Update_geometry();
    ccmc->Update_particles();
    ccmc->Compute_far_fields();

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Vgreen_potentialCXXFMM
//
// Purpose:  Get the potential at the specified position
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double Vgreen_potentialCXXFMM(Vgreen *thee, double x[3]) {

    return ccmc->potential(x);

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Vgreen_fieldCXXFMM
//
// Purpose:  Get the field at the specified position
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Vgreen_fieldCXXFMM(Vgreen *thee, double x[3], 
  double F[3]) {

    ccmc->Get_electric_field(x, F);

}

#endif
