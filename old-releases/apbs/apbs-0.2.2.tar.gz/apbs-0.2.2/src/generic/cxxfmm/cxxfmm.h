/**
 *  @file    cxxfmm.h
 *  @author  Gary Huber (adapted to APBS by Nathan Baker)
 *  @ingroup Vgreen
 *  @brief   Class Vgreen C++ FMM methods
 *  @version $Id: cxxfmm.h,v 1.4 2002/01/04 17:20:50 apbs Exp $
 */

#include "apbs/vgreen.h"

#ifndef CXXFMM_H_
#define CXXFMM_H_

void Vgreen_initCXXFMM(Vgreen *thee, double spacing, int nx, int ny,
  int nz, double xlow, double ylow, double zlow);
void Vgreen_dtorCXXFMM(Vgreen *thee);
void Vgreen_updateCXXFMM(Vgreen *thee);
double Vgreen_potentialCXXFMM(Vgreen *thee, double x[3]);
void Vgreen_fieldCXXFMM(Vgreen *thee, double x[3], double F[3]);

#endif
