#
# The contents of this file are subject to the Mozilla Public
# License Version 1.1 (the "License"); you may not use this file
# except in compliance with the License. You may obtain a copy of
# the License at http://www.mozilla.org/MPL/
# 
# Software distributed under the License is distributed on an "AS
# IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
# implied. See the License for the specific language governing
# rights and limitations under the License.
# The Original Code is "Java-Python Extension libplus (JPE-libplus)".
# 
# The Initial Developer of the Original Code is Frederic Bruno Giacometti.
# Portions created by Frederic Bruno Giacometti are
# Copyright (C) 2002 Frederic Bruno Giacometti. All Rights Reserved.
# 
# Contributor(s): frederic.giacometti@arakne.com

'''libplus configuration module
'''

import config

class Cfg( config.PythonPathDirCfg):

    def makevars( self):
        #if not self.isinstalled: # some more work required ...
        import os
        from os import path
        result = {
            'LIBPLUSDIR': self.rootdir,
            'PYTHONPATH': [self.rootdir],
            'PYBATCH': path.join( self.rootdir, 'bin',
                                  'pybatch.%s' % {'posix': 'ksh',
                                                  'nt': 'bat'}[ os.name]),
            }
        if config.python.ISSHARED:
            result[ 'LD_LIBRARY_PATH'] = config.python.solibpath
            
        return result

    def make( self):
        result = config.PythonPathDirCfg.make( self)
        result[ 0][ 0].update( self.makevars())
        return result
