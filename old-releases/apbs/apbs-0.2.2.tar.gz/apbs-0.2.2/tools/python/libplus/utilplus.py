#
#
# The contents of this file are subject to the Mozilla Public
# License Version 1.1 (the "License"); you may not use this file
# except in compliance with the License. You may obtain a copy of
# the License at http://www.mozilla.org/MPL/
# 
# Software distributed under the License is distributed on an "AS
# IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
# implied. See the License for the specific language governing
# rights and limitations under the License.
# The Original Code is "Java-Python Extension libplus (JPE-libplus)".
# 
# The Initial Developer of the Original Code is Frederic Bruno Giacometti.
# Portions created by Frederic Bruno Giacometti are
# Copyright (C) 2001-2002 Frederic Bruno Giacometti. All Rights Reserved.
# 
# Contributor(s): frederic.giacometti@arakne.com
# 
# Acknowledgments:
# Particular gratitude is expressed to the following parties for their
# contributing support to the development of JPE-libplus:
#     - The Molecular Graphics Laboratory (MGL)
#       at The Scripps Research Institute (TSRI), in La Jolla, CA, USA;
#       and in particular to Michel Sanner and Arthur Olson.
#

import sys, os, warnings

from UserList import UserList
class Path( UserList):
    def __init__( self, data):
        UserList.__init__( self)
        for idata in data:
            self.append( idata)
    def insert( self, idx, other):
        if other:
            UserList.insert( self, idx, other)
    def append( self, other):
        if other not in self:
            self.insert( 0, other)
    def extend( self, other):
        from copy import copy
        revother = copy( other)
        revother.reverse()
        for oitem in revother:
            self.append( oitem)
    def __iadd__( self, other):
        self.extend( other)
        return self
    def __str__( self):
        return os.pathsep.join( self)

def classfile( klass):
    classmod = sys.modules[ klass.__module__]
    if classmod.__name__ == '__main__':
        return sys.argv[ 0]
    else:
        return classmod.__file__

def topmodule( name):
    return sys.modules[ name.split( '.')[ 0]]

def parentmodule( name):
    return sys.modules[ '.'.join( name.split( '.')[ :-1])]

def typeclass( obj):
    from types import InstanceType
    return isinstance( obj, InstanceType) and obj.__class__ or type( obj)

class SysLog( Warning):
    pass

def syslog( msg):
    warnings.warn( msg, SysLog)

class WarnExc( Warning):
    pass

def warn_exc( msg, framecount = None, excinfo = None):
    if not excinfo:
        excinfo = sys.exc_info()
        import traceback
    warnings.warn( '<%s> %s:\n  <%s>\n' % ((msg,) + excinfo[ :2])
                   + ''.join( traceback.format_tb( excinfo[ 2],
                                                   limit = framecount)))
    
def warn_stack( msg, framecount = None, stack = None):
    import traceback
    if not stack:
        stack = traceback.extract_stack( limit = framecount)
    warnings.warn( '<%s>:\n' % msg
                   + ''.join( traceback.format_list( stack)))
    
from UserDict import UserDict
class CustomDict( UserDict):
    def __init__( self):
        UserDict.__init__( self)
        delattr( self, 'data')
    def __getattr__( self, attr):
        if 'data' == attr:
            result = {}
            from os import path
            import imp
            try:
                libpluscfgfile = imp.find_module( 'libpluscfg')[ 1]
            except ImportError, exc:
                warnings.warn( 'libpluscfg not found: <%s>' % exc)
                libpluscfgfile = path.join( sys.prefix,
                                            'libpluscfg_noexist.py')
                
            cusfiles = [path.join( path.dirname( libpluscfgfile),
                                   'tuttidolce_defaults.py'),
                        path.join( os.environ.get( 'HOME', '.'),
                                   '.tuttidolce.py'),
                        'custom.py']
            for cusfile in filter( path.isfile, cusfiles):
                execfile( cusfile, result)
                if result.get( 'utilplus_custom_log', 1):
                    syslog( 'load custom values from <%s>'
                            % path.abspath( cusfile))
        else:
            raise AttributeError( attr)
        setattr( self, attr, result)
        return result

customvalue = CustomDict()
