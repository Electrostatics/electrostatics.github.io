#
# The contents of this file are subject to the Mozilla Public
# License Version 1.1 (the "License"); you may not use this file
# except in compliance with the License. You may obtain a copy of
# the License at http://www.mozilla.org/MPL/
# 
# Software distributed under the License is distributed on an "AS
# IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
# implied. See the License for the specific language governing
# rights and limitations under the License.
# The Original Code is "Java-Python Extension libplus (JPE-libplus)".
# 
# The Initial Developer of the Original Code is Frederic Bruno Giacometti.
# Portions created by Frederic Bruno Giacometti are
# Copyright (C) 2001-2002 Frederic Bruno Giacometti. All Rights Reserved.
# 
# Contributor(s): frederic.giacometti@arakne.com
# 
# Acknowledgments:
# Particular gratitude is expressed to the following parties for their
# contributing support to the development of JPE-libplus:
#     - The Molecular Graphics Laboratory (MGL)
#       at The Scripps Research Institute (TSRI), in La Jolla, CA, USA;
#       and in particular to Michel Sanner and Arthur Olson.
#

import os

class CommandError( RuntimeError):
    def __init__( self, status, errout=''):
        RuntimeError.__init__( self, '%s\n%s' % (status, errout))
        # to be completed ...

class CommandWarning( RuntimeWarning):
    pass

def pcommand( command, mode = 'r', input = '', bufsize = None):
    '''check return code, and raise CommandError on failure
    '''
    pfile = apply( os.popen,
                   bufsize is None
                   and (command, mode) or (command, mode, bufsize))
    if mode == 'r':
        result = pfile.read()
    else:
        if input != '':
            pfile.write( input)
        result = None
    err = pfile.close()
    if err:
        raise CommandError( err, result)
    return result
    

def commandouterr( cmd, workdir=None, dowarning=1,  msgin='',
                   bufsize=None, mode=None):
    '''on win323: no return code check
    '''
    if workdir is not None:
        curdir = os.getcwd()
        os.chdir( workdir)
    try:
        fin, fout, ferr = bufsize is None\
                          and (mode is None and os.popen3( cmd)
                               or os.popen3( cms, mode=mode))\
                          or os.popen3( cmd, bufsize, mode)
    finally:
        if workdir is not None:
            os.chdir( curdir)
    fin.write( msgin)
    fin.close()
    result = fout.read()
    status = fout.close()
    if status:
        raise CommandError( status, ferr.read())
    return result, ferr.read()

def command( cmd, workdir=None, dowarning=1, msgin='',
             bufsize=None, mode=None):
    '''on win323: no return code check
    '''
    result, err = commandouterr( cmd = cmd,
                                 workdir = workdir,
                                 dowarning = dowarning,
                                 msgin = msgin,
                                 bufsize = bufsize,
                                 mode = mode)
    if dowarning and err:
        from warnings import warn
        warn( err, CommandWarning)
    return result

_uname = None

def uname():
    global _uname
    if _uname is None:
        if os.name == 'nt': # replace with call to osplus.uname()
            _uname = (os.environ[ 'OS'], command( 'hostname'), '', '',
                      os.environ[ 'PROCESSOR_ARCHITECTURE'])
        else:
            _uname = os.uname()
    return _uname

def formatcmdarg( name):
    return '"%s"' % name # formatname( name)
    
def formatname( name):
    import re
    return re.sub( '''([ "'])''', lambda x: '\\' + x.group( 1), name)

