#
#
# The contents of this file are subject to the Mozilla Public
# License Version 1.1 (the "License"); you may not use this file
# except in compliance with the License. You may obtain a copy of
# the License at http://www.mozilla.org/MPL/
# 
# Software distributed under the License is distributed on an "AS
# IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
# implied. See the License for the specific language governing
# rights and limitations under the License.
# The Original Code is "Java-Python Extension libplus (JPE-libplus)".
# 
# The Initial Developer of the Original Code is Frederic Bruno Giacometti.
# Portions created by Frederic Bruno Giacometti are
# Copyright (C) 2001-2002 Frederic Bruno Giacometti. All Rights Reserved.
# 
# Contributor(s): frederic.giacometti@arakne.com
# 
# Acknowledgments:
# Particular gratitude is expressed to the following parties for their
# contributing support to the development of JPE-libplus:
#     - The Molecular Graphics Laboratory (MGL)
#       at The Scripps Research Institute (TSRI), in La Jolla, CA, USA;
#       and in particular to Michel Sanner and Arthur Olson.
#

'''Make class
'''

from __future__ import nested_scopes

import string, os
from UserDict import UserDict

class Make:
    '''Description of a Makefile
    '''
    
    def __init__( self, path, (vars, rules, targets)):
        '''
        path - string: Makefile path
        vars - map[ string:string]: Makefile var declarations
        rules - seq( couple( couple( string, string), seq( string))):
            implicit rules. Each rue is described as:
            couple( couple( dep_suffix, target_suffix), seq( command))
        targets - seq( triplet( seq( string), seq( string), seq( string))):
            list of target. Each target is described as:
            (list of targets, list of dependencies, list of commands)

    Attributes
        path String : Makefile path
        vars {} : variables
        rules [((before String, after String), [command String])]
        targets [([target String], [dependency String], [command String])]
        '''
        self.path = path
        self.vars = vars
        self.rules = rules
        self.targets = targets

    def vars2str( self):
        '''
    Return String : variables definition (lexical order)
        '''
        items = self.vars.items()
        items.sort()
        return reduce( lambda x, y: '%s%s=%s\n' % (x, y[ 0], y[ 1]),
                       items, '')

    def rules2str( self):
        '''
    Return String : implicit rules definition
        '''
        suffixes = []
        for suffs, cmds in self.rules:
            for suf in suffs:
                if suf not in suffixes:
                    suffixes.append( suf)
        def mkrule( rule):
            return '\n\t'.join( ['%s%s:' % rule[ 0]] + rule[ 1])
        return '\n\n'.join(
            (suffixes and ([' '.join( ['.SUFFIXES:'] + suffixes)]) or [])
            + map( mkrule, self.rules),
            ) + '\n'

    def targets2str( self):
        '''
    Return String : Makefile targets
        '''
        from operator import add
        from osplus import formatname

        strtargs = reduce( add,
                           [['%s:%s\n'
                             % (' '.join( map( formatname, x[ 0])),
                                ' '.join( [formatname( y)
                                           for y in x[ 1] if y not in x[ 0]])),
                             '%s:\n%s\n' % (' '.join( map( formatname, x[ 0])),
                                            '\n'.join( ['\t%s' % u
                                                        for u in x[ 2]]))]
                            for x in self.targets], [])
        
        result = []
        for target in strtargs:
            if target not in result:
                result.append( target)
        return '\n'.join( result)

    def __str__( self):
        return repr( (
            repr( self),
            self.path,
            [(x, len( getattr( self, x)))
             for x in ['vars', 'rules', 'targets']]
            ))

    def str_all( self):
        '''
    Return string: Makefile
        '''
        return '# Automatically generated\n\n%s\n%s\n%s' % (
            self.vars2str(),
            self.rules2str(),
            self.targets2str()
            )

    def write( self):
        '''write self in its file'''
        open( self.path, 'w').write( self.str_all())


def iaddmk( (vars, rules, targets),
            (ivars, irules, itargets)):
    vars.update( ivars)
    rules.extend( [x for x in irules if x not in rules])
    targets.extend( [x for x in itargets if x not in targets])

    return vars, rules, targets

import utilplus
class Cincludes( utilplus.Path):
    def __str__( self):
        from config import platform
        return platform.includes( self)

from UserList import UserList
class Cdefines( UserList):
    def __str__( self):
        return ' '.join( self)

class IaddVarError( ValueError):
    pass

class UniqueVar:
    def __init__( self, var):
        self.var = var
    def __str__( self):
        return str( self.var)
    def __iadd__( self, value):
        if self.var != value:
            raise IaddVarError( str( value), str( self))
        return self
    
mvarsmap = {
    'CDEFINES': Cdefines,
    'CINCLUDES': Cincludes,
    'LD_LIBRARY_PATH': utilplus.Path,
    'PYTHONHOME': utilplus.Path,
    'PYTHONPATH': utilplus.Path,
    }

class MVars( UserDict):
    def __setitem__( self, key, value):
        data = self.data
        if data.has_key( key):
            dataval = data[ key]
            try:
                dataval += value
            except IaddVarError:
                from warnings import warn
                warn( str( map( str, (key, value, dataval))))
                raise
            data[ key] = dataval
        else:
            data[ key] = mvarsmap.get( key, UniqueVar)( value)
    def update( self, other):
        for key, value in other.items():
            self[ key] = value

def newvarsdesc():
    return MVars()

def newrulesdesc():
    return []

def newtargetsdesc():
    return []

def newmakedesc():
    return newvarsdesc(), newrulesdesc(), newtargetsdesc()


class MakeDesc( UserDict):
    def __init__( self, data={}):
        UserDict.__init__( self)
        if data:
            self.update( data)
    def __setitem__( self, key, value):
        data = self.data
        try:
            mdesc = data[ key]
        except KeyError:
            mdesc = data[ key] = newmakedesc()
        iaddmk( mdesc, value)
    def update( self, other):
        for key, value in other.items():
            self[ key] = value


def iaddmake( (globmake, localdesc),
              (iglobmake, ilocaldesc)):
    localdesc.update( ilocaldesc)
    return iaddmk( globmake, iglobmake), localdesc


def insertglobalmakes( globalmk, localdesc):
    '''concatenates global and local make descs, and return the result
    '''
    result = {}
    for dirpath, localmk in localdesc.items():
        result[ dirpath] = iaddmk( iaddmk( newmakedesc(), globalmk), localmk)
    return result
