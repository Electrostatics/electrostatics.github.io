#
# copyright_notice
#

import os
from ctool.wrapper.swig  import SwigPackageCfg,SwigShadow

FetkInclude = os.environ['FETK_INCLUDE']
FetkLibrary = os.environ['FETK_LIBRARY'] + '/i686-pc-linux-gnu'
CurrDir = os.getcwd()
os.chdir('../../')
TopDir = os.getcwd()
os.chdir(CurrDir)

IncludeFile = [FetkInclude, TopDir + '/src/aaa_inc', TopDir + '/bin']
Liblist = FetkLibrary

class Cfg( SwigPackageCfg):

    def __init__(self,name = None, providers = []):
        self.liblist = Liblist
        SwigPackageCfg.__init__(self,providers=providers,
                                swigclass=SwigShadow)
        
    def make( self):
        
        (allvars, allrules, alltargets), makedesc\
                  = SwigPackageCfg.make( self)
        IncludeFile.append(self.includedir)
        allvars['CINCLUDES']=IncludeFile
        return (allvars, allrules, alltargets), makedesc
