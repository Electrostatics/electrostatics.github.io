# This file was created automatically by SWIG.
import apbslibcc
class MGparm:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,MGparm):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = MGparm.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = MGparm.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["type"] = apbslibcc.MGparm_type_set
    __getmethods__["type"] = apbslibcc.MGparm_type_get
    __setmethods__["parsed"] = apbslibcc.MGparm_parsed_set
    __getmethods__["parsed"] = apbslibcc.MGparm_parsed_get
    __getmethods__["dime"] = apbslibcc.MGparm_dime_get
    __setmethods__["setdime"] = apbslibcc.MGparm_setdime_set
    __getmethods__["setdime"] = apbslibcc.MGparm_setdime_get
    __setmethods__["nlev"] = apbslibcc.MGparm_nlev_set
    __getmethods__["nlev"] = apbslibcc.MGparm_nlev_get
    __setmethods__["setnlev"] = apbslibcc.MGparm_setnlev_set
    __getmethods__["setnlev"] = apbslibcc.MGparm_setnlev_get
    __getmethods__["grid"] = apbslibcc.MGparm_grid_get
    __setmethods__["setgrid"] = apbslibcc.MGparm_setgrid_set
    __getmethods__["setgrid"] = apbslibcc.MGparm_setgrid_get
    __getmethods__["glen"] = apbslibcc.MGparm_glen_get
    __setmethods__["setglen"] = apbslibcc.MGparm_setglen_set
    __getmethods__["setglen"] = apbslibcc.MGparm_setglen_get
    __setmethods__["cmeth"] = apbslibcc.MGparm_cmeth_set
    __getmethods__["cmeth"] = apbslibcc.MGparm_cmeth_get
    __getmethods__["center"] = apbslibcc.MGparm_center_get
    __setmethods__["centmol"] = apbslibcc.MGparm_centmol_set
    __getmethods__["centmol"] = apbslibcc.MGparm_centmol_get
    __setmethods__["setgcent"] = apbslibcc.MGparm_setgcent_set
    __getmethods__["setgcent"] = apbslibcc.MGparm_setgcent_get
    __getmethods__["cglen"] = apbslibcc.MGparm_cglen_get
    __setmethods__["setcglen"] = apbslibcc.MGparm_setcglen_set
    __getmethods__["setcglen"] = apbslibcc.MGparm_setcglen_get
    __getmethods__["fglen"] = apbslibcc.MGparm_fglen_get
    __setmethods__["setfglen"] = apbslibcc.MGparm_setfglen_set
    __getmethods__["setfglen"] = apbslibcc.MGparm_setfglen_get
    __setmethods__["ccmeth"] = apbslibcc.MGparm_ccmeth_set
    __getmethods__["ccmeth"] = apbslibcc.MGparm_ccmeth_get
    __getmethods__["ccenter"] = apbslibcc.MGparm_ccenter_get
    __setmethods__["ccentmol"] = apbslibcc.MGparm_ccentmol_set
    __getmethods__["ccentmol"] = apbslibcc.MGparm_ccentmol_get
    __setmethods__["setcgcent"] = apbslibcc.MGparm_setcgcent_set
    __getmethods__["setcgcent"] = apbslibcc.MGparm_setcgcent_get
    __setmethods__["fcmeth"] = apbslibcc.MGparm_fcmeth_set
    __getmethods__["fcmeth"] = apbslibcc.MGparm_fcmeth_get
    __getmethods__["fcenter"] = apbslibcc.MGparm_fcenter_get
    __setmethods__["fcentmol"] = apbslibcc.MGparm_fcentmol_set
    __getmethods__["fcentmol"] = apbslibcc.MGparm_fcentmol_get
    __setmethods__["setfgcent"] = apbslibcc.MGparm_setfgcent_set
    __getmethods__["setfgcent"] = apbslibcc.MGparm_setfgcent_get
    __getmethods__["partDisjCenterShift"] = apbslibcc.MGparm_partDisjCenterShift_get
    __getmethods__["partDisjLength"] = apbslibcc.MGparm_partDisjLength_get
    __getmethods__["partDisjOwnSide"] = apbslibcc.MGparm_partDisjOwnSide_get
    __getmethods__["partOlapCenterShift"] = apbslibcc.MGparm_partOlapCenterShift_get
    __getmethods__["partOlapLength"] = apbslibcc.MGparm_partOlapLength_get
    __getmethods__["pdime"] = apbslibcc.MGparm_pdime_get
    __setmethods__["setpdime"] = apbslibcc.MGparm_setpdime_set
    __getmethods__["setpdime"] = apbslibcc.MGparm_setpdime_get
    __setmethods__["com"] = apbslibcc.MGparm_com_set
    __getmethods__["com"] = apbslibcc.MGparm_com_get
    __setmethods__["setcom"] = apbslibcc.MGparm_setcom_set
    __getmethods__["setcom"] = apbslibcc.MGparm_setcom_get
    __setmethods__["ofrac"] = apbslibcc.MGparm_ofrac_set
    __getmethods__["ofrac"] = apbslibcc.MGparm_ofrac_get
    __setmethods__["setofrac"] = apbslibcc.MGparm_setofrac_set
    __getmethods__["setofrac"] = apbslibcc.MGparm_setofrac_get
    def __init__(self,*args):
        self.this = apply(apbslibcc.new_MGparm,args)
        self.thisown = 1
    def __del__(self,apbslibcc=apbslibcc):
        if getattr(self,'thisown',0):
            apbslibcc.delete_MGparm(self)
    def __repr__(self):
        return "<C MGparm instance at %s>" % (self.this,)

class MGparmPtr(MGparm):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = MGparm
apbslibcc.MGparm_swigregister(MGparmPtr)
MGparm_ctor = apbslibcc.MGparm_ctor

MGparm_ctor2 = apbslibcc.MGparm_ctor2

MGparm_dtor = apbslibcc.MGparm_dtor

MGparm_dtor2 = apbslibcc.MGparm_dtor2

MGparm_check = apbslibcc.MGparm_check

MGparm_copy = apbslibcc.MGparm_copy

MGparm_parseToken = apbslibcc.MGparm_parseToken


