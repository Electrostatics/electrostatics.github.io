# This file was created automatically by SWIG.
import apbslibc
class AtomForce:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,AtomForce):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = AtomForce.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = AtomForce.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __getmethods__["ibForce"] = apbslibc.AtomForce_ibForce_get
    __getmethods__["qfForce"] = apbslibc.AtomForce_qfForce_get
    __getmethods__["dbForce"] = apbslibc.AtomForce_dbForce_get
    __getmethods__["npForce"] = apbslibc.AtomForce_npForce_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_AtomForce,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_AtomForce(self)
    def __repr__(self):
        return "<C AtomForce instance at %s>" % (self.this,)

class AtomForcePtr(AtomForce):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = AtomForce
apbslibc.AtomForce_swigregister(AtomForcePtr)
class NOsh_calc:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,NOsh_calc):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = NOsh_calc.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = NOsh_calc.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["mgparm"] = apbslibc.NOsh_calc_mgparm_set
    __getmethods__["mgparm"] = apbslibc.NOsh_calc_mgparm_get
    __setmethods__["femparm"] = apbslibc.NOsh_calc_femparm_set
    __getmethods__["femparm"] = apbslibc.NOsh_calc_femparm_get
    __setmethods__["pbeparm"] = apbslibc.NOsh_calc_pbeparm_set
    __getmethods__["pbeparm"] = apbslibc.NOsh_calc_pbeparm_get
    __setmethods__["calctype"] = apbslibc.NOsh_calc_calctype_set
    __getmethods__["calctype"] = apbslibc.NOsh_calc_calctype_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_NOsh_calc,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_NOsh_calc(self)
    def __repr__(self):
        return "<C NOsh_calc instance at %s>" % (self.this,)

class NOsh_calcPtr(NOsh_calc):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = NOsh_calc
apbslibc.NOsh_calc_swigregister(NOsh_calcPtr)
class NOsh:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,NOsh):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = NOsh.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = NOsh.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __getmethods__["calc"] = apbslibc.NOsh_calc_get
    __setmethods__["ncalc"] = apbslibc.NOsh_ncalc_set
    __getmethods__["ncalc"] = apbslibc.NOsh_ncalc_get
    __setmethods__["nelec"] = apbslibc.NOsh_nelec_set
    __getmethods__["nelec"] = apbslibc.NOsh_nelec_get
    __setmethods__["ispara"] = apbslibc.NOsh_ispara_set
    __getmethods__["ispara"] = apbslibc.NOsh_ispara_get
    __setmethods__["proc_rank"] = apbslibc.NOsh_proc_rank_set
    __getmethods__["proc_rank"] = apbslibc.NOsh_proc_rank_get
    __setmethods__["proc_size"] = apbslibc.NOsh_proc_size_set
    __getmethods__["proc_size"] = apbslibc.NOsh_proc_size_get
    __setmethods__["bogus"] = apbslibc.NOsh_bogus_set
    __getmethods__["bogus"] = apbslibc.NOsh_bogus_get
    __getmethods__["elec2calc"] = apbslibc.NOsh_elec2calc_get
    __setmethods__["nmol"] = apbslibc.NOsh_nmol_set
    __getmethods__["nmol"] = apbslibc.NOsh_nmol_get
    __getmethods__["molpath"] = apbslibc.NOsh_molpath_get
    __getmethods__["molfmt"] = apbslibc.NOsh_molfmt_get
    __setmethods__["ndiel"] = apbslibc.NOsh_ndiel_set
    __getmethods__["ndiel"] = apbslibc.NOsh_ndiel_get
    __getmethods__["dielXpath"] = apbslibc.NOsh_dielXpath_get
    __getmethods__["dielYpath"] = apbslibc.NOsh_dielYpath_get
    __getmethods__["dielZpath"] = apbslibc.NOsh_dielZpath_get
    __getmethods__["dielfmt"] = apbslibc.NOsh_dielfmt_get
    __setmethods__["nkappa"] = apbslibc.NOsh_nkappa_set
    __getmethods__["nkappa"] = apbslibc.NOsh_nkappa_get
    __getmethods__["kappapath"] = apbslibc.NOsh_kappapath_get
    __getmethods__["kappafmt"] = apbslibc.NOsh_kappafmt_get
    __setmethods__["ncharge"] = apbslibc.NOsh_ncharge_set
    __getmethods__["ncharge"] = apbslibc.NOsh_ncharge_get
    __getmethods__["chargepath"] = apbslibc.NOsh_chargepath_get
    __getmethods__["chargefmt"] = apbslibc.NOsh_chargefmt_get
    __setmethods__["nprint"] = apbslibc.NOsh_nprint_set
    __getmethods__["nprint"] = apbslibc.NOsh_nprint_get
    __getmethods__["printwhat"] = apbslibc.NOsh_printwhat_get
    __getmethods__["printnarg"] = apbslibc.NOsh_printnarg_get
    __getmethods__["printcalc"] = apbslibc.NOsh_printcalc_get
    __getmethods__["printop"] = apbslibc.NOsh_printop_get
    __setmethods__["parsed"] = apbslibc.NOsh_parsed_set
    __getmethods__["parsed"] = apbslibc.NOsh_parsed_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_NOsh,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_NOsh(self)
    def __repr__(self):
        return "<C NOsh instance at %s>" % (self.this,)

class NOshPtr(NOsh):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = NOsh
apbslibc.NOsh_swigregister(NOshPtr)
class MGparm:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,MGparm):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = MGparm.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = MGparm.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["type"] = apbslibc.MGparm_type_set
    __getmethods__["type"] = apbslibc.MGparm_type_get
    __setmethods__["parsed"] = apbslibc.MGparm_parsed_set
    __getmethods__["parsed"] = apbslibc.MGparm_parsed_get
    __getmethods__["dime"] = apbslibc.MGparm_dime_get
    __setmethods__["setdime"] = apbslibc.MGparm_setdime_set
    __getmethods__["setdime"] = apbslibc.MGparm_setdime_get
    __setmethods__["nlev"] = apbslibc.MGparm_nlev_set
    __getmethods__["nlev"] = apbslibc.MGparm_nlev_get
    __setmethods__["setnlev"] = apbslibc.MGparm_setnlev_set
    __getmethods__["setnlev"] = apbslibc.MGparm_setnlev_get
    __getmethods__["grid"] = apbslibc.MGparm_grid_get
    __setmethods__["setgrid"] = apbslibc.MGparm_setgrid_set
    __getmethods__["setgrid"] = apbslibc.MGparm_setgrid_get
    __getmethods__["glen"] = apbslibc.MGparm_glen_get
    __setmethods__["setglen"] = apbslibc.MGparm_setglen_set
    __getmethods__["setglen"] = apbslibc.MGparm_setglen_get
    __setmethods__["cmeth"] = apbslibc.MGparm_cmeth_set
    __getmethods__["cmeth"] = apbslibc.MGparm_cmeth_get
    __getmethods__["center"] = apbslibc.MGparm_center_get
    __setmethods__["centmol"] = apbslibc.MGparm_centmol_set
    __getmethods__["centmol"] = apbslibc.MGparm_centmol_get
    __setmethods__["setgcent"] = apbslibc.MGparm_setgcent_set
    __getmethods__["setgcent"] = apbslibc.MGparm_setgcent_get
    __getmethods__["cglen"] = apbslibc.MGparm_cglen_get
    __setmethods__["setcglen"] = apbslibc.MGparm_setcglen_set
    __getmethods__["setcglen"] = apbslibc.MGparm_setcglen_get
    __getmethods__["fglen"] = apbslibc.MGparm_fglen_get
    __setmethods__["setfglen"] = apbslibc.MGparm_setfglen_set
    __getmethods__["setfglen"] = apbslibc.MGparm_setfglen_get
    __setmethods__["ccmeth"] = apbslibc.MGparm_ccmeth_set
    __getmethods__["ccmeth"] = apbslibc.MGparm_ccmeth_get
    __getmethods__["ccenter"] = apbslibc.MGparm_ccenter_get
    __setmethods__["ccentmol"] = apbslibc.MGparm_ccentmol_set
    __getmethods__["ccentmol"] = apbslibc.MGparm_ccentmol_get
    __setmethods__["setcgcent"] = apbslibc.MGparm_setcgcent_set
    __getmethods__["setcgcent"] = apbslibc.MGparm_setcgcent_get
    __setmethods__["fcmeth"] = apbslibc.MGparm_fcmeth_set
    __getmethods__["fcmeth"] = apbslibc.MGparm_fcmeth_get
    __getmethods__["fcenter"] = apbslibc.MGparm_fcenter_get
    __setmethods__["fcentmol"] = apbslibc.MGparm_fcentmol_set
    __getmethods__["fcentmol"] = apbslibc.MGparm_fcentmol_get
    __setmethods__["setfgcent"] = apbslibc.MGparm_setfgcent_set
    __getmethods__["setfgcent"] = apbslibc.MGparm_setfgcent_get
    __getmethods__["partDisjCenterShift"] = apbslibc.MGparm_partDisjCenterShift_get
    __getmethods__["partDisjLength"] = apbslibc.MGparm_partDisjLength_get
    __getmethods__["partDisjOwnSide"] = apbslibc.MGparm_partDisjOwnSide_get
    __getmethods__["partOlapCenterShift"] = apbslibc.MGparm_partOlapCenterShift_get
    __getmethods__["partOlapLength"] = apbslibc.MGparm_partOlapLength_get
    __getmethods__["pdime"] = apbslibc.MGparm_pdime_get
    __setmethods__["setpdime"] = apbslibc.MGparm_setpdime_set
    __getmethods__["setpdime"] = apbslibc.MGparm_setpdime_get
    __setmethods__["proc_rank"] = apbslibc.MGparm_proc_rank_set
    __getmethods__["proc_rank"] = apbslibc.MGparm_proc_rank_get
    __setmethods__["setrank"] = apbslibc.MGparm_setrank_set
    __getmethods__["setrank"] = apbslibc.MGparm_setrank_get
    __setmethods__["proc_size"] = apbslibc.MGparm_proc_size_set
    __getmethods__["proc_size"] = apbslibc.MGparm_proc_size_get
    __setmethods__["setsize"] = apbslibc.MGparm_setsize_set
    __getmethods__["setsize"] = apbslibc.MGparm_setsize_get
    __setmethods__["ofrac"] = apbslibc.MGparm_ofrac_set
    __getmethods__["ofrac"] = apbslibc.MGparm_ofrac_get
    __setmethods__["setofrac"] = apbslibc.MGparm_setofrac_set
    __getmethods__["setofrac"] = apbslibc.MGparm_setofrac_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_MGparm,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_MGparm(self)
    def __repr__(self):
        return "<C MGparm instance at %s>" % (self.this,)

class MGparmPtr(MGparm):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = MGparm
apbslibc.MGparm_swigregister(MGparmPtr)
class PBEparm:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,PBEparm):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = PBEparm.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = PBEparm.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["molid"] = apbslibc.PBEparm_molid_set
    __getmethods__["molid"] = apbslibc.PBEparm_molid_get
    __setmethods__["setmolid"] = apbslibc.PBEparm_setmolid_set
    __getmethods__["setmolid"] = apbslibc.PBEparm_setmolid_get
    __setmethods__["useDielMap"] = apbslibc.PBEparm_useDielMap_set
    __getmethods__["useDielMap"] = apbslibc.PBEparm_useDielMap_get
    __setmethods__["dielMapID"] = apbslibc.PBEparm_dielMapID_set
    __getmethods__["dielMapID"] = apbslibc.PBEparm_dielMapID_get
    __setmethods__["useKappaMap"] = apbslibc.PBEparm_useKappaMap_set
    __getmethods__["useKappaMap"] = apbslibc.PBEparm_useKappaMap_get
    __setmethods__["kappaMapID"] = apbslibc.PBEparm_kappaMapID_set
    __getmethods__["kappaMapID"] = apbslibc.PBEparm_kappaMapID_get
    __setmethods__["useChargeMap"] = apbslibc.PBEparm_useChargeMap_set
    __getmethods__["useChargeMap"] = apbslibc.PBEparm_useChargeMap_get
    __setmethods__["chargeMapID"] = apbslibc.PBEparm_chargeMapID_set
    __getmethods__["chargeMapID"] = apbslibc.PBEparm_chargeMapID_get
    __setmethods__["nonlin"] = apbslibc.PBEparm_nonlin_set
    __getmethods__["nonlin"] = apbslibc.PBEparm_nonlin_get
    __setmethods__["setnonlin"] = apbslibc.PBEparm_setnonlin_set
    __getmethods__["setnonlin"] = apbslibc.PBEparm_setnonlin_get
    __setmethods__["bcfl"] = apbslibc.PBEparm_bcfl_set
    __getmethods__["bcfl"] = apbslibc.PBEparm_bcfl_get
    __setmethods__["setbcfl"] = apbslibc.PBEparm_setbcfl_set
    __getmethods__["setbcfl"] = apbslibc.PBEparm_setbcfl_get
    __setmethods__["nion"] = apbslibc.PBEparm_nion_set
    __getmethods__["nion"] = apbslibc.PBEparm_nion_get
    __setmethods__["setnion"] = apbslibc.PBEparm_setnion_set
    __getmethods__["setnion"] = apbslibc.PBEparm_setnion_get
    __getmethods__["ionq"] = apbslibc.PBEparm_ionq_get
    __getmethods__["ionc"] = apbslibc.PBEparm_ionc_get
    __getmethods__["ionr"] = apbslibc.PBEparm_ionr_get
    __getmethods__["setion"] = apbslibc.PBEparm_setion_get
    __setmethods__["pdie"] = apbslibc.PBEparm_pdie_set
    __getmethods__["pdie"] = apbslibc.PBEparm_pdie_get
    __setmethods__["setpdie"] = apbslibc.PBEparm_setpdie_set
    __getmethods__["setpdie"] = apbslibc.PBEparm_setpdie_get
    __setmethods__["sdie"] = apbslibc.PBEparm_sdie_set
    __getmethods__["sdie"] = apbslibc.PBEparm_sdie_get
    __setmethods__["setsdie"] = apbslibc.PBEparm_setsdie_set
    __getmethods__["setsdie"] = apbslibc.PBEparm_setsdie_get
    __setmethods__["srfm"] = apbslibc.PBEparm_srfm_set
    __getmethods__["srfm"] = apbslibc.PBEparm_srfm_get
    __setmethods__["setsrfm"] = apbslibc.PBEparm_setsrfm_set
    __getmethods__["setsrfm"] = apbslibc.PBEparm_setsrfm_get
    __setmethods__["srad"] = apbslibc.PBEparm_srad_set
    __getmethods__["srad"] = apbslibc.PBEparm_srad_get
    __setmethods__["setsrad"] = apbslibc.PBEparm_setsrad_set
    __getmethods__["setsrad"] = apbslibc.PBEparm_setsrad_get
    __setmethods__["swin"] = apbslibc.PBEparm_swin_set
    __getmethods__["swin"] = apbslibc.PBEparm_swin_get
    __setmethods__["setswin"] = apbslibc.PBEparm_setswin_set
    __getmethods__["setswin"] = apbslibc.PBEparm_setswin_get
    __setmethods__["temp"] = apbslibc.PBEparm_temp_set
    __getmethods__["temp"] = apbslibc.PBEparm_temp_get
    __setmethods__["settemp"] = apbslibc.PBEparm_settemp_set
    __getmethods__["settemp"] = apbslibc.PBEparm_settemp_get
    __setmethods__["gamma"] = apbslibc.PBEparm_gamma_set
    __getmethods__["gamma"] = apbslibc.PBEparm_gamma_get
    __setmethods__["setgamma"] = apbslibc.PBEparm_setgamma_set
    __getmethods__["setgamma"] = apbslibc.PBEparm_setgamma_get
    __setmethods__["calcenergy"] = apbslibc.PBEparm_calcenergy_set
    __getmethods__["calcenergy"] = apbslibc.PBEparm_calcenergy_get
    __setmethods__["setcalcenergy"] = apbslibc.PBEparm_setcalcenergy_set
    __getmethods__["setcalcenergy"] = apbslibc.PBEparm_setcalcenergy_get
    __setmethods__["calcforce"] = apbslibc.PBEparm_calcforce_set
    __getmethods__["calcforce"] = apbslibc.PBEparm_calcforce_get
    __setmethods__["setcalcforce"] = apbslibc.PBEparm_setcalcforce_set
    __getmethods__["setcalcforce"] = apbslibc.PBEparm_setcalcforce_get
    __setmethods__["numwrite"] = apbslibc.PBEparm_numwrite_set
    __getmethods__["numwrite"] = apbslibc.PBEparm_numwrite_get
    __getmethods__["writestem"] = apbslibc.PBEparm_writestem_get
    __getmethods__["writetype"] = apbslibc.PBEparm_writetype_get
    __getmethods__["writefmt"] = apbslibc.PBEparm_writefmt_get
    __setmethods__["writemat"] = apbslibc.PBEparm_writemat_set
    __getmethods__["writemat"] = apbslibc.PBEparm_writemat_get
    __setmethods__["setwritemat"] = apbslibc.PBEparm_setwritemat_set
    __getmethods__["setwritemat"] = apbslibc.PBEparm_setwritemat_get
    __setmethods__["writematstem"] = apbslibc.PBEparm_writematstem_set
    __getmethods__["writematstem"] = apbslibc.PBEparm_writematstem_get
    __setmethods__["writematflag"] = apbslibc.PBEparm_writematflag_set
    __getmethods__["writematflag"] = apbslibc.PBEparm_writematflag_get
    __setmethods__["parsed"] = apbslibc.PBEparm_parsed_set
    __getmethods__["parsed"] = apbslibc.PBEparm_parsed_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_PBEparm,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_PBEparm(self)
    def __repr__(self):
        return "<C PBEparm instance at %s>" % (self.this,)

class PBEparmPtr(PBEparm):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = PBEparm
apbslibc.PBEparm_swigregister(PBEparmPtr)
class Vpmgp:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,Vpmgp):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = Vpmgp.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = Vpmgp.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["nx"] = apbslibc.Vpmgp_nx_set
    __getmethods__["nx"] = apbslibc.Vpmgp_nx_get
    __setmethods__["ny"] = apbslibc.Vpmgp_ny_set
    __getmethods__["ny"] = apbslibc.Vpmgp_ny_get
    __setmethods__["nz"] = apbslibc.Vpmgp_nz_set
    __getmethods__["nz"] = apbslibc.Vpmgp_nz_get
    __setmethods__["nlev"] = apbslibc.Vpmgp_nlev_set
    __getmethods__["nlev"] = apbslibc.Vpmgp_nlev_get
    __setmethods__["hx"] = apbslibc.Vpmgp_hx_set
    __getmethods__["hx"] = apbslibc.Vpmgp_hx_get
    __setmethods__["hy"] = apbslibc.Vpmgp_hy_set
    __getmethods__["hy"] = apbslibc.Vpmgp_hy_get
    __setmethods__["hzed"] = apbslibc.Vpmgp_hzed_set
    __getmethods__["hzed"] = apbslibc.Vpmgp_hzed_get
    __setmethods__["nonlin"] = apbslibc.Vpmgp_nonlin_set
    __getmethods__["nonlin"] = apbslibc.Vpmgp_nonlin_get
    __setmethods__["nxc"] = apbslibc.Vpmgp_nxc_set
    __getmethods__["nxc"] = apbslibc.Vpmgp_nxc_get
    __setmethods__["nyc"] = apbslibc.Vpmgp_nyc_set
    __getmethods__["nyc"] = apbslibc.Vpmgp_nyc_get
    __setmethods__["nzc"] = apbslibc.Vpmgp_nzc_set
    __getmethods__["nzc"] = apbslibc.Vpmgp_nzc_get
    __setmethods__["nf"] = apbslibc.Vpmgp_nf_set
    __getmethods__["nf"] = apbslibc.Vpmgp_nf_get
    __setmethods__["nc"] = apbslibc.Vpmgp_nc_set
    __getmethods__["nc"] = apbslibc.Vpmgp_nc_get
    __setmethods__["narrc"] = apbslibc.Vpmgp_narrc_set
    __getmethods__["narrc"] = apbslibc.Vpmgp_narrc_get
    __setmethods__["n_rpc"] = apbslibc.Vpmgp_n_rpc_set
    __getmethods__["n_rpc"] = apbslibc.Vpmgp_n_rpc_get
    __setmethods__["n_iz"] = apbslibc.Vpmgp_n_iz_set
    __getmethods__["n_iz"] = apbslibc.Vpmgp_n_iz_get
    __setmethods__["n_ipc"] = apbslibc.Vpmgp_n_ipc_set
    __getmethods__["n_ipc"] = apbslibc.Vpmgp_n_ipc_get
    __setmethods__["nrwk"] = apbslibc.Vpmgp_nrwk_set
    __getmethods__["nrwk"] = apbslibc.Vpmgp_nrwk_get
    __setmethods__["niwk"] = apbslibc.Vpmgp_niwk_set
    __getmethods__["niwk"] = apbslibc.Vpmgp_niwk_get
    __setmethods__["narr"] = apbslibc.Vpmgp_narr_set
    __getmethods__["narr"] = apbslibc.Vpmgp_narr_get
    __setmethods__["ipkey"] = apbslibc.Vpmgp_ipkey_set
    __getmethods__["ipkey"] = apbslibc.Vpmgp_ipkey_get
    __setmethods__["xcent"] = apbslibc.Vpmgp_xcent_set
    __getmethods__["xcent"] = apbslibc.Vpmgp_xcent_get
    __setmethods__["ycent"] = apbslibc.Vpmgp_ycent_set
    __getmethods__["ycent"] = apbslibc.Vpmgp_ycent_get
    __setmethods__["zcent"] = apbslibc.Vpmgp_zcent_set
    __getmethods__["zcent"] = apbslibc.Vpmgp_zcent_get
    __setmethods__["errtol"] = apbslibc.Vpmgp_errtol_set
    __getmethods__["errtol"] = apbslibc.Vpmgp_errtol_get
    __setmethods__["itmax"] = apbslibc.Vpmgp_itmax_set
    __getmethods__["itmax"] = apbslibc.Vpmgp_itmax_get
    __setmethods__["istop"] = apbslibc.Vpmgp_istop_set
    __getmethods__["istop"] = apbslibc.Vpmgp_istop_get
    __setmethods__["iinfo"] = apbslibc.Vpmgp_iinfo_set
    __getmethods__["iinfo"] = apbslibc.Vpmgp_iinfo_get
    __setmethods__["bcfl"] = apbslibc.Vpmgp_bcfl_set
    __getmethods__["bcfl"] = apbslibc.Vpmgp_bcfl_get
    __setmethods__["key"] = apbslibc.Vpmgp_key_set
    __getmethods__["key"] = apbslibc.Vpmgp_key_get
    __setmethods__["iperf"] = apbslibc.Vpmgp_iperf_set
    __getmethods__["iperf"] = apbslibc.Vpmgp_iperf_get
    __setmethods__["meth"] = apbslibc.Vpmgp_meth_set
    __getmethods__["meth"] = apbslibc.Vpmgp_meth_get
    __setmethods__["mgkey"] = apbslibc.Vpmgp_mgkey_set
    __getmethods__["mgkey"] = apbslibc.Vpmgp_mgkey_get
    __setmethods__["nu1"] = apbslibc.Vpmgp_nu1_set
    __getmethods__["nu1"] = apbslibc.Vpmgp_nu1_get
    __setmethods__["nu2"] = apbslibc.Vpmgp_nu2_set
    __getmethods__["nu2"] = apbslibc.Vpmgp_nu2_get
    __setmethods__["mgsmoo"] = apbslibc.Vpmgp_mgsmoo_set
    __getmethods__["mgsmoo"] = apbslibc.Vpmgp_mgsmoo_get
    __setmethods__["mgprol"] = apbslibc.Vpmgp_mgprol_set
    __getmethods__["mgprol"] = apbslibc.Vpmgp_mgprol_get
    __setmethods__["mgcoar"] = apbslibc.Vpmgp_mgcoar_set
    __getmethods__["mgcoar"] = apbslibc.Vpmgp_mgcoar_get
    __setmethods__["mgsolv"] = apbslibc.Vpmgp_mgsolv_set
    __getmethods__["mgsolv"] = apbslibc.Vpmgp_mgsolv_get
    __setmethods__["mgdisc"] = apbslibc.Vpmgp_mgdisc_set
    __getmethods__["mgdisc"] = apbslibc.Vpmgp_mgdisc_get
    __setmethods__["omegal"] = apbslibc.Vpmgp_omegal_set
    __getmethods__["omegal"] = apbslibc.Vpmgp_omegal_get
    __setmethods__["omegan"] = apbslibc.Vpmgp_omegan_set
    __getmethods__["omegan"] = apbslibc.Vpmgp_omegan_get
    __setmethods__["irite"] = apbslibc.Vpmgp_irite_set
    __getmethods__["irite"] = apbslibc.Vpmgp_irite_get
    __setmethods__["ipcon"] = apbslibc.Vpmgp_ipcon_set
    __getmethods__["ipcon"] = apbslibc.Vpmgp_ipcon_get
    __setmethods__["xlen"] = apbslibc.Vpmgp_xlen_set
    __getmethods__["xlen"] = apbslibc.Vpmgp_xlen_get
    __setmethods__["ylen"] = apbslibc.Vpmgp_ylen_set
    __getmethods__["ylen"] = apbslibc.Vpmgp_ylen_get
    __setmethods__["zlen"] = apbslibc.Vpmgp_zlen_set
    __getmethods__["zlen"] = apbslibc.Vpmgp_zlen_get
    __setmethods__["xmin"] = apbslibc.Vpmgp_xmin_set
    __getmethods__["xmin"] = apbslibc.Vpmgp_xmin_get
    __setmethods__["ymin"] = apbslibc.Vpmgp_ymin_set
    __getmethods__["ymin"] = apbslibc.Vpmgp_ymin_get
    __setmethods__["zmin"] = apbslibc.Vpmgp_zmin_set
    __getmethods__["zmin"] = apbslibc.Vpmgp_zmin_get
    __setmethods__["xmax"] = apbslibc.Vpmgp_xmax_set
    __getmethods__["xmax"] = apbslibc.Vpmgp_xmax_get
    __setmethods__["ymax"] = apbslibc.Vpmgp_ymax_set
    __getmethods__["ymax"] = apbslibc.Vpmgp_ymax_get
    __setmethods__["zmax"] = apbslibc.Vpmgp_zmax_set
    __getmethods__["zmax"] = apbslibc.Vpmgp_zmax_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_Vpmgp,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_Vpmgp(self)
    def __repr__(self):
        return "<C Vpmgp instance at %s>" % (self.this,)

class VpmgpPtr(Vpmgp):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = Vpmgp
apbslibc.Vpmgp_swigregister(VpmgpPtr)
class Vpmg:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,Vpmg):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = Vpmg.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = Vpmg.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["vmem"] = apbslibc.Vpmg_vmem_set
    __getmethods__["vmem"] = apbslibc.Vpmg_vmem_get
    __setmethods__["pmgp"] = apbslibc.Vpmg_pmgp_set
    __getmethods__["pmgp"] = apbslibc.Vpmg_pmgp_get
    __setmethods__["pbe"] = apbslibc.Vpmg_pbe_set
    __getmethods__["pbe"] = apbslibc.Vpmg_pbe_get
    __setmethods__["iparm"] = apbslibc.Vpmg_iparm_set
    __getmethods__["iparm"] = apbslibc.Vpmg_iparm_get
    __setmethods__["rparm"] = apbslibc.Vpmg_rparm_set
    __getmethods__["rparm"] = apbslibc.Vpmg_rparm_get
    __setmethods__["iwork"] = apbslibc.Vpmg_iwork_set
    __getmethods__["iwork"] = apbslibc.Vpmg_iwork_get
    __setmethods__["rwork"] = apbslibc.Vpmg_rwork_set
    __getmethods__["rwork"] = apbslibc.Vpmg_rwork_get
    __setmethods__["a1cf"] = apbslibc.Vpmg_a1cf_set
    __getmethods__["a1cf"] = apbslibc.Vpmg_a1cf_get
    __setmethods__["a2cf"] = apbslibc.Vpmg_a2cf_set
    __getmethods__["a2cf"] = apbslibc.Vpmg_a2cf_get
    __setmethods__["a3cf"] = apbslibc.Vpmg_a3cf_set
    __getmethods__["a3cf"] = apbslibc.Vpmg_a3cf_get
    __setmethods__["ccf"] = apbslibc.Vpmg_ccf_set
    __getmethods__["ccf"] = apbslibc.Vpmg_ccf_get
    __setmethods__["fcf"] = apbslibc.Vpmg_fcf_set
    __getmethods__["fcf"] = apbslibc.Vpmg_fcf_get
    __setmethods__["tcf"] = apbslibc.Vpmg_tcf_set
    __getmethods__["tcf"] = apbslibc.Vpmg_tcf_get
    __setmethods__["u"] = apbslibc.Vpmg_u_set
    __getmethods__["u"] = apbslibc.Vpmg_u_get
    __setmethods__["xf"] = apbslibc.Vpmg_xf_set
    __getmethods__["xf"] = apbslibc.Vpmg_xf_get
    __setmethods__["yf"] = apbslibc.Vpmg_yf_set
    __getmethods__["yf"] = apbslibc.Vpmg_yf_get
    __setmethods__["zf"] = apbslibc.Vpmg_zf_set
    __getmethods__["zf"] = apbslibc.Vpmg_zf_get
    __setmethods__["gxcf"] = apbslibc.Vpmg_gxcf_set
    __getmethods__["gxcf"] = apbslibc.Vpmg_gxcf_get
    __setmethods__["gycf"] = apbslibc.Vpmg_gycf_set
    __getmethods__["gycf"] = apbslibc.Vpmg_gycf_get
    __setmethods__["gzcf"] = apbslibc.Vpmg_gzcf_set
    __getmethods__["gzcf"] = apbslibc.Vpmg_gzcf_get
    __setmethods__["pvec"] = apbslibc.Vpmg_pvec_set
    __getmethods__["pvec"] = apbslibc.Vpmg_pvec_get
    __setmethods__["extDiEnergy"] = apbslibc.Vpmg_extDiEnergy_set
    __getmethods__["extDiEnergy"] = apbslibc.Vpmg_extDiEnergy_get
    __setmethods__["extQmEnergy"] = apbslibc.Vpmg_extQmEnergy_set
    __getmethods__["extQmEnergy"] = apbslibc.Vpmg_extQmEnergy_get
    __setmethods__["extQfEnergy"] = apbslibc.Vpmg_extQfEnergy_set
    __getmethods__["extQfEnergy"] = apbslibc.Vpmg_extQfEnergy_get
    __setmethods__["surfMeth"] = apbslibc.Vpmg_surfMeth_set
    __getmethods__["surfMeth"] = apbslibc.Vpmg_surfMeth_get
    __setmethods__["splineWin"] = apbslibc.Vpmg_splineWin_set
    __getmethods__["splineWin"] = apbslibc.Vpmg_splineWin_get
    __setmethods__["filled"] = apbslibc.Vpmg_filled_set
    __getmethods__["filled"] = apbslibc.Vpmg_filled_get
    __setmethods__["useDielXMap"] = apbslibc.Vpmg_useDielXMap_set
    __getmethods__["useDielXMap"] = apbslibc.Vpmg_useDielXMap_get
    __setmethods__["dielXMap"] = apbslibc.Vpmg_dielXMap_set
    __getmethods__["dielXMap"] = apbslibc.Vpmg_dielXMap_get
    __setmethods__["useDielYMap"] = apbslibc.Vpmg_useDielYMap_set
    __getmethods__["useDielYMap"] = apbslibc.Vpmg_useDielYMap_get
    __setmethods__["dielYMap"] = apbslibc.Vpmg_dielYMap_set
    __getmethods__["dielYMap"] = apbslibc.Vpmg_dielYMap_get
    __setmethods__["useDielZMap"] = apbslibc.Vpmg_useDielZMap_set
    __getmethods__["useDielZMap"] = apbslibc.Vpmg_useDielZMap_get
    __setmethods__["dielZMap"] = apbslibc.Vpmg_dielZMap_set
    __getmethods__["dielZMap"] = apbslibc.Vpmg_dielZMap_get
    __setmethods__["useKappaMap"] = apbslibc.Vpmg_useKappaMap_set
    __getmethods__["useKappaMap"] = apbslibc.Vpmg_useKappaMap_get
    __setmethods__["kappaMap"] = apbslibc.Vpmg_kappaMap_set
    __getmethods__["kappaMap"] = apbslibc.Vpmg_kappaMap_get
    __setmethods__["useChargeMap"] = apbslibc.Vpmg_useChargeMap_set
    __getmethods__["useChargeMap"] = apbslibc.Vpmg_useChargeMap_get
    __setmethods__["chargeMap"] = apbslibc.Vpmg_chargeMap_set
    __getmethods__["chargeMap"] = apbslibc.Vpmg_chargeMap_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_Vpmg,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_Vpmg(self)
    def __repr__(self):
        return "<C Vpmg instance at %s>" % (self.this,)

class VpmgPtr(Vpmg):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = Vpmg
apbslibc.Vpmg_swigregister(VpmgPtr)
class Vpbe:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,Vpbe):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = Vpbe.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = Vpbe.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["vmem"] = apbslibc.Vpbe_vmem_set
    __getmethods__["vmem"] = apbslibc.Vpbe_vmem_get
    __setmethods__["alist"] = apbslibc.Vpbe_alist_set
    __getmethods__["alist"] = apbslibc.Vpbe_alist_get
    __setmethods__["acc"] = apbslibc.Vpbe_acc_set
    __getmethods__["acc"] = apbslibc.Vpbe_acc_get
    __setmethods__["green"] = apbslibc.Vpbe_green_set
    __getmethods__["green"] = apbslibc.Vpbe_green_get
    __setmethods__["T"] = apbslibc.Vpbe_T_set
    __getmethods__["T"] = apbslibc.Vpbe_T_get
    __setmethods__["soluteDiel"] = apbslibc.Vpbe_soluteDiel_set
    __getmethods__["soluteDiel"] = apbslibc.Vpbe_soluteDiel_get
    __setmethods__["solventDiel"] = apbslibc.Vpbe_solventDiel_set
    __getmethods__["solventDiel"] = apbslibc.Vpbe_solventDiel_get
    __setmethods__["solventRadius"] = apbslibc.Vpbe_solventRadius_set
    __getmethods__["solventRadius"] = apbslibc.Vpbe_solventRadius_get
    __setmethods__["bulkIonicStrength"] = apbslibc.Vpbe_bulkIonicStrength_set
    __getmethods__["bulkIonicStrength"] = apbslibc.Vpbe_bulkIonicStrength_get
    __setmethods__["maxIonRadius"] = apbslibc.Vpbe_maxIonRadius_set
    __getmethods__["maxIonRadius"] = apbslibc.Vpbe_maxIonRadius_get
    __setmethods__["numIon"] = apbslibc.Vpbe_numIon_set
    __getmethods__["numIon"] = apbslibc.Vpbe_numIon_get
    __getmethods__["ionConc"] = apbslibc.Vpbe_ionConc_get
    __getmethods__["ionRadii"] = apbslibc.Vpbe_ionRadii_get
    __getmethods__["ionQ"] = apbslibc.Vpbe_ionQ_get
    __setmethods__["xkappa"] = apbslibc.Vpbe_xkappa_set
    __getmethods__["xkappa"] = apbslibc.Vpbe_xkappa_get
    __setmethods__["deblen"] = apbslibc.Vpbe_deblen_set
    __getmethods__["deblen"] = apbslibc.Vpbe_deblen_get
    __setmethods__["zkappa2"] = apbslibc.Vpbe_zkappa2_set
    __getmethods__["zkappa2"] = apbslibc.Vpbe_zkappa2_get
    __setmethods__["zmagic"] = apbslibc.Vpbe_zmagic_set
    __getmethods__["zmagic"] = apbslibc.Vpbe_zmagic_get
    __getmethods__["soluteCenter"] = apbslibc.Vpbe_soluteCenter_get
    __setmethods__["soluteRadius"] = apbslibc.Vpbe_soluteRadius_set
    __getmethods__["soluteRadius"] = apbslibc.Vpbe_soluteRadius_get
    __setmethods__["soluteXlen"] = apbslibc.Vpbe_soluteXlen_set
    __getmethods__["soluteXlen"] = apbslibc.Vpbe_soluteXlen_get
    __setmethods__["soluteYlen"] = apbslibc.Vpbe_soluteYlen_set
    __getmethods__["soluteYlen"] = apbslibc.Vpbe_soluteYlen_get
    __setmethods__["soluteZlen"] = apbslibc.Vpbe_soluteZlen_set
    __getmethods__["soluteZlen"] = apbslibc.Vpbe_soluteZlen_get
    __setmethods__["soluteCharge"] = apbslibc.Vpbe_soluteCharge_set
    __getmethods__["soluteCharge"] = apbslibc.Vpbe_soluteCharge_get
    __setmethods__["paramFlag"] = apbslibc.Vpbe_paramFlag_set
    __getmethods__["paramFlag"] = apbslibc.Vpbe_paramFlag_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_Vpbe,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_Vpbe(self)
    def __repr__(self):
        return "<C Vpbe instance at %s>" % (self.this,)

class VpbePtr(Vpbe):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = Vpbe
apbslibc.Vpbe_swigregister(VpbePtr)
class Valist:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,Valist):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = Valist.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = Valist.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["number"] = apbslibc.Valist_number_set
    __getmethods__["number"] = apbslibc.Valist_number_get
    __getmethods__["center"] = apbslibc.Valist_center_get
    __getmethods__["mincrd"] = apbslibc.Valist_mincrd_get
    __getmethods__["maxcrd"] = apbslibc.Valist_maxcrd_get
    __setmethods__["maxrad"] = apbslibc.Valist_maxrad_set
    __getmethods__["maxrad"] = apbslibc.Valist_maxrad_get
    __setmethods__["charge"] = apbslibc.Valist_charge_set
    __getmethods__["charge"] = apbslibc.Valist_charge_get
    __setmethods__["atoms"] = apbslibc.Valist_atoms_set
    __getmethods__["atoms"] = apbslibc.Valist_atoms_get
    __setmethods__["vmem"] = apbslibc.Valist_vmem_set
    __getmethods__["vmem"] = apbslibc.Valist_vmem_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_Valist,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_Valist(self)
    def __repr__(self):
        return "<C Valist instance at %s>" % (self.this,)

class ValistPtr(Valist):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = Valist
apbslibc.Valist_swigregister(ValistPtr)
class Vgrid:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,Vgrid):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = Vgrid.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = Vgrid.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["nx"] = apbslibc.Vgrid_nx_set
    __getmethods__["nx"] = apbslibc.Vgrid_nx_get
    __setmethods__["ny"] = apbslibc.Vgrid_ny_set
    __getmethods__["ny"] = apbslibc.Vgrid_ny_get
    __setmethods__["nz"] = apbslibc.Vgrid_nz_set
    __getmethods__["nz"] = apbslibc.Vgrid_nz_get
    __setmethods__["hx"] = apbslibc.Vgrid_hx_set
    __getmethods__["hx"] = apbslibc.Vgrid_hx_get
    __setmethods__["hy"] = apbslibc.Vgrid_hy_set
    __getmethods__["hy"] = apbslibc.Vgrid_hy_get
    __setmethods__["hzed"] = apbslibc.Vgrid_hzed_set
    __getmethods__["hzed"] = apbslibc.Vgrid_hzed_get
    __setmethods__["xmin"] = apbslibc.Vgrid_xmin_set
    __getmethods__["xmin"] = apbslibc.Vgrid_xmin_get
    __setmethods__["ymin"] = apbslibc.Vgrid_ymin_set
    __getmethods__["ymin"] = apbslibc.Vgrid_ymin_get
    __setmethods__["zmin"] = apbslibc.Vgrid_zmin_set
    __getmethods__["zmin"] = apbslibc.Vgrid_zmin_get
    __setmethods__["xmax"] = apbslibc.Vgrid_xmax_set
    __getmethods__["xmax"] = apbslibc.Vgrid_xmax_get
    __setmethods__["ymax"] = apbslibc.Vgrid_ymax_set
    __getmethods__["ymax"] = apbslibc.Vgrid_ymax_get
    __setmethods__["zmax"] = apbslibc.Vgrid_zmax_set
    __getmethods__["zmax"] = apbslibc.Vgrid_zmax_get
    __setmethods__["data"] = apbslibc.Vgrid_data_set
    __getmethods__["data"] = apbslibc.Vgrid_data_get
    __setmethods__["readdata"] = apbslibc.Vgrid_readdata_set
    __getmethods__["readdata"] = apbslibc.Vgrid_readdata_get
    __setmethods__["ctordata"] = apbslibc.Vgrid_ctordata_set
    __getmethods__["ctordata"] = apbslibc.Vgrid_ctordata_get
    __setmethods__["mem"] = apbslibc.Vgrid_mem_set
    __getmethods__["mem"] = apbslibc.Vgrid_mem_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_Vgrid,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_Vgrid(self)
    def __repr__(self):
        return "<C Vgrid instance at %s>" % (self.this,)

class VgridPtr(Vgrid):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = Vgrid
apbslibc.Vgrid_swigregister(VgridPtr)
class Vmem:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,Vmem):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = Vmem.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = Vmem.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["name"] = apbslibc.Vmem_name_set
    __getmethods__["name"] = apbslibc.Vmem_name_get
    __setmethods__["mallocBytes"] = apbslibc.Vmem_mallocBytes_set
    __getmethods__["mallocBytes"] = apbslibc.Vmem_mallocBytes_get
    __setmethods__["freeBytes"] = apbslibc.Vmem_freeBytes_set
    __getmethods__["freeBytes"] = apbslibc.Vmem_freeBytes_get
    __setmethods__["highWater"] = apbslibc.Vmem_highWater_set
    __getmethods__["highWater"] = apbslibc.Vmem_highWater_get
    __setmethods__["mallocAreas"] = apbslibc.Vmem_mallocAreas_set
    __getmethods__["mallocAreas"] = apbslibc.Vmem_mallocAreas_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_Vmem,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_Vmem(self)
    def __repr__(self):
        return "<C Vmem instance at %s>" % (self.this,)

class VmemPtr(Vmem):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = Vmem
apbslibc.Vmem_swigregister(VmemPtr)
class Vcom:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,Vcom):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = Vcom.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = Vcom.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["mpi_rank"] = apbslibc.Vcom_mpi_rank_set
    __getmethods__["mpi_rank"] = apbslibc.Vcom_mpi_rank_get
    __setmethods__["mpi_size"] = apbslibc.Vcom_mpi_size_set
    __getmethods__["mpi_size"] = apbslibc.Vcom_mpi_size_get
    __setmethods__["type"] = apbslibc.Vcom_type_set
    __getmethods__["type"] = apbslibc.Vcom_type_get
    __setmethods__["error"] = apbslibc.Vcom_error_set
    __getmethods__["error"] = apbslibc.Vcom_error_get
    __setmethods__["core"] = apbslibc.Vcom_core_set
    __getmethods__["core"] = apbslibc.Vcom_core_get
    def __init__(self,*args):
        self.this = apply(apbslibc.new_Vcom,args)
        self.thisown = 1
    def __del__(self,apbslibc=apbslibc):
        if getattr(self,'thisown',0):
            apbslibc.delete_Vcom(self)
    def __repr__(self):
        return "<C Vcom instance at %s>" % (self.this,)

class VcomPtr(Vcom):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = Vcom
apbslibc.Vcom_swigregister(VcomPtr)
APBS_SWIG = apbslibc.APBS_SWIG
APBSRC = apbslibc.APBSRC
loadMolecules = apbslibc.loadMolecules

loadDielMaps = apbslibc.loadDielMaps

loadKappaMaps = apbslibc.loadKappaMaps

loadChargeMaps = apbslibc.loadChargeMaps

printPBEPARM = apbslibc.printPBEPARM

printMGPARM = apbslibc.printMGPARM

initMG = apbslibc.initMG

solveMG = apbslibc.solveMG

setPartMG = apbslibc.setPartMG

energyMG = apbslibc.energyMG

forceMG = apbslibc.forceMG

writedataMG = apbslibc.writedataMG

printEnergy = apbslibc.printEnergy

startVio = apbslibc.startVio

NOSH_MAXMOL = apbslibc.NOSH_MAXMOL
NOSH_MAXCALC = apbslibc.NOSH_MAXCALC
NOSH_MAXPRINT = apbslibc.NOSH_MAXPRINT
NOSH_MAXPOP = apbslibc.NOSH_MAXPOP
NOsh_getMolpath = apbslibc.NOsh_getMolpath

NOsh_getDielXpath = apbslibc.NOsh_getDielXpath

NOsh_getDielYpath = apbslibc.NOsh_getDielYpath

NOsh_getDielZpath = apbslibc.NOsh_getDielZpath

NOsh_getKappapath = apbslibc.NOsh_getKappapath

NOsh_getChargepath = apbslibc.NOsh_getChargepath

NOsh_getCalc = apbslibc.NOsh_getCalc

NOsh_getDielfmt = apbslibc.NOsh_getDielfmt

NOsh_getKappafmt = apbslibc.NOsh_getKappafmt

NOsh_getChargefmt = apbslibc.NOsh_getChargefmt

NOsh_printWhat = apbslibc.NOsh_printWhat

NOsh_elec2calc = apbslibc.NOsh_elec2calc

NOsh_printNarg = apbslibc.NOsh_printNarg

NOsh_printOp = apbslibc.NOsh_printOp

NOsh_printCalc = apbslibc.NOsh_printCalc

NOsh_ctor = apbslibc.NOsh_ctor

NOsh_ctor2 = apbslibc.NOsh_ctor2

NOsh_dtor = apbslibc.NOsh_dtor

NOsh_dtor2 = apbslibc.NOsh_dtor2

NOsh_parse = apbslibc.NOsh_parse

NOsh_parseFile = apbslibc.NOsh_parseFile

NOsh_setupMGMANUAL = apbslibc.NOsh_setupMGMANUAL

NOsh_setupMGAUTO = apbslibc.NOsh_setupMGAUTO

NOsh_setupMGPARA = apbslibc.NOsh_setupMGPARA

MGparm_getNx = apbslibc.MGparm_getNx

MGparm_getNy = apbslibc.MGparm_getNy

MGparm_getNz = apbslibc.MGparm_getNz

MGparm_getHx = apbslibc.MGparm_getHx

MGparm_getHy = apbslibc.MGparm_getHy

MGparm_getHz = apbslibc.MGparm_getHz

MGparm_setCenterX = apbslibc.MGparm_setCenterX

MGparm_setCenterY = apbslibc.MGparm_setCenterY

MGparm_setCenterZ = apbslibc.MGparm_setCenterZ

MGparm_getCenterX = apbslibc.MGparm_getCenterX

MGparm_getCenterY = apbslibc.MGparm_getCenterY

MGparm_getCenterZ = apbslibc.MGparm_getCenterZ

MGparm_getPartOlapCenterShiftX = apbslibc.MGparm_getPartOlapCenterShiftX

MGparm_getPartOlapCenterShiftY = apbslibc.MGparm_getPartOlapCenterShiftY

MGparm_getPartOlapCenterShiftZ = apbslibc.MGparm_getPartOlapCenterShiftZ

MGparm_ctor = apbslibc.MGparm_ctor

MGparm_ctor2 = apbslibc.MGparm_ctor2

MGparm_dtor = apbslibc.MGparm_dtor

MGparm_dtor2 = apbslibc.MGparm_dtor2

MGparm_check = apbslibc.MGparm_check

MGparm_copy = apbslibc.MGparm_copy

MGparm_parseToken = apbslibc.MGparm_parseToken

PBEPARM_MAXWRITE = apbslibc.PBEPARM_MAXWRITE
PBEparm_getIonCharge = apbslibc.PBEparm_getIonCharge

PBEparm_getIonConc = apbslibc.PBEparm_getIonConc

PBEparm_getIonRadius = apbslibc.PBEparm_getIonRadius

PBEparm_ctor = apbslibc.PBEparm_ctor

PBEparm_ctor2 = apbslibc.PBEparm_ctor2

PBEparm_dtor = apbslibc.PBEparm_dtor

PBEparm_dtor2 = apbslibc.PBEparm_dtor2

PBEparm_check = apbslibc.PBEparm_check

PBEparm_copy = apbslibc.PBEparm_copy

PBEparm_parseToken = apbslibc.PBEparm_parseToken

Vpmgp_ctor = apbslibc.Vpmgp_ctor

Vpmgp_ctor2 = apbslibc.Vpmgp_ctor2

Vpmgp_dtor = apbslibc.Vpmgp_dtor

Vpmgp_dtor2 = apbslibc.Vpmgp_dtor2

VPMGMAXPART = apbslibc.VPMGMAXPART
Vpmg_memChk = apbslibc.Vpmg_memChk

Vpmg_ctor = apbslibc.Vpmg_ctor

Vpmg_ctor2 = apbslibc.Vpmg_ctor2

Vpmg_ctorFocus = apbslibc.Vpmg_ctorFocus

Vpmg_ctor2Focus = apbslibc.Vpmg_ctor2Focus

Vpmg_dtor = apbslibc.Vpmg_dtor

Vpmg_dtor2 = apbslibc.Vpmg_dtor2

Vpmg_fillco = apbslibc.Vpmg_fillco

Vpmg_solve = apbslibc.Vpmg_solve

Vpmg_energy = apbslibc.Vpmg_energy

Vpmg_qfEnergy = apbslibc.Vpmg_qfEnergy

Vpmg_qfAtomEnergy = apbslibc.Vpmg_qfAtomEnergy

Vpmg_qmEnergy = apbslibc.Vpmg_qmEnergy

Vpmg_dielEnergy = apbslibc.Vpmg_dielEnergy

Vpmg_force = apbslibc.Vpmg_force

Vpmg_qfForce = apbslibc.Vpmg_qfForce

Vpmg_dbnpForce = apbslibc.Vpmg_dbnpForce

Vpmg_ibForce = apbslibc.Vpmg_ibForce

Vpmg_setPart = apbslibc.Vpmg_setPart

Vpmg_unsetPart = apbslibc.Vpmg_unsetPart

Vpmg_fillArray = apbslibc.Vpmg_fillArray

Vpmg_printColComp = apbslibc.Vpmg_printColComp

Vpbe_getValist = apbslibc.Vpbe_getValist

Vpbe_getVacc = apbslibc.Vpbe_getVacc

Vpbe_getVgreen = apbslibc.Vpbe_getVgreen

Vpbe_getBulkIonicStrength = apbslibc.Vpbe_getBulkIonicStrength

Vpbe_getMaxIonRadius = apbslibc.Vpbe_getMaxIonRadius

Vpbe_getTemperature = apbslibc.Vpbe_getTemperature

Vpbe_getSoluteDiel = apbslibc.Vpbe_getSoluteDiel

Vpbe_getSoluteRadius = apbslibc.Vpbe_getSoluteRadius

Vpbe_getSoluteXlen = apbslibc.Vpbe_getSoluteXlen

Vpbe_getSoluteYlen = apbslibc.Vpbe_getSoluteYlen

Vpbe_getSoluteZlen = apbslibc.Vpbe_getSoluteZlen

Vpbe_getSoluteCenter = apbslibc.Vpbe_getSoluteCenter

Vpbe_getSoluteCharge = apbslibc.Vpbe_getSoluteCharge

Vpbe_getSolventDiel = apbslibc.Vpbe_getSolventDiel

Vpbe_getSolventRadius = apbslibc.Vpbe_getSolventRadius

Vpbe_getXkappa = apbslibc.Vpbe_getXkappa

Vpbe_getDeblen = apbslibc.Vpbe_getDeblen

Vpbe_getZkappa2 = apbslibc.Vpbe_getZkappa2

Vpbe_getZmagic = apbslibc.Vpbe_getZmagic

Vpbe_ctor = apbslibc.Vpbe_ctor

Vpbe_ctor2 = apbslibc.Vpbe_ctor2

Vpbe_getIons = apbslibc.Vpbe_getIons

Vpbe_dtor = apbslibc.Vpbe_dtor

Vpbe_dtor2 = apbslibc.Vpbe_dtor2

Vpbe_getCoulombEnergy1 = apbslibc.Vpbe_getCoulombEnergy1

Vpbe_memChk = apbslibc.Vpbe_memChk

Valist_getAtomList = apbslibc.Valist_getAtomList

Valist_getCenterX = apbslibc.Valist_getCenterX

Valist_getCenterY = apbslibc.Valist_getCenterY

Valist_getCenterZ = apbslibc.Valist_getCenterZ

Valist_getNumberAtoms = apbslibc.Valist_getNumberAtoms

Valist_getAtom = apbslibc.Valist_getAtom

Valist_memChk = apbslibc.Valist_memChk

Valist_ctor = apbslibc.Valist_ctor

Valist_ctor2 = apbslibc.Valist_ctor2

Valist_dtor = apbslibc.Valist_dtor

Valist_dtor2 = apbslibc.Valist_dtor2

Valist_readPQR = apbslibc.Valist_readPQR

Valist_buildMesh = apbslibc.Valist_buildMesh

Vgrid_memChk = apbslibc.Vgrid_memChk

Vgrid_ctor = apbslibc.Vgrid_ctor

Vgrid_ctor2 = apbslibc.Vgrid_ctor2

Vgrid_value = apbslibc.Vgrid_value

Vgrid_dtor = apbslibc.Vgrid_dtor

Vgrid_dtor2 = apbslibc.Vgrid_dtor2

Vgrid_curvature = apbslibc.Vgrid_curvature

Vgrid_gradient = apbslibc.Vgrid_gradient

Vgrid_writeUHBD = apbslibc.Vgrid_writeUHBD

Vgrid_writeDX = apbslibc.Vgrid_writeDX

Vgrid_readDX = apbslibc.Vgrid_readDX

Vunit_J_to_cal = apbslibc.Vunit_J_to_cal
Vunit_cal_to_J = apbslibc.Vunit_cal_to_J
Vunit_amu_to_kg = apbslibc.Vunit_amu_to_kg
Vunit_kg_to_amu = apbslibc.Vunit_kg_to_amu
Vunit_ec_to_C = apbslibc.Vunit_ec_to_C
Vunit_C_to_ec = apbslibc.Vunit_C_to_ec
Vunit_ec = apbslibc.Vunit_ec
Vunit_kb = apbslibc.Vunit_kb
Vunit_Na = apbslibc.Vunit_Na
Vunit_eps0 = apbslibc.Vunit_eps0
Vunit_esu_ec2A = apbslibc.Vunit_esu_ec2A
Vunit_esu_kb = apbslibc.Vunit_esu_kb
Vmem_bytesTotal = apbslibc.Vmem_bytesTotal

Vmem_mallocBytesTotal = apbslibc.Vmem_mallocBytesTotal

Vmem_freeBytesTotal = apbslibc.Vmem_freeBytesTotal

Vmem_highWaterTotal = apbslibc.Vmem_highWaterTotal

Vmem_mallocAreasTotal = apbslibc.Vmem_mallocAreasTotal

Vmem_printTotal = apbslibc.Vmem_printTotal

Vmem_ctor = apbslibc.Vmem_ctor

Vmem_dtor = apbslibc.Vmem_dtor

Vmem_malloc = apbslibc.Vmem_malloc

Vmem_free = apbslibc.Vmem_free

Vmem_realloc = apbslibc.Vmem_realloc

Vmem_bytes = apbslibc.Vmem_bytes

Vmem_mallocBytes = apbslibc.Vmem_mallocBytes

Vmem_freeBytes = apbslibc.Vmem_freeBytes

Vmem_highWater = apbslibc.Vmem_highWater

Vmem_mallocAreas = apbslibc.Vmem_mallocAreas

Vmem_print = apbslibc.Vmem_print

VCOM_MPI_TAG = apbslibc.VCOM_MPI_TAG
Vcom_init = apbslibc.Vcom_init

Vcom_finalize = apbslibc.Vcom_finalize

Vcom_ctor = apbslibc.Vcom_ctor

Vcom_ctor2 = apbslibc.Vcom_ctor2

Vcom_dtor = apbslibc.Vcom_dtor

Vcom_dtor2 = apbslibc.Vcom_dtor2

Vcom_send = apbslibc.Vcom_send

Vcom_recv = apbslibc.Vcom_recv

Vcom_getCount = apbslibc.Vcom_getCount

Vcom_reduce = apbslibc.Vcom_reduce

Vcom_size = apbslibc.Vcom_size

Vcom_resize = apbslibc.Vcom_resize

Vcom_rank = apbslibc.Vcom_rank

Vcom_barr = apbslibc.Vcom_barr


