/**
 *  @file    read.c
 *  @author  Nathan Baker
 *  @brief   Sample program that illustrates OpenDX data I/O
 *  @version $Id: read.c,v 1.13 2002/05/23 19:53:34 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * Copyright (c) 1999-2002.  The Regents of the University of California.
 * Portions Copyright (c) 1995.  Michael Holst.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE
 * AUTHORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED
 * HEREUNDER IS PROVIDED "AS IS".  THE AUTHORS HAVE NO OBLIGATION TO PROVIDE
 * MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * @endverbatim
 */

#include "apbscfg.h"
#include "apbs/apbs.h"  

#define NMAX 5
#define IJK(i,j,k)  (((k)*(nx)*(ny))+((j)*(nx))+(i))

VEMBED(rcsid="$Id: read.c,v 1.13 2002/05/23 19:53:34 apbs Exp $")

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    int nx, ny, nz, i, j, k;
    double hy, hx, hzed, xmin, ymin, zmin, pt[3], value, sum;
    char *inpath = VNULL;
    char *usage = "\n  read file.dx\n"; 
    Vgrid *grid;
 
    /* *************** CHECK INVOCATION ******************* */
    Vio_start();
    if (argc != 2) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected 2.\n\n",argc);
        Vnm_print(2,"%s\n", usage);
        return -1;
    } else {
        inpath = argv[1];
    }

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(1, "main:  Reading data from %s...\n", inpath);
    Vnm_tstart(26, "DATA READ");
    grid = Vgrid_ctor(0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, VNULL);
    Vgrid_readDX(grid, "FILE", "ASC", VNULL, inpath);
    Vnm_tstop(26, "DATA READ");
    nx = grid->nx; 
    ny = grid->ny; 
    nz = grid->nz; 
    hx = grid->hx;
    hy = grid->hy;
    hzed = grid->hzed;
    xmin = grid->xmin, 
    ymin = grid->ymin,
    zmin = grid->zmin;
    Vnm_print(1, "main:     nx = %d, ny = %d, nz = %d\n", 
      nx, ny, nz);
    Vnm_print(1, "main:     hx = %g, hy = %g, hz = %g\n", 
      hx, hy, hzed);
    Vnm_print(1, "main:     xmin = %g, ymin = %g, zmin = %g\n", 
      xmin, ymin, zmin);

    /* Integrate */
    Vnm_print(1, "main:  Integrating...\n");
    sum = 0;
    Vnm_tstart(26, "INTEGRATE");
    for (i=0; i<nx; i++) {
        for (j=0; j<ny; j++) {
            for (k=0; k<nz; k++) {
                pt[0] = xmin + i*hx;
                pt[1] = ymin + j*hy;
                pt[2] = zmin + k*hzed;
                if (Vgrid_value(grid, pt, &value)) sum = sum + value;
            } 
        }
    }
    Vnm_tstop(26, "INTEGRATE");

    Vnm_print(1, "main:  Integral over grid = %1.12E\n", sum*hx*hy*hzed);

    return 0;
}
