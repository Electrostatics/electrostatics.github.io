var structs_vcsm =
[
    [ "alist", "structs_vcsm.html#ae0b1ff92bae2d15bb71adebfe53bbc17", null ],
    [ "gm", "structs_vcsm.html#a47e3990f869cc9afbc7c5ef756dd6236", null ],
    [ "initFlag", "structs_vcsm.html#a1fa18df106a71df86f7ce9780b65e88b", null ],
    [ "msimp", "structs_vcsm.html#a8ba04ef2735b51fa03bd1958c130609e", null ],
    [ "natom", "structs_vcsm.html#a681d92e8045df3ba705e04a70af0e9d5", null ],
    [ "nqsm", "structs_vcsm.html#a5f074ea44eaf3cbab23592e00e8254c2", null ],
    [ "nsimp", "structs_vcsm.html#a4c0bcf292fae096806030ce251a5de2c", null ],
    [ "nsqm", "structs_vcsm.html#ab7162641d0ac2f5dccb2b09c9b08389f", null ],
    [ "qsm", "structs_vcsm.html#acdc0286469f2269e057d386c0c756595", null ],
    [ "sqm", "structs_vcsm.html#a158de1853ad80a4df58be371723eca77", null ],
    [ "vmem", "structs_vcsm.html#adfacdf16f7a3cf04b35f4821208b5bdd", null ]
];