var searchData=
[
  ['sinh_5fmax',['SINH_MAX',['../group___vhal.html#ga2400b9d421a5356e700fc35a5e60c8aa',1,'vhal.h']]],
  ['sinh_5fmin',['SINH_MIN',['../group___vhal.html#ga2bf4abc739a18443a047ccab0d4ee8df',1,'vhal.h']]]
];
