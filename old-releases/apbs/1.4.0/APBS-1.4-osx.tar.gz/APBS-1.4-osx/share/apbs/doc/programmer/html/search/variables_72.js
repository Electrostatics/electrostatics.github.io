var searchData=
[
  ['radius',['radius',['../structs_vatom.html#a3f67c53b80389c5f53961936edba04c9',1,'sVatom::radius()'],['../structs_vparam___atom_data.html#a3f67c53b80389c5f53961936edba04c9',1,'sVparam_AtomData::radius()']]],
  ['readdata',['readdata',['../structs_vgrid.html#abf20537e721ce04919fff8b3cf6f780b',1,'sVgrid']]],
  ['refsphere',['refSphere',['../structs_vacc.html#aeeef392d16dcd45b5781780ab5afd6d2',1,'sVacc']]],
  ['resdata',['resData',['../struct_vparam.html#a5ee9c6fcb7a45d6f227051a1f99f9ec1',1,'Vparam']]],
  ['resname',['resName',['../structs_vatom.html#a03835e9d9625128793923b9efeb9f5b8',1,'sVatom::resName()'],['../structs_vparam___atom_data.html#a2d2cbf6fa6927c7cd4fde3f2ec13690c',1,'sVparam_AtomData::resName()']]],
  ['rparm',['rparm',['../structs_vpmg.html#a00cb02d8b9719e9574fc04283450b6be',1,'sVpmg']]],
  ['rwork',['rwork',['../structs_vpmg.html#a1ac4dfbbeb3bd0680998c80dee6e8e6a',1,'sVpmg']]]
];
