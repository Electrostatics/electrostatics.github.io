var searchData=
[
  ['max_5fsphere_5fpts',['MAX_SPHERE_PTS',['../group___vhal.html#ga656dd8651f6ddb231c1e0dfdd738eea8',1,'vhal.h']]],
  ['maxfocus',['MAXFOCUS',['../group___vhal.html#ga27770574efd5ffaefb79a54fcc293df3',1,'vhal.h']]],
  ['maxion',['MAXION',['../group___vhal.html#ga8ec2427efb460890f443d47e210d9b60',1,'vhal.h']]],
  ['maxmol',['MAXMOL',['../group___vhal.html#ga420edf92998eb68c51972c65726ecca8',1,'vhal.h']]]
];
