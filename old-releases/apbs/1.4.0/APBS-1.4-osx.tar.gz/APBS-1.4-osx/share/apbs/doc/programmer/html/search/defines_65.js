var searchData=
[
  ['expmax',['EXPMAX',['../group___vcap.html#ga23d246eba89dbfca722195812576a8a4',1,'vcap.h']]],
  ['expmin',['EXPMIN',['../group___vcap.html#gacb93f1a1f5c89b3aa0d99937f0e6a1ef',1,'vcap.h']]]
];
