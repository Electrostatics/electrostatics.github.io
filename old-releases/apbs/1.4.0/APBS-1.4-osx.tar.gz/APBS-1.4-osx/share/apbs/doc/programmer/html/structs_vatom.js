var structs_vatom =
[
    [ "atomName", "structs_vatom.html#af31038b76589235002ed25764e73e4f8", null ],
    [ "charge", "structs_vatom.html#ab3eb30b2f3f9c5ff812ea037220be570", null ],
    [ "epsilon", "structs_vatom.html#a4904cc82627458fdf6672ccc0b2802c7", null ],
    [ "id", "structs_vatom.html#a7441ef0865bcb3db9b8064dd7375c1ea", null ],
    [ "partID", "structs_vatom.html#ad764ef856af40b026335ce3d1caefcde", null ],
    [ "position", "structs_vatom.html#ab2bf41ca00e31fce6d10a4494db3d515", null ],
    [ "radius", "structs_vatom.html#a3f67c53b80389c5f53961936edba04c9", null ],
    [ "resName", "structs_vatom.html#a03835e9d9625128793923b9efeb9f5b8", null ]
];