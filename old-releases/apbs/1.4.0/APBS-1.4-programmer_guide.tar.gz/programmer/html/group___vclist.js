var group___vclist =
[
    [ "vclist.c", "vclist_8c.html", null ],
    [ "vclist.h", "vclist_8h.html", null ],
    [ "sVclistCell", "structs_vclist_cell.html", null ],
    [ "sVclist", "structs_vclist.html", null ],
    [ "Vclist", "group___vclist.html#ga6125c1da9805ceda9e099195bd8a8992", null ],
    [ "Vclist_DomainMode", "group___vclist.html#gacc3f2f310718db10fc2592dd85495ef5", null ],
    [ "VclistCell", "group___vclist.html#gaa8222220f7c6fce1c1f6f2212a81b7f9", null ],
    [ "eVclist_DomainMode", "group___vclist.html#ga4efd3ee8fc4f3862c08a8ccd268dfd78", [
      [ "CLIST_AUTO_DOMAIN", "group___vclist.html#gga4efd3ee8fc4f3862c08a8ccd268dfd78a1115764c7ab2cb3ec7c0d11715b1df7c", null ],
      [ "CLIST_MANUAL_DOMAIN", "group___vclist.html#gga4efd3ee8fc4f3862c08a8ccd268dfd78a7d10f403f2733d4b215befcba67d2ea1", null ]
    ] ],
    [ "Vclist_ctor", "group___vclist.html#gabc96bd5ecfd7b4ddc60544277d5cc7ff", null ],
    [ "Vclist_ctor2", "group___vclist.html#gac37963a24bb0596458f3eeb07b18100a", null ],
    [ "Vclist_dtor", "group___vclist.html#ga3ad2d96a3c99cf862fbb7231b5db1689", null ],
    [ "Vclist_dtor2", "group___vclist.html#ga9410f92c8452a5ae9defd34f401435cf", null ],
    [ "Vclist_getCell", "group___vclist.html#gaee63e2dac121f3469b10f9f16b999402", null ],
    [ "Vclist_maxRadius", "group___vclist.html#gac90480afcf0e082a4b7bf755cb15d360", null ],
    [ "Vclist_memChk", "group___vclist.html#ga61a7f1b80bad426003e449acf97d6d91", null ],
    [ "VclistCell_ctor", "group___vclist.html#ga88d7fd69e274fd575954dcdb1c32d359", null ],
    [ "VclistCell_ctor2", "group___vclist.html#gab33378d8ba4632ba808a175c213253b2", null ],
    [ "VclistCell_dtor", "group___vclist.html#gab3ea675a2c7371c019b9b5a5969fb4af", null ],
    [ "VclistCell_dtor2", "group___vclist.html#gaf4907b9a0a563c4f03178ddc8b52b63c", null ]
];