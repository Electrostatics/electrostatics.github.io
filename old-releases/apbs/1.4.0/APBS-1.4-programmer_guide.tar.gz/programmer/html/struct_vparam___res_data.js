var struct_vparam___res_data =
[
    [ "atomData", "struct_vparam___res_data.html#a9088de54027cd911c62589b79a242663", null ],
    [ "name", "struct_vparam___res_data.html#a3db934774a9129b27f3e9a3289a00434", null ],
    [ "nAtomData", "struct_vparam___res_data.html#acd0cff87c02788f9bd6403b0133cf055", null ],
    [ "vmem", "struct_vparam___res_data.html#adfacdf16f7a3cf04b35f4821208b5bdd", null ]
];