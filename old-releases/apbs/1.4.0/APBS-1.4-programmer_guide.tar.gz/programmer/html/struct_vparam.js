var struct_vparam =
[
    [ "nResData", "struct_vparam.html#a647fcef3ec12dfd1ac5d40b891bbb943", null ],
    [ "resData", "struct_vparam.html#a5ee9c6fcb7a45d6f227051a1f99f9ec1", null ],
    [ "vmem", "struct_vparam.html#adfacdf16f7a3cf04b35f4821208b5bdd", null ]
];