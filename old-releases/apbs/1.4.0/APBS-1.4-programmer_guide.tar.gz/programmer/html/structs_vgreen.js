var structs_vgreen =
[
    [ "alist", "structs_vgreen.html#ae0b1ff92bae2d15bb71adebfe53bbc17", null ],
    [ "np", "structs_vgreen.html#a928495140935d9d6ce0a100550473140", null ],
    [ "qp", "structs_vgreen.html#add50c13c4c9008f180f7061d9c7b40bf", null ],
    [ "vmem", "structs_vgreen.html#adfacdf16f7a3cf04b35f4821208b5bdd", null ],
    [ "xp", "structs_vgreen.html#a7df365c58843453a02cae2d62640973b", null ],
    [ "yp", "structs_vgreen.html#aac4115a8887b9279e971e048bfb884cf", null ],
    [ "zp", "structs_vgreen.html#a5f79e231892a1b0f3661b3b8061cda82", null ]
];