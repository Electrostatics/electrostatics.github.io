var searchData=
[
  ['gem_5fsetexternalupdatefunction',['Gem_setExternalUpdateFunction',['../group___vcsm.html#ga7b9f8299d766954417fbe7b1e32a0cd7',1,'vcsm.h']]]
];
