var searchData=
[
  ['mgparm',['MGparm',['../group___m_gparm.html#ga0a4ec1528c052492a68ef95099bd6028',1,'mgparm.h']]],
  ['mgparm_5fcalctype',['MGparm_CalcType',['../group___m_gparm.html#gacf31be9905f8e0ba1e083e1119b7cd1d',1,'mgparm.h']]],
  ['mgparm_5fcentmeth',['MGparm_CentMeth',['../group___m_gparm.html#ga24ff41cba9df99f0ee193a886d05a002',1,'mgparm.h']]]
];
