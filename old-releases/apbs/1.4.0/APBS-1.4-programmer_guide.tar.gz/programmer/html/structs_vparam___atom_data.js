var structs_vparam___atom_data =
[
    [ "atomName", "structs_vparam___atom_data.html#a8e245a95061ec62160976515159eca7c", null ],
    [ "charge", "structs_vparam___atom_data.html#ab3eb30b2f3f9c5ff812ea037220be570", null ],
    [ "epsilon", "structs_vparam___atom_data.html#a4904cc82627458fdf6672ccc0b2802c7", null ],
    [ "radius", "structs_vparam___atom_data.html#a3f67c53b80389c5f53961936edba04c9", null ],
    [ "resName", "structs_vparam___atom_data.html#a2d2cbf6fa6927c7cd4fde3f2ec13690c", null ]
];