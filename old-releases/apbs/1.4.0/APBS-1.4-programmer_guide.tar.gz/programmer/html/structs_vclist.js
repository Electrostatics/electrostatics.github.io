var structs_vclist =
[
    [ "alist", "structs_vclist.html#ae0b1ff92bae2d15bb71adebfe53bbc17", null ],
    [ "cells", "structs_vclist.html#a867ae0e884453af8e79e4ffaa98a3e1e", null ],
    [ "lower_corner", "structs_vclist.html#a43ced979d13ca462687b29a34a23a6ee", null ],
    [ "max_radius", "structs_vclist.html#aff073dced0564ca6105e9a66f22d77cf", null ],
    [ "mode", "structs_vclist.html#af3596e9b0893d6bcc6d4bbc8bd068d64", null ],
    [ "n", "structs_vclist.html#a76f11d9a0a47b94f72c2d0e77fb32240", null ],
    [ "npts", "structs_vclist.html#a1e0fdf90cb0743aa79d0c480bb6e7444", null ],
    [ "spacs", "structs_vclist.html#aa9d3ccbc79abcd090530368e56dd6c1c", null ],
    [ "upper_corner", "structs_vclist.html#a25cde36b526ca3f79228e79af1abfc47", null ],
    [ "vmem", "structs_vclist.html#adfacdf16f7a3cf04b35f4821208b5bdd", null ]
];