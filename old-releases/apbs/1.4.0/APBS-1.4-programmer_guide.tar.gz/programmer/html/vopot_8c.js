var vopot_8c =
[
    [ "IJK", "vopot_8c.html#a532fc40699d02ed869784335047b15d9", null ],
    [ "Vopot_ctor", "vopot_8c.html#ga862aab44348b5b3527a81899cd436676", null ],
    [ "Vopot_ctor2", "vopot_8c.html#ga76c87497536572225a18c060f4379dc2", null ],
    [ "Vopot_curvature", "vopot_8c.html#gaf6a3279fcbed2618e526fc075196a41a", null ],
    [ "Vopot_dtor", "vopot_8c.html#ga7a32a04e77f23eb310ce23ce9b4ecf6b", null ],
    [ "Vopot_dtor2", "vopot_8c.html#ga24bea2338d4004ac24e8dd1a30a68d42", null ],
    [ "Vopot_gradient", "vopot_8c.html#ga5fd9d88ed744980aff8ea40eb1b10077", null ],
    [ "Vopot_pot", "vopot_8c.html#gaec11bf9879fe1d94313b5a6c9dda57e6", null ]
];