var structs_vacc_surf =
[
    [ "area", "structs_vacc_surf.html#ae517bffd82b9428b4f1d9500ea01c04f", null ],
    [ "bpts", "structs_vacc_surf.html#ae9cda9090b538a29358b87cb56e5c779", null ],
    [ "mem", "structs_vacc_surf.html#a1fd4c83b7f1c23dd45932b41a8fc97ab", null ],
    [ "npts", "structs_vacc_surf.html#a0306378cd06415f84b10cb3d15516ec3", null ],
    [ "probe_radius", "structs_vacc_surf.html#a8c6c90a23abc7b51c35243216f21940c", null ],
    [ "xpts", "structs_vacc_surf.html#adc11c159667b978601b182a72c2f3776", null ],
    [ "ypts", "structs_vacc_surf.html#a3bfb2571d11ee4b7a1f913f83d1af800", null ],
    [ "zpts", "structs_vacc_surf.html#a2596a33a35721e9b3f989c98a8c12589", null ]
];