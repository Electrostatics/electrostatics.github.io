var group___vparam =
[
    [ "vparam.c", "vparam_8c.html", null ],
    [ "vparam.h", "vparam_8h.html", null ],
    [ "sVparam_AtomData", "structs_vparam___atom_data.html", [
      [ "atomName", "structs_vparam___atom_data.html#a8e245a95061ec62160976515159eca7c", null ],
      [ "charge", "structs_vparam___atom_data.html#ab3eb30b2f3f9c5ff812ea037220be570", null ],
      [ "epsilon", "structs_vparam___atom_data.html#a4904cc82627458fdf6672ccc0b2802c7", null ],
      [ "radius", "structs_vparam___atom_data.html#a3f67c53b80389c5f53961936edba04c9", null ],
      [ "resName", "structs_vparam___atom_data.html#a2d2cbf6fa6927c7cd4fde3f2ec13690c", null ]
    ] ],
    [ "Vparam_ResData", "struct_vparam___res_data.html", [
      [ "atomData", "struct_vparam___res_data.html#a9088de54027cd911c62589b79a242663", null ],
      [ "name", "struct_vparam___res_data.html#a3db934774a9129b27f3e9a3289a00434", null ],
      [ "nAtomData", "struct_vparam___res_data.html#acd0cff87c02788f9bd6403b0133cf055", null ],
      [ "vmem", "struct_vparam___res_data.html#adfacdf16f7a3cf04b35f4821208b5bdd", null ]
    ] ],
    [ "Vparam", "struct_vparam.html", [
      [ "nResData", "struct_vparam.html#a647fcef3ec12dfd1ac5d40b891bbb943", null ],
      [ "resData", "struct_vparam.html#a5ee9c6fcb7a45d6f227051a1f99f9ec1", null ],
      [ "vmem", "struct_vparam.html#adfacdf16f7a3cf04b35f4821208b5bdd", null ]
    ] ],
    [ "Vparam", "group___vparam.html#gab4ffa924728b25ec92009438902019e6", null ],
    [ "Vparam_AtomData", "group___vparam.html#gac32a9b1e13afb7c00c80467a89dec754", null ],
    [ "Vparam_ResData", "group___vparam.html#gaad5a862514ab542d8a074bc56731f65e", null ],
    [ "readFlatFileLine", "group___vparam.html#gaa7d2b71a92ebdbe0b847aec3de8669b4", null ],
    [ "readXMLFileAtom", "group___vparam.html#ga8b35934af27637a90fb419cdfe6f8fb5", null ],
    [ "Vparam_AtomData_copyFrom", "group___vparam.html#ga54215291e2b3a75f029e300b4f098b52", null ],
    [ "Vparam_AtomData_copyTo", "group___vparam.html#ga434ae4b213d8d0de3c8dde8f1c63088a", null ],
    [ "Vparam_AtomData_ctor", "group___vparam.html#gadbd8200a44b75d3203ec9099381e6618", null ],
    [ "Vparam_AtomData_ctor2", "group___vparam.html#ga31ad3e978b10eadecffc85451f382b0b", null ],
    [ "Vparam_AtomData_dtor", "group___vparam.html#ga51052b2783170900bf1da80aa4ffa628", null ],
    [ "Vparam_AtomData_dtor2", "group___vparam.html#gabb9ac22e1136349132d7a1a5dd0ef819", null ],
    [ "Vparam_ctor", "group___vparam.html#gae31cd98e2f963a6e1f2e7cfcb80e0b35", null ],
    [ "Vparam_ctor2", "group___vparam.html#gaeb6d3017608c627d279ceda54b51b628", null ],
    [ "Vparam_dtor", "group___vparam.html#gab527b451690bafa8ddae4673194b82a7", null ],
    [ "Vparam_dtor2", "group___vparam.html#ga4790ef16fada6d6170675b73efea72eb", null ],
    [ "Vparam_getAtomData", "group___vparam.html#ga5eb507195510839d9073b535abf4b044", null ],
    [ "Vparam_getResData", "group___vparam.html#gaf373b2f58919aac717afc7fd158d6336", null ],
    [ "Vparam_memChk", "group___vparam.html#ga6b7c75e34d7aabcf7c35a4afdf9a4c77", null ],
    [ "Vparam_readFlatFile", "group___vparam.html#ga61d8ecdb1e58e573392dcc90d3e43bc7", null ],
    [ "Vparam_readXMLFile", "group___vparam.html#gaf9d820136a649147ff362ef78d40b16f", null ],
    [ "Vparam_ResData_copyTo", "group___vparam.html#gaed5da927b1be4ac04c6a740327239217", null ],
    [ "Vparam_ResData_ctor", "group___vparam.html#ga84353e17fc76e44d642948b8a53c1612", null ],
    [ "Vparam_ResData_ctor2", "group___vparam.html#ga6b28c70f61616d5454c926f6ced8514f", null ],
    [ "Vparam_ResData_dtor", "group___vparam.html#ga183931b020c4fc60884439ae5012e010", null ],
    [ "Vparam_ResData_dtor2", "group___vparam.html#ga206cf552ad533634a56d277f92ae9336", null ],
    [ "MCcommChars", "group___vparam.html#ga1cb5f5df5c3c81122065a2bf63c16d0b", null ],
    [ "MCwhiteChars", "group___vparam.html#gae7202540c5141258cbde4e0075f15d64", null ],
    [ "MCxmlwhiteChars", "group___vparam.html#ga866eb2577936568296cca8584baf5da7", null ]
];