var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "fem", "dir_325c623946aaadef5114ca9e069898d6.html", "dir_325c623946aaadef5114ca9e069898d6" ],
    [ "generic", "dir_4075b182e53a3873a42d885f4e1e98c4.html", "dir_4075b182e53a3873a42d885f4e1e98c4" ],
    [ "mg", "dir_1d197ef0d9947f4cc1ac44e7f59e2b57.html", "dir_1d197ef0d9947f4cc1ac44e7f59e2b57" ],
    [ "pmgc", "dir_e7eac49c1a1228b34aea87d37b387ddc.html", "dir_e7eac49c1a1228b34aea87d37b387ddc" ],
    [ "apbs.h", "apbs_8h.html", null ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "routines.c", "routines_8c.html", "routines_8c" ],
    [ "routines.h", "routines_8h.html", "routines_8h" ]
];