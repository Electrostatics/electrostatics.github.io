var searchData=
[
  ['c_20translation_20of_20holst_20group_20pmg_20code',['C translation of Holst group PMG code',['../group___p_m_g_c.html',1,'']]]
];
