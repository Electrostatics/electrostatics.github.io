var group___f_e_mparm =
[
    [ "femparm.c", "femparm_8c.html", null ],
    [ "femparm.h", "femparm_8h.html", null ],
    [ "sFEMparm", "structs_f_e_mparm.html", [
      [ "akeyPRE", "structs_f_e_mparm.html#a6c956a067c62ab09a966a25d4ea7f802", null ],
      [ "akeySOLVE", "structs_f_e_mparm.html#a19d3b7c3046b6aaf141ba04cd15b4ff5", null ],
      [ "ekey", "structs_f_e_mparm.html#a75e7638fc1984fabc3d18af5de746a4e", null ],
      [ "etol", "structs_f_e_mparm.html#a7b76a8eaa9fe5508943674440942ca1e", null ],
      [ "glen", "structs_f_e_mparm.html#a21e3a7ca2cf5d13fec660614a9c9d653", null ],
      [ "maxsolve", "structs_f_e_mparm.html#a403d924c69e54a03b1b17c24ef1ae02a", null ],
      [ "maxvert", "structs_f_e_mparm.html#ab69167089477735cde3d0902de436eee", null ],
      [ "meshID", "structs_f_e_mparm.html#a3552b302dec169446141ae02c7a2dc12", null ],
      [ "parsed", "structs_f_e_mparm.html#a2eda17f70de002520ab4f15af1c3b415", null ],
      [ "pkey", "structs_f_e_mparm.html#aa9cae6d6d3c515e9c73a62df2450ef40", null ],
      [ "setakeyPRE", "structs_f_e_mparm.html#a19064a9bffa8b82a4eee24554f842ec2", null ],
      [ "setakeySOLVE", "structs_f_e_mparm.html#aa3f116f9e8e221839ab02025d0188f6d", null ],
      [ "setekey", "structs_f_e_mparm.html#a87791856948042de354c3be1eb7588a4", null ],
      [ "setetol", "structs_f_e_mparm.html#af3ec392372b34ca177f15c5b28448a29", null ],
      [ "setglen", "structs_f_e_mparm.html#adc7cb6d7ab6a8451f4aa975a29414655", null ],
      [ "setmaxsolve", "structs_f_e_mparm.html#a33cd63eb50378e8b8e8d2598a390c29a", null ],
      [ "setmaxvert", "structs_f_e_mparm.html#a08a5f7b6423fc9a41d99cf66e38f1687", null ],
      [ "settargetNum", "structs_f_e_mparm.html#a842f8585ee420a7b8af9fae61c7b5513", null ],
      [ "settargetRes", "structs_f_e_mparm.html#a49274f6cfa059191fca9adcc640111cd", null ],
      [ "settype", "structs_f_e_mparm.html#a2ef4dd297a1e9f38fabb1a5590111df5", null ],
      [ "targetNum", "structs_f_e_mparm.html#aadfdfd719f4cdc210f2136111699c39e", null ],
      [ "targetRes", "structs_f_e_mparm.html#ae52f467fb8a8c1c23b318e53d620152b", null ],
      [ "type", "structs_f_e_mparm.html#a3a537b707cf0201c6cf61160d3c63129", null ],
      [ "useMesh", "structs_f_e_mparm.html#a07dd757a95d733e070ebf954b2ab36c7", null ]
    ] ],
    [ "FEMparm", "group___f_e_mparm.html#gac19dc8c829972231a889145317a79444", null ],
    [ "FEMparm_CalcType", "group___f_e_mparm.html#gaac30a1d94400a4d8f6b1e7dd2e754d67", null ],
    [ "FEMparm_EstType", "group___f_e_mparm.html#ga73bc50867e817d92bfb8abb39b660199", null ],
    [ "FEMparm_EtolType", "group___f_e_mparm.html#ga5ce88931883d9c9aa6f64e46f17b0d81", null ],
    [ "eFEMparm_CalcType", "group___f_e_mparm.html#gac36fc354fe54c03cfec686666e536c48", [
      [ "FCT_MANUAL", "group___f_e_mparm.html#ggac36fc354fe54c03cfec686666e536c48a2a9ffd02522897f59ce4e6feb17653f0", null ],
      [ "FCT_NONE", "group___f_e_mparm.html#ggac36fc354fe54c03cfec686666e536c48a3606033e115d9dc87ee8a90dd3780918", null ]
    ] ],
    [ "eFEMparm_EstType", "group___f_e_mparm.html#gabe14c957d66befafe12f371de15893c1", [
      [ "FRT_UNIF", "group___f_e_mparm.html#ggabe14c957d66befafe12f371de15893c1adc71ab75c1cfd56dfd4a76a48e38a61c", null ],
      [ "FRT_GEOM", "group___f_e_mparm.html#ggabe14c957d66befafe12f371de15893c1a1f6141e5ee980d4721ac2298ce3e64a5", null ],
      [ "FRT_RESI", "group___f_e_mparm.html#ggabe14c957d66befafe12f371de15893c1aa8781526a79ac22e94d172fb69bc7933", null ],
      [ "FRT_DUAL", "group___f_e_mparm.html#ggabe14c957d66befafe12f371de15893c1ab38e3aaf8cebfc0c7bf4b78b8c01a7a9", null ],
      [ "FRT_LOCA", "group___f_e_mparm.html#ggabe14c957d66befafe12f371de15893c1a3b72b0b69c4cf4428d4658a40aa5d170", null ]
    ] ],
    [ "eFEMparm_EtolType", "group___f_e_mparm.html#ga087262b9e3b70547352f3e2fbc44cd51", [
      [ "FET_SIMP", "group___f_e_mparm.html#gga087262b9e3b70547352f3e2fbc44cd51a9ce8fca936edecd1401c319883ce64b2", null ],
      [ "FET_GLOB", "group___f_e_mparm.html#gga087262b9e3b70547352f3e2fbc44cd51ad99de1f7c5fcd354759485ceab1bbe26", null ],
      [ "FET_FRAC", "group___f_e_mparm.html#gga087262b9e3b70547352f3e2fbc44cd51ae1d7cef8d87bfe6b90b8893552ab22c4", null ]
    ] ],
    [ "FEMparm_check", "group___f_e_mparm.html#ga6e154846c1619a3a949c5bc7b1b0b8b2", null ],
    [ "FEMparm_copy", "group___f_e_mparm.html#ga20a6bf0ce0cbf6482fda22722f3db17b", null ],
    [ "FEMparm_ctor", "group___f_e_mparm.html#gab55bf29011638b3d34f4258044179833", null ],
    [ "FEMparm_ctor2", "group___f_e_mparm.html#gaf9ef3194c104776069cb867d241e69a4", null ],
    [ "FEMparm_dtor", "group___f_e_mparm.html#gae239dd3231f902875739d09f5a598984", null ],
    [ "FEMparm_dtor2", "group___f_e_mparm.html#gae75199b1b6ac6900380fb6996a040852", null ]
];