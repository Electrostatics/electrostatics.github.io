var group___vopot =
[
    [ "vopot.c", "vopot_8c.html", null ],
    [ "vopot.h", "vopot_8h.html", null ],
    [ "sVopot", "structs_vopot.html", [
      [ "bcfl", "structs_vopot.html#a309c773e3e7c928a3e7a7e8e356d85a6", null ],
      [ "mgrid", "structs_vopot.html#ac1652d13f576e15dd5fb52dadc03f30c", null ],
      [ "pbe", "structs_vopot.html#a31a61d9da3a83d7c0328aaaffc6f9a8d", null ]
    ] ],
    [ "Vopot", "group___vopot.html#gab0d4ff9b02d756dca6d2c80c95c02ca6", null ],
    [ "Vopot_ctor", "group___vopot.html#ga862aab44348b5b3527a81899cd436676", null ],
    [ "Vopot_ctor2", "group___vopot.html#ga76c87497536572225a18c060f4379dc2", null ],
    [ "Vopot_curvature", "group___vopot.html#gaf6a3279fcbed2618e526fc075196a41a", null ],
    [ "Vopot_dtor", "group___vopot.html#ga7a32a04e77f23eb310ce23ce9b4ecf6b", null ],
    [ "Vopot_dtor2", "group___vopot.html#ga24bea2338d4004ac24e8dd1a30a68d42", null ],
    [ "Vopot_gradient", "group___vopot.html#ga5fd9d88ed744980aff8ea40eb1b10077", null ],
    [ "Vopot_pot", "group___vopot.html#gaec11bf9879fe1d94313b5a6c9dda57e6", null ]
];