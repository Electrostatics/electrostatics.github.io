var geoflowparm_8h =
[
    [ "GEOFLOWparm", "group___g_e_o_f_l_o_wparm.html#ga480a394dbca212418c3b34acf29f304d", null ],
    [ "GEOFLOWparm_CalcType", "group___g_e_o_f_l_o_wparm.html#ga8bf6b91a66309dff7d057e9379a5b3db", null ],
    [ "eGEOFLOWparm_CalcType", "group___g_e_o_f_l_o_wparm.html#ga3388e58223074ad4cdf17ed26db98755", [
      [ "GFCT_AUTO", "group___g_e_o_f_l_o_wparm.html#gga3388e58223074ad4cdf17ed26db98755a69ce17e084f2cf8bf215eae380f7bba0", null ]
    ] ],
    [ "GEOFLOWparm_check", "group___g_e_o_f_l_o_wparm.html#ga914e7ca69123d56de9a6c3baa43a3914", null ],
    [ "GEOFLOWparm_copy", "group___g_e_o_f_l_o_wparm.html#ga75ea01998928b72d610f2363cb2e372c", null ],
    [ "GEOFLOWparm_ctor", "group___g_e_o_f_l_o_wparm.html#ga588101806097d2a2e6236ea1e1dd3a32", null ],
    [ "GEOFLOWparm_ctor2", "group___g_e_o_f_l_o_wparm.html#gae4200adf7e82328ae805c837cdfa1d30", null ],
    [ "GEOFLOWparm_dtor", "group___g_e_o_f_l_o_wparm.html#ga535d20c7ce43d62d0170636c045b27fd", null ],
    [ "GEOFLOWparm_dtor2", "group___g_e_o_f_l_o_wparm.html#ga0c8163a491a622461ab8c236a0118398", null ],
    [ "GEOFLOWparm_parseETOL", "geoflowparm_8h.html#aeb152b449d3d0a502bb82c0aca9be5bf", null ],
    [ "GEOFLOWparm_parseToken", "group___g_e_o_f_l_o_wparm.html#ga4f77600c0fbb7cfcec88501df8b35f5b", null ],
    [ "GEOFLOWparm_parseVDW", "geoflowparm_8h.html#a8dec370ee4dbc7ba5504cfc19d97c7a8", null ]
];