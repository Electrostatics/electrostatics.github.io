README for Boundary Element Method
==================================

The example input file included in this folder uses a boundary element approach to solve the PBE. BEM has the characteristic that only the boundary of the domain has to be discretized. This is particularly useful for problems in which the data of interest is at the boundary of the solution.