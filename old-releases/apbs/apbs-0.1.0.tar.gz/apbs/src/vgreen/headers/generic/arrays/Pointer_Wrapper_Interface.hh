

ADD_TRAIT_NAME( Member);
ADD_TRAIT_NAME( Index);
ADD_TRAIT_NAME( Const_Index);
ADD_TRAIT_NAME( Const_Forward_Index);
ADD_TRAIT_NAME( Forward_Index);
ADD_TRAIT_NAME( Forward_Iterator);
ADD_TRAIT_NAME( Set_beginning);
ADD_TRAIT_NAME( Increment);
ADD_TRAIT_NAME( Not_at_end);
ADD_TRAIT_NAME( member);
ADD_TRAIT_NAME( size);
ADD_TRAIT_NAME( Pointer);
ADD_TRAIT_NAME( pointer);
ADD_TRAIT_NAME( Const_Pointer);

namespace UCSD_Bioeng{

template< class T>
inline
typename Pointer_Wrapper<T>::iterator pointer( Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::iterator p){
  Assert_debug( v.begin() <= p && p < v.end());
  return p;
}

template< class T>
inline
typename Pointer_Wrapper<T>::const_iterator pointer_const( Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::const_iterator p){
  Assert_debug( v.begin() <= p && p < v.end());
  return p;

}

template< class T>
inline
typename Pointer_Wrapper<T>::const_iterator pointer( const Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::const_iterator p){
  Assert_debug( v.begin() <= p && p < v.end());
  return p;
}

template< class T>
inline
typename Pointer_Wrapper<T>::const_iterator pointer_const( const Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::const_iterator p){
  Assert_debug( v.begin() <= p && p < v.end());
  return p;
}


template< class T>
inline
void Set_beginning( Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::iterator& i){
  i = v.begin();
}

template< class T>
inline
void Set_beginning( const Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::const_iterator& i){
  i = v.begin();
}

template< class T>
inline
void Reset( Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::iterator& i){
  i = v.begin();
  --i;
}

template< class T>
inline
void Increment( Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::iterator& i){

  Assert_debug( v.begin() <= i && i < v.end());
  ++i;
}

template< class T>
inline
void Increment( const Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::const_iterator& i){

  Assert_debug( v.begin() <= i && i < v.end());
  ++i;
}

template< class T>
inline
bool Increment_and_test( const Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::const_iterator& i){

  ++i;
  Assert_debug( v.begin() <= i && i < v.end());
  return i != v.end();
}

template< class T>
inline
bool Increment_and_test( Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::iterator& i){

  ++i;
  Assert_debug( v.begin() <= i && i < v.end());
  return i != v.end();
}


template< class T>
inline
bool Not_at_end( const Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::const_iterator i){
  Assert_debug( v.begin() <= i && v.begin() <= v.end());
  return i != v.end();
}

template< class T>
inline
bool Not_at_end( Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::iterator i){
  Assert_debug( v.begin() <= i && v.begin() <= v.end());
  return i != v.end();
}

template< class T>
inline
T& member( Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::iterator i){

  Assert_debug( v.begin() <= i && i < v.end());
  return *i;
}


template< class T>
inline
const T& member( const Pointer_Wrapper<T>& v, typename Pointer_Wrapper<T>::const_iterator i){

  Assert_debug( v.begin() <= i && i < v.end());
  return *i;
}

template< class T>
inline
size_t size( const Pointer_Wrapper<T>& v){
  return v.size();
}

template< class T>
inline
void Resize( Pointer_Wrapper<T>& v, size_t n){
  v.resize( n);
}

}


SET_TEMPLATED_TRAIT( Member, const UCSD_Bioeng::Pointer_Wrapper, T, const T);
SET_TEMPLATED_TRAIT( Member, UCSD_Bioeng::Pointer_Wrapper, T, T);

SET_TEMPLATED_TRAIT( Index, UCSD_Bioeng::Pointer_Wrapper, T, typename UCSD_Bioeng::Pointer_Wrapper<T>::iterator);
SET_TEMPLATED_TRAIT( Index, const UCSD_Bioeng::Pointer_Wrapper, T, typename UCSD_Bioeng::Pointer_Wrapper<T>::const_iterator);
SET_TEMPLATED_TRAIT( Const_Index, const UCSD_Bioeng::Pointer_Wrapper, T, typename UCSD_Bioeng::Pointer_Wrapper<T>::const_iterator);

SET_TEMPLATED_TRAIT( Pointer, UCSD_Bioeng::Pointer_Wrapper, T, typename UCSD_Bioeng::Pointer_Wrapper<T>::iterator);
SET_TEMPLATED_TRAIT( Pointer, const UCSD_Bioeng::Pointer_Wrapper, T, typename UCSD_Bioeng::Pointer_Wrapper<T>::const_iterator);
SET_TEMPLATED_TRAIT( Const_Pointer, const UCSD_Bioeng::Pointer_Wrapper, T, typename UCSD_Bioeng::Pointer_Wrapper<T>::const_iterator);

SET_TEMPLATED_TRAIT( Forward_Index, UCSD_Bioeng::Pointer_Wrapper, T, typename UCSD_Bioeng::Pointer_Wrapper<T>::iterator);
SET_TEMPLATED_TRAIT( Forward_Index, const UCSD_Bioeng::Pointer_Wrapper, T, typename UCSD_Bioeng::Pointer_Wrapper<T>::const_iterator);
SET_TEMPLATED_TRAIT( Const_Forward_Index, const UCSD_Bioeng::Pointer_Wrapper, T, typename UCSD_Bioeng::Pointer_Wrapper<T>::const_iterator);

SET_FUNCTION_TEMPLATED_TRAIT( Set_beginning, const UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::Set_beginning);
SET_FUNCTION_TEMPLATED_TRAIT( Set_beginning, UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::Set_beginning);
SET_FUNCTION_TEMPLATED_TRAIT( Increment, const UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::Increment);
SET_FUNCTION_TEMPLATED_TRAIT( Increment, UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::Increment);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( Increment_and_test, const UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::Increment_and_test, bool);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( Increment_and_test, UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::Increment_and_test, bool);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( Not_at_end, const UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::Not_at_end, bool);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( Not_at_end, UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::Not_at_end, bool);

SET_FUNCTION_W_RET_TEMPLATED_TRAIT( member, UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::member, T&);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( member, const UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::member, const T&);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( size, const UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::size, size_t);

SET_FUNCTION_W_RET_TEMPLATED_TRAIT( pointer, UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::pointer, typename UCSD_Bioeng::Pointer_Wrapper<T>::iterator);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( pointer, const UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::pointer, typename UCSD_Bioeng::Pointer_Wrapper<T>::const_iterator);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( pointer_const, const UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::pointer_const, typename UCSD_Bioeng::Pointer_Wrapper<T>::const_iterator);

SET_TEMPLATED_TRAIT( Inner_Ref, UCSD_Bioeng::Pointer_Wrapper, T, TEMPLATE1( UCSD_Bioeng::Pointer_Wrapper, T)&);
SET_TEMPLATED_TRAIT( Inner_Ref, const UCSD_Bioeng::Pointer_Wrapper, T, TEMPLATE1( const UCSD_Bioeng::Pointer_Wrapper, T)&);
SET_TEMPLATED_TRAIT( Inner_Const_Ref, const UCSD_Bioeng::Pointer_Wrapper, T, TEMPLATE1( const UCSD_Bioeng::Pointer_Wrapper, T)&);

SET_FUNCTION_TEMPLATED_TRAIT( Resize, UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::Resize);
SET_FUNCTION_TEMPLATED_TRAIT( Reset, UCSD_Bioeng::Pointer_Wrapper, UCSD_Bioeng::Reset);

namespace UCSD_Bioeng{

//######################################################################
template< class T1, class T2>
void Set( Pointer_Wrapper<T1>& z, const Pointer_Wrapper<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Set( (*zp), (*xp));
    ++xp; ++xp;
  }
}


template< class T1, class T2, class T3>
void Set_a( Pointer_Wrapper<T1>& z, 
	    const Pointer_Wrapper<T2>& x, const Pointer_Wrapper<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  Pointer_Wrapper<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Set_a( (*zp), (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S, class T2>
void Set_m( Pointer_Wrapper<T1>& z, const S& a, const Pointer_Wrapper<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Set_m( (*zp), a, (*xp));
    ++xp; ++xp;
  }
}

template< class T1, class S, class T2, class T3>
void Set_ma( Pointer_Wrapper<T1>& z, const S& a, 
	    const Pointer_Wrapper<T2>& x, const Pointer_Wrapper<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  Pointer_Wrapper<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Set_ma( (*zp), s, (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S1, class T2, class S2, class T3>
void Set_mam( Pointer_Wrapper<T1>& z, 
	      const S1& a, const Pointer_Wrapper<T2>& x, 
	      const S2& b, const Pointer_Wrapper<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  Pointer_Wrapper<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Set_mam( (*zp), s, (*xp), b, (*yp));
    ++xp; ++xp; ++yp;
  }
}

//######################################################################
template< class T1, class T2>
void Add( Pointer_Wrapper<T1>& z, const Pointer_Wrapper<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Add( (*zp), (*xp));
    ++xp; ++xp;
  }
}


template< class T1, class T2, class T3>
void Add_a( Pointer_Wrapper<T1>& z, 
	    const Pointer_Wrapper<T2>& x, const Pointer_Wrapper<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  Pointer_Wrapper<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Add_a( (*zp), (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S, class T2>
void Add_m( Pointer_Wrapper<T1>& z, const S& a, const Pointer_Wrapper<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Add_m( (*zp), a, (*xp));
    ++xp; ++xp;
  }
}

template< class T1, class S, class T2, class T3>
void Add_ma( Pointer_Wrapper<T1>& z, const S& a, 
	    const Pointer_Wrapper<T2>& x, const Pointer_Wrapper<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  Pointer_Wrapper<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Add_ma( (*zp), s, (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S1, class T2, class S2, class T3>
void Add_mam( Pointer_Wrapper<T1>& z, 
	      const S1& a, const Pointer_Wrapper<T2>& x, 
	      const S2& b, const Pointer_Wrapper<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  Pointer_Wrapper<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Add_mam( (*zp), s, (*xp), b, (*yp));
    ++xp; ++xp; ++yp;
  }
}

//######################################################################
template< class T1, class T2>
void Subtract( Pointer_Wrapper<T1>& z, const Pointer_Wrapper<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Subtract( (*zp), (*xp));
    ++xp; ++xp;
  }
}


template< class T1, class T2, class T3>
void Subtract_a( Pointer_Wrapper<T1>& z, 
	    const Pointer_Wrapper<T2>& x, const Pointer_Wrapper<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  Pointer_Wrapper<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Subtract_a( (*zp), (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S, class T2>
void Subtract_m( Pointer_Wrapper<T1>& z, const S& a, const Pointer_Wrapper<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Subtract_m( (*zp), a, (*xp));
    ++xp; ++xp;
  }
}

template< class T1, class S, class T2, class T3>
void Subtract_ma( Pointer_Wrapper<T1>& z, const S& a, 
	    const Pointer_Wrapper<T2>& x, const Pointer_Wrapper<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  Pointer_Wrapper<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Subtract_ma( (*zp), s, (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S1, class T2, class S2, class T3>
void Subtract_mam( Pointer_Wrapper<T1>& z, 
	      const S1& a, const Pointer_Wrapper<T2>& x, 
	      const S2& b, const Pointer_Wrapper<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  Pointer_Wrapper<T1>::iterator zp = z.begin();
  const Pointer_Wrapper<T1>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();
  Pointer_Wrapper<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Subtract_mam( (*zp), a, (*xp), b, (*yp));
    ++xp; ++xp; ++yp;
  }
}

//######################################################
template< class T, class S>
void Multiply( Pointer_Wrapper<T>& z, const S& a){

  typename Pointer_Wrapper<T>::iterator zp = z.begin();
  const typename Pointer_Wrapper<T>::iterator ze = z.end();

  while( zp < ze){
    Multiply( (*zp), a);
    ++zp;
  }
}

/* trouble with gcc
template< class T1, class T2, class S1, class S2>
void Set_f( Pointer_Wrapper<T1>& z, S1 (*f)( S2), const Pointer_Wrapper<T2>& x){

  typename Pointer_Wrapper<T>::iterator zp = z.begin();
  const typename Pointer_Wrapper<T>::iterator ze = z.end();
  Pointer_Wrapper<T2>::const_iterator xp = x.begin();

  while( zp < ze){
    Set_f( (*zp), f, (*xp));
    ++zp; ++xp;
  }
}
*/

}





