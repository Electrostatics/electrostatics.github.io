//#################################
template< bool tf, class T1, class T2>
struct If;

template< class T1, class T2>
struct If< true, T1, T2>{
  typedef T1 Result;
};

template< class T1, class T2>
struct If< false, T1, T2>{
  typedef T2 Result;
};

//#################################
template< class T1, class T2>
struct Are_Equal{
  static const bool result = false;
};

template< class T>
struct Are_Equal< T,T>{
  static const bool result = true;
};

//#################################
template< class T>
struct Is_Constant{
  static const bool result = Are_Equal< const T, T>::result;
};

//#################################
template< bool t1, class T1, bool t2, class T2, class T3>
struct Switch3;

template< class T1, bool t2, class T2, class T3>
struct Switch3< true, T1, t2, T2, T3>{
  typedef T1 Result;
};

template< class T1, class T2, class T3>
struct Switch3< false, T1, true, T2, T3>{
  typedef T2 Result;
};

template< class T1, class T2, class T3>
struct Switch3< false, T1, false, T2, T3>{
  typedef T3 Result;
};


//#################################
template< bool t1, class T1, bool t2, class T2, bool t3, class T3, class T4>
struct Switch4;

template< class T1, bool t2, class T2, bool t3, class T3, class T4>
struct Switch4< true, T1, t2, T2, t3, T3, T4>{
  typedef T1 Result;
};

template< class T1, class T2, bool t3, class T3, class T4>
struct Switch4< false, T1, true, T2, t3, T3, T4>{
  typedef T2 Result;
};

template< class T1, class T2, class T3, class T4>
struct Switch4< false, T1, false, T2, true, T3, T4>{
  typedef T3 Result;
};

template< class T1, class T2, class T3, class T4>
struct Switch4< false, T1, false, T2, false, T3, T4>{
  typedef T4 Result;
};

//#################################
template< bool t1, class T1, bool t2, class T2, bool t3, class T3,
          bool t4, class T4, bool t5, class T5, bool t6, class T6, 
          class T7>
struct Switch7;

template<          class T1, bool t2, class T2, bool t3, class T3,
          bool t4, class T4, bool t5, class T5, bool t6, class T6, 
          class T7>
struct Switch7< true, T1, t2, T2, t3, T3, t4, T4, t5, T5, t6, T6, T7>{
  typedef T1 Result;
};

template<          class T1,          class T2, bool t3, class T3,
          bool t4, class T4, bool t5, class T5, bool t6, class T6, 
          class T7>
struct Switch7< false, T1, true, T2, t3, T3, t4, T4, t5, T5, t6, T6, T7>{
  typedef T2 Result;
};

template<          class T1,          class T2,          class T3,
          bool t4, class T4, bool t5, class T5, bool t6, class T6, 
          class T7>
struct Switch7< false, T1, false, T2, true, T3, t4, T4, t5, T5, t6, T6, T7>{
  typedef T3 Result;
};

template<          class T1,          class T2,          class T3,
                   class T4, bool t5, class T5, bool t6, class T6, 
          class T7>
struct Switch7< false, T1, false, T2, false, T3, true, T4, t5, T5, t6, T6, T7>{
  typedef T4 Result;
};

template<          class T1,          class T2,          class T3,
                   class T4,          class T5, bool t6, class T6, 
          class T7>
struct Switch7< false, T1, false, T2, false, T3, false, T4, true, T5, t6, T6, T7>{
  typedef T5 Result;
};

template<          class T1,          class T2,          class T3,
                   class T4,          class T5,          class T6, 
          class T7>
struct Switch7< false, T1, false, T2, false, T3, false, T4, false, T5, true, T6, T7>{
  typedef T6 Result;
};

template<          class T1,          class T2,          class T3,
                   class T4,          class T5,          class T6, 
          class T7>
struct Switch7< false, T1, false, T2, false, T3, false, T4, false, T5, false, T6, T7>{
  typedef T7 Result;
};

//#################################
template< class T1, class T2>
struct Is_Ancestor{
  static const bool result = Is_Ancestor< T1, SUPERCLASS( T2)>::result;
};

template< class T>
struct Is_Ancestor< T,T>{
  static const bool result = true;
};

template< class T>
struct Is_Ancestor< T, Interface::Nothing>{
  static const bool result = false;
};

template<>
struct Is_Ancestor< Interface::Nothing, Interface::Nothing>{
  static const bool result = true;
};



