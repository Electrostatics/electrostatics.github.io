#ifndef __COMPILE_TIME_CHECKERS_HH__
#define __COMPILE_TIME_CHECKERS_HH__

namespace UCSD_Bioeng{

template< size_t i, size_t j>
struct Equality_Asserter_size_t;

template< size_t i>
struct Equality_Asserter_size_t< i,i>{};

}

#endif
