#ifndef __CELL_LIST_HH__
#define __CELL_LIST_HH__
//##############################################################

#include "../arrays/Array.hh"
#include "../arrays/Small_Vector.hh"

SETUP_LOCAL_CONTEXT( UCSD_Bioeng_Cell_List);

ADD_TRAIT_NAME( Pointer);
ADD_TRAIT_NAME( Const_Pointer);
ADD_TRAIT_NAME( Forward_Index);
ADD_TRAIT_NAME( Const_Forward_Index);
ADD_TRAIT_NAME( Get_position);
ADD_TRAIT_NAME( Set_beginning);
ADD_TRAIT_NAME( Increment_and_test);
ADD_TRAIT_NAME( pointer);
ADD_TRAIT_NAME( pointer_const);

namespace UCSD_Bioeng{
//###########################################
template< class Particles, 
          class Local_Context = LOCAL_CONTEXT( UCSD_Bioeng_Cell_List)>
class Cell_List{

public:
  #include "Cell_List_public.hh"

  Cell_List();

  // Set associated list
  void Set_list( Particles&);

  // "spacing" is length of each cubic cell
  void Set_spacing( double spacing);
  double spacing() const;

  // Set lowest corner of cubic cell array
  template< class Position>
  void Set_low_corner( const Position&);
  void Set_low_corner( double, double, double);

  // Set number of cells in each direction
  void Set_dimensions( size_t, size_t, size_t);

  // After the associated list is set with "Set_list" and the spacing is set 
  // with "Set_spacing",it is possible to have the cell list figure out the 
  // corners and number of cells in each direction.  First, the coordinates 
  // of the low corner are set to the lowest coordinates of all the particles.
  // Then, given the spacing, the minimum numbers of cells in each direction
  // necessary to contain all of the particles in the list are computed.
  void Set_default_corners_and_dimensions();

  // When the list, spacing, number of dimensions, and the lower corner
  // have been set, "Update_cells" must be called in order to set up
  // the cell structure.  Whenever the particle positions or any of 
  // the input parameters change, it is necessary to call this function
  // again.
  void Update_cells();

  // Cells are indexed in two ways.  The first is to give its "address"
  // by 3 integers, starting at 0.  The second way is to use one
  // integer as the address;  this is easier for the user to keep
  // track of. 


  // Given a position, returns the one-integer index of the cell that
  // contains the position "x".  If "x" is outside of all the cells,
  // an index that specifically denotes "not inside" is returned.  This
  // index is given by the function "cell_end_index()".

  template< class Position>
  size_t cell_index( const Position& x) const;
  size_t cell_index( size_t ix, size_t iy, size_t iz) const;

  template< class Position, class Indices>
  void Get_cell_indices( const Position& x, Indices&) const;

  template< class Position>
  void Get_cell_indices( const Position& x, size_t&, size_t&, size_t&) const;

  void Get_cell_indices( size_t, size_t&, size_t&, size_t&) const;

  // Return the number of cells in each direction
  size_t n_in_x_direction() const;
  size_t n_in_y_direction() const;
  size_t n_in_z_direction() const;

  // Return the center position of the cell denoted by the
  // indices
  template< class Position>
  void Get_cell_center( size_t, size_t, size_t, Position&) const;

  template< class Position>
  void Get_cell_center( size_t, Position&) const;

  // low and high corners of the Cell_List
  template< class Position>
  void Get_low_corner( Position&) const;

  template< class Position>
  void Get_high_corner( Position&) const;

  // The number of particles in cell "i_cell"
  size_t n_in_cell( size_t i_cell) const;

  // The number of particles in cell "( ix, iy, iz)".
  size_t n_in_cell( size_t ix, size_t iy, size_t iz) const;

  // pointer to "i_particle"_th object in cell "i_cell"
  Pointer particle_pointer( size_t i_cell, size_t i_particle);
  Const_Pointer particle_pointer_const( size_t cell, size_t particle) const;

  // pointer to "i_particle"_th object in cell "(ix, iy, iz)":
  Pointer particle_pointer( size_t ix, size_t iy, size_t iz,
			    size_t i_particle);
  Const_Pointer particle_pointer_const( size_t cellx, size_t celly, size_t cellz,
				  size_t particle) const;

  // This applies functor "f" to all distinct pairs of particles that
  // are in the same or neighboring cells.  There is no double-counting.
  // Functor "f" must have 
  // "operator()( Particles& particles, Pointer p1, Pointer p2)"
  // defined; it operates on the particles in "particles" pointed to
  // by p1 and p2.  For alternative interfaces, see the 
  // Expanded Interfaces above.

  template< class Functor>
  void Apply_to_pairs( Functor& );

  // Just like above, except "f" must have 
  // "operator()( const Particles& particles, Const_Pointer p1, 
  //                                          Const_Pointer p2)"
  // defined.

  template< class Functor>
  void Apply_to_pairs( Functor&) const;

  //  This applies functor "f" to all particles in cell "i_cell" and
  // in "i_cell"'s neighboring cells.  Functor "f" has the form
  // operator()( Particles& particles, Pointer p)

  template< class Functor>
  void Apply_to_neighbors( size_t i_cell, Functor& f);

  // Just like above, except "f" must have
  // operator()( const Particles& particles, Const_Pointer p)

  template< class Functor>
  void Apply_to_neighbors( size_t cell, Functor&) const;

  // Checks to make sure that the geometry and particle list have
  // been set, and throws an error if they haven't.
  void Assert_readiness() const;

  const Particles& particle_list() const;

#include "Cell_List_private.hh"
};

}

#include "Cell_List_impl.hh"
#include "Cell_List_Interface.hh"  

#endif








