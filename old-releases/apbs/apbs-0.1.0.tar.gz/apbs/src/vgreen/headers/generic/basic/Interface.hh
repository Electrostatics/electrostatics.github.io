#ifndef __INTERFACE_HH__
#define __INTERFACE_HH__

#define TEMPLATE1( A, B1) A< B1>
#define TEMPLATE2( A, B1, B2) A< B1, B2>
#define TEMPLATE3( A, B1, B2, B3) A< B1, B2, B3>


namespace Interface{
  
  class Nothing{};

  namespace _Global{
    struct Context{};
  }

  namespace Trait_Names{}

  template< class T>
  struct Superclass_Trait;

  template< class T>
  struct Superclass_Trait< const T>: public Superclass_Trait<T>{};
}


#define SET_SUPERCLASS( Class, Super)		\
namespace Interface{				\
template<>					\
struct Superclass_Trait< Class>{		\
  typedef Super Result;				\
};} class None


// Adds a new trait name
#define ADD_TRAIT_NAME( Name)       		\
  namespace Interface{              		\
  namespace Trait_Names{            		\
    class Name##T;                   		\
  }} class None


#define SUPERCLASS( Class)			\
typename ::Interface::Superclass_Trait< Class>::Result

#include "Metaprograms.hh"

#define LOCAL_TRAIT( Context, Relation, Class)			\
  typename							\
  ::Interface::Traits< Context,					\
                     ::Interface::Trait_Names::Relation##T,	\
                     Class>::Result

#define LTRAIT( Relation, Class)				\
  typename							\
  ::Interface::Traits< Local_Context,				\
                     ::Interface::Trait_Names::Relation##T,	\
                     Class>::Result


#define LOCAL_GTRAIT( Context, Relation, Class)			\
  ::Interface::Traits< Context,					\
                     ::Interface::Trait_Names::Relation##T,	\
                     Class>::Result

#define LGTRAIT( Relation, Class) LOCAL_GTRAIT( Local_Context, Relation, Class)

#define LOCAL_FUNCTION( Context, F, Class)		\
  ::Interface::Traits< Context,				\
                     ::Interface::Trait_Names::F##T,	\
                     Class>::Result::Do

#define LOCAL_FUNCTOR( Context, F, Class)	\
  ::Interface::Traits< Context,			\
                     ::Interface::Trait_Names::F##T,	\
                     Class>::Result()

#define FUNCTION( F, Class)				\
  ::Interface::Traits< Interface::_Global::Context,	\
                     ::Interface::Trait_Names::F##T,	\
                     Class>::Result::Do

#define LFUNCTION( F, Class) 				\
  ::Interface::Traits< Local_Context,			\
                     ::Interface::Trait_Names::F##T,	\
                     Class>::Result::Do

/*
#define LFUNCTION( F, Class) LOCAL_FUNCTION( 
                               TEMPLATE3( 
                                 If, 
                                 ::Interface::TEMPLATE3( Traits, Local_Context, F##T, Class)::is_lspecialized,
                                 Local_Context,
                                 ::Interface::_##F)::Result,
                               F,
                               Class)
*/

#define LFUNCTOR( F, Class) LOCAL_FUNCTOR( Local_Context, F, Class)

#define SET_LOCAL_TRAIT( context, Relation, Class, Res)	\
  ADD_TRAIT_NAME( Relation);				\
  namespace Interface{					\
    template<>						\
    struct Traits< _##context::Context,	\
                   Trait_Names::Relation##T,	\
		   Class>{				\
      typedef Res Result;				\
      static const bool is_specialized = true;		\
      static const bool is_specialized_here = true;		\
      static const bool same_context = true;		\
    };} class None

#define SET_LOCAL_TEMPLATED_TRAIT( context, Relation, Class, Arg, Res)	\
  ADD_TRAIT_NAME( Relation);						\
  namespace Interface{							\
    template< class Arg>						\
    struct Traits< _##context::Context,			\
                   Trait_Names::Relation##T,			\
		   Class<Arg> >{					\
      typedef Res Result;						\
      static const bool is_specialized = true;				\
      static const bool is_specialized_here = true;				\
      static const bool same_context = true; 				\
    };} class None


#define SET_LOCAL_TEMPLATED2_TRAIT( context, Relation, Class, Arg1, Arg2, Res)	\
  ADD_TRAIT_NAME( Relation);							\
  namespace Interface{								\
    template< class Arg1, class Arg2>						\
    struct Traits< _##context::Context,				\
                   Trait_Names::Relation##T,				\
		   Class< Arg1, Arg2> >{					\
      typedef Res Result;							\
      static const bool is_specialized = true;					\
      static const bool is_specialized_here = true;					\
      static const bool same_context = true;					\
    };} class None


#define TRAIT( Relation, Class)					\
  typename							\
  ::Interface::Traits< ::Interface::_Global::Context,		\
                     ::Interface::Trait_Names::Relation##T,	\
                     Class>::Result

#define GTRAIT( Relation, Class) LOCAL_GTRAIT( ::Interface::_Global::Context, Relation, Class)

#define SET_TRAIT( Relation, Class, Res)		\
  ADD_TRAIT_NAME( Relation);				\
  namespace Interface{					\
    template<>						\
    struct Traits< _Global::Context,		\
                   Trait_Names::Relation##T,	\
		   Class>{				\
      typedef Res Result;				\
      static const bool is_specialized = true;		\
      static const bool is_specialized_here = true;		\
      static const bool same_context = true;		\
    };} class None


#define SET_TEMPLATED_TRAIT( Relation, Class, Arg, Res)	\
  ADD_TRAIT_NAME( Relation);				\
  namespace Interface{					\
    template< class Arg>				\
    struct Traits< _Global::Context,		\
                   Trait_Names::Relation##T,	\
		   Class<Arg> >{			\
      typedef Res Result;				\
      static const bool is_specialized = true;		\
      static const bool is_specialized_here = true;		\
      static const bool same_class =  true;		\
      static const bool same_context = true;		\
      Traits(){						\
	printf( "templated trait\n");			\
      }							\
    };} class None


#define SET_TEMPLATED2_TRAIT( Relation, Class, Arg1, Arg2, Res)	\
  ADD_TRAIT_NAME( Relation);					\
  namespace Interface{						\
    template< class Arg1, class Arg2>				\
    struct Traits< _Global::Context,			\
                   Trait_Names::Relation##T,		\
		   Class< Arg1, Arg2> >{			\
      typedef Res Result;					\
      static const bool is_specialized = true;			\
      static const bool is_specialized_here = true;			\
      static const bool same_context = true;			\
    };} class None

namespace Interface{

template< class Class>
struct Superclass_Trait{
  typedef Nothing Result;
};

// If Class is not const and Context is not global, then
//    If is directly specialized with const Class,
//      inherits with const Class
//    Else
//      If is specialized with any superclass of Class inside Context
//        inherits with Superclass( Class)
//      Else
//        inherits with Context::Enclosing

template< class context, class Relation, class Class>
struct Traits: public 
  Switch3< Traits< context, Relation, const Class>::is_specialized_here,
           Traits< context, Relation, const Class>, 
           Traits< context, Relation, SUPERCLASS( Class)>::is_specialized &&
           Traits< context, Relation, SUPERCLASS( Class)>::same_context ,
           Traits< context, Relation, SUPERCLASS( Class)>,
           Traits< typename context::Enclosing, Relation, Class>
	 >::Result
{
  typedef Traits< context, Relation, const Class> Superclass1;
  typedef Traits< context, Relation, SUPERCLASS( Class)> Superclass2;
  typedef Traits< typename context::Enclosing, Relation, Class> Superclass3;

  typedef typename 
          Switch3< Superclass1::is_specialized_here,
                   Superclass1,
                   Superclass2::is_specialized && Superclass2::same_context,
                   Superclass2,
                   Superclass3>::Result Superclass;

  typedef typename Superclass::Result Result; // needed for gcc problem
  static const bool is_specialized = Superclass::is_specialized; // needed for gcc problem

  static const bool is_specialized_here = false;
  static const bool same_context = 
    bool( Superclass1::is_specialized_here) ?
      true :
      (bool( Superclass2::is_specialized) && bool( Superclass2::same_context) ?
        true :
        false);
  
  Traits(){
    printf( "not global, not const %d %d\n", is_specialized_here, same_context);
  }  
};


// This is the top of the Traits hierarchy
template< class Relation>
struct Traits< _Global::Context, Relation, Nothing>{

  static const bool is_specialized = false;
  static const bool is_specialized_here = false;
  static const bool same_context = false;
  typedef Nothing Result;

  Traits(){
    printf( "global, nothing %d %d\n", is_specialized, same_context);
  }
  
};

template< class Relation>
struct Traits< _Global::Context, Relation, const Nothing>{

  typedef Nothing Result;
  static const bool is_specialized = false;
  static const bool is_specialized_here = false;
  static const bool same_context = false;
  
  Traits(){
    printf( "global, const nothing %d %d\n", is_specialized, same_context);
  }
  
};


// If context is global and Class is const, then
//   inherits with const Superclass( Class)

template< class Relation, class Class>
struct Traits< _Global::Context, Relation, const Class>: 
  public Traits< _Global::Context, Relation, const SUPERCLASS( Class)>{

  typedef Traits< _Global::Context, Relation, const SUPERCLASS( Class)> Superclass;

  typedef typename Superclass::Result Result; // needed for gcc problem
  static const bool is_specialized = Superclass::is_specialized; // needed for gcc problem

  static const bool is_specialized_here = false;
  static const bool same_context = true;
  
  Traits(){
    printf( "global, const %d %d\n", is_specialized, same_context);
  }
};

// If context is global and Class is not const, then
//    If is immediately specialized with const Class,
//      inherits with const Class
//    Else
//      inherits with Superclass( Class)

template< class Relation, class Class>
struct Traits< _Global::Context, Relation, Class>: public
  If< Traits< _Global::Context, Relation, const Class>::is_specialized_here,
      Traits< _Global::Context, Relation, const Class>,
      Traits< _Global::Context, Relation, SUPERCLASS( Class)>
    >::Result{

  typedef Traits< _Global::Context, Relation, const Class> Superclass1;
  typedef Traits< _Global::Context, Relation, SUPERCLASS( Class)> Superclass2;

  typedef typename If< Superclass1::is_specialized_here,
                        Superclass1, Superclass2>::Result Superclass;

  static const bool is_specialized = Superclass::is_specialized; // needed for gcc trouble
  typedef typename Superclass::Result Result; // needed for gcc trouble

  static const bool is_specialized_here = false;
  static const bool same_context = true;

  Traits(){
    printf( "global, not const %d %d\n", is_specialized_here, same_context);
  }
  
};
    

  // Not really at top, but needed for checking
template< class context, class Relation>
struct Traits< context, Relation, Nothing>{
  static const bool is_specialized = false;
  static const bool is_specialized_here = false;
  static const bool same_context = false;
  typedef Nothing Result;
  Traits(){
    printf( "not global, Nothing %d %d\n", is_specialized_here, same_context);
  }
};

template< class context, class Relation>
struct Traits< context, Relation, const Nothing>{
  static const bool is_specialized = false;
  static const bool is_specialized_here = false;
  static const bool same_context = false;
  typedef Nothing Result;
  Traits(){
    printf( "not global, const Nothing %d %d\n", is_specialized_here, same_context);
  }
};

// If Class is const and context is not global, then
//    If is specialized with any const superclass of Class inside context, then
//      inherits with const Superclass( Class)
//    Else
//      inherits with context::Enclosing

template< class context, class Relation, class Class>
struct Traits< context, Relation, const Class>: public
  If< Traits< context, Relation, const SUPERCLASS( Class)>::same_context &&
      Traits< context, Relation, const SUPERCLASS( Class)>::is_specialized,
      Traits< context, Relation, const SUPERCLASS( Class)>,
      Traits< typename context::Enclosing, Relation, const Class> 
    >::Result
{
  typedef Traits< context, Relation, const SUPERCLASS( Class)> Superclass1;
  typedef Traits< typename context::Enclosing, Relation, const Class> Superclass2;

  typedef typename
  If< Superclass1::same_context && Superclass1::is_specialized,
      Superclass1, Superclass2>::Result
    Superclass;  

  static const bool is_specialized = Superclass::is_specialized; // needed for gcc problem
  typedef typename Superclass::Result Result; // needed for gcc problem

  static const bool is_specialized_here = false;
  static const bool same_context = bool( Superclass1::is_specialized && Superclass1::same_context);
      
  Traits(){
    printf( "not global, const %d %d\n", is_specialized_here, same_context);
  }
  
};


// Default:  Traits of reference are traits of class.
template< class context, class Relation, class Class> 
struct Traits< context, Relation, Class&>: 
    public Traits< context, Relation, Class>{};

template< class Relation, class Class> 
struct Traits< _Global::Context, Relation, Class&>: 
    public Traits< _Global::Context, Relation, Class>{};
}

#define SETUP_LOCAL_CONTEXT( context)			\
namespace Interface{					\
  namespace _##context{					\
    struct Context: public _Global::Context{	\
      typedef _Global::Context Enclosing;	\
    };							\
  }							\
} class None  

#define SETUP_LOCAL_INHERITED_CONTEXT( context, parent)	\
namespace Interface{					\
  namespace _##context{					\
    struct Context: public _Global::Context{	\
      typedef _##parent::Context Enclosing;	\
    };							\
  }							\
} class None  



#define FLOCAL_CONTEXT( F) ::Interface::_##F::Context()
#define LOCAL_CONTEXT( F) ::Interface::_##F::Context


#include "Function_Traits.hh"


// Lets local function trait function as a local functor
ADD_TRAIT_NAME( Execute);

namespace Interface{

template< class Functor>
struct Trait_Functor< _Global::Context, Trait_Names::ExecuteT, Functor>{

  template< class Arg1>
  static void Do( Functor& f, Arg1& arg1){
    f( arg1);
  }
  template< class Arg1, class Arg2>
  static void Do( Functor& f, Arg1& arg1, Arg2& arg2){
    f( arg1, arg2);
  }
  template< class Arg1, class Arg2, class Arg3>
  static void Do( Functor& f, Arg1& arg1, Arg2& arg2, Arg3& arg3){
    f( arg1, arg2, arg3);
  }
  template< class Arg1, class Arg2, class Arg3, class Arg4>
  static void Do( Functor& f, Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4){
    f( arg1, arg2, arg3, arg4);
  }
  /*
  template< class Arg1>
  static void Do( const Functor& f, Arg1& arg1){
    f( arg1);
  }
  template< class Arg1, class Arg2>
  static void Do( const Functor& f, Arg1& arg1, Arg2& arg2){
    f( arg1, arg2);
  }
  template< class Arg1, class Arg2, class Arg3>
  static void Do( const Functor& f, Arg1& arg1, Arg2& arg2, Arg3& arg3){
    f( arg1, arg2, arg3);
  }
  template< class Arg1, class Arg2, class Arg3, class Arg4>
  static void Do( const Functor& f, Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4){
    f( arg1, arg2, arg3, arg4);
  }
  */
};

template< class Functor>
struct Traits< _Global::Context, Trait_Names::ExecuteT, Functor>{

  static const bool is_specialized = true;								
  static const bool is_specialized_here = true;								
  static const bool same_context = true;								
  typedef Trait_Functor< _Global::Context, Trait_Names::ExecuteT, Functor> Result;		
};

template< class Functor>
struct Traits< _Global::Context, Trait_Names::ExecuteT, const Functor>{

  static const bool is_specialized = true;								
  static const bool is_specialized_here = true;								
  static const bool same_context = true;								
  typedef Trait_Functor< _Global::Context, Trait_Names::ExecuteT, const Functor> Result;		
};



  /*
template< class Context, class Relation, class Class>
struct Traits< _Global::Context, Trait_Names::ExecuteT, Traits< Context, Relation, Class> >{

  template< class TT>
  static void Do( const TT&){
    TT::Do();
  }

  template< class TT, class Arg1>
  static void Do( const TT&, Arg1& arg1){
    TT::Do( arg1);
  }

  template< class TT, class Arg1, class Arg2>
  static void Do( const TT&, Arg1& arg1, Arg2& arg2){
    TT::Do( arg1, arg2);
  }

  template< class TT, class Arg1, class Arg2, class Arg3>
  static void Do( const TT&, Arg1& arg1, Arg2& arg2, Arg3& arg3){
    TT::Do( arg1, arg2, arg3);
  }

  template< class TT, class Arg1, class Arg2, class Arg3, class Arg4>
  static void Do( const TT&, Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4){
    TT::Do( arg1, arg2, arg3, arg4);
  }
};
  */

  //#############
  // Compile-time error checking
  template< class C, class R>
  struct Error_Msg2{};

  template< bool T, class C, class R>
  struct Error_Msg;
  
  template< class Class, class Relation>
  struct Error_Msg< false, Class, Relation>{
    typename Error_Msg2<Class, Relation>::Does_not_have_trait message;
  };
  
  template< class C, class R>
  struct Error_Msg< true, C, R>{};
  
  template< class T>
  inline
  void dummy( const T&){}  
}

#define CHECK_LOCAL_TRAIT( Relation, Class)			\
  ::Interface::dummy(						\
    ::Interface::Error_Msg<					\
      ::Interface::Traits< Local_Context,				\
                         ::Interface::Trait_Names::Relation##T,	\
                         Class>::is_specialized, 		\
      Class, 							\
      ::Interface::Trait_Names::Relation##T>());			\
  class None

#define CHECK_TRAIT( Relation, Class)				\
  ::Interface::dummy(						\
    ::Interface::Error_Msg<					\
      ::Interface::Traits< ::Interface::_Global::Context,		\
                         ::Interface::Trait_Names::Relation##T,	\
                         Class>::is_specialized, 		\
      Class,							\
      ::Interface::Trait_Names::Relation##T>());			\
  class None

#define CHECK_CONCEPT( Concept, Class) 			\
  ::Interface::dummy( Concept< Class, Local_Context>());	\
  class None

// for debugging
#define INSTANTIATE_TRAIT( context, Relation, Class) \
{::Interface::Traits< ::Interface::_##context::Context, ::Interface::Trait_Names::Relation##T, Class> trait;}


#include "Pair_Traits.hh"

#endif




