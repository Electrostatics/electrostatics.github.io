
ADD_TRAIT_NAME( Inner_Ref);
ADD_TRAIT_NAME( Inner_Const_Ref);

namespace Interface{

//####################################################
template< class T, size_t n>
struct Traits<  _Global::Context, Trait_Names::Inner_RefT, 
                UCSD_Bioeng::Small_Vector< T, n> >{
  typedef UCSD_Bioeng::Small_Vector< T, n>& Result;
  static const bool is_specialized = true;
  static const bool is_specialized_here = true;
  static const bool same_context = true;
};
  
template< class T, size_t n>
struct Traits<  _Global::Context, Trait_Names::Inner_Const_RefT, 
                const UCSD_Bioeng::Small_Vector< T, n> >{
  typedef const UCSD_Bioeng::Small_Vector< T, n>& Result;
  static const bool is_specialized = true;
  static const bool is_specialized_here = true;
  static const bool same_context = true;
};
  
}





