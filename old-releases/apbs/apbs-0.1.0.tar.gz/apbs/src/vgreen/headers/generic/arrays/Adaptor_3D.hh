#ifndef __ADAPTOR_3D_HH__
#define __ADAPTOR_3D_HH__

#include "../basic/Interface.hh"

ADD_TRAIT_NAME( Member);
ADD_TRAIT_NAME( Resize);
ADD_TRAIT_NAME( Inner_Ref);
ADD_TRAIT_NAME( Const_Inner_Ref);

namespace UCSD_Bioeng{

//########################################################
template< class A>
class Adaptor_3D{

public:
  typedef TRAIT( Member, A) Member;

  Adaptor_3D( A& _array): array(_array){
    _nx = _ny = _nz = 0;
  }

  void Resize( size_t ix, size_t iy, size_t iz){
    _nx = ix;
    _ny = iy;
    _nz = iz;
    nyz = _ny*_nz;
    size_t nxyz = nyz*_nx;
    FUNCTION( Resize, A)( array, nxyz);
  }

  size_t nx() const{
    return _nx;
  }
  size_t ny() const{
    return _ny;
  }
  size_t nz() const{
    return _nz;
  }

  const Member& operator()( size_t ix, size_t iy, size_t iz) const{
    Check_indices( ix,iy,iz);
    return array[ nyz*ix + _nz*iy + iz]; 
  }

  Member& operator()( size_t ix, size_t iy, size_t iz){
    Check_indices( ix,iy,iz);
    return array[ nyz*ix + _nz*iy + iz]; 
  }


private:
  void Check_indices( size_t ix, size_t iy, size_t iz) const{
    
    Assert_positive_debug( _nx - ix);
    Assert_positive_debug( _ny - iy);
    Assert_positive_debug( _nz - iz);
  }

  Adaptor_3D< A>& operator=( const Adaptor_3D<A>&);
  Adaptor_3D( const Adaptor_3D<A>&);

  TRAIT( Inner_Ref, A) array;
  size_t _nx,_ny,_nz, nyz;

};

//########################################################
template< class A>
class Adaptor_3D< const A>{

public:
  typedef TRAIT( Member, A) Member;

  Adaptor_3D( const A& _array): array(_array){
    _nx = _ny = _nz = 0;
  }

  void Resize( size_t ix, size_t iy, size_t iz){
    _nx = ix;
    _ny = iy;
    _nz = iz;
    nyz = _ny*_nz;
    size_t nxyz = nyz*_nx;
    FUNCTION( Resize, A)( array, nxyz);
  }

  size_t nx() const{
    return _nx;
  }
  size_t ny() const{
    return _ny;
  }
  size_t nz() const{
    return _nz;
  }

  const Member& operator()( size_t ix, size_t iy, size_t iz) const{
    Check_indices( ix,iy,iz);
    return array[ nyz*ix + _nz*iy + iz]; 
  }

private:
  void Check_indices( size_t ix, size_t iy, size_t iz) const{
    using namespace Interface;
    Assert_positive_debug( _nx - ix);
    Assert_positive_debug( _ny - iy);
    Assert_positive_debug( _nz - iz);
  }

  Adaptor_3D< A>& operator=( const Adaptor_3D<A>&);
  Adaptor_3D( const Adaptor_3D<A>&);

  TRAIT( Const_Inner_Ref, A) array;
  size_t _nx,_ny,_nz, nyz;

};

}

#endif







