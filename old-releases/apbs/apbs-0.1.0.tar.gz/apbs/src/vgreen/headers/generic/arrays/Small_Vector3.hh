#ifndef __SMALL_VECTOR3_HH__
#define __SMALL_VECTOR3_HH__

namespace UCSD_Bioeng{
//###################################
template< class T>
class Small_Vector< T, 3>{

public:
  typedef T Value;
  static const size_t n = 3;
  static const size_t size = n;
  typedef Small_Vector< T,n> Self;

  const T& operator[]( size_t i) const{
    Check_index(i);
    return data[i];
  }
  T &operator[]( size_t i){
    Check_index(i);
    return data[i];
  }

  void Zero(){
    FUNCTION( Zero, T)( data[0]);
    FUNCTION( Zero, T)( data[1]);
    FUNCTION( Zero, T)( data[2]);
  }

  Small_Vector(){}

  Small_Vector( const T& t0, const T& t1, const T& t2){
    data[0] = t0;
    data[1] = t1;
    data[2] = t2;
  }

  /*
  template< class V3>
  explicit Small_Vector( const V3& v){
    data[0] = Q::value( v, 0);
    data[1] = Q::value( v, 1);
    data[2] = Q::value( v, 2);
  }

  template< class V3>
  Self& operator=( const V3& _v){
    TRAIT( Inner_Const_Ref, V3) v(_v);
    data[0] = v[0];
    data[1] = v[1];
    data[2] = v[2];
    return *this;
  }    

  template< class V3>
  Self& operator+=( const V3& _v){
    TRAIT( Inner_Const_Ref, V3) v(_v);
    data[0] += v[0];
    data[1] += v[1];
    data[2] += v[2];
    return *this;
  }    

  template< class V3>
  Self& operator-=( const V3& _v){
    TRAIT( Inner_Const_Ref, V3) v(_v);
    data[0] -= v[0];
    data[1] -= v[1];
    data[2] -= v[2];
    return *this;
  }    

  template< class S>
  Self& operator*=( const S& s){
    Do_times_equal( s, TYPE( Shape, S)());
    return *this;
  }    

  template< class Stream>
  friend
  Stream& operator<<( Stream& s, const Small_Vector<T,n>& v){
    for( int i=0; i<n; i++)
      s << v[i] << " ";
    return s;
  }

  template< class Stream>
  friend
  Stream& operator>>( Stream& s, const Small_Vector<T,n>& v){
    for( int i=0; i<n; i++)
      s >> v[i];
    return s;
  }

  */

  //##################################################
private:
  void Check_index( size_t i) const{
    if (i >= n)
      Error1_debug( *this, "index out of range");
  }

  T data[n];
};

//#################################################
inline
double dot( const Small_Vector< double, 3>& a, 
	    const Small_Vector< double, 3>& b){
  
  return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}

}
#endif





