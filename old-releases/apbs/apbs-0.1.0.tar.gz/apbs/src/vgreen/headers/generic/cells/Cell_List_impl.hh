#include <float.h>
#include <generic/arrays/std_vector_Interface.hh>

namespace UCSD_Bioeng{

template< class Particles, class Local_Context>
Cell_List< Particles, Local_Context>::Cell_List(){

  _spacing = -1.0;
  dimensions_set = false;
  particles = NULL;
}


template< class Particles, class Local_Context>
inline
const Particles& Cell_List< Particles, Local_Context>::particle_list() const{

  return *particles;
}



template< class Particles, class Local_Context>
template< class _Position>
void Cell_List< Particles, Local_Context>::
Set_low_corner( const _Position& __low_corner){
  
  LTRAIT( Inner_Const_Ref, _Position) x( __low_corner);

  _low_corner[X] = x[X];
  _low_corner[Y] = x[Y];
  _low_corner[Z] = x[Z];
}


template< class Particles, class Local_Context>
void Cell_List< Particles, Local_Context>::
Set_low_corner( double x, double y, double z){
  
  _low_corner[X] = x;
  _low_corner[Y] = y;
  _low_corner[Z] = z;
}



template< class Particles, class Local_Context>
void Cell_List< Particles, Local_Context>::
Set_spacing( double h){

  Assert_positive( h);
  _spacing = h;
}

template< class Particles, class Local_Context>
inline
double Cell_List< Particles, Local_Context>::spacing() const{

  return _spacing;
}



template< class Particles, class Local_Context>
inline
void Cell_List< Particles, Local_Context>::Set_list( Particles& _particles){

  particles = &_particles;
}


template< class Particles, class Local_Context>
void Cell_List< Particles, Local_Context>::Set_dimensions( size_t ix, size_t iy, size_t iz){

  Assert_positive( ix);
  Assert_positive( iy);
  Assert_positive( iz);

  n_dim[X] = ix;
  n_dim[Y] = iy;
  n_dim[Z] = iz;

  nz = iz;
  nyz = iy*iz;
  nxyz = ix*iy*iz;

  dimensions_set = true;
}


template< class Particles, class Local_Context>
void Cell_List< Particles, Local_Context>::Set_default_corners_and_dimensions(){

  using namespace Interface;
  Assert_not_null( particles);
  Assert_positive( _spacing);

  const Small_Vector< double, 3> spacing_vector( _spacing, _spacing, _spacing);
 
  const double max_value = DBL_MAX; 

  Small_Vector< double, 3> min_pos( max_value, max_value, max_value);

  const double min_value = -DBL_MAX;

  Small_Vector< double, 3> max_pos( min_value, min_value, min_value);

  const size_t n = size();

  Const_Index i;
  Set_beginning( i);
  while( Not_at_end( i)){

    Small_Vector< double, 3> r;
    Get_position( i, r);
    
    if (r[X] < min_pos[X])
      min_pos[X] = r[X];
    if (r[Y] < min_pos[Y])
      min_pos[Y] = r[Y];
    if (r[Z] < min_pos[Z])
      min_pos[Z] = r[Z];
    
    if (r[X] > max_pos[X])
      max_pos[X] = r[X];
    if (r[Y] > max_pos[Y])
      max_pos[Y] = r[Y];
    if (r[Z] > max_pos[Z])
      max_pos[Z] = r[Z];
    Increment( i);
  }
  
  n_dim[X] = size_t(( max_pos[X] - min_pos[X] + spacing_vector[X])/_spacing);
  n_dim[Y] = size_t(( max_pos[Y] - min_pos[Y] + spacing_vector[Y])/_spacing);
  n_dim[Z] = size_t(( max_pos[Z] - min_pos[Z] + spacing_vector[Z])/_spacing);
  
  nz = n_dim[Z];
  nyz = n_dim[X]*n_dim[Y];
  nxyz = n_dim[X]*n_dim[Y]*n_dim[Z];
  dimensions_set = true;

  lengths[X] = n_dim[X]*_spacing;
  lengths[Y] = n_dim[Y]*_spacing;
  lengths[Z] = n_dim[Z]*_spacing;

  Small_Vector< double, 3> diff;

  diff[X] = lengths[X] - ( max_pos[X] - min_pos[X]);
  diff[Y] = lengths[Y] - ( max_pos[Y] - min_pos[Y]);
  diff[Z] = lengths[Z] - ( max_pos[Z] - min_pos[Z]);

  _low_corner[X]  = min_pos[X] - 0.5*diff[X];
  _low_corner[Y]  = min_pos[Y] - 0.5*diff[Y];
  _low_corner[Z]  = min_pos[Z] - 0.5*diff[Z];

  _high_corner[X] = max_pos[X] + 0.5*diff[X];
  _high_corner[Y] = max_pos[Y] + 0.5*diff[Y];
  _high_corner[Z] = max_pos[Z] + 0.5*diff[Z];
}



template< class Particles, class Local_Context>
template< class _Position>
inline
void 
Cell_List< Particles, Local_Context>::
Get_cell_center( size_t ix, size_t iy, size_t iz, _Position& center) const{

  LTRAIT( Inner_Ref, _Position) _center( center);

  Assert_positive_debug( n_dim[X] - ix);
  Assert_positive_debug( n_dim[Y] - iy);
  Assert_positive_debug( n_dim[Z] - iz);

  Small_Vector< double, 3> offset;
  offset[X] = (ix + 0.5)*_spacing;
  offset[Y] = (iy + 0.5)*_spacing;
  offset[Z] = (iz + 0.5)*_spacing;

  _center[X] = _low_corner[X] + offset[X];
  _center[Y] = _low_corner[Y] + offset[Y];
  _center[Z] = _low_corner[Z] + offset[Z];
}

template< class Particles, class Local_Context>
template< class _Position>
inline
void 
Cell_List< Particles, Local_Context>::
Get_cell_center( size_t i, _Position& center) const{
  
  Assert_positive_debug( nxyz - i);

  size_t ix,iy,iz;
  Get_cell_indices( i, ix,iy,iz);

  Get_cell_center( ix, iy, iz, center);
}



template< class Particles, class Local_Context>
inline
size_t
Cell_List< Particles, Local_Context>::indices_beginning( size_t i) const{

  return cell_beginnings[i];
}

template< class Particles, class Local_Context>
inline
size_t
Cell_List< Particles, Local_Context>::indices_end( size_t i) const{

  return cell_beginnings[i+1];
}

template< class Particles, class Local_Context>
inline
size_t
Cell_List< Particles, Local_Context>::
indices_beginning( size_t ix, size_t iy, size_t iz) const{

  return indices_beginning( cell_index( ix, iy, iz));
}

template< class Particles, class Local_Context>
inline
size_t
Cell_List< Particles, Local_Context>::
indices_end( size_t ix, size_t iy, size_t iz) const{

  return indices_end( cell_index( ix, iy, iz));
}


template< class Particles, class Local_Context>
template< class _Position>
size_t 
Cell_List< Particles, Local_Context>::cell_index( const _Position& _x) const{

  Assert_debug( dimensions_set);

  LTRAIT( Inner_Const_Ref, _Position) x(_x);

  const int ix = int( n_dim[X]*(( x[X] - _low_corner[X])/lengths[X]));
  const int iy = int( n_dim[Y]*(( x[Y] - _low_corner[Y])/lengths[Y]));
  const int iz = int( n_dim[Z]*(( x[Z] - _low_corner[Z])/lengths[Z]));

  if ((ix < 0 || ix >= n_dim[X]) || 
      (iy < 0 || iy >= n_dim[Y]) ||
      (iz < 0 || iz >= n_dim[Z])){
    return nxyz;
  }
  else
    return cell_index( ix,iy,iz);
}


template< class Particles, class Local_Context>
template< class _Position, class Indices>
void
Cell_List< Particles, Local_Context>::
Get_cell_indices( const _Position& _x, Indices& _indices) const{

  LTRAIT( Inner_Const_Ref, _Position) x(_x);
  LTRAIT( Inner_Ref, Indices) indices( _indices);

  const int ix = int( n_dim[X]*(( x[X] - _low_corner[X])/lengths[X]));
  const int iy = int( n_dim[Y]*(( x[Y] - _low_corner[Y])/lengths[Y]));
  const int iz = int( n_dim[Z]*(( x[Z] - _low_corner[Z])/lengths[Z]));

  indices[X] = ix;
  indices[Y] = iy;
  indices[Z] = iz;
}

template< class Particles, class Local_Context>
template< class _Position>
void
Cell_List< Particles, Local_Context>::
Get_cell_indices( const _Position& _x, size_t& ix, size_t& iy, size_t& iz) const{

  LTRAIT( Inner_Const_Ref, _Position) x(_x);

  ix = int( n_dim[X]*(( x[X] - _low_corner[X])/lengths[X]));
  iy = int( n_dim[Y]*(( x[Y] - _low_corner[Y])/lengths[Y]));
  iz = int( n_dim[Z]*(( x[Z] - _low_corner[Z])/lengths[Z]));
}

template< class Particles, class Local_Context>
inline
void
Cell_List< Particles, Local_Context>::
Get_cell_indices( size_t i, size_t& ix, size_t& iy, size_t& iz) const{

  ix = i/nyz;
  iy = (i - ix*nyz)/nz; 
  iz = i - ix*nyz - iy*nz;
}


template< class Particles, class Local_Context>
inline
size_t Cell_List< Particles, Local_Context>::n_in_x_direction() const{ 

  Assert_debug( dimensions_set);
  return n_dim[X];
}

template< class Particles, class Local_Context>
inline
size_t Cell_List< Particles, Local_Context>::n_in_y_direction() const{

  Assert_debug( dimensions_set);
  return n_dim[Y];
}

template< class Particles, class Local_Context>
inline
size_t Cell_List< Particles, Local_Context>::n_in_z_direction() const{

  Assert_debug( dimensions_set);
  return n_dim[Z];
}


template< class Particles, class Local_Context>
inline
size_t Cell_List< Particles, Local_Context>::
cell_index( size_t ix, size_t iy, size_t iz) const{

  Assert_debug( dimensions_set);
  Assert_positive_debug( n_dim[X] - ix);
  Assert_positive_debug( n_dim[Y] - iy);
  Assert_positive_debug( n_dim[Z] - iz);

  return iz + n_dim[Z]*iy + nyz*ix;
}


template< class Particles, class Local_Context>
void Cell_List< Particles, Local_Context>::Assert_readiness() const{

  Assert_not_null( particles);
  Assert_positive( _spacing);
  Assert( dimensions_set);
}


template< class Particles, class Local_Context>
inline
void Cell_List< Particles, Local_Context>::
Assert_readiness_debug() const{






}


template< class Particles, class Local_Context>
template< class _Position>
inline
void 
Cell_List< Particles, Local_Context>::
Get_low_corner( _Position& _x) const{

  LTRAIT( Inner_Ref, _Position) x(_x);
  x[0] = _low_corner[0];
  x[1] = _low_corner[1];
  x[2] = _low_corner[2];
}

template< class Particles, class Local_Context>
template< class _Position>
inline
void 
Cell_List< Particles, Local_Context>::
Get_high_corner( _Position& _x) const{

  LTRAIT( Inner_Ref, _Position) x(_x);
  x[0] = _high_corner[0];
  x[1] = _high_corner[1];
  x[2] = _high_corner[2];
}

template< class Particles, class Local_Context>
void Cell_List< Particles, Local_Context>::Update_cells(){

  Assert_readiness();

  cell_beginnings.resize( nxyz+1);
  lengths[X] = _spacing*n_dim[X];
  lengths[Y] = _spacing*n_dim[Y];
  lengths[Z] = _spacing*n_dim[Z];

  _high_corner[X] = _low_corner[X] + lengths[X];
  _high_corner[Y] = _low_corner[Y] + lengths[Y];
  _high_corner[Z] = _low_corner[Z] + lengths[Z];

  for( size_t i=(0); i<(nxyz+1); i++)
    cell_beginnings[i] = 0;
  
  size_t n = size();
  cell_beginnings[0] = 0;

  {
    Const_Index ip;
    Set_beginning( ip);
    while (Not_at_end( ip)){
      Small_Vector< double, 3> x;
      Get_position( ip, x);
      const size_t cell_i = cell_index( x);
      if (cell_i != nxyz)
	++cell_beginnings[ cell_i+1];
      Increment( ip);
    }
  }    

  for( size_t i=(1); i<(nxyz+1); i++)
    cell_beginnings[i] += cell_beginnings[i-1];
  
  pointers.resize( cell_beginnings[ nxyz]);
  
  for( size_t i = nxyz; i>=1; i--)
    cell_beginnings[i] = cell_beginnings[i-1];
  
  {
    Index ip;
    Set_beginning_nc( ip);
    while( Not_at_end_nc( ip)){
      Small_Vector< double, 3> x;
      Get_position( ip, x);
      const size_t cell_i = cell_index( x);
      if (cell_i != nxyz){
	pointers[ cell_beginnings[ cell_i+1]] = pointer( ip);
	++cell_beginnings[ cell_i+1];
      }
      Increment_nc( ip);
    }
  }
}

template< class Particles, class Local_Context>
inline
size_t 
Cell_List< Particles, Local_Context>::n_in_cell( size_t i) const{

  return cell_beginnings[i+1] - cell_beginnings[i];
}

template< class Particles, class Local_Context>
inline
size_t 
Cell_List< Particles, Local_Context>::n_in_cell( size_t ix,
						size_t iy,
						size_t iz) const{

  return n_in_cell( cell_index( ix,iy,iz));
}


template< class Particles, class Local_Context>
inline
Cell_List< Particles, Local_Context>::Const_Pointer
Cell_List< Particles, Local_Context>::
particle_pointer_const( size_t ix, size_t iy, size_t iz, size_t ip) const{

  return particle_pointer_const( cell_index( ix, iy, iz), ip);
}

template< class Particles, class Local_Context>
inline
Cell_List< Particles, Local_Context>::Const_Pointer
Cell_List< Particles, Local_Context>::
particle_pointer_const( size_t ic, size_t ip) const{

  return pointers[ cell_beginnings[ic] + ip];
}


template< class Particles, class Local_Context>
inline
Cell_List< Particles, Local_Context>::Pointer
Cell_List< Particles, Local_Context>::
particle_pointer( size_t ic, size_t ip){

  return pointers[ cell_beginnings[ic] + ip];
}

template< class Particles, class Local_Context>
inline
Cell_List< Particles, Local_Context>::Pointer
Cell_List< Particles, Local_Context>::
particle_pointer( size_t ix, size_t iy, size_t iz, size_t ip){

  return particle_pointer( cell_index( ix, iy, iz), ip);
}


template< class Particles, class Local_Context>
template< class Functor>
void Cell_List< Particles, Local_Context>::Apply_to_pairs( Functor& f){

  const size_t nx = n_in_x_direction();
  const size_t ny = n_in_y_direction();
  const size_t nz = n_in_z_direction();

  for( size_t ix=(0); ix<(nx); ix++){
    const size_t low_x = (ix == 0) ? 0 : ix-1;
    const size_t high_x = min( nx, ix+2);

    for( size_t iy=(0); iy<(ny); iy++) {
      const size_t low_y = (iy == 0) ? 0 : iy-1;
      const size_t high_y = min( ny, iy+2);

      for( size_t iz=(0); iz<(nz); iz++){
	const size_t low_z = (iz == 0) ? 0 : iz-1;
	const size_t high_z = min( nz, iz+2);
	const size_t ic = cell_index( ix, iy, iz);
	const size_t npi = n_in_cell( ic);

	for( size_t jx=(low_x); jx<(high_x); jx++){
	  for( size_t jy=(low_y); jy<(high_y); jy++){
	    for( size_t jz=(low_z); jz<(high_z); jz++){
	      const size_t jc = cell_index( jx, jy, jz);
	      if (jc > ic)
		continue;

	      if (ic == jc){
		for( size_t ip=(0); ip<(npi); ip++) for( size_t jp=(0); jp<(ip); jp++){
		  Apply( f, particle_pointer( ic, ip), 
			    particle_pointer( ic, jp));
		}
	      }
	      else{
		const size_t npj = n_in_cell( jc);
		for( size_t ip=(0); ip<(npi); ip++) for( size_t jp=(0); jp<(npj); jp++){
		  Apply( f, particle_pointer( ic, ip), 
			    particle_pointer( jc, jp));
		}
	      }
	    }
	  }
	}
      }
    }
  }   
}


template< class Particles, class Local_Context>
template< class Functor>
void Cell_List< Particles, Local_Context>::Apply_to_pairs( Functor& f) const{

  

  const size_t nx = n_in_x_direction();
  const size_t ny = n_in_y_direction();
  const size_t nz = n_in_z_direction();

  for( size_t ix=(0); ix<(nx); ix++){
    const size_t low_x = (ix == 0) ? 0 : ix-1;
    const size_t high_x = min( nx, ix+2);

    for( size_t iy=(0); iy<(ny); iy++) {
      const size_t low_y = (iy == 0) ? 0 : iy-1;
      const size_t high_y = min( ny, iy+2);

      for( size_t iz=(0); iz<(nz); iz++){
	const size_t low_z = (iz == 0) ? 0 : iz-1;
	const size_t high_z = min( nz, iz+2);
	const size_t ic = cell_index( ix, iy, iz);
	const size_t npi = n_in_cell( ic);

	for( size_t jx=(low_x); jx<(high_x); jx++){
	  for( size_t jy=(low_y); jy<(high_y); jy++){
	    for( size_t jz=(low_z); jz<(high_z); jz++){
	      const size_t jc = cell_index( jx, jy, jz);
	      if (jc > ic)
		continue;
	      
	      if (ic == jc){
		for( size_t ip=(0); ip<(npi); ip++) for( size_t jp=(0); jp<(ip); jp++)
		  Apply_const( f, particle_pointer( ic, ip), 
			          particle_pointer( ic, jp));
	      }
	      else{
		const size_t npj = n_in_cell( jc);
		for( size_t ip=(0); ip<(npi); ip++) for( size_t jp=(0); jp<(npj); jp++)
		  Apply_const( f, particle_pointer( ic, ip), 
			          particle_pointer( jc, jp));
	      }
	    }
	  }
	}
      }
    }
  }   
}


template< class Particles, class Local_Context>
template< class Functor>
void Cell_List< Particles, Local_Context>::Apply_to_neighbors( size_t ic,
							       Functor& f){

  

  const size_t nx = n_in_x_direction();
  const size_t ny = n_in_y_direction();
  const size_t nz = n_in_z_direction();

  size_t ix,iy,iz;
  Get_cell_indices( ic, ix,iy,iz);

  const size_t low_x = (ix == 0) ? 0 : ix-1;
  const size_t high_x = min( nx, ix+2);

  const size_t low_y = (iy == 0) ? 0 : iy-1;
  const size_t high_y = min( ny, iy+2);

  const size_t low_z = (iz == 0) ? 0 : iz-1;
  const size_t high_z = min( nz, iz+2);

  for( size_t jx=(low_x); jx<(high_x); jx++){

    for( size_t jy=(low_y); jy<(high_y); jy++) {

      for( size_t jz=(low_z); jz<(high_z); jz++){
	const size_t jc = cell_index( jx, jy, jz);

	const size_t npj = n_in_cell( jc);
	for( size_t jp=(0); jp<(npj); jp++){
	  Apply( f, particle_pointer( jc, jp));
	}
      }
    }   
  }
}

template< class Particles, class Local_Context>
template< class Functor>
void Cell_List< Particles, Local_Context>::Apply_to_neighbors( size_t i_cell,
							       Functor& f) const {

  

  const size_t nx = n_in_x_direction();
  const size_t ny = n_in_y_direction();
  const size_t nz = n_in_z_direction();

  size_t ix,iy,iz;
  Get_cell_indices( i_cell, ix,iy,iz);

  const size_t low_x = (ix == 0) ? 0 : ix-1;
  const size_t high_x = min( nx, ix+2);

  const size_t low_y = (iy == 0) ? 0 : iy-1;
  const size_t high_y = min( ny, iy+2);

  const size_t low_z = (iz == 0) ? 0 : iz-1;
  const size_t high_z = min( nz, iz+2);

  for( size_t jx=(low_x); jx<(high_x); jx++){

    for( size_t jy=(low_y); jy<(high_y); jy++) {

      for( size_t jz=(low_z); jz<(high_z); jz++){
	const size_t jc = cell_index( jx, jy, jz);

	const size_t npj = n_in_cell( jc);
	for( size_t jp=(0); jp<(npj); jp++){		   
	  Apply_const( f, particle_pointer_const( jc, jp));
	}
      }
    }   
  }
}

}











