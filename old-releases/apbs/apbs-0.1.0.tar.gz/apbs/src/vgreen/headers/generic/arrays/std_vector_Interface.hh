#ifndef __STD_VECTOR_INTERFACE_HH__
#define __STD_VECTOR_INTERFACE_HH__

#include <vector>
#include "../checkers/Error.hh"

ADD_TRAIT_NAME( Member);
ADD_TRAIT_NAME( Index);
ADD_TRAIT_NAME( Const_Index);
ADD_TRAIT_NAME( Const_Forward_Index);
ADD_TRAIT_NAME( Forward_Index);
ADD_TRAIT_NAME( Forward_Iterator);
ADD_TRAIT_NAME( Set_beginning);
ADD_TRAIT_NAME( Increment);
ADD_TRAIT_NAME( Not_at_end);
ADD_TRAIT_NAME( member);
ADD_TRAIT_NAME( size);
ADD_TRAIT_NAME( Pointer);
ADD_TRAIT_NAME( pointer);
ADD_TRAIT_NAME( Const_Pointer);

namespace UCSD_Bioeng{

template< class T>
inline
typename std::vector<T>::iterator pointer( std::vector<T>& v, typename std::vector<T>::iterator p){
  Assert_debug( v.begin() <= p && p < v.end());
  return p;
}

template< class T>
inline
typename std::vector<T>::const_iterator pointer_const( std::vector<T>& v, typename std::vector<T>::const_iterator p){
  Assert_debug( v.begin() <= p && p < v.end());
  return p;

}

template< class T>
inline
typename std::vector<T>::const_iterator pointer( const std::vector<T>& v, typename std::vector<T>::const_iterator p){
  Assert_debug( v.begin() <= p && p < v.end());
  return p;
}

template< class T>
inline
typename std::vector<T>::const_iterator pointer_const( const std::vector<T>& v, typename std::vector<T>::const_iterator p){
  Assert_debug( v.begin() <= p && p < v.end());
  return p;
}


template< class T>
inline
void Set_beginning( std::vector<T>& v, typename std::vector<T>::iterator& i){
  i = v.begin();
}

template< class T>
inline
void Set_beginning( const std::vector<T>& v, typename std::vector<T>::const_iterator& i){
  i = v.begin();
}

template< class T>
inline
void Reset( std::vector<T>& v, typename std::vector<T>::iterator& i){
  i = v.begin();
  --i;
}

template< class T>
inline
void Increment( std::vector<T>& v, typename std::vector<T>::iterator& i){

  Assert_debug( v.begin() <= i && i < v.end());
  ++i;
}

template< class T>
inline
void Increment( const std::vector<T>& v, typename std::vector<T>::const_iterator& i){

  Assert_debug( v.begin() <= i && i < v.end());
  ++i;
}

template< class T>
inline
bool Increment_and_test( const std::vector<T>& v, typename std::vector<T>::const_iterator& i){

  ++i;
  Assert_debug( v.begin() <= i && i < v.end());
  return i != v.end();
}

template< class T>
inline
bool Increment_and_test( std::vector<T>& v, typename std::vector<T>::iterator& i){

  ++i;
  Assert_debug( v.begin() <= i && i < v.end());
  return i != v.end();
}


template< class T>
inline
bool Not_at_end( const std::vector<T>& v, typename std::vector<T>::const_iterator i){
  Assert_debug( v.begin() <= i && v.begin() <= v.end());
  return i != v.end();
}

template< class T>
inline
bool Not_at_end( std::vector<T>& v, typename std::vector<T>::iterator i){
  Assert_debug( v.begin() <= i && v.begin() <= v.end());
  return i != v.end();
}

template< class T>
inline
T& member( std::vector<T>& v, typename std::vector<T>::iterator i){

  Assert_debug( v.begin() <= i && i < v.end());
  return *i;
}


template< class T>
inline
const T& member( const std::vector<T>& v, typename std::vector<T>::const_iterator i){

  Assert_debug( v.begin() <= i && i < v.end());
  return *i;
}

template< class T>
inline
size_t size( const std::vector<T>& v){
  return v.size();
}

template< class T>
inline
void Resize( std::vector<T>& v, size_t n){
  v.resize( n);
}

}

SET_TEMPLATED_TRAIT( Member, const std::vector, T, const T);
SET_TEMPLATED_TRAIT( Member, std::vector, T, T);

SET_TEMPLATED_TRAIT( Index, std::vector, T, typename std::vector<T>::iterator);
SET_TEMPLATED_TRAIT( Index, const std::vector, T, typename std::vector<T>::const_iterator);
SET_TEMPLATED_TRAIT( Const_Index, const std::vector, T, typename std::vector<T>::const_iterator);

SET_TEMPLATED_TRAIT( Pointer, std::vector, T, typename std::vector<T>::iterator);
SET_TEMPLATED_TRAIT( Pointer, const std::vector, T, typename std::vector<T>::const_iterator);
SET_TEMPLATED_TRAIT( Const_Pointer, const std::vector, T, typename std::vector<T>::const_iterator);

SET_TEMPLATED_TRAIT( Forward_Index, std::vector, T, typename std::vector<T>::iterator);
SET_TEMPLATED_TRAIT( Forward_Index, const std::vector, T, typename std::vector<T>::const_iterator);
SET_TEMPLATED_TRAIT( Const_Forward_Index, const std::vector, T, typename std::vector<T>::const_iterator);

SET_FUNCTION_TEMPLATED_TRAIT( Set_beginning, const std::vector, UCSD_Bioeng::Set_beginning);
SET_FUNCTION_TEMPLATED_TRAIT( Set_beginning, std::vector, UCSD_Bioeng::Set_beginning);
SET_FUNCTION_TEMPLATED_TRAIT( Increment, const std::vector, UCSD_Bioeng::Increment);
SET_FUNCTION_TEMPLATED_TRAIT( Increment, std::vector, UCSD_Bioeng::Increment);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( Increment_and_test, const std::vector, UCSD_Bioeng::Increment_and_test, bool);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( Increment_and_test, std::vector, UCSD_Bioeng::Increment_and_test, bool);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( Not_at_end, const std::vector, UCSD_Bioeng::Not_at_end, bool);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( Not_at_end, std::vector, UCSD_Bioeng::Not_at_end, bool);

SET_FUNCTION_W_RET_TEMPLATED_TRAIT( member, std::vector, UCSD_Bioeng::member, T&);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( member, const std::vector, UCSD_Bioeng::member, const T&);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( size, const std::vector, UCSD_Bioeng::size, size_t);

SET_FUNCTION_W_RET_TEMPLATED_TRAIT( pointer, std::vector, UCSD_Bioeng::pointer, typename std::vector<T>::iterator);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( pointer, const std::vector, UCSD_Bioeng::pointer, typename std::vector<T>::const_iterator);
SET_FUNCTION_W_RET_TEMPLATED_TRAIT( pointer_const, const std::vector, UCSD_Bioeng::pointer_const, typename std::vector<T>::const_iterator);

SET_TEMPLATED_TRAIT( Inner_Ref, std::vector, T, TEMPLATE1( std::vector, T)&);
SET_TEMPLATED_TRAIT( Inner_Ref, const std::vector, T, TEMPLATE1( const std::vector, T)&);
SET_TEMPLATED_TRAIT( Inner_Const_Ref, const std::vector, T, TEMPLATE1( const std::vector, T)&);

SET_FUNCTION_TEMPLATED_TRAIT( Resize, std::vector, UCSD_Bioeng::Resize);
SET_FUNCTION_TEMPLATED_TRAIT( Reset, std::vector, UCSD_Bioeng::Reset);


namespace UCSD_Bioeng{
//######################################################################
template< class T1, class T2>
void Set( std::vector<T1>& z, const std::vector<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Set( (*zp), (*xp));
    ++xp; ++xp;
  }
}


template< class T1, class T2, class T3>
void Set_a( std::vector<T1>& z, 
	    const std::vector<T2>& x, const std::vector<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  std::vector<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Set_a( (*zp), (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S, class T2>
void Set_m( std::vector<T1>& z, const S& a, const std::vector<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Set_m( (*zp), a, (*xp));
    ++xp; ++xp;
  }
}

template< class T1, class S, class T2, class T3>
void Set_ma( std::vector<T1>& z, const S& a, 
	    const std::vector<T2>& x, const std::vector<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  std::vector<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Set_ma( (*zp), s, (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S1, class T2, class S2, class T3>
void Set_mam( std::vector<T1>& z, 
	      const S1& a, const std::vector<T2>& x, 
	      const S2& b, const std::vector<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  std::vector<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Set_mam( (*zp), s, (*xp), b, (*yp));
    ++xp; ++xp; ++yp;
  }
}

//######################################################################
template< class T1, class T2>
void Add( std::vector<T1>& z, const std::vector<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Add( (*zp), (*xp));
    ++xp; ++xp;
  }
}


template< class T1, class T2, class T3>
void Add_a( std::vector<T1>& z, 
	    const std::vector<T2>& x, const std::vector<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  std::vector<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Add_a( (*zp), (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S, class T2>
void Add_m( std::vector<T1>& z, const S& a, const std::vector<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Add_m( (*zp), a, (*xp));
    ++xp; ++xp;
  }
}

template< class T1, class S, class T2, class T3>
void Add_ma( std::vector<T1>& z, const S& a, 
	    const std::vector<T2>& x, const std::vector<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  std::vector<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Add_ma( (*zp), s, (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S1, class T2, class S2, class T3>
void Add_mam( std::vector<T1>& z, 
	      const S1& a, const std::vector<T2>& x, 
	      const S2& b, const std::vector<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  std::vector<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Add_mam( (*zp), s, (*xp), b, (*yp));
    ++xp; ++xp; ++yp;
  }
}

//######################################################################
template< class T1, class T2>
void Subtract( std::vector<T1>& z, const std::vector<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Subtract( (*zp), (*xp));
    ++xp; ++xp;
  }
}


template< class T1, class T2, class T3>
void Subtract_a( std::vector<T1>& z, 
	    const std::vector<T2>& x, const std::vector<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  std::vector<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Subtract_a( (*zp), (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S, class T2>
void Subtract_m( std::vector<T1>& z, const S& a, const std::vector<T2>& x){
  
  Assert_same_sizes_debug( z, x);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  
  while( zp < ze){
    Subtract_m( (*zp), a, (*xp));
    ++xp; ++xp;
  }
}

template< class T1, class S, class T2, class T3>
void Subtract_ma( std::vector<T1>& z, const S& a, 
	    const std::vector<T2>& x, const std::vector<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  std::vector<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Subtract_ma( (*zp), s, (*xp), (*yp));
    ++xp; ++xp; ++yp;
  }
}

template< class T1, class S1, class T2, class S2, class T3>
void Subtract_mam( std::vector<T1>& z, 
	      const S1& a, const std::vector<T2>& x, 
	      const S2& b, const std::vector<T3>& y){
  
  Assert_same_sizes_debug( z, x);
  Assert_same_sizes_debug( z, y);
  std::vector<T1>::iterator zp = z.begin();
  const std::vector<T1>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();
  std::vector<T3>::const_iterator yp = y.begin();
  
  while( zp < ze){
    Subtract_mam( (*zp), a, (*xp), b, (*yp));
    ++xp; ++xp; ++yp;
  }
}

//######################################################
template< class T, class S>
void Multiply( std::vector<T>& z, const S& a){

  typename std::vector<T>::iterator zp = z.begin();
  const typename std::vector<T>::iterator ze = z.end();

  while( zp < ze){
    Multiply( (*zp), a);
    ++zp;
  }
}

/* trouble with gcc
template< class T1, class T2, class S1, class S2>
void Set_f( std::vector<T1>& z, S1 (*f)( S2), const std::vector<T2>& x){

  typename std::vector<T>::iterator zp = z.begin();
  const typename std::vector<T>::iterator ze = z.end();
  std::vector<T2>::const_iterator xp = x.begin();

  while( zp < ze){
    Set_f( (*zp), f, (*xp));
    ++zp; ++xp;
  }
}
*/

}

#endif






