#ifndef __COULOMBIC_CELL_MULTIPOLE_CALCULATOR_VATOM_HH__
#define __COULOMBIC_CELL_MULTIPOLE_CALCULATOR_VATOM_HH__

#include <generic/arrays/Small_Pointer_Wrapper.hh>
#include <generic/arrays/Pointer_Wrapper.hh>
#include <generic/cells/multipole/coulombic/Coulombic_Cell_Multipole_Calculator.hh>

class Coulombic_Cell_Multipole_Calculator_Vatom: 
  private ::UCSD_Bioeng::Coulombic_Cell_Multipole_Calculator< ::UCSD_Bioeng::Pointer_Wrapper< const Vatom> >{

public:

  // Associate the object with a list of atoms
  void Set_list( const Vatom*, size_t n);

  // Set the size of the cubic cells
  void Set_cell_spacing( double);

  // Set the number of cells in each direction
  void Set_dimensions( size_t, size_t, size_t);

  // Set the low corner of the array of cells
  void Set_low_corner( double, double, double);

  // Call this whenever you change the geometry by 
  // calling any of the preceeding 3 functions
  void Update_geometry();

  // Call whenever any of the particles might have changed
  // cells
  void Update_particles();

  // Computes and stores the part of the electric field
  // resulting from atoms in non-nearest neighbor cells
  void Compute_far_fields();
  
  // If Update_particles and Compute_far_fields have
  // been called and the atom positions haven't changed,
  // then you can call these next 2 functions any number
  // of times 
  double potential( const double* position) const;
  void Get_electric_field( const double* position, double* field) const;

  //##############################
private:
  typedef UCSD_Bioeng::Coulombic_Cell_Multipole_Calculator< ::UCSD_Bioeng::Pointer_Wrapper< const Vatom> > Superclass;

  UCSD_Bioeng::Pointer_Wrapper< const Vatom> atoms;
};

inline
void Coulombic_Cell_Multipole_Calculator_Vatom::Get_electric_field( const double* x, double* E) const{
  ::UCSD_Bioeng::Small_Pointer_Wrapper< double, 3> EE( E);
  const ::UCSD_Bioeng::Small_Pointer_Wrapper< const double, 3> xx( x);
  Superclass::Get_electric_field( xx, EE);
}

inline
double Coulombic_Cell_Multipole_Calculator_Vatom::potential( const double* x) const{
  return Superclass::potential( ::UCSD_Bioeng::Small_Pointer_Wrapper< const double, 3>( x));
}

inline
void Coulombic_Cell_Multipole_Calculator_Vatom::Compute_far_fields(){
  Superclass::Compute_far_fields();
}

inline
void Coulombic_Cell_Multipole_Calculator_Vatom::Update_geometry(){
  Superclass::Update_geometry();
}

inline
void Coulombic_Cell_Multipole_Calculator_Vatom::Update_particles(){
  Superclass::Update_particles();
}

inline
void Coulombic_Cell_Multipole_Calculator_Vatom::Set_low_corner( double x, double y, double z){
  Superclass::Set_low_corner( x, y, z);
}

inline
void Coulombic_Cell_Multipole_Calculator_Vatom::Set_dimensions( size_t ix, size_t iy, size_t iz){
  Superclass::Set_dimensions( ix, iy, iz);
}

inline
void Coulombic_Cell_Multipole_Calculator_Vatom::Set_cell_spacing( double s){
  Superclass::Set_cell_spacing( s);
}

inline
void Coulombic_Cell_Multipole_Calculator_Vatom::Set_list( const Vatom* in_atoms, size_t n_atoms){
  atoms.Reset( in_atoms, n_atoms);
  Superclass::Set_list( atoms);
}

//#################################################################
namespace UCSD_Bioeng{
namespace Nathan_Baker{

typedef Pointer_Wrapper< const Vatom> Atoms;

inline 
double charge( const Atoms& atoms, 
	       const Vatom* p){
  return p->charge;
}

inline
void Get_position( const Atoms& atoms, 
		   const Vatom* p, Small_Vector< double, 3>& x){

  x[0] = p->position[0];
  x[1] = p->position[1];
  x[2] = p->position[2];
}
}}

SET_FUNCTION_W_RET_TRAIT( charge, const UCSD_Bioeng::Nathan_Baker::Atoms, 
			  UCSD_Bioeng::Nathan_Baker::charge, double);

SET_FUNCTION_TRAIT( Get_position, const UCSD_Bioeng::Nathan_Baker::Atoms, 
		    UCSD_Bioeng::Nathan_Baker::Get_position);


#endif









