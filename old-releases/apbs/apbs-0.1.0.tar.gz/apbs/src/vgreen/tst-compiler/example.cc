typedef struct Vatom {
  
  double position[3];   /* Atomic position */
  double radius;        /* Atomic radius   */
  double charge;        /* Atomic charge   */
  int partID;           /* Partition ID    */
  
} Vatom;


#include "Coulombic_Cell_Multipole_Calculator_Vatom.hh"

#define FOR( i, m, n) for( size_t i=m; i<n; i++)

//###############################
inline
double randomm(){
  return double(rand())/RAND_MAX;
}

//#####################################
int main(){
  srand( 12121216);

  const size_t L = 16;
  const size_t n = 8*L*L*L;

  const double h = 1.0;

  Vatom* atoms = new Vatom [n];

  FOR( i, 0, n){
    atoms[i].position[0] = L*randomm();
    atoms[i].position[1] = L*randomm();
    atoms[i].position[2] = L*randomm();
    atoms[i].charge = 1.0;
  }

  const Vatom* catoms = atoms;

  Coulombic_Cell_Multipole_Calculator_Vatom ccmc;
  ccmc.Set_list( catoms, n);
  ccmc.Set_cell_spacing( h);
  ccmc.Set_dimensions( L,L,L);
  ccmc.Set_low_corner( 0.0, 0.0, 0.0);
  ccmc.Update_geometry();

  ccmc.Update_particles();
  ccmc.Compute_far_fields();

  FOR( i_test, 0, 100){
    double x[3];
    x[0] = L*h*randomm();
    x[1] = L*h*randomm();
    x[2] = L*h*randomm();
    printf( "%f\n", ccmc.potential( x));
    
    double F[3];
    ccmc.Get_electric_field( x, F);
    printf( "%f %f %f\n\n", F[0], F[1], F[2]);
  }
}








