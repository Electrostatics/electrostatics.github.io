/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     acconfig.h
//
// Purpose:  Generates the main configuration header file "config.h" for MC.
//
// Notes:    See the comments at the top of the file "configure.in" for
//           an outline of the sequence of steps that turns acconfig.h
//           into config.h.in and then eventually into config.h.
//
//           The final autoconf generated "config.h" attempts to handle
//           things like correct header file layout for various UNIX-like
//           machines, giving access to several things beyond ISO C/C++,
//           including BSD Signals, UNIX Domain sockets, INET TCP/IP sockets,
//           and the WINSOCK implementation of INET TCP/IP sockets.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */

#ifndef _CONFIG_H_
#define _CONFIG_H_
@TOP@

/* Name of package */
#undef PACKAGE

/* Version number of package */
#undef VERSION

/* Does the EMBED macro for embedding rcsid symbols into binaries work? */
#undef HAVE_EMBED

/* Do I have MPI header? */
#undef HAVE_MPI_H

/* Do I have FETK? */
#undef HAVE_FETK_H


/* Do I have PMG? */
#undef USE_PMG
#undef USE_CXX_FMM

/* F77 name mangling */
#undef VF77_NOUNDERSCORE
#undef VF77_ONEUNDERSCORE
#undef VF77_UPPERCASE
#undef VF77_LOWERCASE

@BOTTOM@

#define VHACK

#if defined(VF77_UPPERCASE)
#   if defined(VF77_NOUNDERSCORE)
#       define VF77_MANGLE(name,NAME) NAME
#   endif
#   if defined(VF77_ONEUNDERSCORE)
#       define VF77_MANGLE(name,NAME) NAME ## _
#   endif
#else
#   if defined(VF77_NOUNDERSCORE)
#       define VF77_MANGLE(name,NAME) name
#   endif
#   if defined(VF77_ONEUNDERSCORE)
#       define VF77_MANGLE(name,NAME) name ## _
#   endif
#endif


#endif /* _CONFIG_H_ */

