/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
///
/// rcsid="$Id: read.c,v 1.6 2001/08/29 19:30:47 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     read.c
//
// Purpose:  Test program for reading OpenDX format regular grid data.
//
// Author:   Nathan Baker
//
// rcsid="$Id: read.c,v 1.6 2001/08/29 19:30:47 apbs Exp $"
/////////////////////////////////////////////////////////////////////////// */

#include "apbscfg.h"
#include "apbs/apbs.h"  

VEMBED(rcsid="$Id: read.c,v 1.6 2001/08/29 19:30:47 apbs Exp $")

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    int nx, ny, nz;
    double *data = VNULL;
    double hy, hx, hzed, xmin, ymin, zmin;
    char *inpath = VNULL;
    char *outpath = "check.dx";
    char *usage = "\n  read file.dx\n"; 
 
    /* *************** CHECK INVOCATION ******************* */
    Vio_start();
    if (argc != 2) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected 2.\n\n",argc);
        Vnm_print(2,"%s\n", usage);
        return -1;
    } else {
        inpath = argv[1];
    }

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(1, "main:  Reading data from %s...\n", inpath);
    Vpmg_readDX("FILE", "ASC", VNULL, inpath, 
      &nx, &ny, &nz, &hx, &hy, &hzed, &xmin, &ymin, &zmin, &data);
    Vnm_print(1, "main:     nx = %d, ny = %d, nz = %d\n", 
      nx, ny, nz);
    Vnm_print(1, "main:     hx = %g, hy = %g, hz = %g\n", 
      hx, hy, hzed);
    Vnm_print(1, "main:     xmin = %g, ymin = %g, zmin = %g\n", 
      xmin, ymin, zmin);
    Vnm_print(1, "main:  Writing data to %s for check...\n", outpath);
    Vpmg_writeDX2("FILE", "ASC", VNULL, outpath, "TEST", data,
      hx, hy, hzed, nx, ny, nz, xmin, ymin, zmin);

    return 0;
}
