#ifndef __ERROR_HH__
#define __ERROR_HH__

#include <stdlib.h>
#include <stdio.h>
#include "../arrays/Scalars.hh"

ADD_TRAIT_NAME( Is_positive);
ADD_TRAIT_NAME( Is_negative);
ADD_TRAIT_NAME( Are_unequal);
ADD_TRAIT_NAME( Is_zero);
ADD_TRAIT_NAME( Is_null);
ADD_TRAIT_NAME( Is_NaN);
ADD_TRAIT_NAME( size);

namespace UCSD_Bioeng{

template< class Type1>
inline
void Error1( const Type1 &t1, const char *message){
  
  fprintf( stderr,  "%s\n", const_cast< char *>(message));
  abort();
}


template< class Type1>
inline
void Error1_debug( const Type1 &t1, const char *message){
  
#ifdef DEBUG
  fprintf( stderr,  "%s\n", const_cast< char *>(message));
  abort();
#endif
}

template< class Type1, class Type2>
inline
void Error2( const Type1 &t1, const Type2 &t2, const char *message){
  
  fprintf( stderr,  "%s\n", const_cast< char *>(message));
  abort();
}

template< class Type1, class Type2>
inline
void Error2_debug( const Type1 &t1, const Type2 &t2, const char *message){
  
#ifdef DEBUG
  fprintf( stderr,  "%s\n", const_cast< char *>(message));
  abort();
#endif
}


inline
void Error2_debug( const char *t1, const char *t2, 
		   const char *message){
  
#ifdef DEBUG
  fprintf( stderr,  "%s %s %s\n", 
	  const_cast< char *>(t1),
	  const_cast< char *>(t2),
	  const_cast< char *>(message));
  abort();
#endif
}

inline
void Error2( const char *t1, const char *t2, 
	     const char *message){
  
  fprintf( stderr,  "%s %s %s\n", 
	  const_cast< char *>(t1),
	  const_cast< char *>(t2),
	  const_cast< char *>(message));
  abort();
}

inline
void Assert( bool tf){
  if (!tf)
    Error1( tf, "Assertion failed");
}

inline
void Assert_debug( bool tf){
  if (!tf)
    Error1_debug( tf, "Assertion failed");
}


template< class T>
inline
void Assert_positive( const T& t){

  if (!FUNCTION( Is_positive, T)(t))
    Error1( t, "quantity not positive");
}

template< class T>
inline
void Assert_not_zero( const T& t){

  if (!FUNCTION( Is_zero, T)(t))
    Error1( t, "quantity zero");
}

template< class T>
inline
void Assert_positive_debug( const T& t){

  if (!FUNCTION( Is_positive, T)(t))
    Error1_debug( t, "quantity not positive");
}

template< class T1, class T2>
inline
void Assert_are_equal( const T1& t1, const T2& t2){

  if (FUNCTION2( Are_unequal, T1, T2)( t1, t2))
    Error2( t1, t2, "quantities not equal");
}

template< class T1, class T2>
inline
  void Assert_are_equal_debug( const T1& t1, const T2& t2){
    
  if (FUNCTION2( Are_unequal, T1, T2)( t1, t2))
    Error2_debug( t1, t2, "quantities not equal");
}

template< class T>
inline
void Assert_zero_debug( const T& t){

  if (!FUNCTION( Is_zero, T)(t))
    Error1_debug( t, "quantity not zero");
}


template< class T>
inline
void Assert( bool t){

  if (!t)
    Error1( t, "statement not true");
}

template< class T>
inline
void Assert_debug( bool t){

  if (!t)
    Error1_debug( t, "statement not true");
}

template< class T>
inline
void Assert_not_null( const T* t){

  if (FUNCTION( Is_null, const T*)(t))
    Error1( t, "null value encountered");
}

template< class T>
inline
void Assert_not_null_debug( const T& t){

  if (FUNCTION( Is_null, T)(t))
    Error1_debug( t, "null value encountered");
}

template< class T>
inline
void Assert_no_NaN( const T& t){

  if (FUNCTION( Is_NaN, T)(t))
    Error1( t, "NaN encountered");
}

template< class T>
inline
void Assert_no_NaN_debug( const T& t){

  if (FUNCTION( Is_NaN, T)(t))
    Error1_debug( t, "NaN encountered");
}

template< class V1, class V2>
inline
void Assert_same_sizes( const V1& v1, const V2& v2){

  if (FUNCTION( size, V1)(v1) != FUNCTION( size, V2)(v2))
    Error2( v1, v2, "sizes of containers do not agree");
}

template< class V1, class V2>
inline
void Assert_same_sizes_debug( const V1& v1, const V2& v2){

  if (FUNCTION( size, V1)(v1) != FUNCTION( size, V2)(v2))
    Error2_debug( v1, v2, "sizes of containers do not agree");
}

}

#endif







