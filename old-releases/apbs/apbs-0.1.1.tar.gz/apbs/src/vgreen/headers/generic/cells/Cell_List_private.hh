private:
  void Test_templates() const;

  int min( int i, int j) const{
    return (i<j) ? i : j;
  }

  void Get_position( Const_Index ip, Inner_Position& x) const{
    Const_Pointer p = pointer_const( ip);
    LFUNCTION( Get_position, Particles)( *particles, p, x); 
  }

  void Set_beginning( Const_Index& i) const{
    LFUNCTION( Set_beginning, Particles)( *particles, i);
  }
  void Set_beginning_nc( Index& i) const{
    LFUNCTION( Set_beginning, Particles)( *particles, i);
  }

  void Increment( Const_Index& i) const{
    LFUNCTION( Increment, Particles)( *particles, i);
  }
  void Increment_nc( Index& i) const{
    LFUNCTION( Increment, Particles)( *particles, i);
  }

  bool Not_at_end( const Const_Index& i){
    return LFUNCTION( Not_at_end, Particles)( *particles, i);
  }
  bool Not_at_end_nc( const Index& i){
    return LFUNCTION( Not_at_end, Particles)( *particles, i);
  }

  Pointer pointer( const Index& i){
    return LFUNCTION( pointer, Particles)( *particles, i);
  }
  Const_Pointer pointer_const( const Const_Index& i) const{
    return LFUNCTION( pointer_const, Particles)( *particles, i);
  }

  const Particles& const_particles() const{
    return *particles;
  }

  size_t size() const{
    return LFUNCTION( size, Particles)( *particles);
  }

  template< class Functor>
  void Apply( Functor& f, Pointer p){
    LFUNCTION( Execute, Functor)( f, *particles, p);
  }
  template< class Functor>
  void Apply_const( Functor& f, Const_Pointer p) const{
    LFUNCTION( Execute, Functor)( f, *particles, p);
  }

  template< class Functor>
  void Apply( Functor& f, Pointer p1, Pointer p2){
    LFUNCTION( Execute, Functor)( f, *particles, p1, p2);
  }
  template< class Functor>
  void Apply_const( Functor& f, Const_Pointer p1, Const_Pointer p2) const{
    LFUNCTION( Execute, Functor)( f, *particles, p1, p2);
  }

  //###################
  size_t indices_beginning( size_t) const;
  size_t indices_end( size_t) const;
  size_t indices_beginning( size_t, size_t, size_t) const;
  size_t indices_end( size_t, size_t, size_t) const;

  static const size_t X = 0;
  static const size_t Y = 1;
  static const size_t Z = 2;

  void Assert_readiness_debug() const;

  Particles* particles;
  Array< Pointer> pointers;
  Array< size_t> cell_beginnings;

  size_t nz,nyz,nxyz;
  Small_Vector< size_t, 3> n_dim;
  double _spacing;
  Small_Vector< double, 3> _low_corner, _high_corner, lengths;

  bool dimensions_set;

  








