#ifndef __SCALARS_HH__
#define __SCALARS_HH__

#include "../basic/Interface.hh"

ADD_TRAIT_NAME( Is_zero);

namespace UCSD_Bioeng{

//#######################################################
inline
bool Is_zero( const double a){
  return a == 0.0;
}

inline
bool Is_zero( const int a){
  return a == 0;
}

inline
bool Is_zero( const size_t a){
  return a == 0;
}

}

SET_FUNCTION_W_RET_TRAIT( Is_zero, double, UCSD_Bioeng::Is_zero, bool);
SET_FUNCTION_W_RET_TRAIT( Is_zero, int, UCSD_Bioeng::Is_zero, bool);
SET_FUNCTION_W_RET_TRAIT( Is_zero, size_t, UCSD_Bioeng::Is_zero, bool);

namespace UCSD_Bioeng{

//#######################################################
inline
void Zero( double& a){
  a = 0.0;
}

inline
void Zero( int& a){
  a = 0;
}

inline
void Zero( size_t& a){
  a = 0;
}

}

SET_FUNCTION_TRAIT( Zero, double, UCSD_Bioeng::Zero);
SET_FUNCTION_TRAIT( Zero, int, UCSD_Bioeng::Zero);
SET_FUNCTION_TRAIT( Zero, size_t, UCSD_Bioeng::Zero);

ADD_TRAIT_NAME( Is_positive);

namespace UCSD_Bioeng{
//#######################################################

inline
bool Is_positive( const double a){
  return a > 0.0;
}

inline
bool Is_positive( const int a){
  return a > 0;
}

inline
bool Is_positive( const size_t a){
  return int(a) > 0;
}

}

SET_FUNCTION_W_RET_TRAIT( Is_positive, double, UCSD_Bioeng::Is_positive, bool);
SET_FUNCTION_W_RET_TRAIT( Is_positive, int, UCSD_Bioeng::Is_positive, bool);
SET_FUNCTION_W_RET_TRAIT( Is_positive, size_t, UCSD_Bioeng::Is_positive, bool);

ADD_TRAIT_NAME( Is_negative);

namespace UCSD_Bioeng{
//#######################################################
inline
bool Is_negative( const double a){
  return a > 0.0;
}

inline
bool Is_negative( const int a){
  return a > 0;
}

inline
bool Is_negative( const size_t a){
  return a > 0;
}
}

SET_FUNCTION_W_RET_TRAIT( Is_negative, double, UCSD_Bioeng::Is_negative, bool);
SET_FUNCTION_W_RET_TRAIT( Is_negative, int, UCSD_Bioeng::Is_negative, bool);
SET_FUNCTION_W_RET_TRAIT( Is_negative, size_t, UCSD_Bioeng::Is_negative, bool);


ADD_TRAIT_NAME( Is_NaN);

namespace UCSD_Bioeng{
//#######################################################
inline
bool Is_NaN( const double a){
  return a != a;
}
}

SET_FUNCTION_W_RET_TRAIT( Is_NaN, double, UCSD_Bioeng::Is_NaN, bool);
//#######################################################
ADD_TRAIT_NAME( Is_null);

namespace UCSD_Bioeng{

template< class T>
inline
bool Is_null( const T* t){
  return t == (const T *)(0);
}
}

namespace Interface{	
  template< class T>
  struct Trait_Functor< _Global::Context,      
                        Trait_Names::Is_nullT,
                        const T*>{	       
    static bool Do( const T* p){
      return Is_null( p);
    }
  };
								
  template< class T>									      
  struct Traits< _Global::Context,					
                 Trait_Names::Is_nullT,					
                 const T*>{								
											
    typedef  
    Trait_Functor< _Global::Context,
                   Trait_Names::Is_nullT,
                   const T*> Result;

    static const bool is_specialized =	true;
    static const bool is_specialized_here = true;
    static const bool same_context = true;
  };												
}

namespace UCSD_Bioeng{
//########################################################
template< class T1, class T2>
inline
void Set( T1& t1, const T2& t2){
  t1 = t2;
}

template< class T1, class S, class T2>
inline
void Set_m( T1& t1, const S& a, const T2& t2){
  t1 = a*t2;
}

template< class T1, class S, class T2, class T3>
inline
void Set_ma( T1& t1, const S& a, const T2& t2, const T3& t3){
  t1 = a*t2 + t3;
}

template< class T1, class T2, class T3>
inline
void Set_a( T1& t1, const T2& t2, const T3& t3){
  t1 = t2 + t3;
}

template< class T1, class S1, class T2, class S2, class T3>
inline
void Set_mam( T1& t1, const S1& a, const T2& t2, const S2& b, const T3& t3){
  t1 = a*t2 + b*t3;
}

//########################################################
template< class T1, class T2>
inline
void Add( T1& t1, const T2& t2){
  t1 += t2;
}

template< class T1, class S, class T2>
inline
void Add_m( T1& t1, const S& a, const T2& t2){
  t1 += a*t2;
}

template< class T1, class S, class T2, class T3>
inline
void Add_ma( T1& t1, const S& a, const T2& t2, const T3& t3){
  t1 += a*t2 + t3;
}

template< class T1, class T2, class T3>
inline
void Add_a( T1& t1, const T2& t2, const T3& t3){
  t1 += t2 + t3;
}

template< class T1, class S1, class T2, class S2, class T3>
inline
void Add_mam( T1& t1, const S1& a, const T2& t2, const S2& b, const T3& t3){
  t1 += a*t2 + b*t3;
}

//########################################################
template< class T1, class T2>
inline
void Subtract( T1& t1, const T2& t2){
  t1 -= t2;
}

template< class T1, class S, class T2>
inline
void Subtract_m( T1& t1, const S& a, const T2& t2){
  t1 -= a*t2;
}

template< class T1, class S, class T2, class T3>
inline
void Subtract_ma( T1& t1, const S& a, const T2& t2, const T3& t3){
  t1 -= a*t2 + t3;
}

template< class T1, class T2, class T3>
inline
void Subtract_a( T1& t1, const T2& t2, const T3& t3){
  t1 -= t2 + t3;
}

template< class T1, class S1, class T2, class S2, class T3>
inline
void Subtract_mam( T1& t1, const S1& a, const T2& t2, const S2& b, const T3& t3){
  t1 -= a*t2 + b*t3;
}

//#############################################################
template< class T, class S>
inline
void Multiply( T& t, const S& a){

  t *= a;
}

}

#endif






