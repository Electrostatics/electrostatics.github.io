#ifndef _SMALL_MATRIX_HH__
#define _SMALL_MATRIX_HH__

#include "../basic/Interface.hh"
#include "../checkers/Compile_Time_Checkers.hh"

namespace UCSD_Bioeng{

template< class T, size_t n0, size_t n1>
class Small_Matrix{

public:
  
  Small_Matrix(){
    Zero( *this);
  }

  const T& operator()( size_t i, size_t j) const{
    Check_indices( i,j);
    return data[i][j];
  }

  T& operator()( size_t i, size_t j){
    Check_indices( i,j);
    return data[i][j];
  }

  /*
  template< class M>
  Small_Matrix( const M& other){
    Do_nothing( Equality_Asserter_size_t< GTRAIT( Size0, M), n0>());
    Do_nothing( Equality_Asserter_size_t< GTRAIT( Size1, M), n1>());

    FOR( i, 0, n0) FOR( j, 0, n1)
      Copy( Q::value( other, i,j), data[i][j]);
  }

  template< class M>
  Small_Matrix< T,n0,n1> operator=( const M& other){
    Do_nothing( Equality_Asserter_size_t< GTRAIT( Size0, M), n0>());
    Do_nothing( Equality_Asserter_size_t< GTRAIT( Size1, M), n1>());

    FOR( i, 0, n0) FOR( j, 0, n1)
      Copy( Q::value( other, i,j), data[i][j]);
    return *this;
  }

  template< class M>
  Small_Matrix< T,n0,n1> operator+=( const M& other){
    Do_nothing( Equality_Asserter_size_t< GTRAIT( Size0, M), n0>());
    Do_nothing( Equality_Asserter_size_t< GTRAIT( Size1, M), n1>());

    FOR( i, 0, n0) FOR( j, 0, n1)
      data[i][j] += Q::value( other, i,j);
    return *this;
  }
  */

  //######################################
private:

#ifdef DEBUG
  void Check_indices( size_t i, size_t j) const{
    if (i >= n0 || j >= n1)
      Error1( *this, "index out of range");
  }
#else
  void Check_indices( size_t, size_t) const{}
#endif


  T data[n0][n1];
};

}

#include "Small_Matrix33.hh"
#include "Small_Matrix_Interface.hh"


#endif







