namespace Interface{


class Ambiguity_Tag;

template< class Context, class Relation, class T1, class T2>
struct Traits2_SMarker;


//#################################################
template< class Context, class Relation,
          class A1, class A2>
struct Pair_Resolver{

  typedef          Pair_Resolver< Context, Relation, A1, A2>                      Self;
  typedef typename Pair_Resolver< Context, Relation, SUPERCLASS( A1), A2>::Result Left;
  typedef typename Pair_Resolver< Context, Relation, A1, SUPERCLASS( A2)>::Result Right;

  typedef A1 Arg1;
  typedef A2 Arg2;

  typedef typename
    Switch7< 

      Traits2_SMarker< Context, Relation, A1, A2>::is_specialized,

      Self,

      bool( Are_Equal<
        Left,
        Ambiguity_Tag
        >::result) ||
      bool( Are_Equal<
        Right,
        Ambiguity_Tag
        >::result),

      Ambiguity_Tag,

      bool( Are_Equal<
        typename Left::Result1,
        Nothing
        >::result) ||
      bool( Are_Equal<
        typename Left::Result2,
        Nothing
        >::result),

      typename If< 
        bool( Are_Equal<
          typename Right::Result1,
	  Nothing
        >::result) ||
        bool( Are_Equal<
          typename Right::Result2,
	  Nothing
        >::result),

	Pair_Resolver< Context, Relation, Nothing, Nothing>,
        Right
        >::Result,

      bool( Are_Equal<
        typename Right::Result1,
        Nothing
      >::result) ||
      bool( Are_Equal<
        typename Right::Result2,
        Nothing
      >::result),

      Left,

      bool( Is_Ancestor< typename Right::Arg1, typename Left::Arg1>::result) && 
      bool( Is_Ancestor< typename Right::Arg2, typename Left::Arg2>::result),

      Left,

      bool( Is_Ancestor< typename Left::Arg1, typename Right::Arg1>::result) && 
      bool( Is_Ancestor< typename Left::Arg2, typename Right::Arg2>::result),
       
      Right,

      Ambiguity_Tag

    >::Result
    Result;

  typedef typename Result::Arg1 Result1;
  typedef typename Result::Arg2 Result2;
};

  //##############
template< class Context, class Relation>
struct Pair_Resolver< Context, Relation, Nothing, Nothing>{

  typedef Nothing Arg1;
  typedef Nothing Arg2;

  typedef Nothing Result1;
  typedef Nothing Result2;
  typedef Pair_Resolver< Context, Relation, Nothing, Nothing> Result;
};


template< class Context, class Relation, class T>
struct Pair_Resolver< Context, Relation, T, Nothing>{

  typedef T Arg1;
  typedef Nothing Arg2;

  typedef Nothing Result1;
  typedef Nothing Result2;
  typedef Pair_Resolver< Context, Relation, Nothing, Nothing> Result;
};

template< class Context, class Relation, class T>
struct Pair_Resolver< Context, Relation, Nothing, T>{

  typedef T Arg2;
  typedef Nothing Arg1;

  typedef Nothing Result1;
  typedef Nothing Result2;
  typedef Pair_Resolver< Context, Relation, Nothing, Nothing> Result;
};



//##################################################
template< class Context, class Relation, class T1, class T2>
struct Traits2_SMarker{
  static const bool is_specialized = false;
};

 
template< class Context, class Relation, class T1, class T2>
struct Traits2: public
  If< Traits2< Context, Relation, 
               typename Pair_Resolver< Context, Relation, T1, T2>::Result1, 
               typename Pair_Resolver< Context, Relation, T1, T2>::Result2 >::is_lspecialized,
      Traits2< Context, Relation, 
               typename Pair_Resolver< Context, Relation, T1, T2>::Result1, 
               typename Pair_Resolver< Context, Relation, T1, T2>::Result2 >,
      Traits2< typename Context::Enclosing, Relation, T1, T2> >::Result
{};

 
template< class Relation, class T1, class T2>
struct Traits2< _Global::Context, Relation, T1, T2>:
  public Traits2< _Global::Context, Relation, 
                  typename Pair_Resolver< _Global::Context, Relation, T1, T2>::Result1,
                  typename Pair_Resolver< _Global::Context, Relation, T1, T2>::Result2 >{

  static const bool is_lspecialized = false;
};

template< class Relation, class T>
struct Traits2< _Global::Context, Relation, T, Nothing>{
  static const bool is_lspecialized = false;
  typedef Nothing Result;
};

template< class Relation, class T>
struct Traits2< _Global::Context, Relation, Nothing, T>{
  static const bool is_lspecialized = false;
  typedef Nothing Result;
};

template< class Context, class Relation>
struct Traits2< Context, Relation, Nothing, Nothing>{
  static const bool is_lspecialized = false;
  typedef Nothing Result;
};

template< class Context, class Relation, class T1, class T2>
struct Traits2< Context, Relation, T1&, T2>:
    public Traits2< Context, Relation, T1, T2>{};

template< class Context, class Relation, class T1, class T2>
struct Traits2< Context, Relation, T1, T2&>:
    public Traits2< Context, Relation, T1, T2>{};

template< class Context, class Relation, class T1, class T2>
struct Traits2< Context, Relation, T1&, T2&>:
    public Traits2< Context, Relation, T1, T2>{};

template< class Context, class Relation, class T1, class T2>
struct Traits2< Context, Relation, const T1, T2>:
    public Traits2< Context, Relation, T1, T2>{};

template< class Context, class Relation, class T1, class T2>
struct Traits2< Context, Relation, T1, const T2>:
    public Traits2< Context, Relation, T1, T2>{};

template< class Context, class Relation, class T1, class T2>
struct Traits2< Context, Relation, const T1, const T2>:
    public Traits2< Context, Relation, T1, T2>{};      
}

#define LOCAL_TRAIT2( Context, Relation, T1, T2)		\
  typename						\
  Interface::Traits2< Context,				\
                     Interface::Trait_Names::Relation##T,	\
                     T1, T2>::Result

#define LTRAIT2( Relation, T1, T2) LOCAL_TRAIT2( Local_Context, Relation, T1, T2)

#define LOCAL_GRAIT2( Context, Relation, T1, T2)		\
  Interface::Traits2< Context,				\
                      Interface::Trait_Names::Relation##T,	\
                      T1, T2>::Result

#define LGTRAIT2( Relation, T1, T2) LOCAL_GTRAIT2( Local_Context, Relation, T1, T2)

#define LOCAL_FUNCTION2( Context, F, T1, T2)		\
  Interface::Traits2< Context,				\
                      Interface::Trait_Names::F##T,	\
                      T1, T2>::Do

#define LFUNCTION2( F, T1, T2) LOCAL_FUNCTION2( Local_Context, F, T1, T2)

#define FUNCTION2( F, T1, T2) LOCAL_FUNCTION2( Interface::_Global::Context, F, T1, T2)

#define SET_LOCAL_TRAIT2( context, Relation, T1, T2, Res)					\
ADD_TRAIT_NAME( Relation);                                                                      \
  namespace Interface{										\
    template<>											\
    struct Traits2< Interface::_##context::Context,						\
                   Interface::Trait_Names::Relation##T,						\
		   T1, T2>{									\
      typedef Res Result;									\
      static const bool is_lspecialized =							\
       !Are_Equal< Interface::_##context::Context, Interface::_Global::Context>::result;	\
    };												\
    template<>											\
    struct Traits2_SMarker< Interface::_##context::Context,					\
                            Interface::Trait_Names::Relation##T,					\
		            T1, T2>{								\
      static const bool is_specialized = true;							\
  };} class None


#define TRAIT2( Relation, Class) LOCAL_TRAIT2( Global, Relation, Class)

#define GTRAIT2( Relation, Class) LOCAL_GTRAIT2( Global, Relation, Class)

#define SET_TRAIT2( Relation, Class, Result) SET_LOCAL_TRAIT2( Global, Relation, Class, Result)


#define SET_FUNCTION_LOCAL_TRAIT2( context, Function, T1, T2, Outer_Function)			\
ADD_TRAIT_NAME( Function);                                                                      \
namespace Interface{										\
  template<>											\
  struct Traits2< Interface::_##context::Context,							\
                  Interface::Trait_Names::Function##T,						\
                  T1, T2>{									\
												\
    template< class Arg1>									\
    static void Do( Arg1& arg1){								\
      Outer_Function( arg1);									\
    }												\
    template< class Arg1, class Arg2>								\
    static void Do( Arg1& arg1, Arg2& arg2){							\
      Outer_Function( arg1, arg2);								\
    }												\
    static const bool is_lspecialized =								\
       !Are_Equal< Interface::_##context::Context, Interface::_Global::Context>::result;		\
  };												\
  template<>											\
  struct Traits2_SMarker< Interface::_##context::Context,						\
                          Interface::Trait_Names::Function##T,					\
                          T1, T2>{								\
    static const bool is_specialized = true;							\
  };} class None			       						


#define SET_FUNCTIONR_LOCAL_TRAIT2( context, Function, T1, T2, Outer_Function, Ret)		\
ADD_TRAIT_NAME( Function);                                                                      \
namespace Interface{										\
  template<>											\
  struct Traits2< Interface::_##context::Context,							\
                  Interface::Trait_Names::Function##T,						\
                  T1, T2>{									\
												\
    template< class Arg1>									\
    static Ret Do( Arg1& arg1){									\
        return Outer_Function( arg1);								\
    }												\
    template< class Arg1, class Arg2>								\
    static Ret Do( Arg1& arg1, Arg2& arg2){							\
      return Outer_Function( arg1, arg2);							\
    } 												\
    static const bool is_lspecialized =								\
       !Are_Equal< Interface::_##context::Context, Interface::_Global::Context>::result;		\
  };												\
  template<>											\
  struct Traits2_SMarker< Interface::_##context::Context,						\
                          Interface::Trait_Names::Function##T,					\
                          T1, T2>{								\
    static const bool is_specialized = true;							\
  };} class None			       						

#define SET_FUNCTION_TRAIT2( Relation, T1,T2,OF) SET_FUNCTION_LOCAL_TRAIT2( Global, Relation, T1,T2,OF)

#define SET_FUNCTIONR_TRAIT2( Relation, T1,T2,OF,R) SET_FUNCTIONR_LOCAL_TRAIT2( Global, Relation, T1,T2,OF,R)

 





