ADD_TRAIT_NAME( Inner_Ref);
ADD_TRAIT_NAME( Inner_Const_Ref);

namespace Interface{

template< class T, size_t n0, size_t n1>
struct Traits< _Global::Context, Trait_Names::Inner_RefT, UCSD_Bioeng::Small_Matrix< T, n0, n1> >{
  typedef UCSD_Bioeng::Small_Matrix< T, n0, n1>& Type;
};

template< class T, size_t n0, size_t n1>
struct Traits< _Global::Context, Trait_Names::Inner_Const_RefT, UCSD_Bioeng::Small_Matrix< T, n0, n1> >{
  typedef const UCSD_Bioeng::Small_Matrix< T, n0, n1>& Type;
};

}
