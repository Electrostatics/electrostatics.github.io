#ifndef __POINTER_WRAPPER_HH__
#define __POINTER_WRAPPER_HH__

#include "../basic/Interface.hh"
#include "../checkers/Error.hh"

namespace UCSD_Bioeng{

//#########################################################
template< class T>
class Pointer_Wrapper{

public:
  typedef T* iterator;
  typedef const T* const_iterator;

  Pointer_Wrapper(){}
  Pointer_Wrapper( T*, size_t);
  void Reset( T*, size_t);

  const T& operator[]( size_t i) const;
  T& operator[]( size_t i);
  
  size_t size() const;

  T* begin(){
    return data;
  }

  const T* begin() const{
    return data;
  }

  T* end(){
    return data + n;
  }

  const T* end() const{
    return data + n;
  }

private:
  T* data;
  size_t n;
};

//#########################################################
template< class T>
inline
Pointer_Wrapper<T>::Pointer_Wrapper( T* _data, size_t _n): data(_data), n(_n){}

template< class T>
inline
void Pointer_Wrapper<T>::Reset( T* _data, size_t _n){
  data = _data;
  n = _n;
}

template< class T>
inline
const T& Pointer_Wrapper<T>::operator[]( size_t i) const{

  Assert_debug( i < n);
  return data[i];
}

template< class T>
inline
T& Pointer_Wrapper<T>::operator[]( size_t i){

  Assert_debug( i < n);
  return data[i];
}

template< class T>
inline
size_t Pointer_Wrapper<T>::size() const{

  return n;
}

}

#include "Pointer_Wrapper_Interface.hh"

#endif








