#ifndef __ARRAY_3D_HH__
#define __ARRAY_3D_HH__

#include "Array.hh"
#include "Adaptor_3D.hh"

namespace UCSD_Bioeng{

//#############################################
template< class T>
class Array_3D: public Adaptor_3D< Array<T> >{

public:
  Array_3D(): Adaptor_3D< Array<T> >( array_1D){}

  Array_3D( size_t ix, size_t iy, size_t iz): 
    Adaptor_3D< Array<T> >( array_1D){
    Resize( ix, iy, iz);
  }


private:
  Array_3D<T>& operator=( const Array_3D<T>&);
  Array_3D( const Array_3D<T>&);

  Array<T> array_1D;
};

}

#include "Array_3D_Interface.hh"

#endif










