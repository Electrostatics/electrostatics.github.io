#ifndef __ARRAY_HH__
#define __ARRAY_HH__

#include "std_vector_Interface.hh"

namespace UCSD_Bioeng{

template< class T>
class Array: public std::vector<T>{

public:
  Array( size_t n=0): std::vector<T>(n){}

  const T& operator[]( size_t i) const{
    Assert_positive_debug( size() - i);
    return std::vector<T>::operator[](i);
  }

  T& operator[]( size_t i){
    Assert_positive_debug( size() - i);
    return std::vector<T>::operator[](i);
  }
};

}

namespace Interface{
template< class T>
struct Superclass_Trait< UCSD_Bioeng::Array<T> >{
  typedef std::vector<T> Result;
};

template< class T>
struct Superclass_Trait< const UCSD_Bioeng::Array<T> >{
  typedef const std::vector<T> Result;
};

}
#endif






