
SET_TEMPLATED_TRAIT( Value, const UCSD_Bioeng::Array_3D, T, T);
SET_TEMPLATED_TRAIT( Inner_Ref, const UCSD_Bioeng::Array_3D, T, const TEMPLATE1( UCSD_Bioeng::Array_3D, T)& );
SET_TEMPLATED_TRAIT( Inner_Ref, UCSD_Bioeng::Array_3D, T, TEMPLATE1( UCSD_Bioeng::Array_3D, T)& );
SET_TEMPLATED_TRAIT( Inner_Const_Ref, const UCSD_Bioeng::Array_3D, T, 
		     const TEMPLATE1( UCSD_Bioeng::Array_3D, T)& );






