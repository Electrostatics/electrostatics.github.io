#ifndef __SMALL_POINTER_WRAPPER_HH__
#define __SMALL_POINTER_WRAPPER_HH__

#include <stdlib.h>
#include "../basic/Interface.hh"

namespace UCSD_Bioeng{

template< class T, size_t n>
class Small_Pointer_Wrapper{

public:
  Small_Pointer_Wrapper( T* in_data): data( in_data){}

  const T& operator[]( size_t i) const{
    return data[i];
  }

  T& operator[]( size_t i){
    return data[i];
  }

private:
  T* data;
};

}

//#################################################################
ADD_TRAIT_NAME( Inner_Ref);
ADD_TRAIT_NAME( Inner_Const_Ref);

namespace Interface{

//####################################################
template< class T, size_t n>
struct Traits<  _Global::Context, Trait_Names::Inner_RefT, 
                UCSD_Bioeng::Small_Pointer_Wrapper< T, n> >{
  typedef UCSD_Bioeng::Small_Pointer_Wrapper< T, n>& Result;
  static const bool is_specialized = true;
  static const bool is_specialized_here = true;
  static const bool same_context = true;
};
  
template< class T, size_t n>
struct Traits<  _Global::Context, Trait_Names::Inner_Const_RefT, 
                const UCSD_Bioeng::Small_Pointer_Wrapper< T, n> >{
  typedef const UCSD_Bioeng::Small_Pointer_Wrapper< T, n>& Result;
  static const bool is_specialized = true;
  static const bool is_specialized_here = true;
  static const bool same_context = true;
};
  
}

#endif




