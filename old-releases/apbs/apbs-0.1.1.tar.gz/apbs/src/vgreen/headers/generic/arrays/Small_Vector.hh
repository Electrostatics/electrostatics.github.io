#ifndef __SMALL_VECTOR_HH__
#define __SMALL_VECTOR_HH__

#include "../basic/Interface.hh"
#include "../checkers/Error.hh"
#include "../checkers/Compile_Time_Checkers.hh"

namespace UCSD_Bioeng{
//###################################
template< class T, size_t n>
class Small_Vector{

public:
  typedef T Value;
  typedef Small_Vector< T,n> Self;
  static const size_t size = n;

  const T& operator[]( size_t i) const{
    Check_index(i);
    return data[i];
  }
  T &operator[]( size_t i){
    Check_index(i);
    return data[i];
  }

  Small_Vector(){}

  /*
  Small_Vector( const Value a0, const Value a1){
    Do_nothing( Equality_Asserter_size_t<2,n>());
    data[0] = a0;
    data[1] = a1;
  }

  template< class V>
  Small_Vector( const V& v){
    Do_nothing( Equality_Asserter_size_t< n, GTYPE( Size, V)>()); 
    FOR( i, 0, n)
      data[i] = Q::value( v, i);
  }

  template< class Stream>
  friend
  Stream& operator<<( Stream& s, const Small_Vector<T,n>& v){
    for( int i=0; i<n; i++)
      s << v[i] << " ";
    return s;
  }

  template< class V>
  Self& operator+=( const V& v){
    FOR( i, 0, n)
      data[i] += Q::value( v, i);
    return *this;
  }

  template< class V>
  Self& operator-=( const V& v){
    FOR( i, 0, n)
      data[i] += Q::value( v, i);
    return *this;
  }

  template< class S>
  Self& operator*=( const S& s){
    FOR( i, 0, n)
      data[i] *= s;
    return *this;
  }

  template< class V>
  Self& operator=( const V& v){
    FOR( i, 0, n)
      Copy( Q::value( v, i), data[i]);
    return *this;
  }
  */

  //#####################################################
private:
  void Check_index( size_t i) const{
    if (i >= n)
      Error1_debug( *this, "index out of range");
  }

  T data[n];
};
}

#include "Small_Vector3.hh"
#include "Small_Vector_Interface.hh"
#endif











