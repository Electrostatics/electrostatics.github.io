#ifndef __UNIFORM_ARRAY_HH__
#define __UNIFORM_ARRAY_HH__

#include "../checkers/Error.hh"

namespace UCSD_Bioeng{
//############################################################
template< class T>
class Uniform_Array{

public:
  Uniform_Array( size_t _n, T _value): n(_n), value(_value){}

  const T& operator[]( size_t i) const{
    Assert_positive_debug( n - i);
    return value;
  }

  void Change_value( T _value){
    value = _value;
  }

  void Resize( size_t _n){
    n = _n;
  }

  size_t size() const{
    return n;
  }

private:
  T value;
  size_t n;
};

template< class T>
inline
Uniform_Array<T> uniform_array( size_t n, T t){
  
  return Uniform_Array<T>( n, t);
}
}

//############################################################
ADD_TRAIT_NAME( Member);
SET_TEMPLATED_TRAIT( Member, UCSD_Bioeng::Uniform_Array, T, T);

ADD_TRAIT_NAME( Const_Forward_Iterator);
SET_TEMPLATED_TRAIT( Const_Forward_Iterator, UCSD_Bioeng::Uniform_Array, T, size_t);

//SET_TEMPLATED_TRAIT( Shape, Uniform_Array, T, Large_Array);
//SET_TEMPLATED_TRAIT( Inner_Ref, Uniform_Array, T, TEMPLATE1( Uniform_Array, T)&);
//SET_TEMPLATED_TRAIT( Inner_Const_Ref, Uniform_Array, T, const TEMPLATE1( Uniform_Array, T)&);
//SET_TEMPLATED_TRAIT( Const_Index, Uniform_Array, T, size_t);


namespace UCSD_Bioeng{
template< class T>
inline
size_t size( const Uniform_Array<T>& v){

  return v.size();
}
}

SET_FUNCTION_W_RET_TEMPLATED_TRAIT( size, UCSD_Bioeng::Uniform_Array, T, UCSD_Bioeng::size, size_t);

namespace UCSD_Bioeng{
template< class T>
inline
void Set_beginning( const Uniform_Array<T>&, size_t& i){
  i = 0;
}
}

SET_FUNCTION_TEMPLATED_TRAIT( Set_beginning, UCSD_Bioeng::Uniform_Array, UCSD_Bioeng::Set_beginning);

template< class T>
inline
void Increment( const Uniform_Array<T>& v, size_t& i){
  Assert_debug( Not_at_end( v, i));
  ++i;
}

SET_FUNCTION_TEMPLATED_TRAIT( Increment, UCSD_Bioeng::Uniform_Array, UCSD_Bioeng::Increment);

namespace UCSD_Bioeng{
template< class T>
inline
bool Not_at_end( const Uniform_Array<T>& v, size_t i){
  return i < v.size();
}
}

SET_FUNCTION_W_RET_TEMPLATED_TRAIT( Not_at_end, UCSD_Bioeng::Uniform_Array, T, UCSD_Bioeng::Not_at_end, bool);

namespace UCSD_Bioeng{
template< class T>
inline
const T& member( const Uniform_Array<T>& v, size_t& i){
  Assert_debug( Not_at_end( v, i));
  return v[i];
}
}

SET_FUNCTION_W_RET_TEMPLATED_TRAIT( member, UCSD_Bioeng::Uniform_Array, T, UCSD_Bioeng::member, const T&);

#endif
