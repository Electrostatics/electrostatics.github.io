ADD_TRAIT_NAME( charge);

SET_TEMPLATED2_TRAIT( Particles, const UCSD_Bioeng::Cell_List, Particles, LS, Particles);

SET_TEMPLATED2_TRAIT( Const_Particle_Pointer, const UCSD_Bioeng::Cell_List, Particles, LS, LOCAL_TRAIT( LS, Const_Pointer, Particles)); 

SET_TEMPLATED2_TRAIT( Const_Cell_Index, const UCSD_Bioeng::Cell_List, Particles, LS, size_t);
SET_TEMPLATED2_TRAIT( Const_Cell_Particle_Index, const UCSD_Bioeng::Cell_List, Particles, LS, 
		      size_t);

namespace UCSD_Bioeng{

template< class Particles, class LC, class Position>
inline
void 
Get_low_corner( const Cell_List< Particles, LC>& cells, Position& x){
  
  cells.Get_low_corner( x);
}

template< class Particles, class LC, class Position>
inline
void
Get_high_corner( const Cell_List< Particles, LC>& cells, Position& x){
  
  cells.Get_high_corner( x);
}

template< class Particles, class LC>
inline
size_t nx( const Cell_List< Particles, LC>& cells){

  return cells.n_in_x_direction();
}

template< class Particles, class LC>
inline
size_t ny( const Cell_List< Particles, LC>& cells){

  return cells.n_in_y_direction();
}

template< class Particles, class LC>
inline
size_t nz( const Cell_List< Particles, LC>& cells){

  return cells.n_in_z_direction();
}

template< class Particles, class LC>
inline
typename Cell_List< Particles, LC>::Pointer 
pointer( Cell_List< Particles, LC>& cells, 
	 size_t ix, size_t iy, size_t iz, size_t i_particle){

  return cells.particle_pointer( ix, iy, iz, i_particle);
}

template< class Particles, class LC>
inline
typename Cell_List< Particles, LC>::Const_Pointer 
pointer( const Cell_List< Particles, LC>& cells, 
	 size_t ix, size_t iy, size_t iz, size_t i_particle){

  return cells.particle_pointer( ix, iy, iz, i_particle);
}

template< class Particles, class LC, class Position>
inline
void Get_cell_indices( const Cell_List< Particles, LC>& cells, 
		       const Position& x, 
		       size_t& ix, size_t& iy, size_t& iz){

  cells.Get_cell_indices( x, ix,iy,iz);
}

template< class Particles, class LC>
inline
void Assert_is_ready( const Cell_List< Particles, LC>& cells){

  cells.Assert_readiness();
}

template< class Particles, class Local_Context, class _Position>
inline
void Get_cell_position( const Cell_List< Particles, Local_Context>& cells, 
		   size_t ix, size_t iy, size_t iz,
		   _Position& _x){

  LTRAIT( Inner_Ref, _Position) x(_x);
  cells.Get_cell_center( ix, iy, iz, x);
}

template< class Particles, class LC>
inline
bool is_occupied( const Cell_List< Particles, LC>& cells, 
		  size_t ix, size_t iy, size_t iz){

  return (cells.n_in_cell( ix,iy,iz) > 0);
}

template< class Particles, class LC>
inline
size_t cell_index( const Cell_List< Particles, LC>& cells, 
		  size_t ix, size_t iy, size_t iz){

  return cells.cell_index( ix,iy,iz);
}

template< class Particles, class LC>
inline
void Reset( const Cell_List< Particles, LC>& cells, 
	    size_t i_cell, size_t& i_part){

  i_part = 0;
  --i_part;
}

template< class Particles, class LC>
inline
bool Increment_and_test( const Cell_List< Particles, LC>& cells, 
			 size_t i_cell, size_t& i_part){

  ++i_part;
  return (i_part < cells.n_in_cell( i_cell));
}

template< class Particles, class LC>
inline
typename Cell_List< Particles, LC>::Const_Pointer
particle_pointer_const( const Cell_List< Particles, LC>& cells,
		  size_t i_cell, size_t i_part){

  return cells.particle_pointer_const( i_cell, i_part);
}

template< class Particles, class LC>
inline
typename Cell_List< Particles, LC>::Pointer
particle_pointer( Cell_List< Particles, LC>& cells,
		  size_t i_cell, size_t i_part){

  return cells.particle_pointer( i_cell, i_part);
}

template< class Particles, class Local_Context>
inline
double
particle_charge( const Cell_List< Particles, Local_Context>& cells,
		 typename Cell_List< Particles, Local_Context>::Const_Pointer p){

  return LFUNCTION( charge, Particles)( cells.particle_list(), p);
}

template< class Particles, class Local_Context, class Position>
inline
void
Get_particle_position( const Cell_List< Particles, Local_Context>& cells,
		       typename Cell_List< Particles, Local_Context>::Const_Pointer p, Position& x){

  LFUNCTION( Get_position, Particles)( cells.particle_list(), p, x);
}

template< class Particles, class LC>
inline
const Particles& particle_list( const Cell_List< Particles, LC>& cells){

  return cells.particle_list();
}

}


SET_FUNCTION_TEMPLATED2_TRAIT( Get_low_corner, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::Get_low_corner);
SET_FUNCTION_TEMPLATED2_TRAIT( Get_high_corner, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::Get_high_corner);
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( nx, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::nx, size_t);
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( ny, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::ny, size_t);
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( nz, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::nz, size_t);
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( pointer, UCSD_Bioeng::Cell_List, UCSD_Bioeng::pointer, LOCAL_TRAIT( T2, Pointer, T1) ); 
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( cpointer, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::pointer, LOCAL_TRAIT( T2, Const_Pointer, T1)); 
SET_FUNCTION_TEMPLATED2_TRAIT( Get_cell_indices, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::Get_cell_indices);
SET_FUNCTION_TEMPLATED2_TRAIT( Assert_readiness, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::Assert_is_ready);
SET_FUNCTION_TEMPLATED2_TRAIT( Get_cell_position, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::Get_cell_position);
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( is_occupied, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::is_occupied, bool);
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( cell_index, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::cell_index, size_t);
SET_FUNCTION_TEMPLATED2_TRAIT( Reset, UCSD_Bioeng::Cell_List, UCSD_Bioeng::Reset);
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( Increment_and_test, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::Increment_and_test, bool);
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( particle_pointer_const, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::particle_pointer_const, LOCAL_TRAIT( T2, Const_Pointer, T1));
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( particle_pointer, UCSD_Bioeng::Cell_List, UCSD_Bioeng::particle_pointer, LOCAL_TRAIT( T2, Pointer, T1));
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( particle_charge, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::particle_charge, double);
SET_FUNCTION_TEMPLATED2_TRAIT( Get_particle_position, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::Get_particle_position);
SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( particle_list, const UCSD_Bioeng::Cell_List, UCSD_Bioeng::particle_list, const T1&);








