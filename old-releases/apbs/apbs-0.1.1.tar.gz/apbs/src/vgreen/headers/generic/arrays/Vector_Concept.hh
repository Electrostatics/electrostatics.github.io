#ifndef __VECTOR_CONCEPT_HH__
#define __VECTOR_CONCEPT_HH__

ADD_TRAIT_NAME( Set);
ADD_TRAIT_NAME( Set_p);
ADD_TRAIT_NAME( Set_m);
ADD_TRAIT_NAME( Set_ma);
ADD_TRAIT_NAME( Set_mam);

ADD_TRAIT_NAME( Add);
ADD_TRAIT_NAME( Add_p);
ADD_TRAIT_NAME( Add_m);
ADD_TRAIT_NAME( Add_ma);
ADD_TRAIT_NAME( Add_mam);

ADD_TRAIT_NAME( Subtract);
ADD_TRAIT_NAME( Subtract_p);
ADD_TRAIT_NAME( Subtract_m);
ADD_TRAIT_NAME( Subtract_ma);
ADD_TRAIT_NAME( Subtract_mam);

ADD_TRAIT_NAME( Multiply);

template< class V, class Local_Context>
struct Vector_Concept{

  ~Vector_Concept(){
    CHECK_LOCAL_TRAIT( Set, V);
    CHECK_LOCAL_TRAIT( Set_a, V);
    CHECK_LOCAL_TRAIT( Set_m, V);
    CHECK_LOCAL_TRAIT( Set_ma, V);
    CHECK_LOCAL_TRAIT( Set_mam, V);

    CHECK_LOCAL_TRAIT( Add, V);
    CHECK_LOCAL_TRAIT( Add_a, V);
    CHECK_LOCAL_TRAIT( Add_m, V);
    CHECK_LOCAL_TRAIT( Add_ma, V);
    CHECK_LOCAL_TRAIT( Add_mam, V);

    CHECK_LOCAL_TRAIT( Subtract, V);
    CHECK_LOCAL_TRAIT( Subtract_a, V);
    CHECK_LOCAL_TRAIT( Subtract_m, V);
    CHECK_LOCAL_TRAIT( Subtract_ma, V);
    CHECK_LOCAL_TRAIT( Subtract_ma, V);

    CHECK_LOCAL_TRAIT( Multiply, V);
  }
};

#endif



