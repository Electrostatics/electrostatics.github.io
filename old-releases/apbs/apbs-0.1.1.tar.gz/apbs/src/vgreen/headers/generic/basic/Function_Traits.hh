#define FUNCTOR_GUTS( Outer_Function)														\
    template< class Arg1>														\
    static void Do( Arg1& arg1){													\
      Outer_Function( arg1);														\
    }																	\
    template< class Arg1, class Arg2>													\
    static void Do( Arg1& arg1, Arg2& arg2){												\
      Outer_Function( arg1, arg2);													\
    }																	\
    template< class Arg1, class Arg2, class Arg3>											\
    static void Do( Arg1& arg1, Arg2& arg2, Arg3& arg3){										\
      Outer_Function( arg1, arg2, arg3);												\
    }																	\
    template< class Arg1, class Arg2, class Arg3, class Arg4>										\
    static void Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4){									\
      Outer_Function( arg1, arg2, arg3, arg4);												\
    }																	\
    template< class Arg1, class Arg2, class Arg3, class Arg4, class Arg5>								\
    static void Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5){							\
      Outer_Function( arg1, arg2, arg3, arg4, arg5);											\
    }																	\
    template< class Arg1, class Arg2, class Arg3, class Arg4, class Arg5, class Arg6>							\
    static void Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6){						\
      Outer_Function( arg1, arg2, arg3, arg4, arg5, arg6);										\
    }																	\
    template< class Arg1, class Arg2, class Arg3, class Arg4, class Arg5, class Arg6, class Arg7>					\
    static void Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6, Arg7& arg7){				\
      Outer_Function( arg1, arg2, arg3, arg4, arg5, arg6, arg7);									\
    }																	\
    template< class Arg1, class Arg2, class Arg3, class Arg4, class Arg5, class Arg6, class Arg7, class Arg8>				\
    static void Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6, Arg7& arg7, Arg8& arg8){			\
      Outer_Function( arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);									\
    }																	\
    template< class Arg1, class Arg2, class Arg3, class Arg4, class Arg5, class Arg6, class Arg7, class Arg8, class Arg9>		\
    static void Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6, Arg7& arg7, Arg8& arg8, Arg9& arg9){	\
      Outer_Function( arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);								\
    }

#define FUNCTOR_W_RET_GUTS( Outer_Function, Ret)											\
    template< class Arg1>													\
    static Ret Do( Arg1& arg1){													\
      return Outer_Function( arg1);												\
    }																\
    template< class Arg1, class Arg2>												\
    static Ret Do( Arg1& arg1, Arg2& arg2){											\
      return Outer_Function( arg1, arg2);											\
    }																\
    template< class Arg1, class Arg2, class Arg3>										\
    static Ret Do( Arg1& arg1, Arg2& arg2, Arg3& arg3){										\
      return Outer_Function( arg1, arg2, arg3);											\
    }																\
    template< class Arg1, class Arg2, class Arg3, class Arg4>									\
    static Ret Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4){								\
      return Outer_Function( arg1, arg2, arg3, arg4);										\
    }																\
    template< class Arg1, class Arg2, class Arg3, class Arg4, class Arg5>							\
    static Ret Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5){							\
      return Outer_Function( arg1, arg2, arg3, arg4, arg5);									\
    }																\
    template< class Arg1, class Arg2, class Arg3, class Arg4, class Arg5, class Arg6>						\
    static Ret Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6){					\
      return Outer_Function( arg1, arg2, arg3, arg4, arg5, arg6);								\
    }																\
    template< class Arg1, class Arg2, class Arg3, class Arg4, class Arg5, class Arg6, class Arg7>				\
    static Ret Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6, Arg7& arg7){				\
      return Outer_Function( arg1, arg2, arg3, arg4, arg5, arg6, arg7);								\
    }																\
    template< class Arg1, class Arg2, class Arg3, class Arg4, class Arg5, class Arg6, class Arg7, class Arg8>			\
    static Ret Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6, Arg7& arg7, Arg8& arg8){		\
      return Outer_Function( arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);							\
    }																\
    template< class Arg1, class Arg2, class Arg3, class Arg4, class Arg5, class Arg6, class Arg7, class Arg8, class Arg9>	\
    static Ret Do( Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6, Arg7& arg7, Arg8& arg8, Arg9& arg9){	\
      return Outer_Function( arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);						\
    }

//########################################################################################
namespace Interface{

template< class context, class Relation, class Function>
struct Trait_Functor;

}


//########################################################################################
#define SET_FUNCTION_LOCAL_TRAIT( context, Function, Class, Outer_Function)				\
ADD_TRAIT_NAME( Function);										\
namespace Interface{											\
													\
template<>												\
struct Trait_Functor< _##context::Context, Trait_Names::Function##T, Class>{	\
  FUNCTOR_GUTS( Outer_Function)									\
};													\
													\
template<>												\
struct Traits< _##context::Context,								\
               Trait_Names::Function##T,							\
               Class>{											\
  typedef  _##context::Context Context;						\
  typedef  Trait_Names::Function##T Function;					\
													\
  static const bool is_specialized = true;								\
  static const bool is_specialized_here = true;								\
  static const bool same_context = true;								\
  typedef Trait_Functor< Context, Function, Class> Result;						\
};													\
													\
} class None

#define SET_FUNCTION_TRAIT( Function, Class, Outer_Function)				\
ADD_TRAIT_NAME( Function);										\
namespace Interface{											\
													\
template<>												\
struct Trait_Functor< _Global::Context, Trait_Names::Function##T, Class>{	\
  FUNCTOR_GUTS( Outer_Function)									\
};													\
													\
template<>												\
struct Traits< _Global::Context,								\
               Trait_Names::Function##T,							\
               Class>{											\
  typedef  _Global::Context Context;						\
  typedef  Trait_Names::Function##T Function;					\
													\
  static const bool is_specialized = true;								\
  static const bool is_specialized_here = true;								\
  static const bool same_context = true;								\
  typedef Trait_Functor< Context, Function, Class> Result;						\
};													\
													\
} class None


//########################################################################################
#define SET_FUNCTION_W_RET_LOCAL_TRAIT( context, Function, Class, Outer_Function, Ret)				\
ADD_TRAIT_NAME( Function);											\
namespace Interface{												\
														\
template<>													\
struct Trait_Functor< _##context::Context, Trait_Names::Function##T, Class>{		\
  typedef Ret Return; \
  FUNCTOR_W_RET_GUTS( Outer_Function, Return)									\
};														\
														\
template<>													\
struct Traits< _##context::Context,									\
               Trait_Names::Function##T,								\
               Class>{												\
  typedef  _##context::Context Context;							\
  typedef  Trait_Names::Function##T Function;						\
														\
  static const bool is_specialized = true;									\
  static const bool is_specialized_here = true;									\
  static const bool same_context = true;									\
  typedef Trait_Functor< Context, Function, Class> Result;							\
};														\
} class None

#define SET_FUNCTION_W_RET_TRAIT( Function, Class, Outer_Function, Ret)				\
ADD_TRAIT_NAME( Function);											\
namespace Interface{												\
														\
template<>													\
struct Trait_Functor< _Global::Context, Trait_Names::Function##T, Class>{		\
  typedef Ret Return; \
  FUNCTOR_W_RET_GUTS( Outer_Function, Return)									\
};														\
														\
template<>													\
struct Traits< _Global::Context,									\
               Trait_Names::Function##T,								\
               Class>{												\
  typedef  _Global::Context Context;							\
  typedef  Trait_Names::Function##T Function;						\
														\
  static const bool is_specialized = true;									\
  static const bool is_specialized_here = true;									\
  static const bool same_context = true;									\
  typedef Trait_Functor< Context, Function, Class> Result;							\
};														\
} class None


//###########################################################################################
#define SET_FUNCTION_LOCAL_TEMPLATED_TRAIT( context, Function, Class, Outer_Function)			\
ADD_TRAIT_NAME( Function);										\
namespace Interface{											\
													\
template< class T>											\
struct Trait_Functor< _##context::Context, Trait_Names::Function##T, Class<T> >{	\
  FUNCTOR_GUTS( Outer_Function)									\
};													\
													\
template< class T>											\
struct Traits< _##context::Context,								\
              Trait_Names::Function##T,							\
              Class<T> >{										\
  typedef  _##context::Context Context;						\
  typedef  Trait_Names::Function##T Function;					\
													\
  static const bool is_specialized = true;								\
  static const bool is_specialized_here = true;								\
  static const bool same_context = true;								\
  typedef Trait_Functor< Context, Function, Class<T> > Result;						\
};													\
													\
} class None

#define SET_FUNCTION_TEMPLATED_TRAIT( Function, Class, Outer_Function)			\
ADD_TRAIT_NAME( Function);										\
namespace Interface{											\
													\
template< class T>											\
struct Trait_Functor< _Global::Context, Trait_Names::Function##T, Class<T> >{	\
  FUNCTOR_GUTS( Outer_Function)									\
};													\
													\
template< class T>											\
struct Traits< _Global::Context,								\
              Trait_Names::Function##T,							\
              Class<T> >{										\
  typedef  _Global::Context Context;						\
  typedef  Trait_Names::Function##T Function;					\
													\
  static const bool is_specialized = true;								\
  static const bool is_specialized_here = true;								\
  static const bool same_context = true;								\
  typedef Trait_Functor< Context, Function, Class<T> > Result;						\
};													\
													\
} class None



//###########################################################################################
#define SET_FUNCTION_W_RET_LOCAL_TEMPLATED_TRAIT( context, Function, Class, Outer_Function, Ret)	\
ADD_TRAIT_NAME( Function);										\
namespace Interface{											\
													\
template< class T>											\
struct Trait_Functor< _##context::Context, Trait_Names::Function##T, Class<T> >{	\
  typedef Ret Return; \
  FUNCTOR_W_RET_GUTS( Outer_Function, Return)								\
};													\
													\
template< class T>											\
struct Traits< _##context::Context,								\
              Trait_Names::Function##T,							\
              Class<T> >{										\
  typedef  _##context::Context Context;						\
  typedef  Trait_Names::Function##T Function;					\
													\
  static const bool is_specialized = true;								\
  static const bool is_specialized_here = true;								\
  static const bool same_context = true;								\
  typedef Trait_Functor< Context, Function, Class<T> > Result;						\
};													\
													\
} class None

#define SET_FUNCTION_W_RET_TEMPLATED_TRAIT( Function, Class, Outer_Function, Ret)	\
ADD_TRAIT_NAME( Function);										\
namespace Interface{											\
													\
template< class T>											\
struct Trait_Functor< _Global::Context, Trait_Names::Function##T, Class<T> >{	\
  typedef Ret Return; \
  FUNCTOR_W_RET_GUTS( Outer_Function, Return)								\
};													\
													\
template< class T>											\
struct Traits< _Global::Context,								\
              Trait_Names::Function##T,							\
              Class<T> >{										\
  typedef  _Global::Context Context;						\
  typedef  Trait_Names::Function##T Function;					\
													\
  static const bool is_specialized = true;								\
  static const bool is_specialized_here = true;								\
  static const bool same_context = true;								\
  typedef Trait_Functor< Context, Function, Class<T> > Result;						\
};													\
													\
} class None



//###########################################################################################
#define SET_FUNCTION_LOCAL_TEMPLATED2_TRAIT( context, Function, Class, Outer_Function)				\
ADD_TRAIT_NAME( Function);											\
namespace Interface{												\
														\
template< class T1, class T2>											\
struct Trait_Functor< _##context::Context, Trait_Names::Function##T, Class<T1,T2> >{	\
  FUNCTOR_GUTS( Outer_Function)										\
};														\
														\
template< class T1, class T2>											\
struct Traits< _##context::Context,									\
              Trait_Names::Function##T,								\
              Class<T1, T2> >{											\
  typedef  _##context::Context Context;							\
  typedef  Trait_Names::Function##T Function;						\
														\
  static const bool is_specialized = true;									\
  static const bool is_specialized_here = true;									\
  static const bool same_context = true;									\
  typedef Trait_Functor< Context, Function, Class<T1,T2> > Result;						\
};														\
														\
} class None

#define SET_FUNCTION_TEMPLATED2_TRAIT( Function, Class, Outer_Function)				\
ADD_TRAIT_NAME( Function);											\
namespace Interface{												\
														\
template< class T1, class T2>											\
struct Trait_Functor< _Global::Context, Trait_Names::Function##T, Class<T1,T2> >{	\
  FUNCTOR_GUTS( Outer_Function)										\
};														\
														\
template< class T1, class T2>											\
struct Traits< _Global::Context,									\
              Trait_Names::Function##T,								\
              Class<T1, T2> >{											\
  typedef  _Global::Context Context;							\
  typedef  Trait_Names::Function##T Function;						\
														\
  static const bool is_specialized = true;									\
  static const bool is_specialized_here = true;									\
  static const bool same_context = true;									\
  typedef Trait_Functor< Context, Function, Class<T1,T2> > Result;						\
};														\
														\
} class None


//###########################################################################################
#define SET_FUNCTION_W_RET_LOCAL_TEMPLATED2_TRAIT( context, Function, Class, Outer_Function, Ret)			\
ADD_TRAIT_NAME( Function);											\
namespace Interface{												\
														\
template< class T1, class T2>											\
struct Trait_Functor< _##context::Context, Trait_Names::Function##T, Class<T1,T2> >{	\
  typedef Ret Return; \
  FUNCTOR_W_RET_GUTS( Outer_Function, Return)									\
};														\
														\
template< class T1, class T2>											\
struct Traits< _##context::Context,									\
              Trait_Names::Function##T,								\
              Class<T1, T2> >{											\
  typedef  _##context::Context Context;							\
  typedef  Trait_Names::Function##T Function;						\
														\
  static const bool is_specialized = true;									\
  static const bool is_specialized_here = true;									\
  static const bool same_context = true;									\
  typedef Trait_Functor< Context, Function, Class<T1,T2> > Result;						\
};														\
														\
} class None


#define SET_FUNCTION_W_RET_TEMPLATED2_TRAIT( Function, Class, Outer_Function, Ret)			\
ADD_TRAIT_NAME( Function);										\
namespace Interface{											\
													\
template< class T1, class T2>										\
struct Trait_Functor< _Global::Context, Trait_Names::Function##T, Class<T1,T2> >{	\
  typedef Ret Return;											\
  FUNCTOR_W_RET_GUTS( Outer_Function, Return)								\
};													\
													\
template< class T1, class T2>										\
struct Traits< _Global::Context,								\
              Trait_Names::Function##T,							\
              Class<T1, T2> >{										\
  typedef  _Global::Context Context;								\
  typedef  Trait_Names::Function##T Function;						\
													\
  static const bool is_specialized = true;								\
  static const bool is_specialized_here = true;								\
  static const bool same_context = true;								\
  typedef Trait_Functor< Context, Function, Class<T1,T2> > Result;					\
};													\
													\
} class None




