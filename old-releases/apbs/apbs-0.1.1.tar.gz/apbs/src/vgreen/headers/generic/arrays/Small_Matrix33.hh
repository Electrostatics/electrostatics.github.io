namespace UCSD_Bioeng{

//################################################
template< class T>
class Small_Matrix< T, 3,3>{

public:
  static const size_t n0 = 3, n1 = 3;

  Small_Matrix(){
    Zero();
  }

  void Zero(){
    FUNCTION( Zero, T)( data[0][0]);
    FUNCTION( Zero, T)( data[0][1]);
    FUNCTION( Zero, T)( data[0][2]);
    FUNCTION( Zero, T)( data[1][0]);
    FUNCTION( Zero, T)( data[1][1]);
    FUNCTION( Zero, T)( data[1][2]);
    FUNCTION( Zero, T)( data[2][0]);
    FUNCTION( Zero, T)( data[2][1]);
    FUNCTION( Zero, T)( data[2][2]);    
  }

  Small_Matrix( T t00, T t01, T t02, 
		T t10, T t11, T t12, 
		T t20, T t21, T t22){

    data[0][0] = t00;
    data[0][1] = t01;
    data[0][2] = t02;
    data[1][0] = t10;
    data[1][1] = t11;
    data[1][2] = t12;
    data[2][0] = t20;
    data[2][1] = t21;
    data[2][2] = t22;
  }

  const T& operator()( size_t i, size_t j) const{
    Check_indices( i,j);
    return data[i][j];
  }

  T& operator()( size_t i, size_t j){
    Check_indices( i,j);
    return data[i][j];
  }

  /*
  template< class M>
  Small_Matrix( const M& _other){
    Do_nothing( Equality_Asserter_size_t< TRAIT( Size0, M), n0>());
    Do_nothing( Equality_Asserter_size_t< TRAIT( Size1, M), n1>());

    TRAIT( Inner_Const_Ref, M) other(_other);

    FOR( i, 0, n0) FOR( j, 0, n1)
      Copy( other(i,j), data[i][j]);
  }

  template< class M>
  Small_Matrix< T,n0,n1> operator=( const M& _other){
    Do_nothing( Equality_Asserter_size_t< TRAIT( Size0, M), n0>());
    Do_nothing( Equality_Asserter_size_t< TRAIT( Size1, M), n1>());

    TRAIT( Inner_Const_Ref, M) other(_other);

    FOR( i, 0, n0) FOR( j, 0, n1)
      Copy( other(i,j), data[i][j]);
    return *this;
  }
  */

  //######################################
private:

#ifdef DEBUG
  void Check_indices( size_t i, size_t j) const{
    if (i >= n0 || j >= n1)
      Error1( *this, "index out of range");
  }
#else
  void Check_indices( size_t, size_t) const{}
#endif


  T data[n0][n1];
};


//#############################################
/*
template< class Stream, class T, size_t n0, size_t n1>
inline
Stream& operator<<( Stream& stream, const Small_Matrix< T, n0, n1>& m){
  
  stream << "\n";
  FOR( i, 0, n0) {
    FOR( j, 0, n1)
      stream << m( i,j) << " ";
    stream << "\n";
  }
  return stream;
}


//#############################################
template< class Stream, class T, size_t n0, size_t n1>
inline
Stream& operator>>( Stream& stream, Small_Matrix< T, n0, n1>& m){
  
  FOR( i, 0, n0) FOR( j, 0, n1)
    stream >> m( i,j);

  return stream;
}
*/

}


