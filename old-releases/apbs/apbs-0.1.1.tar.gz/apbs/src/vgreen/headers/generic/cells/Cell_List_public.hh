
  typedef Small_Vector< double, 3> Inner_Position;

  typedef LTRAIT( Pointer,  Particles) Pointer;
  typedef LTRAIT( Const_Pointer,  Particles) Const_Pointer;
  typedef LTRAIT( Forward_Index,  Particles) Index;
  typedef LTRAIT( Const_Forward_Index,  Particles) Const_Index;
