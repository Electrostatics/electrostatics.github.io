/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
//////////////////////////////////////////////////////////////////////////// 
/// rcsid="$Id: mgsh.c,v 1.3 2001/05/22 18:30:22 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     mgsh.c
//
// Purpose:  Class MGsh: methods.
//
// Author:   Nathan Baker and Michael Holst
//
// Note:     This file is derived from the FEtk/MG file mcsh.c written by Mike
//           Holst
/////////////////////////////////////////////////////////////////////////// */

#include "apbscfg.h"
#include "maloc/maloc.h"
#include "apbs/mgsh.h"
#include "apbs/vpbe.h"
#include "apbs/vpmg.h"
#include "apbs/vpmgp.h"
#include "apbs/valist.h"
#include "apbs/vatom.h"

VEMBED(rcsid="$Id: mgsh.c,v 1.3 2001/05/22 18:30:22 apbs Exp $")

/* builtin MGsh commands */
typedef enum MGsh_command {
    mgcom_none,
    mgcom_initpbe,
    mgcom_lsolve,
    mgcom_nsolve,
    mgcom_lenergy1,
    mgcom_lenergy2,
    mgcom_nenergy,
    mgcom_sasa,
    mgcom_writepot,
    mgcom_writeacc,
    mgcom_readmol,
    mgcom_memchk,
    mgcom_free,
    mgcom_help
} MGsh_command;

VPRIVATE void initPartitions(MGsh *thee);
VPRIVATE void solvePDE(MGsh *thee, int imol, int nonlin);
VPRIVATE int checkMolNumber(int imol);

/* ///////////////////////////////////////////////////////////////////////////
// Class MGsh: Inlineable methods
/////////////////////////////////////////////////////////////////////////// */
#if !defined(VINLINE_MGSH)

#endif /* if !defined(VINLINE_MGSH) */
/* ///////////////////////////////////////////////////////////////////////////
// Class MGsh: Non-inlineable methods
/////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGsh_ctor
//
// Purpose:  The MGsh constructor.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC MGsh* MGsh_ctor(int argc, char **argv) {

    MGsh *thee = VNULL;

    int i;

    VDEBUGIO("MGsh_ctor: CREATING object..");

    thee = Vmem_malloc( VNULL, 1, sizeof(MGsh) );
    thee->vmem = Vmem_ctor( "MGsh" );

    VDEBUGIO("..done.\n");

    /* the environment and shell object */
    thee->PR[0] = '\0';
    thee->USER_shell = VNULL;
    thee->vsh = Vsh_ctor(VNULL, argc, argv);

    /* set the various MG object pointers to VNULL */
    for (i=0; i<MAXFOCUS; i++) {
        thee->pmg[i] = VNULL;
        thee->pmgp[i] = VNULL;
    }
    for (i=0; i<MAXMOL; i++) {
        thee->pbe[i] = VNULL;
        thee->alist[i] = VNULL;
    }
    
    return thee;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGsh_dtor
//
// Purpose:  The MGsh destructor.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void MGsh_dtor(MGsh **thee) {

    int i;

    if ((*thee) != VNULL) {

        for (i=0; i<MAXFOCUS; i++) {
            if ((*thee)->pmg[i] != VNULL) Vpmg_dtor(&((*thee)->pmg[i]));
            if ((*thee)->pmgp[i] != VNULL) Vpmgp_dtor(&((*thee)->pmgp[i]));
        }
        for (i=0; i<MAXMOL; i++) {
            if ((*thee)->pbe[i] != VNULL) Vpbe_dtor(&((*thee)->pbe[i]));
            if ((*thee)->alist[i] != VNULL) Valist_dtor(&((*thee)->alist[i]));
        }

        VDEBUGIO("MGsh_dtor: DESTROYING object..");
        Vmem_dtor( &((*thee)->vmem) );
        Vmem_free( VNULL, 1, sizeof(MGsh), (void**)thee );
        VDEBUGIO("..done.\n");

        (*thee) = VNULL;
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGsh_publishVars
//
// Purpose:  Publish a set of environment variables with Vsh.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE void MGsh_publishVars(MGsh *thee)
{
    int i, numVars = 40;
    typedef struct mgVars {
        char envi[80];
        char valu[80];
        char info[80];
    } mgVars;
    mgVars envVars[] = {

        /* --------   -----       ----------- */
        /* VARIABLE   VALUE       EXPLANATION */
        /* --------   -----       ----------- */

        /* *** 11 PBE VARIABLES ** */
        { "IONC",   "0.0",
            "monovalent ion concentration (M)" },
        { "TEMPR",  "298.15",
            "temperature (K)" },
        { "PDIEL",  "2.00",
            "solute dielectric constant" },
        { "SDIEL",  "78.54",
            "solvent dielectric constant" },
        { "RION",   "2.00",
            "ion exclusion radius (Ang)" },
        { "RSOLV",  "1.40",
            "solvent exclusion radius (Ang)" },
        { "BCFL",   "2",
            "boundary condition flag (0=zero,1=single DH,2=multi DH,4=focus)" },
        { "LENERGY", "0.0",
            "elec. energy (kJ/mol, only for local part, set by energy commands)" },
        { "GENERGY", "0.0",
            "elec. energy (kJ/mol, for entire system, set by energy commands)" },
        { "SASA", "0.0",
            "solvent-accessible surface area (Ang^2)" },
        { "MOL",    "0",
            "molecule index; controls currently active molecule" },

        /* *** 9 MESH VARIABLES *** */
        { "NX",     "97",
            "number of mesh points in the x-direction (= 2^l+1)" },
        { "NY",     "97",
            "number of mesh points in the y-direction (= 2^l+1)" },
        { "NZ",     "97",
            "number of mesh points in the z-direction (= 2^l+1)" },
        { "HX",     "0.5",
            "mesh spacing in the x-direction (Ang)" },
        { "HY",     "0.5",
            "mesh spacing in the y-direction (Ang)" },
        { "HZ",     "0.5",
            "mesh spacing in the z-direction (Ang)" },
        { "XCENT",  "0.0",
            "x-coordinate of mesh center (Ang)" },
        { "YCENT",  "0.0",
            "y-coordinate of mesh center (Ang)" },
        { "ZCENT",  "0.0",
            "z-coordinate of mesh center (Ang)" },

        /* *** 6 FOCUSING VARIABLES *** */
        { "XLENF",  "14.0",
            "length of focused subdomain in x-direction (Ang)" },
        { "YLENF",  "14.0",
            "length of focused subdomain in y-direction (Ang)" },
        { "ZLENF",  "14.0",
            "length of focused subdomain in z-direction (Ang)" },
        { "XCENTF",  "0.0",
            "x-ccordinate for focused subdomain center (Ang)" },
        { "YCENTF",  "0.0",
            "y-coordinate for focused subdomain center (Ang)" },
        { "ZCENTF",  "0.0",
            "z-coordinate for focused subdomain center (Ang)" },

        /* *** 4 PARALLEL VARIABLES *** */
        { "OFRAC",  "0.1",
            "overlap fraction for parallel focusing" },
        { "NPX",  "1",
            "number of processors in x-direction" },
        { "NPY",  "1",
            "number of processors in y-direction" },
        { "NPZ",  "1",
            "number of processors in y-direction" },

        /* *** 10 SOLVER VARIABLES *** */
        { "NLEV",   "4",
            "depth of hierarchy (see 'l' in 'NX','NY','NZ' definitions)" },
        { "NMAX",     "100",
            "maximum number of iterations"},
        { "ISTOP",     "1",
            "iter stop criterion (0=res,1=relres,2=dif,3=errc,4=errd,5=aerrd)"},
        { "LTOL",     "1.0e-9",
            "linear solve error tolerance" },
        { "NTOL",     "1.0e-7",
            "nonlinear solve error tolerance" },
        { "IINFO",     "1",
            "PMG runtime status messages (0=none,1=some,2=lots,etc.)" },
        { "IPERF",     "0",
            "operator analysis (0=none,1=cond,2=spec radius,3=both)" },
        { "LKEY",      "2",
            "lin solv meth (0=cgmg,1=newton,2=mg,3=cg,4=sor,5=rbgs,6=wjac,7-rich)" },
        { "OMEGAL",    "0.8",
            "linear relaxation parameter" },
        { "OMEGAN",    "0.9",
            "nonlinear relaxation parameter" },

        /* *** 2 I/O VARIABLES *** */
        { "MOLFMT",    "0",
            "molecule data format (0=pqr)"},
        { "FCNFMT",    "0",
            "grid-based function format (0=OpenDX,1=UHBD)"}

    };

    for (i=0; i<numVars; i++) {
        Vsh_putenv(     thee->vsh, envVars[i].envi, envVars[i].valu );
        Vsh_putenvInfo( thee->vsh, envVars[i].envi, envVars[i].info );
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGsh_getCmd
//
// Purpose:  Get (decode) the command.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE MGsh_command MGsh_getCmd(MGsh *thee, int argc, char **argv)
{
    MGsh_command theCmd = mgcom_none;
    if (!strcmp(argv[0],"")) {
        theCmd = mgcom_none;
    } else if (!strcmp(argv[0],"help")) { 
        theCmd = mgcom_help;
    } else if (!strcmp(argv[0],"initpbe")) {
        theCmd = mgcom_initpbe;
    } else if (!strcmp(argv[0],"lsolve")) {
        theCmd = mgcom_lsolve;
    } else if (!strcmp(argv[0],"nsolve")) {
        theCmd = mgcom_nsolve;
    } else if (!strcmp(argv[0],"lenergy1")) {
        theCmd = mgcom_lenergy1;
    } else if (!strcmp(argv[0],"lenergy2")) {
        theCmd = mgcom_lenergy2;
    } else if (!strcmp(argv[0],"nenergy")) {
        theCmd = mgcom_nenergy;
    } else if (!strcmp(argv[0],"sasa")) {
        theCmd = mgcom_sasa;
    } else if (!strcmp(argv[0],"writepot")) {
        theCmd = mgcom_writepot;
    } else if (!strcmp(argv[0],"writeacc")) {
        theCmd = mgcom_writeacc;
    } else if (!strcmp(argv[0],"readmol")) {
        theCmd = mgcom_readmol;
    } else if (!strcmp(argv[0],"memchk")) {
        theCmd = mgcom_memchk;
    } else if (!strcmp(argv[0],"free")) {
        theCmd = mgcom_free;
    } else {
        theCmd = mgcom_none;
    }
    return theCmd;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGsh_ioSetup
//
// Purpose:  Setup for an I/O command.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE void MGsh_ioSetup(MGsh *thee,
    char *key, char *iodev, char *iofmt, char *iohost, char *iofile)
{
    /* setup for a read */
    if (!strcmp("r",key)) {

        strncpy(iohost,Vsh_getenv(thee->vsh,"IHVAL"),VMAX_BUFSIZE);

        if (!strcmp("sdio",Vsh_getenv(thee->vsh,"ISKEY"))) {
            strncpy(iodev,"SDIO",VMAX_BUFSIZE);
            strncpy(iofile,"console",VMAX_BUFSIZE);
        } else if (!strcmp("file",Vsh_getenv(thee->vsh,"ISKEY"))) {
            strncpy(iodev,"FILE",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"IFNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("buff",Vsh_getenv(thee->vsh,"ISKEY"))) {
            strncpy(iodev,"BUFF",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"ISNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("unix",Vsh_getenv(thee->vsh,"ISKEY"))) {
            strncpy(iodev,"UNIX",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"ISNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("inet",Vsh_getenv(thee->vsh,"ISKEY"))) {
            strncpy(iodev,"INET",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"ISNAM"),VMAX_BUFSIZE);
        } else Vnm_print(2,"MGsh_ioSetup: Internal logic error.\n");

        if (!strcmp("asc",Vsh_getenv(thee->vsh,"ISFMT"))) {
            strncpy(iofmt,"ASC", VMAX_BUFSIZE);
        } else if (!strcmp("xdr",Vsh_getenv(thee->vsh,"ISFMT"))) {
            strncpy(iofmt,"XDR", VMAX_BUFSIZE);
        } else Vnm_print(2,"MGsh_ioSetup: Internal logic error.\n");

    /* setup for a write */
    } else if (!strcmp("w",key)) {

        strncpy(iohost,Vsh_getenv(thee->vsh,"OHVAL"),VMAX_BUFSIZE);

        if (!strcmp("sdio",Vsh_getenv(thee->vsh,"OSKEY"))) {
            strncpy(iodev,"SDIO",VMAX_BUFSIZE);
            strncpy(iofile,"console",VMAX_BUFSIZE);
        } else if (!strcmp("file",Vsh_getenv(thee->vsh,"OSKEY"))) {
            strncpy(iodev,"FILE",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"OFNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("buff",Vsh_getenv(thee->vsh,"OSKEY"))) {
            strncpy(iodev,"BUFF",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"OSNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("unix",Vsh_getenv(thee->vsh,"OSKEY"))) {
            strncpy(iodev,"UNIX",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"OSNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("inet",Vsh_getenv(thee->vsh,"OSKEY"))) {
            strncpy(iodev,"INET",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"OSNAM"),VMAX_BUFSIZE);
        } else Vnm_print(2,"MGsh_ioSetup: Internal logic error.\n");

        if (!strcmp("asc",Vsh_getenv(thee->vsh,"OSFMT"))) {
            strncpy(iofmt,"ASC", VMAX_BUFSIZE);
        } else if (!strcmp("xdr",Vsh_getenv(thee->vsh,"OSFMT"))) {
            strncpy(iofmt,"XDR", VMAX_BUFSIZE);
        } else Vnm_print(2,"MGsh_ioSetup: Internal logic error.\n");

    } else Vnm_print(2,"MGsh_ioSetup: Internal logic error.\n");

    Vnm_print(0,"MGsh_ioSetup: iodev =<%s>\n", iodev);
    Vnm_print(0,"MGsh_ioSetup: iofmt =<%s>\n", iofmt);
    Vnm_print(0,"MGsh_ioSetup: iohost=<%s>\n", iohost);
    Vnm_print(0,"MGsh_ioSetup: iofile=<%s>\n", iofile);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGsh_builtIn
//
// Purpose:  Deal with a builtin command.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE int MGsh_builtIn(void *pthee, int argc, char **argv)
{
    MGsh *thee = (MGsh*)pthee;

    int i,rank,imol,rc;
    char iodev[VMAX_BUFSIZE], iofmt[VMAX_BUFSIZE];
    char iohost[VMAX_BUFSIZE], iofile[VMAX_BUFSIZE];
    double lenergy, genergy; 
    MGsh_command theCmd;

    static int  init=0;
    static char helpmsg[VMAX_BUFSIZE];
    const char *stmp;

    /* one-time intialization */
    if (!init) {
        init=1;

        /* make the pbe message (%s slots = 1) */
        stmp = "%s: Commands: \n"
               "    initpbe  --> initial problem from given PBE parms\n"
               "    lsolve   --> solve the LPBE\n"
               "    nsolve   --> solve the NPBE\n"
               "    lenergy1 --> calc LPBE free energy via sum over atoms\n"
               "    lenergy2 --> calc LPBE free energy via energy norm\n"
               "    nenergy  --> calc NPBE free energy\n"
               "    sasa     --> calc solvent-accessible surface area\n"
               "    writepot --> write out potential\n"
               "    writeacc --> write out solvent accessibility\n"
               "    readmol  --> read in molecule data in PQR format\n"
               "    memchk   --> check memory usage\n"
               "    free     --> free all allocated memory\n"
               "    help     --> get some help (help <command> works, too)\n";
        sprintf(helpmsg,stmp,thee->PR);

    }

    /* the user-defined shell gets first shot at the command */
    if (thee->USER_shell != VNULL) {
        rc = (*(thee->USER_shell))(thee,argc,argv);
        if (rc != 0) return rc;
    }

    /* default return code (success) */
    rc = 1;

    /* get the command */
    theCmd = MGsh_getCmd(thee, argc, argv);

    /* get the current molecule number */
    imol = Vsh_getenvInt(thee->vsh, "MOL");
    if (!checkMolNumber(imol)) return rc;

    /* get the current proc rank and ignore "eliminated" procs */
    rank = Vsh_getenvInt(thee->vsh, "VMP_I");
    if (rank < 0) return rc;

    /* decode and execute the command */
    switch (theCmd) {

      case mgcom_initpbe:
        if (thee->alist[imol] == VNULL) {
            Vnm_print(2, "MGsh: NULL molecule; do `readmol` first or check MOL\n!");
            break;
        }
        thee->pbe[imol] = Vpbe_ctor(thee->alist[imol], 
          Vsh_getenvReal(thee->vsh, "IONC"),
          Vsh_getenvReal(thee->vsh, "RION"), 
          Vsh_getenvReal(thee->vsh, "TEMPR"),
          Vsh_getenvReal(thee->vsh, "PDIEL"), 
          Vsh_getenvReal(thee->vsh, "SDIEL"),
          Vsh_getenvReal(thee->vsh, "RSOLV"));
        break;

      case mgcom_lsolve:
        solvePDE(thee, imol, 0);
        break;

      case mgcom_nsolve:
        solvePDE(thee, imol, 1);
        break;

      case mgcom_lenergy1:
        if (Vsh_getenvInt(thee->vsh, "BCFL") != 4) {
            if (thee->pmg[0] != VNULL) {
                lenergy = Vunit_kb*Vsh_getenvReal(thee->vsh, "TEMPR")
                  *Vunit_Na*Vpmg_energy(thee->pmg[0],0)/1000.0;
            } else {
                Vnm_print(2, "MGsh: NULL unfocused MG object; run `lsolve`/`nsolve` first!\n");
                break;
            }
        } else {
            if (thee->pmg[1] != VNULL) {
                lenergy = Vunit_kb*Vsh_getenvReal(thee->vsh, "TEMPR")
                  *Vunit_Na*Vpmg_energy(thee->pmg[1],0)/1000.0;
            } else {
                Vnm_print(2, "MGsh: NULL focused MG object; run `lsolve`/`nsolve` first or check BCFL!\n");
                break;
            }
        }
        Vsh_putenvReal(thee->vsh, "LENERGY", lenergy);
#if 0
        Vcom_reduce(thee->com, &lenergy, &genergy, 1, 2, 0);
#else
        Vnm_print(2, "MGsh: WARNING -- Vcom support not available yet!\n");
        Vnm_print(2, "MGsh: Setting global energy to local!\n");
        genergy = lenergy;
#endif
        Vsh_putenvReal(thee->vsh, "GENERGY", genergy);
        break;

      case mgcom_lenergy2:
        Vnm_print(2, "MGsh: Sorry -- 'lenergy2' not implemented yet.\n");
        break;

      case mgcom_nenergy:
        Vnm_print(2, "MGsh: Sorry -- 'nenergy' not implemented yet.\n");
        break;

      case mgcom_sasa:
        if (thee->pbe[imol] == VNULL) {
            Vnm_print(2, "MGsh: NULL PBE object; run `initpbe` first\n");
            break;
        }
        Vsh_putenvReal(thee->vsh, "SASA",
          Vacc_totalSASA(Vpbe_getVacc(thee->pbe[imol]), 
          Vsh_getenvReal(thee->vsh, "RSOLV")));
        break;

      case mgcom_readmol:
        if (thee->alist[imol] != VNULL) {
            Valist_dtor(&(thee->alist[imol]));
        }
        thee->alist[imol] = Valist_ctor();
        MGsh_ioSetup(thee,"r",iodev,iofmt,iohost,iofile);
        if (Vsh_getenvInt(thee->vsh, "MOLFMT") != 0) {
            Vnm_print(2, "MGsh: ERROR -- invalid format (MOLFMT = %d)\n",
              Vsh_getenvInt(thee->vsh, "MOLFMT"));
            break;
        }
        Valist_readPQR(thee->alist[imol], iodev, iofmt, iohost, iofile);
        Vnm_print(0, "MGsh: read %d atoms.\n",
          Valist_getNumberAtoms(thee->alist[imol]));
        break;

      case mgcom_writepot:
        MGsh_ioSetup(thee,"w",iodev,iofmt,iohost,iofile);
        if (Vsh_getenvInt(thee->vsh, "BCFL") != 4) {
            if (thee->pmg[0] == VNULL) {
                Vnm_print(2, "MGsh: NULL unfocused MG object; run `lsolve`/`nsolve`\n");
                break;
            }
            Vpmg_writeDX(thee->pmg[0], iodev, iofmt, iohost, iofile,
              "POTENTIAL", thee->pmg[0]->u);
        } else {
            if (thee->pmg[1] == VNULL) {
                Vnm_print(2, "MGsh: NULL focused MG object; run `lsolve`/`nsolve` or reset BCFL\n");
                break;
            }
            Vpmg_writeDX(thee->pmg[1], iodev, iofmt, iohost, iofile,
              "POTENTIAL", thee->pmg[1]->u);
        }
        break;

      case mgcom_writeacc:
        MGsh_ioSetup(thee,"w",iodev,iofmt,iohost,iofile);
        if (Vsh_getenvInt(thee->vsh, "BCFL") != 4) {
            if (thee->pmg[0] == VNULL) {
                Vnm_print(2, "MGsh: NULL unfocused MG object; run `lsolve`/`nsolve`\n");
                break;
            }
            Vpmg_fillAcc(thee->pmg[0], thee->pmg[0]->rwork, 0, 
              Vsh_getenvReal(thee->vsh, "RSOLV"));
            Vpmg_writeDX(thee->pmg[0], iodev, iofmt, iohost, iofile,
              "SOLVENT ACCESSIBILITY", thee->pmg[0]->rwork);
        } else {
            if (thee->pmg[1] == VNULL) {
                Vnm_print(2, "MGsh: NULL focused MG object; run `lsolve`/`nsolve`\n");
                break;
            }
            Vpmg_fillAcc(thee->pmg[1], thee->pmg[1]->rwork, 0, 
              Vsh_getenvReal(thee->vsh, "RSOLV"));
            Vpmg_writeDX(thee->pmg[1], iodev, iofmt, iohost, iofile,
              "SOLVENT ACCESSIBILITY", thee->pmg[1]->rwork);
        }
        break;

      case mgcom_memchk:
        MGsh_memChk(thee);
        break;

      case mgcom_free:
        for (i=0; i<MAXMOL; i++) {
            if (thee->pbe[i] != VNULL) Vpbe_dtor(&(thee->pbe[i]));
            if (thee->alist[i] != VNULL) Valist_dtor(&(thee->alist[i]));
        }
        for (i=0; i<MAXFOCUS; i++) {
            if (thee->pmg[i] != VNULL) Vpmg_dtor(&(thee->pmg[i]));
            if (thee->pmgp[i] != VNULL) Vpmgp_dtor(&(thee->pmgp[i]));
        }
        break;

      case mgcom_help:
        if (argc==1) {
            Vnm_print(1,"MGsh: MGsh-layer Help Menu:\n");
            Vnm_print(1, helpmsg);
            Vnm_print(1,"MGsh: do `help <command>` and `pinfo` for more information\n");
            rc = 0;  /* pretend we didn't see it so subshell can help too */
        } else {
            if (!strcmp(argv[1],"initpbe")) { 
                stmp = 
"initpbe -- Initializes PBE-specific internal variables and structures.\n"
"           A molecule must be read in first with `readmol` and this\n"
"           molecule should be specified by setting the MOL variable to\n"
"           the appropriate value.\n"
"           See variables IONC TEMPR PDIEL SDIEL RION RSOLV BCFL.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"lsolve")) { 
                stmp = 
"lsolve -- Solves the LPBE via multigrid.\n"
"          The PBE system must be initialized with initpbe and, if\n"
"          focusing is desired (BCFL=4), a previous lsolve or nsolve\n"
"          must have been executed.  A specific molecule should be selected\n"
"          by setting the variable MOL to the appropriate value.\n"
"          Grid specification:\n"
"            See variables NLEV NX NY NZ HZ HY HZ XCENT YCENT ZCENT for\n"
"            normal calculations.\n"
"            See also variables XLENF YLENF ZLENF XCENTF YCENTF ZCENTF\n"
"            OFRAC NPX NPY NPZ for focusing and parallel focusing\n"
"            calculations.\n"
"          Solver parameters:\n"
"            See variables NMAX ISTOP NTOL IINFO IPERF LKEY OMEGAL OMEGAN\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"nsolve")) { 
                stmp =
"nsolve -- Solves the NPBE via multigrid.\n"
"          The PBE system must be initialized with initpbe and, if\n"
"          focusing is desired (BCFL=4), a previous lsolve or nsolve\n"
"          must have been executed.  A specific molecule should be selected\n"
"          by setting the variable MOL to the appropriate value.\n"
"          Grid specification:\n"
"            See variables NLEV NX NY NZ HZ HY HZ XCENT YCENT ZCENT for\n"
"            normal calculations.\n"
"            See also variables XLENF YLENF ZLENF XCENTF YCENTF ZCENTF\n"
"            OFRAC NPX NPY NPZ for focusing and parallel focusing\n" 
"            calculations.\n"
"          Solver parameters:\n"
"            See variables NMAX ISTOP NTOL IINFO IPERF LKEY OMEGAL OMEGAN\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"lenergy1")) { 
                stmp = 
"lenergy1 -- Calculate the free energy (including self-energy) from the\n"
"            solution to the LPBE and return the result in units of kJ/mol.\n"
"            The energy is calculated by a sum of the potential evaluated\n"
"            pointwise at the atomic locations.  This command must be\n"
"            preceded by a call to either `lsolve` or `nsolve` and requires\n"
"            that the appropriate molecule be selected by setting the MOL"
"            variable.\n"
"            For parallel calculations, the energy contribution from the\n"
"            local partition is stored in variable LENERGY and the global\n"
"            energy is stored in GENERGY.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"lenergy2")) { 
                stmp = 
"lenergy2 -- NOT IMPLEMENTED YET.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"nenergy")) { 
                stmp = 
"nenergy -- NOT IMPLEMENTED YET.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"sasa")) { 
                stmp = 
"sasa -- Calculate the solvent-accessible surface area for the molecule and\n"
"        return the result in Angstroms^2.  This command must be preceded\n"
"        by a call to `initpbe` and requires that the variable MOL be set\n"
"        to the appropriate molecule ID.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"writepot")) { 
                stmp =
"writepot -- Write out the electrostatic potential in the specified format\n"
"            (see variable FCNFMT).  This command must be preceded by a\n"
"            call to either `lsolve` or `nsolve`.\n"
"            See variables FCNFMT OSKEY OSFMT OFNAM OSNAM OHVAL.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"writeacc")) { 
                stmp = 
"writeacc -- Write out the solvent accessibility in the specified format\n"
"            (see variable FCNFMT).  This command must be preceded by a\n"
"            call to either `initpbe` and MOL must be set to the\n"
"            appropriate value.\n"
"            See also variables OSKEY OSFMT OFNAM OSNAM OHVAL.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"writeacc")) { 
                stmp = 
"readmol -- Read in a molecule in the specified format (see variable\n"
"           MOLFMT).  The molecule will be assigned the value of MOL as an\n"
"           ID.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"memchk")) { 
                stmp = 
"memchk -- Report the memory usage by objects allocated from the MGsh\n"
"          constructor.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"free")) { 
                stmp = 
"free -- Destroys all objects allocated by MGsh.  Great way to start over.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else if (!strcmp(argv[1],"help")) { 
                stmp = "help -- Get some much-needed help.\n";
                Vnm_print(1, "\n%s\n", stmp);
            } else {
                rc = 0;  /* we didn't get it; give it to the subshell */
            }
        }
        break;                                                              

      default:
        rc = 0;
        break;
    }
    return rc;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGsh_shell
//
// Purpose:  The actual shell.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int MGsh_shell(MGsh *thee, 
    int (*USER_shell)(void *thee, int argc, char **argv))
{
    thee->USER_shell = USER_shell;
    strcpy(thee->PR,"MGsh");
    MGsh_publishVars(thee);
    return Vsh_shell(thee->vsh, thee->PR, (void*)thee, &MGsh_builtIn);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGsh_memChk
//
// Purpose:  Print the exact current malloc usage.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void MGsh_memChk(MGsh *thee)
{
    int i, mem;
    Vnm_print(0, "MG SOLVER STORAGE:\n");
    mem = 0;
    for (i=0; i<MAXFOCUS; i++) {
        if (thee->pmg[i] != VNULL) {
            mem += Vpmg_memChk(thee->pmg[i]);
            Vnm_print(0, "\tFocus level #%d: %d B\n", i,
               Vpmg_memChk(thee->pmg[i]));
        }
        Vnm_print(0, "\tTotal: %d B\n", mem);
    }
    Vnm_print(0, "MG PARAMETER STORAGE:\n");
    mem = 0;
    for (i=0; i<MAXFOCUS; i++) {
        if (thee->pmgp[i] != VNULL) {
            mem += sizeof(Vpmgp);
            Vnm_print(0, "\tFocus level #%d: %d B\n", i, sizeof(Vpmgp));
        }
        Vnm_print(0, "\tTotal: %d B\n", mem);
    }
    Vnm_print(0, "PBE OBJECT STORAGE:\n");
    mem = 0;
    for (i=0; i<MAXMOL; i++) {
        if (thee->pbe[i] != VNULL) {
            mem += Vpbe_memChk(thee->pbe[i]);
            Vnm_print(0, "\tMolecule #%d: %d B\n", i,
              Vpbe_memChk(thee->pbe[i]));
        }
        Vnm_print(0, "\tTotal: %d B\n", mem);
    }
    Vnm_print(0, "ATOMIC DATA STORAGE:\n");
    mem = 0;
    for (i=0; i<MAXMOL; i++) {
        if (thee->alist[i] != VNULL) {
            mem += Valist_memChk(thee->alist[i]);
            Vnm_print(0, "\tMolecule #%d: %d B\n", i,
              Valist_memChk(thee->alist[i]));
        }
        Vnm_print(0, "\tTotal: %d B\n", mem);
    }
    Vnm_print(0, "OVERALL MEMORY USAGE:\n");
    Vnm_print(0, "\tTotal bytes:     %d B\n", Vmem_bytesTotal());
    Vnm_print(0, "\tTotal allocated: %d B\n", Vmem_mallocBytesTotal());
    Vnm_print(0, "\tTotal freed:     %d B\n", Vmem_freeBytesTotal());
    Vnm_print(0, "\tHigh water mark: %d B\n", Vmem_highWaterTotal());
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  initPartitions
//
// Purpose:  Initialize the focusing partitions
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE void initPartitions(MGsh *thee) {

    int rank, nproc, np, npx, npy, npz, nx, ny, nz;
    double ofrac;
    double xlenFOCUS, ylenFOCUS, zlenFOCUS;
    double xcentFOCUS, ycentFOCUS, zcentFOCUS;

    nx = Vsh_getenvInt(thee->vsh, "NX");
    ny = Vsh_getenvInt(thee->vsh, "NY");
    nz = Vsh_getenvInt(thee->vsh, "NZ");
    npx = Vsh_getenvInt(thee->vsh, "NPX");
    npy = Vsh_getenvInt(thee->vsh, "NPY");
    npz = Vsh_getenvInt(thee->vsh, "NPZ");
    np = npx*npy*npz;
    nproc = Vsh_getenvInt(thee->vsh, "VMP_N");
    rank = Vsh_getenvInt(thee->vsh, "VMP_I");
    ofrac = Vsh_getenvReal(thee->vsh, "OFRAC");
    xlenFOCUS = Vsh_getenvReal(thee->vsh, "XLENF");
    ylenFOCUS = Vsh_getenvReal(thee->vsh, "YLENF");
    zlenFOCUS = Vsh_getenvReal(thee->vsh, "ZLENF");
    xcentFOCUS = Vsh_getenvReal(thee->vsh, "XCENTF");
    ycentFOCUS = Vsh_getenvReal(thee->vsh, "YCENTF");
    zcentFOCUS = Vsh_getenvReal(thee->vsh, "ZCENTF");

    /* Eliminate superfluous processors */
    if (np < nproc) {
        Vnm_print(2, "MGsh:  WARNING -- only using %d of %d available procs!\n",
          np, nproc);
        Vnm_print(2, "MGsh:  WARNING -- eliminating %d procs!\n", nproc - np);
#if 0
        Vcom_resize(thee->vsh->vcom, np);
        nproc = np;
        Vsh_putenvInt(thee->vsh, "VMP_N", np);
        rank = Vcom_rank(thee->vsh->vcom);
        Vsh_putenvInt(thee->vsh, "VMP_I", rank);
#else
        Vnm_print(2, "MGsh: ERROR -- no support for incorrect numbers of processors until Vcom gets implemented in Vsh\n");
        VASSERT(0);
#endif
    }

    /* Now, if we've survived the cut, do the rest... */
    if (rank != -1) {
        /* Processor coordinate */
        thee->kp = (int)floor(rank/(npx*npy));
        thee->jp = (int)floor((rank-(thee->kp)*npx*npy)/npx);
        thee->ip = rank - (thee->kp)*npx*npy - (thee->jp)*npx;
     
        /* Calculate the region over which energies will be calculated */
        thee->xlenPart = xlenFOCUS/((double)npx);
        thee->ylenPart = ylenFOCUS/((double)npy);
        thee->zlenPart = zlenFOCUS/((double)npz);
        thee->xcentPart = (thee->ip+0.5)*thee->xlenPart
          - 0.5*xlenFOCUS + xcentFOCUS;
        thee->ycentPart = (thee->jp+0.5)*thee->ylenPart
          - 0.5*ylenFOCUS + ycentFOCUS;
        thee->zcentPart = (thee->kp+0.5)*thee->zlenPart 
          - 0.5*zlenFOCUS + zcentFOCUS;

        /* Include the overlap and calculate the actual problem domain for this
         * processor */
        thee->xlenOlap = thee->xlenPart;
        thee->ylenOlap = thee->ylenPart;
        thee->zlenOlap = thee->zlenPart;
        thee->xcentOlap = thee->xcentPart;
        thee->ycentOlap = thee->ycentPart;
        thee->zcentOlap = thee->zcentPart;
        if (thee->ip != 0) {
            thee->xlenOlap += (ofrac*thee->xlenPart);
            thee->xcentOlap -= (0.5*ofrac*thee->xlenPart);
        }
        if (thee->ip != (npx-1)) {
            thee->xlenOlap += (ofrac*thee->xlenPart);
            thee->xcentOlap += (0.5*ofrac*thee->xlenPart);
        }
        if (thee->jp != 0) {
            thee->ylenOlap += (ofrac*thee->ylenPart);
            thee->ycentOlap -= (0.5*ofrac*thee->ylenPart);
        }
        if (thee->jp != (npy-1)) {
            thee->ylenOlap += (ofrac*thee->ylenPart);
            thee->ycentOlap += (0.5*ofrac*thee->ylenPart);
        }
        if (thee->kp != 0) {
            thee->zlenOlap += (ofrac*thee->zlenPart);
            thee->zcentOlap -= (0.5*ofrac*thee->zlenPart);
        }
        if (thee->kp != (npz-1)) {
            thee->zlenOlap += (ofrac*thee->zlenPart);
            thee->zcentOlap += (0.5*ofrac*thee->zlenPart);
        }
    
        /* Set the actual mesh spacings used in the focused calculation */
        thee->hxf = thee->xlenOlap/((double)(nx-1));
        thee->hyf = thee->ylenOlap/((double)(ny-1));
        thee->hzf = thee->zlenOlap/((double)(nz-1));

    } 
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  solvePDE
//
// Purpose:  Construct, initialize the MG objects and solve. 
//           Also set domain for subsequent emergy, etc. calculations.
//
// Args:     nonlin   0 => LPBE
//                    1 => NPBE
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE void solvePDE(MGsh *thee, int imol, int nonlin) {

    if (thee->pbe[imol] == VNULL) {
        Vnm_print(2, "MGsh: NULL PBE object; do `initpbe` first or check the value of MOL!\n");
        return;
    }

    /* Check to see whether this is a coarse or focused run */
    if (Vsh_getenvInt(thee->vsh, "BCFL") != 4) {
        /* Construct the parameter object */
        if (thee->pmgp[0] != VNULL) Vpmgp_dtor(&(thee->pmgp[0]));
        thee->pmgp[0] = Vpmgp_ctor(
          Vsh_getenvInt(thee->vsh, "NX"),
          Vsh_getenvInt(thee->vsh, "NY"),
          Vsh_getenvInt(thee->vsh, "NZ"),
          Vsh_getenvInt(thee->vsh, "NLEV"),
          Vsh_getenvReal(thee->vsh, "HX"),
          Vsh_getenvReal(thee->vsh, "HY"),
          Vsh_getenvReal(thee->vsh, "HZ"),
          nonlin);
        /* Assign some of the other parameters */
        thee->pmgp[0]->xcent = Vsh_getenvReal(thee->vsh, "XCENT");
        thee->pmgp[0]->ycent = Vsh_getenvReal(thee->vsh, "YCENT");
        thee->pmgp[0]->zcent = Vsh_getenvReal(thee->vsh, "ZCENT");
        thee->pmgp[0]->bcfl = Vsh_getenvInt(thee->vsh, "BCFL");
        thee->pmgp[0]->errtol = Vsh_getenvReal(thee->vsh, "LTOL");
        thee->pmgp[0]->itmax = Vsh_getenvInt(thee->vsh, "NMAX");
        thee->pmgp[0]->istop = Vsh_getenvInt(thee->vsh, "ISTOP");
        thee->pmgp[0]->iinfo = Vsh_getenvInt(thee->vsh, "IINFO");
        thee->pmgp[0]->iperf = Vsh_getenvInt(thee->vsh, "IPERF");
        thee->pmgp[0]->meth = Vsh_getenvInt(thee->vsh, "LKEY");
        thee->pmgp[0]->omegal = Vsh_getenvInt(thee->vsh, "OMEGAL");
        thee->pmgp[0]->omegan = Vsh_getenvInt(thee->vsh, "OMEGAN");
        /* Construct the solver object */
        if (thee->pmg[0] != VNULL) Vpmg_dtor(&(thee->pmg[0]));
        thee->pmg[0] = Vpmg_ctor(thee->pmgp[0], thee->pbe[imol]);
        Vpmg_fillco(thee->pmg[0], 1, 0);
        Vpmg_solve(thee->pmg[0]);

    } else { /* bcfl == 4 */

        /* Check to make sure the old solver object is still around */
        if (thee->pmg[0] == VNULL) {
            Vnm_print(2, "MGsh: ERROR -- Attempting focused run without coarse-level solution!\n");
            Vnm_print(2, "MGsh: ERROR -- Run `lsolve`/`nsolve` or check BCFL!\n");
            return;
        }
        /* Calculate the mesh parameters for the focused calculation */
        initPartitions(thee);
        /* Construct the parameter object */
        if (thee->pmgp[1] != VNULL) 
        thee->pmgp[1] = Vpmgp_ctor(
          Vsh_getenvInt(thee->vsh, "NX"),
          Vsh_getenvInt(thee->vsh, "NY"),
          Vsh_getenvInt(thee->vsh, "NZ"),
          Vsh_getenvInt(thee->vsh, "NLEV"),
          thee->hxf, thee->hyf, thee->hzf, nonlin);
        /* Assign some of the other parameters */
        thee->pmgp[1]->xcent = thee->xcentOlap;
        thee->pmgp[1]->ycent = thee->ycentOlap;
        thee->pmgp[1]->zcent = thee->zcentOlap;
        thee->pmgp[1]->bcfl = Vsh_getenvInt(thee->vsh, "BCFL");
        thee->pmgp[1]->errtol = Vsh_getenvReal(thee->vsh, "LTOL");
        thee->pmgp[1]->itmax = Vsh_getenvInt(thee->vsh, "NMAX");
        thee->pmgp[1]->istop = Vsh_getenvInt(thee->vsh, "ISTOP");
        thee->pmgp[1]->iinfo = Vsh_getenvInt(thee->vsh, "IINFO");
        thee->pmgp[1]->iperf = Vsh_getenvInt(thee->vsh, "IPERF");
        thee->pmgp[1]->meth = Vsh_getenvInt(thee->vsh, "LKEY");
        thee->pmgp[1]->omegal = Vsh_getenvInt(thee->vsh, "OMEGAL");
        thee->pmgp[1]->omegan = Vsh_getenvInt(thee->vsh, "OMEGAN");
        /* Construct the solver object */
        if (thee->pmg[1] != VNULL) Vpmg_dtor(&(thee->pmg[1]));
        thee->pmg[1] = Vpmg_ctorFocus(thee->pmgp[1], thee->pbe[imol],
          thee->pmg[0]);
        Vpmgp_dtor(&(thee->pmgp[0]));
        Vpmg_fillco(thee->pmg[1], 1, 0);
        Vpmg_solve(thee->pmg[1]);
        Vpmg_setPart(thee->pmg[1],
          (thee->xcentPart-0.5*thee->xlenPart), 
          (thee->ycentPart-0.5*thee->ylenPart),
          (thee->zcentPart-0.5*thee->zlenPart), 
          (thee->xcentPart+0.5*thee->xlenPart),
          (thee->ycentPart+0.5*thee->ylenPart), 
          (thee->zcentPart+0.5*thee->zlenPart));
    }

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  checkMolNumber
//
// Purpose:  Checks the validity of the MOL variable, returns 1 if OK
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE int checkMolNumber(int imol) {
    if ((imol < 0) || (imol>=MAXMOL)) return 0;
    else return 1;
}
