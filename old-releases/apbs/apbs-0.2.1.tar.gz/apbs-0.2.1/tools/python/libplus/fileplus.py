#
# The contents of this file are subject to the Mozilla Public
# License Version 1.1 (the "License"); you may not use this file
# except in compliance with the License. You may obtain a copy of
# the License at http://www.mozilla.org/MPL/
# 
# Software distributed under the License is distributed on an "AS
# IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
# implied. See the License for the specific language governing
# rights and limitations under the License.
# The Original Code is "Java-Python Extension libplus (JPE-libplus)".
# 
# The Initial Developer of the Original Code is Frederic Bruno Giacometti.
# Portions created by Frederic Bruno Giacometti are
# Copyright (C) 2001-2002 Frederic Bruno Giacometti. All Rights Reserved.
# 
# Contributor(s): frederic.giacometti@arakne.com
# 
# Acknowledgments:
# Particular gratitude is expressed to the following parties for their
# contributing support to the development of JPE-libplus:
#     - The Molecular Graphics Laboratory (MGL)
#       at The Scripps Research Institute (TSRI), in La Jolla, CA, USA;
#       and in particular to Michel Sanner and Arthur Olson.
#

"""File manipulation utilities
"""

import os
from os import path

def fileindirs( filename, dirs, boolfun=None):
    """Searches for the directories where a given file is located,
    and returns a possibly-empty list of additional directories, or None
    if the file couldn't be found at all.

    'filename' is the name of a file, such as readline.h or libcrypto.a.

    'paths' is a list of directories to check

    boolfun is None or a funtion taking the found file path are argument;
        boolfun( fname) will return if fname is satisfying
    """

    result = []
    for dir in dirs:
        fullname = path.join(dir, filename)
        if path.exists( fullname) and (not boolfun or boolfun( fullname)):
            result.append( fullname)

    return map( path.dirname, result)

class NotFoundError( ValueError):
    pass

def findindir( matchfun, reldir, dirs):
    from operator import add
    return reduce( add,
                   [[path.join( dirname, x)
                     for x in os.listdir( path.join( reldir, dirname))
                     if matchfun( x)]
                    for dirname in dirs])

def find_file( filename, dirs, boolfun=None):
    for dir in dirs:
        fullname = path.join(dir, filename)
        if path.exists( fullname) and (not boolfun or boolfun( fullname)):
            return fullname
    else:
        raise NotFoundError( filename, dirs, boolfun)

def findindirs( name, dirlist):
    if os.name == 'posix':
        for dir in dirlist:
            if path.isdir( dir) and name in os.listdir( dir):
                return path.join( dir, name)
    elif os.name == 'nt':
        for dir in dirlist:
            if path.isdir( dir)\
               and name.lower() in [x.lower() for x in os.listdir( dir)]:
                return path.join( dir, name)
    else:
        raise NotImplementedError( os.name)
    raise NotFoundError( name, dirlist)

def findpath( name, pathval = None):
    """
    name - string : name searched
    path - string [default: $PATH] : path
return string : fullpath

raise NotFounderror if not found
    """
    if path.isabs( name):
        return name
    if pathval is None:
        pathval = os.environ[ 'PATH']
    import types
    if isinstance( pathval, types.StringType):
        pathval = pathval.split( os.pathsep)
    return findindirs( name, pathval)

def installf( src, dst):
    ddir = path.dirname( dst)
    if not path.isdir( ddir):
        os.makedirs( ddir)
    from shutil import copy2
    copy2( src, dst)

def find( rootdir,
          filefun = lambda x: x != 'CVS' and x[ -1] != '~',
          dirfun = lambda x: x != 'CVS' and x[ -1] != '~',
          fullpath = 0):
    result = []
    def visitfun( (lresult, lfilefun, ldirfun), dirname, names):
        lresult.extend( [path.join( dirname, x)
                         for x in names if lfilefun( x)])
        for idx in xrange( len( names) - 1, -1, -1):
            if not ldirfun( names[ idx]):
                del names[ idx]
            
    path.walk( rootdir, visitfun, (result, filefun, dirfun))
    if not fullpath:
        result = [ x[ len( rootdir) + 1:] for x in result]
    return result

def filterfile( pyscript, call, input, output, *includes):
    assert not [x for x in includes if x[ :2] != '-I']
    import fileplus
    inputfile = fileplus.findindirs( input, [x[ 2:] for x in includes])
    scriptglobs = {}
    execfile( pyscript, scriptglobs)
    outtxt = scriptglobs[ call]( open( inputfile).read())
    open( output, 'w').write( outtxt)
