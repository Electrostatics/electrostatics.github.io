#
# copyright_notice Alex Gillet 2002
#

"""Makefile...
"""

LDSHARED='g77 -shared'

if __name__ == '__main__':
    import sys, os
    from os import path
    bootdir = path.dirname( path.abspath( sys.argv[ 0]))
    libplusdir  = path.normpath( path.join( bootdir, '.', 'libplus'))
    
    argdic = {
        'LIBPLUSDIR': path.isdir( libplusdir) and libplusdir or '',
        }

    for key, value in [x.split( '=', 1) for x in sys.argv[ 1:]]:
        argdic[ key] = value
    if argdic[ 'LIBPLUSDIR']: # make module is in LIBPLUSDIR
        argdic[ 'LIBPLUSDIR'] = path.abspath( argdic[ 'LIBPLUSDIR'])
        assert path.isdir( argdic[ 'LIBPLUSDIR']), argdic[ 'LIBPLUSDIR']
        sys.path.insert( 0, argdic[ 'LIBPLUSDIR'])
    import devkit
    devkit.runconfig( bootdir, argdic) ## will exit - no return
else:
    from cfg import Cfg

    class MakeCfg( Cfg):


        def __init__( self):
            import devkit
            Cfg.__init__( self,
                          providers = [devkit.getcfgclass( 'ctool')()])
            
        def buildmake( self, argv=[]):
            
            result = Cfg.buildmake( self, argv)

            
            result[ self.makefilename] = ({}, [], [
                (['all'], [], ['cd extent && $(MAKE)']),
                (['cleanall'],[],[ 'cd extent && $(MAKE) $@']),
                ])
            
            swigpython = self.swigpython

            extenttargets = []

            extenttargets.extend( swigpython.allmaketargets(
                name = 'apbslib',
                objlist = ['$(PYTHONPLUSOBJ)'],
                liblist = [(self.liblist ,
                            ['apbs','maloc','apbsmainroutines'])],
                ))
            
            from os import path
            result[ path.join( 'extent', self.makefilename)] = ({}, [],
                                                                extenttargets)
            return result

    def genmake():
        import devkit
        devkit.genmake( MakeCfg)





