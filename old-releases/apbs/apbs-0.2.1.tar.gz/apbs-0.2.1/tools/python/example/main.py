
from apbslib import *
import sys, time

from sys import stdout, stderr

class APBSError(Exception):
	def __init__(self, value):
		self.value = value
	def __str__(self):
		return `self.value`

Python_kb = 1.3806581e-23
Python_Na = 6.0221367e+23

header = "\n\n\
    ----------------------------------------------------------------------\n\
    Adaptive Poisson-Boltzmann Solver (APBS)\n\
    Version 0.2.1 (April 23, 2002)\n\
    \n\
    Nathan A. Baker (nbaker@wasabi.ucsd.edu)\n\
    Dept. of Chemistry and Biochemistry\n\
    Dept. of Mathematics, Scientific Computing Group\n\
    University of California, San Diego \n\n\
    Additional contributing authors listed in the code documentation.\n\n\
    Copyright (c) 1999-2002.\n\
    Nathan A. Baker\n\
    All Rights Reserved.\n\n\
    Permission to use, copy, modify, and distribute this software and its\n\
    documentation for educational, research, and not-for-profit purposes,\n\
    without fee and without a signed licensing agreement, is hereby granted,\n\
    provided that the above copyright notice, this paragraph and the\n\
    following two paragraphs appear in all copies, modifications, and\n\
    distributions.\n\n\
    IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR DIRECT,\n\
    INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST\n\
    PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,\n\
    EVEN IF THE AUTHORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH\n\
    DAMAGE.\n\n\
    THE AUTHORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING, BUT NOT\n\
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A\n\
    PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF\n\
    ANY, PROVIDED HEREUNDER IS PROVIDED \"AS IS\".  THE AUTHORS HAVE NO\n\
    OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR\n\
    MODIFICATIONS.\n\
    ----------------------------------------------------------------------\n\
    \n\n"

usage = "\n\n\
    ----------------------------------------------------------------------\n\
    This driver program calculates electrostatic potentials, energies,\n\
    and forces using both multigrid and finite element methods.\n\
    It is invoked as:\n\n\
      apbs apbs.in\n\n\
    where apbs.in is a formatted input file.\n\
    ----------------------------------------------------------------------\n\n"

# Initialize the MALOC library
startVio()

# Fake a parallel environment
size = 1
rank = 0
stdout.write("main:  Hello world from PE %d of %d\n" % (rank, size))

# Start the main timer
main_timer_start = time.clock()

# Check invocation
stdout.write(header)
if len(sys.argv) != 2:
	stderr.write("main:  Called with %d arguments!\n" % len(sys.argv))
	stderr.write(usage)
	raise APBSError, "Oops!"

# Parse the input file
nosh = NOsh()
NOsh_ctor2(nosh, rank, size)
input_file = sys.argv[1]
stdout.write("main:  Parsing input file %s...\n" % input_file)
if NOsh_parseFile(nosh, input_file) != 1:
	stderr.write("main:  Error while parsing input file.\n")
	raise APBSError, "Oops!"

# Load the molecules
alist = []
if nosh.nmol <= 0:
	stderr.write("main:  You didn't specify any molecules!\n")
	raise APBSError, "Oops!"
stdout.write("main:  Preparing to read %d molecule(s)...\n" % nosh.nmol)
for i in range(nosh.nmol):
	molpath = NOsh_getMolpath(nosh, i)
	stdout.write("main:  Reading molecule %d data from %s\n" % 
	  (i, molpath))
	theAlist = Valist()
	Valist_ctor2(theAlist)
	if Valist_readPQR(theAlist, "FILE", "ASC", "localhost", molpath) != 1:
		stderr.write("main:  Fatal error while reading from %s!\n" %
		  molpath)
		raise APBSError, "Oops!"
	else:
		stdout.write("main:    %d atoms\n" % theAlist.number)
		stdout.write("main:    Centered at (%4.3f, %4.3f, %4.3f)\n" %
		  (Valist_getCenterX(theAlist), Valist_getCenterY(theAlist),
		   Valist_getCenterZ(theAlist)))
		stdout.write("main:    Net charge %3.2e\n" % theAlist.charge)
		alist = alist + [theAlist]

# Load the dieletric maps
dielXMap = []
dielYMap = []
dielZMap = []
if nosh.ndiel > 0:
	stderr.write("main:  Got paths for %d dielectric map sets\n", nosh.ndiel)
	for i in range(nosh.ndiel):
		dielpath = NOsh_getDielXpath(nosh, i)
		foo = 0.0
		theDielXMap = Vgrid()
		Vgrid_ctor2(theDielXMap, 0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, foo)
		if NOsh_getDielfmt(nosh, i) == 0:
			if Vgrid_readDX(theDielXMap, "FILE", "ASC", "localhost",
			  dielpath) != 1:
				stderr.write("main:  Fatal error while reading from %s\n" %
				  NOsh_getDielXpath(nosh, i))
				raise APBSError, "Oops!"
		dielXMap = dielXMap + [theDielXMap]
		dielpath = NOsh_getDielXpath(nosh, i)
		foo = 0.0
        theDielYMap = Vgrid()
        Vgrid_ctor2(theDielYMap, 0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, foo)
        if NOsh_getDielfmt(nosh, i) == 0:
            if Vgrid_readDX(theDielYMap, "FILE", "ASC", "localhost",
              dielpath) != 1:
                stderr.write("main:  Fatal error while reading from %s\n" %
                  NOsh_getDielYpath(nosh, i))
                raise APBSError, "Oops!"
		dielYMap = dielYMap + [theDielYMap]
		foo = 0.0
        theDielZMap = Vgrid()
        Vgrid_ctor2(theDielZMap, 0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, foo)
        if NOsh_getDielfmt(nosh, i) == 0:
            if Vgrid_readDX(theDielZMap, "FILE", "ASC", "localhost",
              dielpath) != 1:
                stderr.write("main:  Fatal error while reading from %s\n" %
                  NOsh_getDielZpath(nosh, i))
                raise APBSError, "Oops!"
        dielZMap = dielZMap + [theDielZMap]

# Load the kappa maps
kappaMap = []
if nosh.nkappa > 0:
    stderr.write("main:  Got paths for %d kappa maps\n", nosh.nkappa)
    for i in range(nosh.nkappa):
        kappapath = NOsh_getKappapath(nosh, i)
        foo = 0
        theKappaMap = Vgrid()
        Vgrid_ctor2(theKappaMap, 0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, foo)
        if NOsh_getKappafmt(nosh, i) == 0:
            if Vgrid_readDX(theKappaMap, "FILE", "ASC", "localhost",
              kappapath) != 1:
                stderr.write("main:  Fatal error while reading from %s\n" %
                  kappapath)
                raise APBSError, "Oops!"
        kappaMap = theKappaMap + [kappaMap]

# Load the charge maps
chargeMap = []
if nosh.ncharge > 0:
    stderr.write("main:  Got paths for %d charge maps\n", nosh.ncharge)
    for i in range(nosh.nkappa):
        chargepath = NOsh_getChargepath(nosh, i)
        foo = 0
        theChargeMap = Vgrid()
        Vgrid_ctor2(theChargeMap, 0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, foo)
        if NOsh_getChargefmt(nosh, i) == 0:
            if Vgrid_readDX(theChargeMap, "FILE", "ASC", "localhost",
              chargepath) != 1:
                stderr.write("main:  Fatal error while reading from %s\n" %
                  chargepath)
                raise APBSError, "Oops!"
        chargeMap = theChargeMap + [chargeMap]


# Do the calculations
pbe = []
pmg = []
pmgp = []
totEnergy = []
qfEnergy = []
qmEnergy = []
dielEnergy = []

for icalc in range(nosh.ncalc):
	stdout.write("main:  ---------------------------------------------\n")
	calc = NOsh_getCalc(nosh, icalc)
	mgparm = calc.mgparm
	femparm = calc.femparm
	pbeparm = calc.pbeparm
	if calc.calctype != 0:
		stderr.write("main:  Only multigrid calculations supported!\n")
		raise APBSError, "Oops!"
	stdout.write("main:  CALCULATION #%d:  MULTIGRID\n" % (icalc+1))
	stdout.write("main:    Setting up problem...\n")

	setup_timer_start = time.clock()

	# Fix mesh center for "GCENT MOL" types of declarations
	if mgparm.cmeth == 1:
		molid = mgparm.centmol - 1
		theAlist = alist[molid]
		MGparm_setCenterX(mgparm, Valist_getCenterX(theAlist))
		MGparm_setCenterY(mgparm, Valist_getCenterY(theAlist))
		MGparm_setCenterZ(mgparm, Valist_getCenterZ(theAlist))

    # If we're a parallel calculation, update the grid center based on the
    # appropriate shifts
	if mgparm.type == 2:
		realCenterX = MGparm_getCenterX(mgparm) + MGparm_getPartOlapCenterShiftX(mgparm)
		realCenterY = MGparm_getCenterY(mgparm) + MGparm_getPartOlapCenterShiftY(mgparm)
		realCenterZ = MGparm_getCenterZ(mgparm) + MGparm_getPartOlapCenterShiftZ(mgparm)
	else:
		realCenterX = MGparm_getCenterX(mgparm)
		realCenterY = MGparm_getCenterY(mgparm)
		realCenterZ = MGparm_getCenterZ(mgparm)

	# Set up PBE object
	if pbeparm.srfm == 2: 
		sparm = pbeparm.swin 
	else:
		sparm = pbeparm.srad
	thePbe = Vpbe()
	Vpbe_ctor2(thePbe, alist[pbeparm.molid-1], pbeparm.nion, pbeparm.ionc,
	  pbeparm.ionr, pbeparm.ionq, pbeparm.temp, pbeparm.pdie, pbeparm.sdie,
	  sparm)
	pbe = pbe + [thePbe]

	# Set up the PDE object
	thePmgp = Vpmgp()
	Vpmgp_ctor2(thePmgp, MGparm_getNx(mgparm), MGparm_getNy(mgparm),
	  MGparm_getNz(mgparm), mgparm.nlev, MGparm_getHx(mgparm),
	  MGparm_getHy(mgparm), MGparm_getHz(mgparm), pbeparm.nonlin)
	pmgp = pmgp + [thePmgp]
	thePmg = Vpmg()
	if pbeparm.bcfl == 4:
		if icalc == 0:
			stderr.write("main:  Can't focus first calculation!\n")
			raise APBSError, "Oops!"
		Vpmg_ctorFocus2(thePmg, pmgp[icalc], pbe[icalc], pmg[icalc-1], 
		  pbeparm.calcenergy)
	else:
		if icalc>0:
			Vpmg_dtor2(pmg[icalc-1])
		Vpmg_ctor2(thePmg, pmgp[icalc], pbe[icalc])
	pmg = pmg + [thePmg]
	if icalc>0:
		Vpmgp_dtor2(pmgp[icalc-1])
		Vpbe_dtor2(pbe[icalc-1])
	if pbeparm.useDielMap == 1:
		theDielXMap = dielXMap[pbeparm.dielMapID-1]
		theDielYMap = dielYMap[pbeparm.dielMapID-1]
		theDielZMap = dielZMap[pbeparm.dielMapID-1]
	else:
		theDielXMap = Vgrid()
		theDielYMap = Vgrid()
		theDielZMap = Vgrid()
	if pbeparm.useKappaMap == 1:
		theKappaMap = kappaMap[pbeparm.kappaMapID-1]
	else:
		theKappaMap = Vgrid()
	if pbeparm.useChargeMap == 1:
		theChargeMap = chargeMap[pbeparm.chargeMapID-1]
	else:
		theChargeMap = Vgrid()
	Vpmg_fillco(thePmg, pbeparm.srfm, pbeparm.swin, pbeparm.useDielMap,
	  theDielXMap, pbeparm.useDielMap, theDielYMap, pbeparm.useDielMap, 
	  theDielZMap, pbeparm.useKappaMap, theKappaMap, pbeparm.useChargeMap, 
	  theChargeMap);

	# Setup time
	setup_timer_stop = time.clock()
	stdout.write("main:    Setup time: %1.6e sec\n" % 
	  (setup_timer_stop - setup_timer_start))

	# Memory statistics
	bytesTotal = Vmem_bytesTotal()
	highWater = Vmem_highWaterTotal()
	stdout.write("main:    Current memory usage:  %4.3f MB total, %4.3f MB high water\n" % 
	  (bytesTotal/(1024.*1024.), highWater/(1024.*1024.)))

	# Print problem parameters
	if mgparm.type == 2:
		stderr.write("main:  No parallel Python support!\n")
		raise APBSError, "Oops!\n"
	nx = MGparm_getNx(mgparm)
	ny = MGparm_getNy(mgparm)
	nz = MGparm_getNz(mgparm)
	hx = MGparm_getHx(mgparm)
	hy = MGparm_getHy(mgparm)
	hz = MGparm_getHz(mgparm)
	stdout.write("main:    Grid dimensions:  %d x %d x %d\n" 
	  % (nx, ny, nz))
	stdout.write("main:    Grid spacings:  %4.3f, %4.3f, %4.3f\n" 
	  % (hx, hy, hz))
	stdout.write("main:    Grid lengths:  %4.3f x %4.3f x %4.3f\n" % 
	  ((nx-1)*hx, (ny-1)*hy, (nz-1)*hz))
	stdout.write("main:    Grid center:  %4.3f, %4.3f, %4.3f\n" % 
	  (realCenterX, realCenterY, realCenterZ))
	stdout.write("main:    Molecule ID:  %d\n" % pbeparm.molid)
	if pbeparm.nonlin == 0:
		stdout.write("main:    Linearized PBE\n")
	else:
		stdout.write("main:    Nonlinear PBE\n")
	if pbeparm.bcfl == 0:
		stdout.write("main:    Zero boundary conditions\n")
	elif pbeparm.bcfl == 1:
		stdout.write("main:    Single Debye-Huckel sphere boundary conditions\n")
	elif pbeparm.bcfl == 2:
		stdout.write("main:    Multiple Debye-Huckel sphere boundary conditions\n")
	elif pbeparm.bcfl == 4:
		stdout.write("main:    Boundary conditions from focusing\n");
	else:
		stderr.write("main:  Invalid boundary condition (%d)!\n" %
		  pbeparm.bcfl)
	ionstr = 0.0;
	for iion in range(pbeparm.nion):
		q = PBEparm_getIonCharge(pbeparm, iion)
		c = PBEparm_getIonConc(pbeparm, iion)
		ionstr = ionstr + (0.5*q*q*c*c)
	stdout.write("main:    %d ion species (%4.3f M ionic strength)\n" %
	  (pbeparm.nion, ionstr))
	for iion in range(pbeparm.nion):
		stdout.write("main:     %4.3f A-radius, %4.3f e-charge, %4.3f M concentration\n" %
		  (PBEparm_getIonRadius(pbeparm, iion), PBEparm_getIonCharge(pbeparm,
		  iion), PBEparm_getIonConc(pbeparm, iion)))

	stdout.write("main:    Solute dielectric: %4.3f\n" % pbeparm.pdie)
	stdout.write("main:    Solvent dielectric: %4.3f\n" % pbeparm.sdie)
	if pbeparm.srfm == 0:
		stdout.write("main:    Using molecular surface, no smoothing\n")
		stdout.write("main:    Solvent probe radius: %4.3f\n" % pbeparm.srad)
	elif pbeparm.srfm == 1:
		stdout.write("main:    Using molecular surface, harmonic smoothing\n")
		stdout.write("main:    Solvent probe radius: %4.3f\n" % pbeparm.srad)
	elif pbeparm.srfm == 2:
		stdout.write("main:    Using spline-based surface, window: %4.3f\n" %
		  pbeparm.swin)
	stdout.write("main:    Temperature: %4.3f K\n" % pbeparm.temp)
	stdout.write("main:    Surface tension: %4.3f kJ/mol/A^2\n" % 
	  pbeparm.gamma)
	if pbeparm.calcenergy > 0:
		stdout.write("main:    Electrostatic energies will be calculated\n")
	if pbeparm.calcforce > 0:
		stdout.write("main:    Solvation forces will be calculated\n")

	Python_kbT = Python_kb*Python_Na*(pbeparm.temp)/1000

	# Solve the sucker
	solve_timer_start = time.clock()
	if mgparm.type != 3:
		stdout.write("main:    Solving PDE (see io.mc* for details)...\n")
		Vpmg_solve(pmg[icalc])
	else:
		stdout.write("main:    Skipping solve for mg-dummy run!\n")
	solve_timer_stop = time.clock()
	stdout.write("main:    Solve time:  %1.6e sec\n" % 
	  (solve_timer_stop - solve_timer_start))

	# Set partition information
	stdout.write("main:    SKIPPING PARTITION SETUP!!!\n")
	
	# Write out energies
	if mgparm.type == 2:
		extEnergy = 0;
	else:
		extEnergy = 1
	if pbeparm.calcenergy == 1:
		totEnergy = totEnergy + [0.0]
		qfEnergy = qfEnergy + [0.0]
		qmEnergy = qmEnergy + [0.0]
		dielEnergy = dielEnergy + [0.0]
		if nosh.bogus == 0:
			totEnergy[icalc] = Vpmg_energy(pmg[icalc], extEnergy)
			stdout.write("main:    Total electrostatic energy = %1.12e kT\n" %
			  totEnergy[icalc])
	elif pbeparm.calcenergy == 2:
		totEnergy[icalc] = Vpmg_energy(pmg[icalc], extEnergy)
		qfEnergy[icalc] = Vpmg_qfEnergy(pmg[icalc], extEnergy)
		qmEnergy[icalc] = Vpmg_qmEnergy(pmg[icalc], extEnergy)
		dielEnergy[icalc] = Vpmg_dielEnergy(pmg[icalc], extEnergy)
		stdout.write("main:    Total electrostatic energy = %1.12e kT\n" %
		  (totEnergy[icalc]))
		stdout.write("main:    Fixed charge energy = %1.12e kT\n" %
		  0.5*(qfEnergy[icalc]))
		stdout.write("main:    Mobile charge energy = %1.12e kT\n" %
		  (qmEnergy[icalc]))
		stdout.write("main:    Dielectric energy = %1.12e kT\n" %
		  (dielEnergy[icalc]))
		alist = pmg[icalc].pbe.alist
		stdout.write("main:    Per-atom energies:\n")
		for iatom in range(Valist_getNumberAtoms(alist)):
			atom = Valist_getAtom(alist, iatom); 
			tenergy = Vpmg_qfAtomEnergy(pmg[iatom], atom);
			stdout.write("main:      Atom %d:  %1.12e kT\n", (iatom,
			  tenergy))

	# Set partition information
	stdout.write("main:    SKIPPING FORCE I/O!!!\n")

	# Write out data from MG calculations	
	stdout.write("main:    SKIPPING DATA I/O!!!\n")
	
	# Write out matrix from MG calculations	
	stdout.write("main:    SKIPPING MATRIX I/O!!!\n")

# Handle print statements
if nosh.nprint > 0:
	stdout.write("main:  ---------------------------------------------\n")
	stdout.write("main:  PRINT STATEMENTS\n")
	for iprint in range(nosh.nprint):
		if NOsh_printWhat(nosh, iprint) == 0:
			stdout.write("main:  print energy %d " % NOsh_printCalc(nosh,
			  iprint, 0))
			for iarg in range(1,NOsh_printNarg(nosh, iprint)):
				if NOsh_printOp(nosh, iprint, iarg-1) == 0:
					stdout.write("+ ")
				elif NOsh_printOp(nosh, iprint, iarg-1) == 1:
					stdout.write("- ")
				else:
					stderr.write("main:    Ignoring undefined print op!\n")
				stdout.write("%d " % NOsh_printCalc(nosh, iprint, iarg))
			stdout.write("end\n")
		calcid = NOsh_elec2calc(nosh, NOsh_printCalc(nosh, iprint, 0)-1)
		calc = NOsh_getCalc(nosh, calcid)
		pbeparm = calc.pbeparm
		if pbeparm.calcenergy != 0:
			ltenergy = totEnergy[calcid]
		else:
			ltenergy = 0.0
			stderr.write("main:    Didn't calculate energy in Calc #%d\n" %
			  (calcid+1))
		for iarg in range(1,NOsh_printNarg(nosh, iprint)):
			calcid = NOsh_elec2calc(nosh, NOsh_printCalc(nosh, iprint, iarg)-1)
			calc = NOsh_getCalc(nosh, calcid)
			pbeparm = calc.pbeparm
			if pbeparm.calcenergy != 0:
				if NOsh_printOp(nosh, iprint, iarg-1) == 0:
					ltenergy = ltenergy + totEnergy[calcid]
				elif NOsh_printOp(nosh, iprint, iarg-1) == 1:
					ltenergy = ltenergy - totEnergy[calcid]
			else:
				stderr.write("main:    Didn't calculate energy in Calc #%d\n" %
				  (calcid+1))
		stdout.write("main:    Local answer = %1.12e kT\n" % ltenergy)

	

# Stop the main timer
main_timer_stop = time.clock()
stdout.write("main:  Total execution time:  %1.6e sec\n" % 
  (main_timer_stop - main_timer_start))

