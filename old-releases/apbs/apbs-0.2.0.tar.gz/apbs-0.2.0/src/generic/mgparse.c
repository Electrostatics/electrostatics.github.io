/**
 *  @file    mgparse.h
 *  @ingroup NOsh
 *  @author  Nathan Baker
 *  @brief   Class NOsh parsing methods
 *  @version $Id: mgparse.c,v 2.14 2002/03/20 17:17:47 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (nbaker@wasabi.ucsd.edu)
 * Dept. of Chemistry and Biochemistry
 * University of California, San Diego 
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 1999-2002.  Nathan A. Baker.  All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE
 * AUTHORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED
 * HEREUNDER IS PROVIDED "AS IS".  THE AUTHORS HAVE NO OBLIGATION TO PROVIDE
 * MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * @endverbatim
 */

#include "apbscfg.h"
#include "apbs/apbs.h"
#include "apbs/mgparm.h"
#include "apbs/nosh.h"
#include "apbs/vstring.h"

/* File contains some extra stuff that was cluttering up nosh.c */

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  NOsh_parseMG
//
// Purpose:  Parse an MG type of ELEC section
//
// Arguments:  sock     Socket from which to read tokens
//             type     Type of MG calculation 
//                      0 => sequential manual
//                      1 => sequential auto-focus
//                      2 => parallel auto-focus
//
// Returns:  1 on sucess, 0 on failure
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int NOsh_parseMG(NOsh *thee, Vio *sock, int type) {

    char tok[VMAX_BUFSIZE];
    MGparm *mgparm = VNULL;    
    PBEparm *pbeparm = VNULL;    
    int rc;
    /* Check the arguments */
    if (thee == VNULL) {
        Vnm_print(2, "NOsh:  Got NULL thee!\n");
        return 0;
    }
    if (sock == VNULL) {
        Vnm_print(2, "NOsh:  Got pointer to NULL socket!\n");
        return 0;
    }

    Vnm_print(0, "NOsh_parseMG: Parsing parameters for MG calculation\n");

    /* Construct multigrid and PBE parameter objects to hold the parsed input */
    mgparm  = MGparm_ctor(type);
    if (type == 2) {
        mgparm->com = thee->com;
        mgparm->setcom = 1;
    }
    pbeparm = PBEparm_ctor();

    /* Start snarfing tokens from the input stream */
    rc = 1;
    while (Vio_scanf(sock, "%s", tok) == 1) { 

        /* See if it's an END token */
        if (Vstring_strcasecmp(tok, "end") == 0) {
            mgparm->parsed = 1;
            pbeparm->parsed = 1;
            rc = 1;
            break;
        }

        /* Pass the token through a series of parsers */
        rc = PBEparm_parseToken(pbeparm, tok, sock);
        if (rc == -1) {
            Vnm_print(0, "NOsh_parseMG:  parsePBE error!\n");
            break;
        } else if (rc == 0) {
            /* Pass the token to the generic MG parser */
            rc = MGparm_parseToken(mgparm, tok, sock);
            if (rc == -1) { 
               Vnm_print(0, "NOsh_parseMG:  parseMG error!\n");
               break;
            } else if (rc == 0) {
                /* We ran out of parsers! */
                Vnm_print(2, "NOsh:  Unrecognized keyword: %s\n", tok);
                break;
            }
        }
    }

    /* Handle various errors arising in the token-snarfing loop -- these all
     * just result in simple returns right now */
    if (rc == -1) return 0;
    if (rc == 0) return 0;
   
    /* Check the status of the parameter objects */
    if ((!MGparm_check(mgparm)) || (!PBEparm_check(pbeparm))) {
        Vnm_print(2, "NOsh:  MG parameters not set correctly!\n");
        return 0;
    }
   
    /* Now we're ready to whatever sorts of post-processing operations that are
     * necessary for the various types of calculations */
    if (type == 0) return NOsh_setupMGMANUAL(thee, mgparm, pbeparm);
    else if (type == 1) return NOsh_setupMGAUTO(thee, mgparm, pbeparm);
    else if (type == 2) return NOsh_setupMGPARA(thee, mgparm, pbeparm);

    /* Should never get here */
    return 0;

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  NOsh_setupMGMANUAL
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int NOsh_setupMGMANUAL(NOsh *thee, MGparm *mgparm, PBEparm *pbeparm) {

    if (thee == VNULL) {
        Vnm_print(2, "NOsh_setupMGMANUAL:  Got NULL thee!\n");
        return 0;
    }
    if (mgparm == VNULL) {
        Vnm_print(2, "NOsh_setupMGMANUAL:  Got NULL mgparm!\n");
        return 0;
    }
    if (pbeparm == VNULL) {
        Vnm_print(2, "NOsh_setupMGMANUAL:  Got NULL pbeparm!\n");
        return 0;
    }

    /* Set up missing MG parameters */
    if (mgparm->setgrid == 0) {
        mgparm->grid[0] = mgparm->glen[0]/((double)(mgparm->dime[0]-1));
        mgparm->grid[1] = mgparm->glen[1]/((double)(mgparm->dime[1]-1));
        mgparm->grid[2] = mgparm->glen[2]/((double)(mgparm->dime[2]-1));
    }
    if (mgparm->setglen == 0) {
        mgparm->glen[0] = mgparm->grid[0]*((double)(mgparm->dime[0]-1));
        mgparm->glen[1] = mgparm->grid[1]*((double)(mgparm->dime[1]-1));
        mgparm->glen[2] = mgparm->grid[2]*((double)(mgparm->dime[2]-1));
    }


    /* Check to see if he have any room left for this type of
     * calculation, if so: set the calculation type, update the number
     * of calculations of this type, and parse the rest of the section
     */
    if (thee->ncalc >= NOSH_MAXCALC) {
        Vnm_print(2, "NOsh:  Too many calculations in this run!\n");
        Vnm_print(2, "NOsh:  Current max is %d; ignoring this calculation\n",
          NOSH_MAXCALC);
        return 0;
    }

    /* Increment the number of calculations */
    (thee->ncalc)++;

    /* Set the calculation type to multigrid */
    thee->calc[thee->ncalc-1].calctype = 0;

    /* Associate ELEC statement with the calculation */
    thee->elec2calc[thee->nelec-1] = thee->ncalc-1;

    thee->calc[thee->ncalc-1].mgparm = mgparm;
    thee->calc[thee->ncalc-1].pbeparm = pbeparm;

    return 1;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  NOsh_setupMGAUTO
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int NOsh_setupMGAUTO(NOsh *thee, MGparm *mgparm, PBEparm *pbeparm) {
 
    MGparm *tmgparm, *mgparms[NOSH_MAXCALC];
    PBEparm *tpbeparm, *pbeparms[NOSH_MAXCALC];
    int i, j, tnfocus[3], nfocus, nparm;
    double td, redrat[3], cgrid[3], fgrid[3];


    if (thee == VNULL) {
        Vnm_print(2, "NOsh_setupMGAUTO:  Got NULL thee!\n");
        return 0;
    }
    if (mgparm == VNULL) {
        Vnm_print(2, "NOsh_setupMGAUTO:  Got NULL mgparm!\n");
        return 0;
    }
    if (pbeparm == VNULL) {
        Vnm_print(2, "NOsh_setupMGAUTO:  Got NULL pbeparm!\n");
        return 0;
    }

    /* Calculate the grid spacing on the coarse and fine levels */
    for (i=0; i<3; i++) {
        cgrid[i] = mgparm->cglen[i]/((double)(mgparm->dime[i]-1));
        fgrid[i] = mgparm->fglen[i]/((double)(mgparm->dime[i]-1));
    }
    Vnm_print(0, "NOsh:  Coarse grid spacing = %g, %g, %g\n",
      cgrid[0], cgrid[1], cgrid[2]);
    Vnm_print(0, "NOsh:  Fine grid spacing = %g, %g, %g\n",
      fgrid[0], fgrid[1], fgrid[2]);

    /* Now calculate the number of focusing levels, never reducing the grid
     * spacing by more than redfrac at each level */
    for (i=0; i<3; i++) {
        if (fgrid[i]/cgrid[i] < VREDFRAC) {
            td = log(fgrid[i]/cgrid[i])/log(VREDFRAC);
            tnfocus[i] = (int)ceil(td) + 1;
        } else tnfocus[i] = 2;
    }
    nfocus = VMAX2(tnfocus[0], tnfocus[1]);
    nfocus = VMAX2(nfocus, tnfocus[2]);

    /* Now set redrat to the actual value by which the grid spacing is
     * reduced at each level of focusing */
    for (i=0; i<3; i++) {
        redrat[i] = VPOW((fgrid[i]/cgrid[i]), 1.0/((double)nfocus-1.0));
    }
    Vnm_print(0, "NOsh:  %d levels of focusing with %g, %g, %g reductions\n",
      nfocus, redrat[0], redrat[1], redrat[2]);

    /* Now that we know how many focusing levels to use, we're ready to set up
     * the parameter objects */
    if (nfocus > NOSH_MAXCALC) {
        Vnm_print(2, "NOsh:  This calculation requires too many levels of \
focusing!\n");
        return 0;
    }
    nparm = nfocus;
    for (i=0; i<nfocus; i++) {
        mgparms[i] = MGparm_ctor(0);
        pbeparms[i] = PBEparm_ctor(0);
    }

    /* Set up the parameter objects */
    for (i=0; i<nfocus; i++) {
        tmgparm = mgparms[i];
        tpbeparm = pbeparms[i];

        /* Most of the parameters are derived from the coarsest level */
        MGparm_copy(tmgparm, mgparm);
        PBEparm_copy(tpbeparm, pbeparm);

        if (i == 0) {
            for (j=0; j<3; j++) {
                tmgparm->partOlapCenterShift[j] = 0;
                tmgparm->grid[j] = cgrid[j];
                tmgparm->glen[j] = mgparm->cglen[j];
            }
        } else {
            for (j=0; j<3; j++) {
                tmgparm->grid[j] = redrat[j]*(mgparms[i-1]->grid[j]);
                tmgparm->glen[j] = redrat[j]*(mgparms[i-1]->glen[j]);
            }
        }

        tmgparm->setgrid = 1;
        tmgparm->setglen = 1;

        /* Finer levels inherit centering method from the finest level */
        if (i == 0) {
            tmgparm->cmeth = mgparm->ccmeth;
            for (j=0; j<3; j++) tmgparm->center[j] = mgparm->ccenter[j];
            tmgparm->centmol = mgparm->ccentmol;
        } else {
            tmgparm->cmeth = mgparm->fcmeth;
            for (j=0; j<3; j++) tmgparm->center[j] = mgparm->fcenter[j];
            tmgparm->centmol = mgparm->fcentmol;
        }

        /* Finer levels have focusing boundary conditions */
        if (i != 0) tpbeparm->bcfl = 4;

        /* Only the finest level handles I/O and needs to worry about disjoint
         * partitioning */
        if (i != (nfocus-1)) {
            tpbeparm->writepot = 0;
            tpbeparm->setwritepot = 1;
            tpbeparm->writepotfmt = 0;
            tpbeparm->writeacc = 0;
            tpbeparm->setwriteacc = 1;
            tpbeparm->writeaccfmt = 0;
        }
        if (tmgparm->type != 2)  {
           Vnm_print(0, "NOsh_setupMGAUTO:  Resetting boundary flags\n");
           for (j=0; j<6; j++) tmgparm->partDisjOwnSide[j] = 1;
           for (j=0; j<3; j++) {
               tmgparm->partDisjCenterShift[j] = 0;
                tmgparm->partDisjLength[j] = tmgparm->glen[j];
           }
        }


        tmgparm->parsed = 1;
    }


    if ((thee->ncalc + nparm) >= NOSH_MAXCALC) {
        Vnm_print(2, "NOsh:  Focusing requires too many multigrid \
electrostatics calculations in this run!\n");
        Vnm_print(2, "NOsh:  Current max is %d; ignoring this \
calculation\n",
          NOSH_MAXCALC);
        return 0;
    }
    for (i=0; i<nparm; i++) {
        thee->calc[thee->ncalc+i].mgparm = mgparms[i];
        thee->calc[thee->ncalc+i].pbeparm = pbeparms[i];
        thee->calc[thee->ncalc+i].calctype = 0;
    }

    /* Setup the map from ELEC statement to actual calculation */
    thee->elec2calc[thee->nelec-1] = thee->ncalc + nparm - 1;
    thee->ncalc += nparm;

    /* Destroy the dummy parameter objects */
    MGparm_dtor(&mgparm);
    PBEparm_dtor(&pbeparm);

    return 1;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  NOsh_setupMGPARA
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int NOsh_setupMGPARA(NOsh *thee, MGparm *mgparm, PBEparm *pbeparm) {

    int rank, size, npx, npy, npz, nproc, ip, jp, kp;
    double ofrac, dx, dy, dz, xmin, ymin, zmin, xmax, ymax, zmax;
    double xlenDisj, ylenDisj, zlenDisj;
    double xcentDisj, ycentDisj, zcentDisj;
    double xcentOlap, ycentOlap, zcentOlap;
    double xlenOlap, ylenOlap, zlenOlap;

    Vnm_tprint(1,
    "NOsh:  THIS IS WARNING.  THE CURRENT VERSION OF PARALLEL FOCUSING ONLY\n\
     NOsh:  WORKS FOR ENERGY EVALUATIONS IF THE FINE GRID (AS DETERMINED BY\n\
     NOsh:  FGLEN AND FGCENT) COMPLETELY CONTAINS ALL ATOMS OF ALL\n\
     NOsh:  MOLECULES.  LATER VERSIONS OF APBS WILL REMOVE THIS RESTRICTION.\n\
     NOsh:  THIS WARNING MESSAGE DOES NOT IMPLY THAT YOU HAVE ATOMS WHICH\n\
     NOsh:  ARE NOT CONTAINED IN FINE MESH, IT'S SIMPLY A GENERIC WARNING\n");
    Vnm_tprint(2,
    "NOsh:  THIS IS WARNING.  THE CURRENT VERSION OF PARALLEL FOCUSING ONLY\n\
     NOsh:  WORKS FOR ENERGY EVALUATIONS IF THE FINE GRID (AS DETERMINED BY\n\
     NOsh:  FGLEN AND FGCENT) COMPLETELY CONTAINS ALL ATOMS OF ALL\n\
     NOsh:  MOLECULES.  LATER VERSIONS OF APBS WILL REMOVE THIS RESTRICTION.\n\
     NOsh:  THIS WARNING MESSAGE DOES NOT IMPLY THAT YOU HAVE ATOMS WHICH\n\
     NOsh:  ARE NOT CONTAINED IN FINE MESH, IT'S SIMPLY A GENERIC WARNING\n");

    if (thee == VNULL) {
        Vnm_print(2, "NOsh_setupMGPARA:  Got NULL thee!\n");
        return 0;
    }
    if (mgparm == VNULL) {
        Vnm_print(2, "NOsh_setupMGPARA:  Got NULL mgparm!\n");
        return 0;
    }
    if (pbeparm == VNULL) {
        Vnm_print(2, "NOsh_setupMGPARA:  Got NULL pbeparm!\n");
        return 0;
    }

    /* Grab some useful variables */
    ofrac = mgparm->ofrac;
    rank = Vcom_rank(thee->com); 
    size = Vcom_size(thee->com);
    npx = mgparm->pdime[0]; 
    npy = mgparm->pdime[1]; 
    npz = mgparm->pdime[2]; 
    nproc = npx*npy*npz;
   
    Vnm_print(0, "NOsh_setupMGPARA:  Hello from procesor %d of %d\n", rank, size);

    /* Check to see if we have too many processors.  If so, then simply set
     * this processor to duplicating the work of processor 0. */
    if (rank > (nproc-1)) {
        Vnm_print(2, "NOsh_setupMGPARA:  There are more processors available than\
 the %d you requested.\n", nproc);
        Vnm_print(2, "NOsh_setupMGPARA:  Eliminating processor %d\n", rank);
        thee->bogus = 1;
        rank = 0;
    }
    /* Check to see if we have too few processors.  If so, this is a fatal
     * error. */
    if (size < nproc) {
        Vnm_print(2, "NOsh_setupMGPARA:  There are too few processors (%d) to \
satisfy requirements (%d)\n", size);
        return 0;
    }

    /* Calculate the processor's coordinates in the processor grid */
    kp = (int)floor(rank/(npx*npy));
    jp = (int)floor((rank-kp*npx*npy)/npx);
    ip = rank - kp*npx*npy - jp*npx;
    Vnm_print(0, "NOsh_setupMGPARA:  Hello world from PE (%d, %d, %d)\n", 
      ip, jp, kp);

    /* Calculate the disjoint partition length and center displacement */
    xlenDisj = mgparm->fglen[0]/((double)npx);
    ylenDisj = mgparm->fglen[1]/((double)npy);
    zlenDisj = mgparm->fglen[2]/((double)npz);
    xcentDisj = (ip+0.5)*xlenDisj - 0.5*(mgparm->fglen[0]);
    ycentDisj = (jp+0.5)*ylenDisj - 0.5*(mgparm->fglen[1]);
    zcentDisj = (kp+0.5)*zlenDisj - 0.5*(mgparm->fglen[2]);

    Vnm_print(0, "NOsh_setupMGPARA:  Disj part length = (%g, %g, %g)\n", 
      xlenDisj, ylenDisj, zlenDisj);
    Vnm_print(0, "NOsh_setupMGPARA:  Disj part center = (%g, %g, %g)\n", 
      xcentDisj, ycentDisj, zcentDisj);

    /* Calculate the overlapping partition length and center displacement and
     * set the ownership for the various sides of our partition */
    xlenOlap = xlenDisj;
    ylenOlap = ylenDisj;
    zlenOlap = zlenDisj;
    xcentOlap = xcentDisj;
    ycentOlap = ycentDisj;
    zcentOlap = zcentDisj;
    if (ip != 0) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adding %g overlap to left\n",
          (ofrac*xlenDisj));
        xlenOlap += (ofrac*xlenDisj);
        xcentOlap -= (0.5*ofrac*xlenDisj);
    }
    if (ip != (npx-1)) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adding %g overlap to right\n",
          (ofrac*xlenDisj));
        xlenOlap += (ofrac*xlenDisj);
        xcentOlap += (0.5*ofrac*xlenDisj);
    } 
    if (jp != 0) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adding %g overlap to back\n",
          (ofrac*ylenDisj));
        ylenOlap += (ofrac*ylenDisj);
        ycentOlap -= (0.5*ofrac*ylenDisj);
    }
    if (jp != (npy-1)) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adding %g overlap to front\n",
          (ofrac*ylenDisj));
        ylenOlap += (ofrac*ylenDisj);
        ycentOlap += (0.5*ofrac*ylenDisj);
    }
    if (kp != 0) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adding %g overlap to bottom\n",
          (ofrac*zlenDisj));
        zlenOlap += (ofrac*zlenDisj);
        zcentOlap -= (0.5*ofrac*zlenDisj);
    }
    if (kp != (npz-1)) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adding %g overlap to top\n",
          (ofrac*zlenDisj));
        zlenOlap += (ofrac*zlenDisj);
        zcentOlap += (0.5*ofrac*zlenDisj);
    }

    /* Check to make sure we haven't fallen off the fine mesh */
    xmin = -0.5*mgparm->fglen[0];
    xmax =  0.5*mgparm->fglen[0];
    ymin = -0.5*mgparm->fglen[1];
    ymax =  0.5*mgparm->fglen[1];
    zmin = -0.5*mgparm->fglen[2];
    zmax =  0.5*mgparm->fglen[2];
    /* Calculate the difference between the fine mesh and overlapping 
     * processor boundaries */
    dx = xmin - (xcentOlap - 0.5*xlenOlap);
    if (dx > 0) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adjusting xcentOlap by %g\n", dx);
        xcentOlap += dx;
    }
    dx = xmax - (xcentOlap + 0.5*xlenOlap);
    if (dx < 0) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adjusting xcentOlap by %g\n", dx);
        xcentOlap += dx;
    }
    dy = ymin - (ycentOlap - 0.5*ylenOlap);
    if (dy > 0) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adjusting ycentOlap by %g\n", dy);
        ycentOlap += dy;
    }
    dy = ymax - (ycentOlap + 0.5*ylenOlap);
    if (dy < 0) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adjusting ycentOlap by %g\n", dx);
        ycentOlap += dy;
    }
    dz = zmin - (zcentOlap - 0.5*zlenOlap);
    if (dz > 0) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adjusting zcentOlap by %g\n", dz);
        zcentOlap += dz;
    }
    dz = zmax - (zcentOlap + 0.5*zlenOlap);
    if (dz < 0) {
        Vnm_print(0, "NOsh_setupMGPARA:  Adjusting zcentOlap by %g\n", dz);
        zcentOlap += dz;
    }

    /* Figure out who own the grid point on their partition boundaries.
     * Domain boundary partitions always own their boundary sides.  Interior
     * partitions always own their LEFT/BACK/DOWN sides. */
    if (ip == 0) mgparm->partDisjOwnSide[VAPBS_LEFT] = 1;
    else mgparm->partDisjOwnSide[VAPBS_LEFT] = 1;
    if (ip == (npx-1)) mgparm->partDisjOwnSide[VAPBS_RIGHT] = 1;
    else mgparm->partDisjOwnSide[VAPBS_RIGHT] = 0;
    if (jp == 0) mgparm->partDisjOwnSide[VAPBS_BACK] = 1;
    else mgparm->partDisjOwnSide[VAPBS_BACK] = 1;
    if (jp == (npy-1)) mgparm->partDisjOwnSide[VAPBS_FRONT] = 1;
    else mgparm->partDisjOwnSide[VAPBS_FRONT] = 0;
    if (kp == 0) mgparm->partDisjOwnSide[VAPBS_DOWN] = 1;
    else mgparm->partDisjOwnSide[VAPBS_DOWN] = 1;
    if (kp == (npz-1)) mgparm->partDisjOwnSide[VAPBS_UP] = 1;
    else mgparm->partDisjOwnSide[VAPBS_UP] = 0;

    Vnm_print(0, "NOsh_setupMGPARA:  partDisjOwnSide[LEFT] = %d\n", 
      mgparm->partDisjOwnSide[VAPBS_LEFT]);
    Vnm_print(0, "NOsh_setupMGPARA:  partDisjOwnSide[RIGHT] = %d\n", 
      mgparm->partDisjOwnSide[VAPBS_RIGHT]);
    Vnm_print(0, "NOsh_setupMGPARA:  partDisjOwnSide[FRONT] = %d\n", 
      mgparm->partDisjOwnSide[VAPBS_FRONT]);
    Vnm_print(0, "NOsh_setupMGPARA:  partDisjOwnSide[BACK] = %d\n", 
      mgparm->partDisjOwnSide[VAPBS_BACK]);
    Vnm_print(0, "NOsh_setupMGPARA:  partDisjOwnSide[UP] = %d\n", 
      mgparm->partDisjOwnSide[VAPBS_UP]);
    Vnm_print(0, "NOsh_setupMGPARA:  partDisjOwnSide[DOWN] = %d\n", 
      mgparm->partDisjOwnSide[VAPBS_DOWN]);

    Vnm_print(0, "NOsh_setupMGPARA:  Olap part length = (%g, %g, %g)\n", 
      xlenOlap, ylenOlap, zlenOlap);
    Vnm_print(0, "NOsh_setupMGPARA:  Olap part center = (%g, %g, %g)\n", 
      xcentOlap, ycentOlap, zcentOlap);


    /* Set the disjoint partition information */
    mgparm->partDisjCenterShift[0] = xcentDisj;
    mgparm->partDisjCenterShift[1] = ycentDisj;
    mgparm->partDisjCenterShift[2] = zcentDisj;
    mgparm->partDisjLength[0] = xlenDisj;
    mgparm->partDisjLength[1] = ylenDisj;
    mgparm->partDisjLength[2] = zlenDisj;
   
    /* Set the fine mesh parameters to the non-disjoint partition */ 
    mgparm->fglen[0] = xlenOlap;
    mgparm->fglen[1] = ylenOlap;
    mgparm->fglen[2] = zlenOlap;
    mgparm->partOlapLength[0] = xlenOlap;
    mgparm->partOlapLength[1] = ylenOlap;
    mgparm->partOlapLength[2] = zlenOlap;
    mgparm->partOlapCenterShift[0] = xcentOlap;
    mgparm->partOlapCenterShift[1] = ycentOlap;
    mgparm->partOlapCenterShift[2] = zcentOlap;

    return NOsh_setupMGAUTO(thee, mgparm, pbeparm);
}
