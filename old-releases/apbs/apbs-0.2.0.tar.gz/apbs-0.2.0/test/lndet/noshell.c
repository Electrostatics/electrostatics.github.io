/**
 *  @file    noshell.c
 *  @author  Nathan Baker and Steve Bond
 *  @brief   Adaptive multilevel FEM APBS ln det calculator
 * 
 *  @version $Id: noshell.c,v 1.4 2002/03/20 17:07:30 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (nbaker@wasabi.ucsd.edu)
 * Dept. of Chemistry and Biochemistry
 * University of California, San Diego 
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 1999-2002.  Nathan A. Baker.  All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE
 * AUTHORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED
 * HEREUNDER IS PROVIDED "AS IS".  THE AUTHORS HAVE NO OBLIGATION TO PROVIDE
 * MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * @endverbatim
 */


#include "mc/mc.h"  
#include "mcx/mcx.h"  
#include "apbs/vfetk.h"
#include "apbs/vopot.h"
#include "apbs/vpbe.h"
#include "apbs/apbs.h"  
#include "mypde.h"
#include "myelm.h"

#define APBS_ERR_RC 13
#define APBS_OK_RC 0

VEMBED(rcsid="$Id: noshell.c,v 1.4 2002/03/20 17:07:30 apbs Exp $")

/*
 * Begin Private Headers
 */

VPRIVATE Gem_buildMeshFromUnifPot(Gem *gm, Vpbe *pbe, Vopot *opot, int opFlag);

/*
 * End Private Headers
 */

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    /* Objects */
    PDE *pde;
    AM *am;
    Vfetk *fetk;
    Vpbe *pbe;
    Valist *alist;
    Vopot *opot;
    Gem *gm = VNULL;

    /* PBE parameters */
    int opFlag, ionNum, nx, ny, nz;
    double ionConc[MAXION], ionRadii[MAXION], ionQ[MAXION];
    double T, soluteDiel, solventDiel, solventRadius;
    double hx, hy, hzed, xmin, ymin, zmin;

    /* Parameters for I/O */
    char *pqr_path, *dx_path;
    char *sepline = "--------------------------------------------------------";

    /* Counters, etc. */
    int i, bytesTotal, highWaterTotal;
    double *data, lndet;

    /* Instructions: */
    char *usage = "\
    This driver program represents a mish-mash of instructions for\n\
    building, factoring, and calculating ln det for various electrostatics\n\
    operators.  It is invoked as\n\
      noshell flag pot.dx mol.pqr\n\
    where flag tells the program what type of operator to assemble\n\
    (0 = Laplacian, 1 = Poisson, 2 = Poisson-Boltzmann), pot.dx is the\n\
    electrostatic potential on a Cartesian mesh in DX format, and\n\
    mol.pqr is the PQR format molecule data for the biomolecule of\n\
    interest.  All of these files are required, even in cases where the\n\
    potential (flag=0,1) or molecule data (flag=2) are irrelevant.\n\n";


    /* ********************* START PARMETER SETTINGS ********************** */
    ionNum = 2;                  /* Number of ionic species                 */
    ionConc[0] = 0.000;          /* ion concentration in M                  */
    ionRadii[0] = 2.0;           /* ion sphere radius                       */
    ionQ[0] = 1.0;               /* ion charge                              */
    ionConc[1] = 0.000;          /* ion concentration in M                  */
    ionRadii[1] = 2.0;           /* ion sphere radius                       */
    ionQ[1] = -1.0;              /* ion charge                              */
    T = 298.15;                  /* temperature in K                        */
    soluteDiel = 1.0;            /* solute dielectric constant              */
    solventDiel = 78.54;         /* solvent diel. constant (78.54 = water)  */
    solventRadius = 1.40;        /* solvent sphere radius                   */
    /* ********************* END PARMETER SETTINGS ********************** */

    /* *************** CHECK INVOCATION ******************* */
    Vio_start();
    Vnm_print(1,"main:  Constructing VCOM object.\n");
    if (argc != 4) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected 4.\n\n",
          argc);
        Vnm_print(2,"%s\n", usage);
        return APBS_ERR_RC;
    } else {

        sscanf(argv[1], "%d", &opFlag);
        if (opFlag == 0) {
            Vnm_print(1,"\nmain:  Working with Laplace operator.\n");
        } else if (opFlag == 1) {
            Vnm_print(1,"\nmain:  Working with Poisson operator.\n");
        } else if (opFlag == 2) {
            Vnm_print(1,"\nmain:  Working with Poisson-Boltzmann operator.\n");
        } else {
            Vnm_print(2,"\n*** Syntax error: invalid flag = %d.\n\n", opFlag);
            Vnm_print(2,"%s\n", usage);
            return APBS_ERR_RC;
        }

        /* Grab paths to DX and PQR files */
        dx_path = argv[2]; 
        Vnm_print(1, "main:  Potential data at %s.\n", dx_path);
        pqr_path = argv[3];
        Vnm_print(1, "main:  Molecule data at %s.\n", pqr_path);
    }

    /* *************** READ IN ATOM LIST ******************* */
    Vnm_print(1,"main:  Constructing VALIST object.\n");
    alist = Valist_ctor();
    Vnm_print(1, "main:  Reading molecule data from %s...\n",
      pqr_path);
    if (Valist_readPQR(alist, "FILE", "ASC", VNULL, pqr_path) != 1) {
        Vnm_print(2, "main:  Fatal error reading PQR!\n");
        return APBS_ERR_RC;
    }
    Vnm_print(1, "main:  Molecule has %d atoms\n", 
      Valist_getNumberAtoms(alist));

    /* *************** VPBE INITIALIZATION ******************* */
    Vnm_print(1,"main: Constructing VPBE object.\n");
    Vnm_print(1,"main: Initializing VPBE parameters, hash tables, and charge-simplex map.\n");
    for (i=0; i<ionNum; i++) {
        Vnm_print(1,"main:       Ion #%d conc    %4.3f M\n", 
          i, ionConc[i]);
        Vnm_print(1,"main:       Ion #%d radius  %4.3f A\n", 
          i, ionRadii[i]);
        Vnm_print(1,"main:       Ion #%d charge  %4.3f e\n",
          i, ionQ[i]);
    }
    Vnm_print(1,"main:        Temperature   %4.3f K\n", T);
    Vnm_print(1,"main:  Solute dielectric   %4.3f \n", soluteDiel);
    Vnm_print(1,"main: Solvent dielectric   %4.3f \n", solventDiel);
    Vnm_print(1,"main:     Solvent radius   %4.3f A\n", solventRadius);
    Vnm_print(1,"main:  CONSTRUCTING Vpbe object\n");
    pbe = Vpbe_ctor(alist, ionNum, ionConc, ionRadii, ionQ, T, 
      soluteDiel, solventDiel, solventRadius);
    Vnm_print(1,"main:      Solute charge   %4.3f \n", 
      Vpbe_getSoluteCharge(pbe));
    Vnm_print(1,"main:      Solute radius   %4.3f \n", 
      Vpbe_getSoluteRadius(pbe));
    Vnm_print(1,"main:      Solute center   (%4.3f, %4.3f, %4.3f) \n", 
      Vpbe_getSoluteCenter(pbe)[0], 
      Vpbe_getSoluteCenter(pbe)[1],
      Vpbe_getSoluteCenter(pbe)[2]);
    Vnm_print(1,"main:  Solute dimensions    (%4.3f, %4.3f, %4.3f) \n",
      Vpbe_getSoluteXlen(pbe), Vpbe_getSoluteYlen(pbe),
      Vpbe_getSoluteZlen(pbe));

    /* *************** READ IN POTENTIAL DATA ******************* */
    Vnm_print(1, "main:  Reading potential data from %s...\n", dx_path);
    Vpmg_readDX("FILE", "ASC", VNULL, dx_path, 
      &nx, &ny, &nz, &hx, &hy, &hzed, &xmin, &ymin, &zmin, &data);
    Vnm_print(1, "main:     nx = %d, ny = %d, nz = %d\n", 
      nx, ny, nz);
    Vnm_print(1, "main:     hx = %g, hy = %g, hz = %g\n", 
      hx, hy, hzed);
    Vnm_print(1, "main:     xmin = %g, ymin = %g, zmin = %g\n", 
      xmin, ymin, zmin);
    Vnm_print(1, "main:  Constructing potential oracle...\n");
    opot = Vopot_ctor(nx, ny, nz, hx, hy, hzed, xmin, ymin, zmin, data, pbe);

    /* *************** MC INITIALIZATION ******************* */
    Vnm_redirect(1);
    Vnm_print(1,"main:  Constructing PDE object.\n");
    /* potData should be a simple oracle object */
    pde = PDE_ctor(); 
    Vnm_print(1,"main:  Constructing (empty) GEM object;\n");
    gm = Gem_ctor(VNULL, pde->bisectEdge, pde->mapBoundary,
      pde->markSimplex, pde->oneChart);

    /* *************** MESH ASSEMBLY ******************* */
    Gem_buildMeshFromUnifPot( gm, pbe, opot, opFlag );

    Vnm_print(1,"main:  Constructing AM object;\n");
    am = AM_ctor(VNULL, gm, pde);
    PDE_setDim(am->pde, Gem_dim(gm));
    PDE_setDimII(am->pde, Gem_dimII(gm));
    am->minLevel = 0;
    for (i=0; i<PDE_vec(am->pde); i++) {
        am->re[i]  = Re_ctor(0, PDE_dim(am->pde),
          am->pde->simplexBasisInit, am->pde->simplexBasisForm);
        am->reB[i] = Re_ctor(0, PDE_dim(am->pde),
          am->pde->simplexBasisInit, am->pde->simplexBasisForm);
    }

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(1,"main:  Constructing VFETK and initializing PDE object.\n");
    fetk = Vfetk_ctor(pbe, gm, am);
    PDE_init(pde, opot, fetk, opFlag);

    /* *************** MEM USAGE ********************* */
    Vnm_print(1, "main:  MEMORY USAGE BEFORE FACTORING:\n");
    Vnm_redirect(0);
    Vmem_print(VNULL);
    Vmem_printTotal();
    Vnm_redirect(1);
    bytesTotal = Vmem_bytesTotal();
    highWaterTotal    = Vmem_highWaterTotal();
    Vnm_print(1, "main: %4.3f MB TOTAL\n",  bytesTotal/(1024.0*1024.0));
    Vnm_print(1," main: %4.3f MB HIGH WATER\n",
      highWaterTotal/(1024.0*1024.0));

    /* *************** BUILD/FACTOR/ln det for OPERATOR ******************* */
    /* The mypde.c file is responsible for specifying the actual operator that
     * we want to factor (i.e., the linearization around some solution), so
     * we can just go ahead and assemble ==> flag argument = 0 */
    Vnm_print(1,"main:  Building, factoring, and evaluating ln det of \
operator.\n");
    fflush(stdout);
    lndet = Vfetk_lnDet(fetk, -1, 0);
    Vnm_print(1, "main:  ln det(A) = %1.12E\n");

    /* *************** MEM USAGE ********************* */
    Vnm_print(1, "main:  MEMORY USAGE AFTER FACTORING:\n");
    Vnm_redirect(0);
    Vmem_print(VNULL);
    Vmem_printTotal();
    Vnm_redirect(1);
    bytesTotal = Vmem_bytesTotal();
    highWaterTotal    = Vmem_highWaterTotal();
    Vnm_print(1, "main: %4.3f MB TOTAL\n",  bytesTotal/(1024.0*1024.0));
    Vnm_print(1," main: %4.3f MB HIGH WATER\n",
      highWaterTotal/(1024.0*1024.0));

    /* *************** GARBAGE COLLECTION ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: NO GARBAGE COLLECTION: EXITING\n");

    /* *************** THE END ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STOPPING EXECUTION\n");
    return APBS_OK_RC;
}

VPRIVATE Gem_buildMeshFromUnifPot(Gem *gm, Vpbe *pbe, Vopot *opot, int opFlag)
{

    VASSERT(0);

}
