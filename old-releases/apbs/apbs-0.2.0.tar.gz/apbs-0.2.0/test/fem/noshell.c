/**
 *  @file    noshell.c
 *  @author  Nathan Baker
 *  @brief   Adaptive multilevel FEM APBS testing "front-end"
 * 
 *           This driver program represents a mish-mash of instructions for
 *           calculating electrostatic potentials, as well as free energies of
 *           binding and solvation.  It is invoked as:
 *
 *               noshell flag mesh.m refMol.pqr [mol1.pqr mol2.pqr ...]
 *
 *           where flag tells the program what type of calculation to perform
 *           (0 = solvation free energy, 1 = binding free energy), mesh.m is
 *           the initial finite element mesh in MCSF format, refMol.pqr is the
 *           PQR format molecule data for reference molecule (the complex or
 *           the molecule whose solvation free energy you'd like to calculate),
 *           and mol#.pqr are either the constituents of the complex or, for
 *           solvation free energies, the same molecule as refMol.pqr.
 * 
 *  @version $Id: noshell.c,v 1.56 2002/03/22 16:15:24 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (nbaker@wasabi.ucsd.edu)
 * Dept. of Chemistry and Biochemistry
 * University of California, San Diego 
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 1999-2002.  Nathan A. Baker.  All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE
 * AUTHORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED
 * HEREUNDER IS PROVIDED "AS IS".  THE AUTHORS HAVE NO OBLIGATION TO PROVIDE
 * MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * @endverbatim
 */


#include "mc/mc.h"  
#include "mcx/mcx.h"  
#include "apbs/vfetk.h"
#include "apbs/vpee.h"
#include "apbs/apbs.h"  
#include "pdePBE.h"
#include "myelm.h"
#include "routines.h"

/* If you want to use the hierarchical basis solver (Burak), define the
 * following macro.  Otherwise, comment this line out */
/* #define VUSEHB 1  */

/* If you want nonlinear PBE, set the following to 1.  Otherwise, set it to 0
 * (and LPBE will be used) */
#define VNPBE 0 

VEMBED(rcsid="$Id: noshell.c,v 1.56 2002/03/22 16:15:24 apbs Exp $")

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    /* MPI parameters */
    int myrank, nproc;

    /* Objects for each molecule */
    PDE *pdePBE[MAXMOL];
    AM *amPBE[MAXMOL];
    Vfetk *fetkPBE[MAXMOL];
    char *meshpath = "mesh.m";

    Vpbe *pbe[MAXMOL];
    Valist *alist[MAXMOL];
    int nmol, imol;
    /* Objects for solver */
    Gem *gm = VNULL;
    Vcom *com = VNULL;
    Vio *sock = VNULL;

    /* Mesh parameters */
    double radScale;
    int meshmol;
    /* PBE parameters */
    int energyFlag;
    int ionNum;
    double ionConc[MAXION], ionRadii[MAXION], ionQ[MAXION];
    double T, soluteDiel, solventDiel, solventRadius;
    /* Parameters for solving */
    SolveVars solveVars;
    int level, isolve, maxsolve;
    /* Parameters for refinement */
    double etol, targetSize;
    int akeyPRE, akeySOLVE;
    int ekey;
    int marked, targetNum, minsimps;
    int maxvert;
    int pkey;
    /* Parameters for I/O */
    int iounit;
    char *pqr_path[MAXMOL];
    char *sepline = "--------------------------------------------------------";
    int iofreq, ioflag;
    char iopath[256];
    /* Counters, etc. */
    int bytesTotal, highWaterTotal;
    int i, nsimps, nverts;

    /* Instructions: */
    char *usage = "\
    This driver program represents a mish-mash of instructions for\n\
    calculating electrostatic potentials, as well as free energies of\n\
    binding and solvation.  It is invoked as:\n\n\
      noshell flag refMol.pqr [mol1.pqr mol2.pqr ...]\n\n\
    where flag tells the program what type of calculation to perform\n\
    (0 = no energies, 1 = solvation free energy, 2 = binding free energy),\n\
    refMol.pqr is the PQR format molecule data for reference molecule\n\
    (the complex or the molecule whose solvation free energy you'd like\n\
    to calculate), and mol#.pqr are either the constituents of the complex\n\
    or, for solvation free energies, the same molecule as refMol.pqr.\n\n";


    /* ********************* START PARMETER SETTINGS ********************** */
    etol = 1e+2     ;            /* error tolerance for refinement marking  */
    ekey = 1;                    /* how etol is interpreted: 0 => per-      *
                                  * simplex, 1 => global, 2 => fraction of  *
                                  * simps we want to have refined           */
    akeyPRE = 1;                 /* refinement method for pre-solve refine  */
    akeySOLVE = 2;               /* refinement method for solve-est-refine  */
    targetNum = 20;            /* # verts required before solve-est-ref   */
    targetSize = 0.0;            /* Size to refine simplices with charges   */
    minsimps = 0;                /* minimum number of simps marked by est   */
    radScale = 2.0;             /* How many times bigger than the molecule
                                  * shoudl the mesh be?                     */
    meshmol = 0;                 /* Molecule to build the mesh from         */

    iofreq = 0;                  /* frequency to write out solution         */
    ioflag = 0;                  /* bitfield: 1st bit GMV output, 2nd bit   *
                                  * AVS UCD output, 3rd bit OFF output,     *
                                  * 4th bit OpenDX output                   */

    ionNum = 2;                  /* Number of ionic species                 */
    ionConc[0] = 0.000;          /* ion concentration in M                  */
    ionRadii[0] = 2.0;           /* ion sphere radius                       */
    ionQ[0] = 1.0;               /* ion charge                              */
    ionConc[1] = 0.000;          /* ion concentration in M                  */
    ionRadii[1] = 2.0;           /* ion sphere radius                       */
    ionQ[1] = -1.0;              /* ion charge                              */
    T = 298.15;                  /* temperature in K                        */
    soluteDiel = 1.0;            /* solute dielectric constant              */
    solventDiel = 78.54;         /* solvent diel. constant (78.54 = water)  */
    solventRadius = 1.40;        /* solvent sphere radius                   */

    level = 0;                   /* initial level of mesh                   */
    maxsolve = 16;               /* maximum number of solve-est-ref iters.  */
    maxvert = 500000;            /* maximum number vertices (ignored if <=0)*/
    solveVars.lkey = 1;          /* multilevel solver (use 1 or 3) */
    solveVars.lmax = 100000000;  /* maximum number of iters for LA solver   */
    solveVars.ltol = 1.0e-05;    /* residual tolerance for LA solver        */
    solveVars.nkey = 0;          /* newton's method                         */
    solveVars.nmax = 100000000;  /* maximum number of iters for LA solver   */
    solveVars.ntol = 1.0e-05;    /* residual tolerance for LA solver        */
    solveVars.gues = 0;          /* use previous solution as initial guess  */
    solveVars.pjac = -1;          /* print the jacobians                     */
#if defined(VUSEHB)
    pkey = 0;                    /* Store the n x n prolongation op */
#else
    pkey = 1;                    /* Store the N x N prolongation op */
#endif
    /* ********************* END PARMETER SETTINGS ********************** */

    /* *************** CHECK INVOCATION ******************* */
    Vio_start();
    Vnm_print(1,"main:  Constructing VCOM object.\n");
    com = Vcom_ctor(1);
    myrank = 0;
    nproc = 1;
    Vnm_print(1,"main: Processor %d of %d.\n", myrank, nproc);
    if (myrank == 0) iounit = 1;
    else iounit = 0;
    if (argc < 3) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected >=3.\n\n",argc);
        Vnm_print(2,"%s\n", usage);
        return -1;
    } else if (argc > 2 + MAXMOL) {
        Vnm_print(2,"\n*** Maximum of %d molecules allowed!\n\n", MAXMOL);
        return -1;
    } else {
        sscanf(argv[1], "%d", &energyFlag);
        if (energyFlag == 0) {
            Vnm_print(1,"\nCalculating electrostatic potential only.\n");
        } else if (energyFlag == 1) {
            Vnm_print(1,"\nCalculating solvation free energy.\n");
        } else if (energyFlag == 2) {
            Vnm_print(1,"\nCalculating binding free energy.\n");
        } else {
            Vnm_print(2,"\n*** Syntax error: invalid flag = %d.\n\n", energyFlag);
            Vnm_print(2,"%s\n", usage);
            return -1;
        }
        /* Need a hack here to avoid processing MPICH arguments which appear at
         * the end */
        nmol = 0;
        for (imol=0; imol<argc-2; imol++) {
            if (argv[2+imol][0] == '-') break;
            pqr_path[imol] = argv[2+imol];
            nmol++;
        }
        if (energyFlag == 1) {
            if (nmol > 1) Vnm_print(2,"\n*** Warning: only first of %d molecules used in solvation free energy calculations.\n\n", nmol);
            nmol = 2;
        }
    }

    /* *************** READ IN ATOM LISTS ******************* */
    Vnm_print(iounit,"main: Constructing %d VALIST objects.\n", nmol);
    if (energyFlag == 1) {
        alist[0] = Valist_ctor();
        Vnm_print(iounit, "main:    Reading molecule data from %s\n",
          pqr_path[0]);
        alist[1] = alist[0];
        if (Valist_readPQR(alist[0], "FILE", "ASC", VNULL, pqr_path[0]) != 1) {
            Vnm_print(2, "main:  Fatal error reading PQR!\n");
            return 666;
        }
        Vnm_print(iounit, "main:    Mol %d has %d atoms\n", imol,
           Valist_getNumberAtoms(alist[0]));
    } else {
        for (imol=0; imol<nmol; imol++) {
            alist[imol] = Valist_ctor();
            Vnm_print(iounit, "main:    Reading molecule data from %s\n",
              pqr_path[imol]);
            if (Valist_readPQR(alist[imol], "FILE", "ASC", VNULL,
              pqr_path[imol]) != 1) {
                Vnm_print(2, "main:  Fatal error reading PQR!\n");
                return 666;
            }
            Vnm_print(iounit, "main:    Mol %d has %d atoms\n", imol,
               Valist_getNumberAtoms(alist[imol]));
        }
    }

    /* *************** VPBE INITIALIZATION ******************* */
    Vnm_print(iounit,"main: Constructing %d VPBE objects.\n", nmol);
    Vnm_print(iounit,"main: Initializing VPBE parameters, hash tables, and charge-simplex map.\n");
    for (i=0; i<ionNum; i++) {
        Vnm_print(iounit,"main:       Ion #%d conc    %4.3f M\n", 
          i, ionConc[i]);
        Vnm_print(iounit,"main:       Ion #%d radius  %4.3f A\n", 
          i, ionRadii[i]);
        Vnm_print(iounit,"main:       Ion #%d charge  %4.3f e\n",
          i, ionQ[i]);
    }
    Vnm_print(iounit,"main:        Temperature   %4.3f K\n", T);
    Vnm_print(iounit,"main:  Solute dielectric   %4.3f \n", soluteDiel);
    Vnm_print(iounit,"main: Solvent dielectric   %4.3f \n", solventDiel);
    Vnm_print(iounit,"main:     Solvent radius   %4.3f A\n", solventRadius);
    if (energyFlag == 1) {
        Vnm_print(iounit,"main:  CONSTRUCTING VPBE #1\n");
        pbe[0] = Vpbe_ctor(alist[0], ionNum, ionConc, ionRadii, ionQ, T, 
          soluteDiel, solventDiel, solventRadius);
        Vnm_print(iounit,"main:  CONSTRUCTING VPBE #2\n");
        pbe[1] = Vpbe_ctor(alist[0], 0, ionConc, ionRadii, ionQ, T, 
          soluteDiel, soluteDiel, solventRadius);
        Vnm_print(iounit,"main:      Solute charge   %4.3f \n", 
          Vpbe_getSoluteCharge(pbe[0]));
        Vnm_print(iounit,"main:      Solute radius   %4.3f \n", 
          Vpbe_getSoluteRadius(pbe[0]));
        Vnm_print(iounit,"main:      Solute center   (%4.3f, %4.3f, %4.3f) \n", 
          Vpbe_getSoluteCenter(pbe[0])[0], 
          Vpbe_getSoluteCenter(pbe[0])[1],
          Vpbe_getSoluteCenter(pbe[0])[2]);
        Vnm_print(iounit,"main:  Solute dimensions    (%4.3f, %4.3f, %4.3f) \n",
          Vpbe_getSoluteXlen(pbe[0]), Vpbe_getSoluteYlen(pbe[0]),
          Vpbe_getSoluteZlen(pbe[0]));
    } else {
        for (imol=0; imol<nmol; imol++) {
	    pbe[imol] = Vpbe_ctor(alist[imol], ionNum, ionConc, ionRadii, 
              ionQ, T, soluteDiel, solventDiel, solventRadius);
            Vnm_print(iounit,"main:   Solute %d charge   %4.3f \n", imol,
              Vpbe_getSoluteCharge(pbe[imol]));
            Vnm_print(iounit,"main:   Solute %d radius   %4.3f \n", imol,
              Vpbe_getSoluteRadius(pbe[imol]));
            Vnm_print(iounit,"main:   Solute %d center   (%4.3f, %4.3f, %4.3f) \n", imol,
              Vpbe_getSoluteCenter(pbe[imol])[0], 
              Vpbe_getSoluteCenter(pbe[imol])[1],
              Vpbe_getSoluteCenter(pbe[imol])[2]);
            Vnm_print(iounit,"main:     Solute %d dims    (%4.3f, %4.3f, %4.3f) \n",
              imol, Vpbe_getSoluteXlen(pbe[imol]), Vpbe_getSoluteYlen(pbe[imol]),
              Vpbe_getSoluteZlen(pbe[imol]));
        }
    }


    /* *************** MC/MPI INITIALIZATION ******************* */
    Vnm_redirect(1);
    Vnm_print(iounit,"main:  Constructing %d PDE objects.\n", nmol);
    for (imol=0; imol<nmol; imol++) {
        pdePBE[imol] = pdePBE_ctor(VNPBE);
    }
    Vnm_print(iounit,"main:  Constructing mesh and GEM object;\n");
    gm = Gem_ctor(VNULL, pdePBE[0]->bisectEdge, pdePBE[0]->mapBoundary,
      pdePBE[0]->markSimplex, pdePBE[0]->oneChart);
#if 0
    Vnm_print(iounit, "main:  Building icosahedral mesh based on molecule\
 %d\n", meshmol);
    Vnm_print(iounit, "main:  Mesh will have %g A radius and be centered at\
 (%g, %g, %g)\n", radScale*Vpbe_getSoluteRadius(pbe[meshmol]),
Vpbe_getSoluteCenter(pbe[meshmol])[0], Vpbe_getSoluteCenter(pbe[meshmol])[1],
Vpbe_getSoluteCenter(pbe[meshmol])[2]);
    Vfetk_genIcosGem(gm, radScale*Vpbe_getSoluteRadius(pbe[meshmol]),
      Vpbe_getSoluteCenter(pbe[meshmol]));
    Gem_formChk(gm, 3);
    Vnm_print(iounit,"main:  Constructing referece AM object.\n");
    amPBE[0] = AM_ctor(VNULL, gm, pdePBE[0]);
    PDE_setDim(amPBE[0]->pde, Gem_dim(gm));
    PDE_setDimII(amPBE[0]->pde, Gem_dimII(gm));
    amPBE[0]->minLevel = 0;
    for (i=0; i<PDE_vec(amPBE[0]->pde); i++) {
        amPBE[0]->re[i]  = Re_ctor(0, PDE_dim(amPBE[0]->pde),
            amPBE[0]->pde->simplexBasisInit, amPBE[0]->pde->simplexBasisForm);
        amPBE[0]->reB[i] = Re_ctor(0, PDE_dim(amPBE[0]->pde),
            amPBE[0]->pde->simplexBasisInit, amPBE[0]->pde->simplexBasisForm);
    }
#else
    amPBE[0] = AM_ctor(VNULL, gm, pdePBE[0]);
    sock = Vio_ctor("FILE", "ASC", "localhost", meshpath, "r");
    AM_getMesh(amPBE[0], 0, sock);
    Vio_dtor(&sock);
#endif


    Vnm_print(iounit, "main: Constructing %d remaining AM objects.\n", nmol-1);
    for (imol=1; imol<nmol; imol++) {
        amPBE[imol] = AM_ctor(VNULL, gm, pdePBE[imol]);
        PDE_setDim(amPBE[imol]->pde, Gem_dim(gm));
        PDE_setDimII(amPBE[imol]->pde, Gem_dimII(gm));
        amPBE[imol]->minLevel = 0;
        for (i=0; i<PDE_vec(amPBE[imol]->pde); i++) {
            amPBE[imol]->re[i]  = Re_ctor(0, PDE_dim(amPBE[imol]->pde),
            amPBE[imol]->pde->simplexBasisInit, amPBE[imol]->pde->simplexBasisForm);
            amPBE[imol]->reB[i] = Re_ctor(0, PDE_dim(amPBE[imol]->pde),
              amPBE[imol]->pde->simplexBasisInit, 
              amPBE[imol]->pde->simplexBasisForm);
        }
    }


    /* Set the refinement level */
    level = 0;

    /* Construct the VFETK objects to pass to the PDE objects and we're ready
     * to go */
    Vnm_print(iounit,"main: Constructing VFETK objects and passing to PDE objects.\n");
    for (imol=0; imol<nmol; imol++) {
        fetkPBE[imol] = Vfetk_ctor(pbe[imol], gm, amPBE[imol]);
        pdePBE_setPDE(pdePBE[imol], imol, VNPBE);
        pdePBE_init(pdePBE[imol], fetkPBE[imol]);
    }

    /* *************** PRE-SOLVER TASKS ******************* */
    Vnm_print(iounit,"\nmain: %s\n", sepline);
    Vnm_print(iounit,"main: Geometry-based pre-refinement (mol #0) to >%d vertices.\n", 
      targetNum);
    /* Refine the mesh to the desired level. */
    pdePBE_setPDE(pdePBE[meshmol], meshmol, VNPBE);
    pdePBE_setRefineParam(pdePBE[meshmol], meshmol, 0, targetSize);
    nverts = Gem_numVV(gm);
    Vnm_print(iounit, "main: N = [");
    while (nverts < targetNum) {
        for (imol=0; imol<nmol; imol++) {
            pdePBE_setPDE(pdePBE[imol], imol, VNPBE);
            AM_algInit(amPBE[imol], level);
        }
        pdePBE_setPDE(pdePBE[meshmol], meshmol, VNPBE);
        marked = AM_markRefine(amPBE[meshmol], level, 1, -1, ekey, etol);
        if (marked == 0) 
          AM_markRefine(amPBE[meshmol], level, 0, -1, ekey, etol);
        Gem_refine(gm, 0, pkey);
        nverts = Gem_numVV(gm);
        Vnm_print(iounit, "%d ", nverts);
        level++;
    }
    Vnm_print(iounit, "]\n");
#if 0
    refineToSize(pdePBE, amPBE, gm, nmol, 0, 1, targetSize, -1, &level, pkey,
      VNPBE); 
#endif
    /* This is where partitioning would go */
    for (imol=0; imol<nmol; imol++) {
        Vfetk_setAtomColors(fetkPBE[imol]);
    }

    /* *************** SOLVE-ESTIMATE-REFINE ******************* */
    Vnm_print(iounit,"\nmain: %s\n", sepline);
    Vnm_print(iounit,"main: SOLVE-ESTIMATE-REFINE LOOP\n");
    
    /* Solve-estimate-refine */
    for (isolve=0; isolve<maxsolve; isolve++) {
        Vnm_print(iounit,"\nmain: Solve-estimate-refine #%d.\n", isolve);

        /* I/O regarding mesh information */
        nsimps = Gem_numSS(gm); 
        nverts = Gem_numVV(gm);
        Vnm_print(1,"main (PE %d): Have %d simplices and %d vertices TOTAL\n", 
          myrank, nsimps, nverts);

        if (myrank == 0) {
            Vnm_redirect(0);
            Gem_shapeChk(gm);
            Vnm_redirect(1);
        }

        /* Solve step */
        Vnm_print(iounit,"main: Initializing AMs and solving...\n");
        for (imol=0; imol<nmol; imol++) {
            pdePBE_setPDE(pdePBE[imol], imol, VNPBE);
            AM_algInit(amPBE[imol], level);
#if defined(VUSEHB)
            if (VNPBE) {
                Vnm_print(2, "main:  Can't use HB with NPBE!  Using newton.\n");
                AM_nSolve(amPBE[imol], level, solveVars.nkey, solveVars.nmax,
                  solveVars.ntol, solveVars.lkey, solveVars.lmax, 
                  solveVars.ltol, solveVars.gues, solveVars.pjac);
            } else {
                Vnm_print(iounit, "main:  amPBE[%d]->minLevel = %d\n", imol, 
                  amPBE[imol]->minLevel);
                AM_hSolve(amPBE[imol], level, 0, solveVars.lkey, solveVars.lmax,
                  solveVars.ltol, solveVars.gues, solveVars.pjac);
            }
#else
            if (VNPBE) {
                AM_nSolve(amPBE[imol], level, solveVars.nkey, solveVars.nmax,
                  solveVars.ntol, solveVars.lkey, solveVars.lmax,
                  solveVars.ltol, solveVars.gues, solveVars.pjac);
            } else {
		AM_lSolve(amPBE[imol], level, 0, solveVars.lkey,
                  solveVars.lmax, solveVars.ltol, solveVars.gues, 
                  solveVars.pjac);
            }
#endif /* defined(VUSEHB) */
            Vnm_print(iounit,"main: Solved PBE for molecule #%d...\n", imol);
            
        }

        /* For one-processor systems, print the energy */
        if (energyFlag != 0) 
          printE(pdePBE, fetkPBE, nmol, 0, com, myrank, level, iounit, VNPBE);


        /* I/O of systems */
        if (iofreq > 0) {
            if ((isolve % iofreq) == 0) {
                sprintf(iopath, "sol-lev%d-pe%d", level, myrank);
                writeToFile(pdePBE, pbe, nmol, 0, gm, amPBE, 0, ioflag, level, iopath);
            }
        }

        /* Check to see if the current number of vertices exceeeds the max */
        if ((nverts > maxvert) && (maxvert >0)) {
            Vnm_print(1,"main (PE %d): %d VERTICES >= %d MAX. BREAKING!\n", 
              myrank, nverts, maxvert);
            break;
        }

        /* Estimate-refine */
        if (isolve != (maxsolve-1)) {
            Vnm_print(iounit,"main: Refining...\n");
	    if (level == 0) marked = refineOnce(pdePBE, nmol, 0, gm, amPBE, 0,
              myrank, &level, ekey, etol, solveVars, pkey, VNPBE);
	    else marked = refineOnce(pdePBE, nmol, 0, gm, amPBE, akeySOLVE,
              myrank, &level, ekey, etol, solveVars, pkey, VNPBE);
            if (marked == 0) {
                Vnm_print(1, "main (PE %d): No simplices marked for refinement; breaking!\n");
                break;
            }
            Vnm_print(iounit,"main: Marked %d/%d simps, have %d after \
refinement\n", 
              marked, nsimps, Gem_numSS(gm));
        }

        /* Memory I/O */
        Vnm_redirect(0);
        Vmem_print(VNULL);
        Vmem_printTotal();
        Vnm_redirect(1);
        bytesTotal = Vmem_bytesTotal();
        highWaterTotal    = Vmem_highWaterTotal();
        Vnm_print(iounit,"main: %f MB TOTAL\n",  bytesTotal/(1024.0*1024.0));
        Vnm_print(iounit,"main: %f MB HIGH WATER\n",
          highWaterTotal/(1024.0*1024.0));
    }

    /* *************** POST-SOLVER TASKS ******************* */
    Vnm_print(iounit,"\nmain: %s\n", sepline);
    Vnm_print(iounit,"main: POST-SOLVER TASKS\n");
    sock = Vio_ctor("FILE", "ASC", "localhost", "soln.gmv", "w");
    AM_writeGMV(amPBE[0], level, sock, -1);
    Vio_dtor(&sock);
#if 0
    sock = Vio_ctor("FILE", "ASC", "localhost", meshpath, "w");
    Gem_write(gm, 0, sock, 0);
    Vio_dtor(&sock);
#endif

    /* Energy evaluation */
    if (energyFlag != 0) {
        Vnm_print(iounit, "main: Finding mean field energies....\n");
        printE(pdePBE, fetkPBE, nmol, 0, VNULL, myrank, level, iounit, VNPBE);

    }


    /* I/O of solution */
#if 0
    sprintf(iopath, "sol-lev%d-pe%d", level, myrank);
    writeToFile(pdePBE, pbe, nmol, 0, gm, am, 0, 1, level, iopath);
    writeToFile(pdePBE, pbe, nmol, 0, gm, am, 1, 5, level, iopath);
#endif

    /* *************** GARBAGE COLLECTION ******************* */
    Vnm_print(iounit,"\nmain: %s\n", sepline);
    Vnm_print(iounit,"main: NO GARBAGE COLLECTION: EXITING\n");

    /* *************** THE END ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STOPPING EXECUTION\n");
    return 0;
}
