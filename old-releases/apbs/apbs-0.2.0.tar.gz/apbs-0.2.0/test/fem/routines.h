/**
 *  @file    routines.h
 *  @author  Nathan Baker
 *  @brief   Auxiliary routines for FEM testing front-ends
 *  @version $Id: routines.h,v 1.14 2002/03/20 17:07:30 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (nbaker@wasabi.ucsd.edu)
 * Dept. of Chemistry and Biochemistry
 * University of California, San Diego 
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 1999-2002.  Nathan A. Baker.  All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE
 * AUTHORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED
 * HEREUNDER IS PROVIDED "AS IS".  THE AUTHORS HAVE NO OBLIGATION TO PROVIDE
 * MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * @endverbatim
 */

#ifndef _ROUTINES_H_
#define _ROUTINES_H_

#include "pdePBE.h"
#include "mc/mc.h"
#include "mcx/mcx.h"
#include "apbs/apbs.h"
#include "apbs/vfetk.h"
#include "apbs/vpee.h"
#include "apbs/vcsm.h"

typedef struct SolveVars {
  int lkey;
  int lmax;
  double ltol;
  int nkey;
  int nmax;
  double ntol;
  int gues;
  int pjac;
} SolveVars;

/* ///////////////////////////////////////////////////////////////////////////
// Prototypes for APBS
/////////////////////////////////////////////////////////////////////////// */
VEXTERNC int refineOnce(PDE *pde[MAXMOL], int nmol, int refMol,
  Gem *gm, AM *am[MAXMOL], int refKey, int partID,
  int *level, int ekey, double etol, SolveVars solveVars, int pkey, 
  int pdeKey);

#if defined(HAVE_MCX_H)
VEXTERNC int prefineOnce(PDE *pde[MAXMOL], int nmol, int refMol, Vpee *pee,
  Gem *gm, AM *am[MAXMOL], int refKey, int partID,
  int *level, int ekey, double etol, SolveVars solveVars, int pkey, 
  int pdeKey);
#endif

VEXTERNC void refineToSize(PDE *pde[MAXMOL], AM *am[MAXMOL], Gem *gm, 
  int nmol, int refMol, int refCrit, double size, int partID, int *level, 
  int pkey, int pdeKey);
VEXTERNC void writeToFile(PDE *pde[MAXMOL], Vpbe *pbe[MAXMOL], int nmol, 
  int theMol, Gem *gm, AM *am[MAXMOL], int funcKey, int fmtKey, int level, 
  char *stem);
VEXTERNC void printE(PDE *pde[MAXMOL], Vfetk *fetk[MAXMOL], int nmol, 
  int refMol, Vcom *com, int myrank, int level, int iounit, int nonlin);
VEXTERNC double Bvec_select(Bvec *thee, int k, int m);

#endif /* ifndef _ROUTINES_H_ */
