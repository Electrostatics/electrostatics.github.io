/**
 *  @file    pdePBE.h
 *  @author  Nathan Baker
 *  @brief   FEtk PDE definition for Poisson-Boltzmann equation
 *  @version $Id: pdePBE.h,v 1.2 2002/03/20 17:07:31 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (nbaker@wasabi.ucsd.edu)
 * Dept. of Chemistry and Biochemistry
 * University of California, San Diego 
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 1999-2002.  Nathan A. Baker.  All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE
 * AUTHORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED
 * HEREUNDER IS PROVIDED "AS IS".  THE AUTHORS HAVE NO OBLIGATION TO PROVIDE
 * MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 * @endverbatim
 */

#ifndef _PDEPBE_H_
#define _PDEPBE_H_

#include "myelm.h"
#include "mc/mc.h"
#include "mcx/mcx.h"
#include "apbs/apbs.h"
#include "apbs/vfetk.h"
#include "apbs/vcsm.h"
#include "apbs/vpee.h"

VEMBED(rcsid="$Id: pdePBE.h,v 1.2 2002/03/20 17:07:31 apbs Exp $")

/* ///////////////////////////////////////////////////////////////////////////
// Prototypes for APBS
/////////////////////////////////////////////////////////////////////////// */
VEXTERNC void pdePBE_init(PDE* thee, Vfetk *tfetk);
VEXTERNC void pdePBE_setPDE(PDE* thee, int imol, int pdeKey);
VEXTERNC void pdePBE_setRefineParam(PDE* thee, int imol, int refCrit, 
  double param);
VEXTERNC double pdePBE_U(int d, double x[]);

/* ///////////////////////////////////////////////////////////////////////////
// Required prototypes for MC
/////////////////////////////////////////////////////////////////////////// */
VEXTERNC PDE* pdePBE_ctor();
VEXTERNC void pdePBE_dtor(PDE **thee);
VEXTERNC void pdePBE_initAssemble(PDE *thee, int ip[], double rp[]);
VEXTERNC void pdePBE_initElement(PDE *thee, int elementType, int chart, 
  double tvx[][3], void *data);
VEXTERNC void pdePBE_initFace(PDE *thee, int faceType, int chart, 
  double tnvec[]);
VEXTERNC void pdePBE_initPoint(PDE *thee, int pointType, int chart, 
  double txq[], double tU[], double tdU[][3]);
VEXTERNC void pdePBE_Fu(PDE *thee, int key, double F[]);
VEXTERNC double pdePBE_Fu_v(PDE *thee, int key, double V[], double dV[][3]);
VEXTERNC double pdePBE_DFu_wv(PDE *thee, int key, double W[], double dW[][3],
  double V[], double dV[][3]);
VEXTERNC void pdePBE_delta(PDE *thee, int type, int chart, double txq[], 
  void *data, double F[]);
VEXTERNC void pdePBE_u_D(PDE *thee, int type, int chart, double txq[], 
  double F[]);
VEXTERNC void pdePBE_u_T(PDE *thee, int type, int chart, double txq[], 
  double F[]);
VEXTERNC void pdePBE_bisectEdge(int dim, int dimII, int edgeType, int chart[], 
    double vx[][3]);
VEXTERNC void pdePBE_mapBoundary(int dim, int dimII, int vertexType, int chart, 
    double vx[3]);
VEXTERNC int pdePBE_markSimplex(int dim, int dimII, int simplexType, 
    int faceType[4], int vertexType[4], int chart[], double vx[][3], 
    void *data);
VEXTERNC void pdePBE_oneChart(int dim, int dimII, int objType, int chart[], 
    double vx[][3], int dimV);
VEXTERNC int pdePBE_simplexBasisInit(int key, int dim, int comp, int *ndof, 
    int dof[]);
VEXTERNC void simplexBasisForm(int key, int dim, int comp, int pdkey, 
    double xq[], double basis[]);
VEXTERNC void pdePBE_externalUpdateFunction(SS **simps, int num);

VEXTERNC void Gem_setExternalUpdateFunction(Gem *thee,
    void (*externalUpdate)(SS **simps, int num));

#endif
