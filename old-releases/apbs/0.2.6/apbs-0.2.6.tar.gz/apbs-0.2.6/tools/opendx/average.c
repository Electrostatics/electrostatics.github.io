/**
 *  @file    average.c
 *  @author  Nathan Baker
 *  @brief   Sample program that illustrates OpenDX data I/O
 *  @version $Id: average.c,v 1.12 2003/01/17 16:23:59 apbs Exp $
 *
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (baker@biochem.wustl.edu)
 * Dept. of Biochemistry and Molecular Biophysics
 * Center for Computational Biology
 * Washington University in St. Louis
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 2003.  Washington University in St. Louis.
 * All Rights Reserved.
 * Portions Copyright (c) 1999-2003.  The Regents of the University of
 * California.  
 * Portions Copyright (c) 1995.  Michael Holst.
 *
 * This file is part of APBS.
 *
 * APBS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * APBS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with APBS; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
 *
 * @endverbatim
 */


#include "apbscfg.h"
#include "apbs/apbs.h"  

VEMBED(rcsid="$Id: average.c,v 1.12 2003/01/17 16:23:59 apbs Exp $")

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    int u, i, j, k, nx, ny, nz, imin, imax, jmin, jmax, kmin, kmax, navg;
    Vgrid *grid;
    double avg;
    double hy, hx, hzed, xmin, ymin, zmin;
    double xminAVG, xmaxAVG, yminAVG, ymaxAVG, zminAVG, zmaxAVG;
    double xcentAVG, ycentAVG, zcentAVG, xlenAVG, ylenAVG, zlenAVG;
    char *inpath = VNULL;
    char *usage = "\n  average file.dx\n"; 

 
    /* *************** CHECK INVOCATION ******************* */
    Vio_start();
    if (argc != 2) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected 2.\n\n",argc);
        Vnm_print(2,"%s\n", usage);
        return -1;
    } else {
        inpath = argv[1];
    }

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(1, "#  Reading data from %s...\n", inpath);
    grid = Vgrid_ctor(0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, VNULL);
    Vgrid_readDX(grid, "FILE", "ASC", VNULL, inpath);
    nx = grid->nx;
    ny = grid->ny;
    nz = grid->nz;
    hx = grid->hx;
    hy = grid->hy;
    hzed = grid->hzed;
    xmin = grid->xmin,
    ymin = grid->ymin,
    zmin = grid->zmin;
    Vnm_print(1, "#     nx = %d, ny = %d, nz = %d\n", 
      grid->nx, grid->ny, grid->nz);
    Vnm_print(1, "#     hx = %g, hy = %g, hz = %g\n", 
      grid->hx, grid->hy, grid->hzed);
    Vnm_print(1, "#     xmin = %g, ymin = %g, zmin = %g\n", 
      grid->xmin, grid->ymin, grid->zmin);

    /* *************** SETTINGS ******************** */
    xcentAVG = 112.160;
    ycentAVG = 63.5;
    zcentAVG = 137.245;
    xlenAVG = 70.0;
    zlenAVG = 70.0;
    ylenAVG = hy*(ny-1);

    /* *************** AVERAGE ********************** */
    xminAVG = xcentAVG - 0.5*xlenAVG;
    xmaxAVG = xcentAVG + 0.5*xlenAVG;
    yminAVG = ycentAVG - 0.5*ylenAVG;
    ymaxAVG = ycentAVG + 0.5*ylenAVG;
    zminAVG = zcentAVG - 0.5*zlenAVG;
    zmaxAVG = zcentAVG + 0.5*zlenAVG;
    imin = (int)floor((xminAVG - xmin)/hx);
    imin = VMAX2(imin, 0);
    jmin = (int)floor((yminAVG - ymin)/hy);
    jmin = VMAX2(jmin, 0);
    kmin = (int)floor((zminAVG - zmin)/hzed);
    kmin = VMAX2(kmin, 0);
    imax = (int)ceil((xmaxAVG - xmin)/hx);
    imax = VMIN2(imax, nx-1);
    jmax = (int)ceil((ymaxAVG - ymin)/hy);
    jmax = VMIN2(jmax, ny-1);
    kmax = (int)ceil((zmaxAVG - zmin)/hzed);
    kmax = VMIN2(kmax, nz-1);

    Vnm_print(1, "#  \tY POS\t\tAVERAGE\n");
    for (j=jmin; j<jmax; j++) {
        avg = 0.0;
        navg = 0;
        for (k=kmin; k<kmax; k++) {
            for (i=imin; i<imax; i++) {
                u = nx*ny*k + nx*j + i;
                avg += grid->data[u];
                navg++;
            }
        }
        avg = avg/((double)navg);
        Vnm_print(1, "   \t%e\t\t%e\n", hy*j + ymin, avg);
    }

    return 0;
}
