/**
 *  @file    mypde.h
 *  @author  Nathan Baker
 *  @brief   FEtk PDE definition for Poisson-Boltzmann equation
 *  @version $Id: mypde.h,v 1.14 2003/01/17 16:23:57 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (baker@biochem.wustl.edu)
 * Dept. of Biochemistry and Molecular Biophysics
 * Center for Computational Biology
 * Washington University in St. Louis
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 2003.  Washington University in St. Louis.
 * All Rights Reserved.
 * Portions Copyright (c) 1999-2003.  The Regents of the University of
 * California.  
 * Portions Copyright (c) 1995.  Michael Holst.
 *
 * This file is part of APBS.
 *
 * APBS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * APBS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with APBS; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
 *
 * @endverbatim
 */
#include "mc/mcsh.h"
#include "maloc/vec3.h"

#include "apbs/vacc.h"
#include "apbs/valist.h"
#include "apbs/vcsm.h"
#include "apbs/vpbe.h"
#include "apbs/vfetk.h"

/* ///////////////////////////////////////////////////////////////////////////
// Required prototypes
/////////////////////////////////////////////////////////////////////////// */

VEXTERNC PDE* myPDE_ctor();
VEXTERNC void myPDE_dtor(PDE **thee);
VEXTERNC void myPDE_init(PDE* thee, Vfetk *fetk);
VEXTERNC void myPDE_setColor(int color);

VEXTERNC void initAssemble(PDE *thee, int ip[], double rp[]);
VEXTERNC void initElement(PDE *thee, int elementType, int chart,
    double tvx[][3], void *data);
VEXTERNC void initFace(PDE *thee, int faceType, int chart, double tnvec[]);
VEXTERNC void initPoint(PDE *thee, int pointType, int chart, double txq[],
    double tU[], double tdU[][3]);

VEXTERNC void Fu(PDE *thee, int key, double F[]);
VEXTERNC double Fu_v(PDE *thee, int key, double V[], double dV[][3]);
VEXTERNC double DFu_wv(PDE *thee, int key, double W[], double dW[][3],
    double V[], double dV[][3]);

VEXTERNC void delta(PDE *thee, int type, int chart, double txq[],
    void *data, double F[]);
VEXTERNC void u_D(PDE *thee, int type, int chart, double txq[], double F[]);
VEXTERNC void u_T(PDE *thee, int type, int chart, double txq[], double F[]);

VEXTERNC void bisectEdge(int dim, int dimII, int edgeType, int chart[],
    double vx[][3]);
VEXTERNC void mapBoundary(int dim, int dimII, int vertexType, int chart,
    double vx[3]);
VEXTERNC int markSimplex(int dim, int dimII, int simplexType,
    int faceType[4], int vertexType[4], int chart[], double vx[][3],
    void *data);
VEXTERNC void oneChart(int dim, int dimII, int objType, int chart[],
    double vx[][3], int dimV);

VEXTERNC int simplexBasisInit(int key, int dim, int comp, int *ndof,
    int dof[]);
VEXTERNC void simplexBasisForm(int key, int dim, int comp, int pdkey,
    double xq[], double basis[]);

VEXTERNC double my_U(int d, double x[]);

VEXTERNC void Gem_setExternalUpdateFunction(Gem *thee,
    void (*externalUpdate)(SS **simps, int num));

/* ///////////////////////////////////////////////////////////////////////////
// Problem-specific
/////////////////////////////////////////////////////////////////////////// */
VEXTERNC void Gem_externalUpdateFunction(SS **simps, int num);
VEXTERNC void AM_smoothEstimate(AM *thee, Gem *gm, double alpha);
VEXTERNC void AM_writeSimplexGV(AM *thee, const char *iodev,
  const char *iofmt, const char *theHost, const char *theSock, int number);
VEXTERNC void Aprx_writeSimplexGV(Aprx *thee, const char *iodev, const char
  *iofmt, const char *theHost, const char *theSock, int number);
VEXTERNC void Gem_writeSimplexGV(Gem *thee, const char *iodev,
  const char *iofmt, const char *thost, const char *fname, int number,
  int chartKey, double *defX[MAXV]);
