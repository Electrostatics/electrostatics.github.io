/**
 *  @file    routines.c
 *  @author  Nathan Baker
 *  @brief   Auxiliary routines for FEM testinf front-ends
 *  @version $Id: routines.c,v 1.27 2003/01/17 16:23:56 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (baker@biochem.wustl.edu)
 * Dept. of Biochemistry and Molecular Biophysics
 * Center for Computational Biology
 * Washington University in St. Louis
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 2003.  Washington University in St. Louis.
 * All Rights Reserved.
 * Portions Copyright (c) 1999-2003.  The Regents of the University of
 * California.  
 * Portions Copyright (c) 1995.  Michael Holst.
 *
 * This file is part of APBS.
 *
 * APBS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * APBS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with APBS; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
 *
 * @endverbatim
 */
#include "mc/mc.h"
#include "apbs/vfetk.h"

#include "routines.h"

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  writeToFile
//
// Purpose:  Write interesting things about the specified system (theMol) to
//           files in various formats
//
// Args:     pde         An array of PDE objects, each associated with a
//                       particular physical component of the system
//           nmol        Number of systems (i.e., # valid entries in pde[])
//           theMol      Index of the system you want write out
//           gm          The grid manager
//           am          An array of AM objects, each associated with a
//                       particular physical component of the system
//           funcKey     What to write.  0 = solution, 1 = mesh, 2 = solvent
//                       accessible volume
//           fmtKey      A bit field indicating what to write.
//                       1st bit = GMV, 2nd bit = AVS UCD,
//                       3rd bit = Geomview OFF
//           level       The level of refinement.
//           stem        The stem of the filename; a description of the file
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void writeToFile(PDE *pde[MAXMOL], Vpbe *pbe[MAXMOL], int nmol,
  int theMol, Gem *gm, AM *am[MAXMOL], int funcKey, int fmtKey, int level,
  char *stem) {

    Vio *sock;
    char filename[256];

    pdePBE_setPDE(pde[theMol], theMol, 0);
    if (funcKey == 0) {
        if ((fmtKey & 1) != 0) {
            sprintf(filename, "%s.gmv", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeSOL(am[theMol], sock, -1, "GMV");
            Vio_dtor(&sock);
        }
        if ((fmtKey & 2) != 0) {
            sprintf(filename, "%s.ucd", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeSOL(am[theMol], sock, -1, "UCD");
            Vio_dtor(&sock);
        }
        if ((fmtKey & 4) != 0) {
            Vnm_print(2, "writeToFile: OFF format solution data not supported!\n");
        }
        if ((fmtKey & 8) != 0) {
            sprintf(filename, "%s.dx", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeSOL(am[theMol], sock, -1, "DX");
            Vio_dtor(&sock);
        }
    } else if (funcKey == 1) {
        if ((fmtKey & 1) != 0) {
            sprintf(filename, "%s.gmv", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeSOL(am[theMol], sock, -1, "GMV");
            Vio_dtor(&sock);
        }
        if ((fmtKey & 2) != 0) {
            sprintf(filename, "%s.ucd", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeSOL(am[theMol], sock, -1, "UCD");
            Vio_dtor(&sock);
        }
        if ((fmtKey & 4) != 0) {
            sprintf(filename, "%s.off", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeGEOM(am[theMol], sock, 0, 1, -1, 1.0, -1, 0, "GV");
            Vio_dtor(&sock);
        }
        if ((fmtKey & 8) != 0) {
            sprintf(filename, "%s.dx", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeSOL(am[theMol], sock, -1, "DX");
            Vio_dtor(&sock);
        }
    } else if (funcKey == 2) {
        if ((fmtKey & 1) != 0) {
            sprintf(filename, "%s.gmv", stem);
            Vacc_writeGMV(Vpbe_getVacc(pbe[theMol]),
              Vpbe_getSolventRadius(pbe[theMol]), 0, gm, "FILE", "ASC",
              "localhost", filename);
        }
        if ((fmtKey & 2) != 0) {
            Vnm_print(2, "writeToFile: UCD format accessiblity data not supported!\n");
        }
        if ((fmtKey & 4) != 0) {
            Vnm_print(2, "writeToFile: OFF format accessiblity data not supported!\n");
        }
        if ((fmtKey & 8) != 0) {
            Vnm_print(2, "writeToFile: DX format accessiblity data not supported!\n");
        }
    } else VASSERT(0);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  mark
//
// Purpose:  Mark the mesh according to the specified error estimator and
//           refine to conformity.  Return 0 if no simplices were
//           marked/refined; return # simplices marked otherwise.
//
// Args:     pde         An array of PDE objects, each associated with a
//                       particular physical component of the system
//           nmol        Number of systems (i.e., # valid entries in pde[])
//           gm          The grid manager
//           am          An array of AM objects, each associated with a
//                       particular physical component of the system
//           refKey      How to refine the mesh.  0 = uniform, 1 =
//                       user-defined (see markSimplex), 2 = residual-based
//                       adaptive (if this is used an solve must have recently
//                       occurred)
//           partID      The ID of the partition in which to constrain
//                       refinement or -1 if refinement happens everywhere
//           level       The current level of refinement.
//           ekey        How etol is interpreted
//                          0 => etol is a local error tolerance applied to
//                               each simplex
//                          1 => etol is a global error tolerance from which
//                               the per-simplex tolerances are derived
//           etol        The error criterion to use for error-based refinement
//                       schemes (see ekey).  This is ignored for uniform and
//                       user-defined refinement.
//           pkey        Prolongation operator key
//           pdeKey
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int mark(PDE *pde[MAXMOL], int nmol, Gem *gm, AM *am[MAXMOL],
  int refKey, int partID, int level, int ekey, double etol, int pdeKey) {

    int i, j, nsimp, marked, *markings, currentQ;
    double myEtol;
    SS *simp;

    /* Allocate and clear markings array */
    nsimp = Gem_numSS(gm);
    markings = Vmem_malloc(VNULL, nsimp, sizeof(int));
    VASSERT(markings != VNULL);
    for (i=0; i<nsimp; i++) markings[i] = 0;

    /* Get the markings for each molecule */
    for (i=0; i<nmol; i++) {
        /* Reset the simplex queues */
        currentQ = 0;
        Gem_resetSQ(gm, currentQ);
        Gem_resetSQ(gm, !currentQ);

        /* Set the PDE */
        pdePBE_setPDE(pde[i], i, pdeKey);
	AM_create(am[i]); /* Is this necessary? */

        /* Mark it */
        if (refKey == 0) {
            Vnm_print(0, "mark:  Uniform marking of mesh (mol %d)...\n", i);
        } else if (refKey == 1) {
            Vnm_print(0, "mark:  Geometry-based marking of mesh (mol %d)...\n",
              i);
        } else if (refKey == 2) {
            Vnm_print(0, "mark:  Residual-based marking of mesh (mol %d)...\n",
              i);
        } else {
            Vnm_print(0, "mark:  Unknown method (%d) for marking mesh (mol %d)...\n", refKey, i);
            Vnm_print(0, "mark:  Check what AM_markRefine does with it.\n");
        }
        marked = AM_markRefine(am[i], refKey, partID, ekey, etol);
        Vnm_print(0, "mark:  Marked %d simplices.\n", marked);

        /* Add to the global list of markings */
        currentQ = 0;
        for (j=0; j<Gem_numSQ(gm, currentQ); j++) {
            simp = Gem_SQ(gm, currentQ, j);
            markings[SS_id(simp)] = 1;
        }
        currentQ = !currentQ;
        for (j=0; j<Gem_numSQ(gm, currentQ); j++) {
            simp = Gem_SQ(gm, currentQ, j);
            markings[SS_id(simp)] = 1;
        }
    }

    /* Mark the mesh based on the global list of markings */
    Vnm_print(0, "mark:  Unifying markings across molecules...\n");
    currentQ = 0;
    Gem_resetSQ(gm, currentQ);
    Gem_resetSQ(gm, !currentQ);
    marked = 0;
    for (i=0; i<nsimp; i++) {
        if (markings[i]) {
            simp = Gem_SS(gm, i);
            Gem_appendSQ(gm, currentQ, simp);
            SS_setRefineKey(simp, currentQ, 1);
            SS_setRefinementCount(simp, 1);
            marked++;
        }
    }
    Vnm_print(0, "mark:  Total of %d marked simplices.\n", marked);

    /* Free markings array */
    Vmem_free(VNULL, nsimp, sizeof(int), (void **)&markings);

    return marked;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  printE
//
// Purpose:  Print out information about the energeis
//
// Args:     pde         An array of PDE objects, each associated with a
//                       particular physical component of the system
//           nmol        Number of systems (i.e., # valid entries in pde[])
//           refMol      Index of the system you want to use as a reference
//           com         The communications objevt
//           myrank      The rank of this process
//                       refinement or -1 if refinement happens everywhere
//           level       The level of refinement.
//           iounit      Where to print out the information (0 = io.mc, 1 =
//                       stdout, 2 = stderr)
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void printE(PDE *pde[MAXMOL], Vfetk *fetk[MAXMOL], int nmol,
  int refMol, Vcom *com, int myrank, int level, int iounit, int pdeKey)
{
    int imol;
    double rEnergy, lEnergy[MAXMOL], gEnergy[MAXMOL];

    for (imol=0; imol<nmol; imol++) {
        pdePBE_setPDE(pde[imol], imol, pdeKey);
        rEnergy = Vfetk_energy(fetk[imol], myrank, pdeKey);
        Vnm_print(1, "mol %d, energy = %g kT\n", imol, rEnergy);
        lEnergy[imol] = (Vunit_kb)*(298.15)*Vunit_Na*rEnergy;
    }
    fflush(stdout);


#if defined(HAVE_MPI_H)
    Vcom_reduce(com, lEnergy, gEnergy, nmol, 2, 0);
#else
    for (imol=0; imol<nmol; imol++) gEnergy[imol] = lEnergy[imol];
#endif
    for (imol=0; imol<nmol; imol++) {
        Vnm_print(iounit, "main:    Abs. energy of mol %d = %e kJ/mol\n",
          imol, gEnergy[imol]/1000.);
    }
    rEnergy = gEnergy[refMol];
    for (imol=0; imol<nmol; imol++) {
        if (imol != refMol) rEnergy = rEnergy - gEnergy[imol];
    }
    Vnm_print(iounit, "main:    Rel. energy of mol %d = %e kJ/mol\n",
      refMol, rEnergy/1000.);
}
