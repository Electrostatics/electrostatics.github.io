/**
 *  @file    pdePBE.h
 *  @author  Nathan Baker
 *  @brief   FEtk PDE definition for Poisson-Boltzmann equation
 *  @version $Id: pdePBE.h,v 1.11 2003/01/17 16:23:56 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (baker@biochem.wustl.edu)
 * Dept. of Biochemistry and Molecular Biophysics
 * Center for Computational Biology
 * Washington University in St. Louis
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 2003.  Washington University in St. Louis.
 * All Rights Reserved.
 * Portions Copyright (c) 1999-2003.  The Regents of the University of
 * California.  
 * Portions Copyright (c) 1995.  Michael Holst.
 *
 * This file is part of APBS.
 *
 * APBS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * APBS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with APBS; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
 *
 * @endverbatim
 */
#ifndef _PDEPBE_H_
#define _PDEPBE_H_

/* ///////////////////////////////////////////////////////////////////////////
// Prototypes for APBS
/////////////////////////////////////////////////////////////////////////// */
VEXTERNC void pdePBE_init(PDE* thee, Vfetk *tfetk);
VEXTERNC void pdePBE_setPDE(PDE* thee, int imol, int pdeKey);
VEXTERNC void pdePBE_setRefineParam(PDE* thee, int imol, int refCrit, 
  double param);
VEXTERNC double pdePBE_U(int d, double x[]);

/* ///////////////////////////////////////////////////////////////////////////
// Required prototypes for MC
/////////////////////////////////////////////////////////////////////////// */
VEXTERNC PDE* pdePBE_ctor();
VEXTERNC void pdePBE_dtor(PDE **thee);
VEXTERNC void pdePBE_initAssemble(PDE *thee, int ip[], double rp[]);
VEXTERNC void pdePBE_initElement(PDE *thee, int elementType, int chart, 
  double tvx[][3], void *data);
VEXTERNC void pdePBE_initFace(PDE *thee, int faceType, int chart, 
  double tnvec[]);
VEXTERNC void pdePBE_initPoint(PDE *thee, int pointType, int chart, 
  double txq[], double tU[], double tdU[][3]);
VEXTERNC void pdePBE_Fu(PDE *thee, int key, double F[]);
VEXTERNC double pdePBE_Fu_v(PDE *thee, int key, double V[], double dV[][3]);
VEXTERNC double pdePBE_DFu_wv(PDE *thee, int key, double W[], double dW[][3],
  double V[], double dV[][3]);
VEXTERNC void pdePBE_delta(PDE *thee, int type, int chart, double txq[], 
  void *data, double F[]);
VEXTERNC void pdePBE_u_D(PDE *thee, int type, int chart, double txq[], 
  double F[]);
VEXTERNC void pdePBE_u_T(PDE *thee, int type, int chart, double txq[], 
  double F[]);
VEXTERNC void pdePBE_bisectEdge(int dim, int dimII, int edgeType, int chart[], 
    double vx[][3]);
VEXTERNC void pdePBE_mapBoundary(int dim, int dimII, int vertexType, int chart, 
    double vx[3]);
VEXTERNC int pdePBE_markSimplex(int dim, int dimII, int simplexType, 
    int faceType[4], int vertexType[4], int chart[], double vx[][3], 
    void *data);
VEXTERNC void pdePBE_oneChart(int dim, int dimII, int objType, int chart[], 
    double vx[][3], int dimV);
VEXTERNC int pdePBE_simplexBasisInit(int key, int dim, int comp, int *ndof, 
    int dof[]);
VEXTERNC void simplexBasisForm(int key, int dim, int comp, int pdkey, 
    double xq[], double basis[]);
VEXTERNC void pdePBE_externalUpdateFunction(SS **simps, int num);

VEXTERNC void Gem_setExternalUpdateFunction(Gem *thee,
    void (*externalUpdate)(SS **simps, int num));

#endif
