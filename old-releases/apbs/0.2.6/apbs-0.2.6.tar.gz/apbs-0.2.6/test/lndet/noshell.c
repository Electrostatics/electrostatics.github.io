/**
 *  @file    noshell.c
 *  @author  Nathan Baker and Stephen Bond
 *  @brief   Adaptive multilevel FEM APBS ln det calculator
 * 
 *  @version $Id: noshell.c,v 1.25 2003/01/17 16:23:56 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (baker@biochem.wustl.edu)
 * Dept. of Biochemistry and Molecular Biophysics
 * Center for Computational Biology
 * Washington University in St. Louis
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 2003.  Washington University in St. Louis.
 * All Rights Reserved.
 * Portions Copyright (c) 1999-2003.  The Regents of the University of
 * California.  
 * Portions Copyright (c) 1995.  Michael Holst.
 *
 * This file is part of APBS.
 *
 * APBS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * APBS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with APBS; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
 *
 * @endverbatim
 */

#include "apbscfg.h"

#include "mc/mc.h"
#include "apbs/vfetk.h"
#include "apbs/vopot.h"

#include "mypde.h"

#define APBS_ERR_RC 13
#define APBS_OK_RC 0

#define VEMBED(rctag) VPRIVATE const char* rctag; \
    static void* use_rcsid=(0 ? &use_rcsid : (void**)&rcsid);
VEMBED(rcsid="$Id: noshell.c,v 1.25 2003/01/17 16:23:56 apbs Exp $")

/*
 * Begin Private Headers
 */

VPRIVATE void Gem_approxOpot(Gem *gm, Vpbe *pbe, Vopot *opot, int opFlag);
VPRIVATE void HeapSort( double *data, int *indices, int N );

/*
 * End Private Headers
 */

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    /* Objects */
    PDE *pde;
    AM *am;
    Vfetk *fetk;
    Vpbe *pbe;
    Valist *alist;
    Vopot *opot;
    Vgrid *grid;
    Gem *gm = VNULL;
    Aprx *aprx = VNULL;
    VV *vx;
    SS *sm;
    Vio *sock;

    /* PBE parameters */
    int opFlag, ionNum, nx, ny, nz, i, j, level, doRefine;
    double ionConc[MAXION], ionRadii[MAXION], ionQ[MAXION], etol, edgeLength;
    double T, soluteDiel, solventDiel, solventRadius, fineLength, coarseLength;
    double hx, hy, hzed, xmin, ymin, zmin, xlen, ylen, zlen, x, y, z, gamma;
    char *pqr_path, *dx_path;
    char *sepline = "--------------------------------------------------------";
    int bytesTotal, highWaterTotal;
    double lndet;

    /* Instructions: */
    char *usage = "\
    This driver program represents a mish-mash of instructions for\n\
    building, factoring, and calculating ln det for various electrostatics\n\
    operators.  It is invoked as\n\
      noshell flag pot.dx mol.pqr\n\
    where flag tells the program what type of operator to assemble\n\
    (0 = Laplacian, 1 = Poisson, 2 = Poisson-Boltzmann), pot.dx is the\n\
    electrostatic potential on a Cartesian mesh in DX format, and\n\
    mol.pqr is the PQR format molecule data for the biomolecule of\n\
    interest.  All of these files are required, even in cases where the\n\
    potential (flag=0,1) or molecule data (flag=2) are irrelevant.\n\n";


    /* ********************* START PARMETER SETTINGS ********************** */
    ionNum = 2;                  /* Number of ionic species                 */
    ionConc[0] = 0.150;          /* ion concentration in M                  */
    ionRadii[0] = 2.0;           /* ion sphere radius                       */
    ionQ[0] = 1.0;               /* ion charge                              */
    ionConc[1] = 0.150;          /* ion concentration in M                  */
    ionRadii[1] = 2.0;           /* ion sphere radius                       */
    ionQ[1] = -1.0;              /* ion charge                              */
    T = 298.15;                  /* temperature in K                        */
    gamma = 0.0;                 /* apolar coefficient (kJ/mo/A^2)          */
    soluteDiel = 1.0;            /* solute dielectric constant              */
    solventDiel = 78.54;         /* solvent diel. constant (78.54 = water)  */
    solventRadius = 1.40;        /* solvent sphere radius                   */
    coarseLength = 10.0;         /* Desired initial resolution of the mesh  */
    etol = 1e-1;                 /* Max second derivative estimate in a simplex
                                  */
    /* ********************* END PARMETER SETTINGS ********************** */

    /* *************** CHECK INVOCATION ******************* */
    Vio_start();
    Vnm_print(1,"main:  Constructing VCOM object.\n");
    if (argc != 4) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected 4.\n\n",
          argc);
        Vnm_print(2,"%s\n", usage);
        return APBS_ERR_RC;
    } else {

        sscanf(argv[1], "%d", &opFlag);
        if (opFlag == 0) {
            Vnm_print(1,"\nmain:  Working with Laplace operator.\n");
        } else if (opFlag == 1) {
            Vnm_print(1,"\nmain:  Working with Poisson operator.\n");
        } else if (opFlag == 2) {
            Vnm_print(1,"\nmain:  Working with Poisson-Boltzmann operator.\n");
        } else {
            Vnm_print(2,"\n*** Syntax error: invalid flag = %d.\n\n", opFlag);
            Vnm_print(2,"%s\n", usage);
            return APBS_ERR_RC;
        }

        /* Grab paths to DX and PQR files */
        dx_path = argv[2];
        Vnm_print(1, "main:  Potential data at %s.\n", dx_path);
        pqr_path = argv[3];
        Vnm_print(1, "main:  Molecule data at %s.\n", pqr_path);
    }

    /* *************** READ IN ATOM LIST ******************* */
    Vnm_print(1,"main:  Constructing VALIST object.\n");
    alist = Valist_ctor();
    Vnm_print(1, "main:  Reading molecule data from %s...\n",
      pqr_path);
    if (Valist_readPQR(alist, "FILE", "ASC", VNULL, pqr_path) != 1) {
        Vnm_print(2, "main:  Fatal error reading PQR!\n");
        return APBS_ERR_RC;
    }
    Vnm_print(1, "main:  Molecule has %d atoms\n",
      Valist_getNumberAtoms(alist));

    /* *************** VPBE INITIALIZATION ******************* */
    Vnm_print(1,"main: Constructing VPBE object.\n");
    Vnm_print(1,"main: Initializing VPBE parameters, hash tables, ");
    Vnm_print(1,"and charge-simplex map.\n");
    for (i=0; i<ionNum; i++) {
        Vnm_print(1,"main:       Ion #%d conc    %4.3f M\n",
          i, ionConc[i]);
        Vnm_print(1,"main:       Ion #%d radius  %4.3f A\n",
          i, ionRadii[i]);
        Vnm_print(1,"main:       Ion #%d charge  %4.3f e\n",
          i, ionQ[i]);
    }
    Vnm_print(1,"main:        Temperature   %4.3f K\n", T);
    Vnm_print(1,"main:  Solute dielectric   %4.3f \n", soluteDiel);
    Vnm_print(1,"main: Solvent dielectric   %4.3f \n", solventDiel);
    Vnm_print(1,"main:     Solvent radius   %4.3f A\n", solventRadius);
    Vnm_print(1,"main:  CONSTRUCTING Vpbe object\n");
    pbe = Vpbe_ctor(alist, ionNum, ionConc, ionRadii, ionQ, T, gamma,
      soluteDiel, solventDiel, solventRadius);
    Vnm_print(1,"main:      Solute charge   %4.3f \n",
      Vpbe_getSoluteCharge(pbe));
    Vnm_print(1,"main:      Solute radius   %4.3f \n",
      Vpbe_getSoluteRadius(pbe));
    Vnm_print(1,"main:      Solute center   (%4.3f, %4.3f, %4.3f) \n",
      Vpbe_getSoluteCenter(pbe)[0],
      Vpbe_getSoluteCenter(pbe)[1],
      Vpbe_getSoluteCenter(pbe)[2]);
    Vnm_print(1,"main:  Solute dimensions    (%4.3f, %4.3f, %4.3f) \n",
      Vpbe_getSoluteXlen(pbe), Vpbe_getSoluteYlen(pbe),
      Vpbe_getSoluteZlen(pbe));

    /* *************** READ IN POTENTIAL DATA ******************* */
    Vnm_print(1, "main:  Reading potential data from %s...\n", dx_path);
    grid = Vgrid_ctor(0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, VNULL);
    Vgrid_readDX(grid, "FILE", "ASC", VNULL, dx_path);
    nx = grid->nx; ny = grid->ny; nz = grid->nz;
    hx = grid->hx; hy = grid->hy; hzed = grid->hzed;
    xmin = grid->xmin; ymin = grid->ymin; zmin = grid->zmin;
    Vnm_print(1, "main:     nx = %d, ny = %d, nz = %d\n",
      grid->nx, grid->ny, grid->nz);
    Vnm_print(1, "main:     hx = %g, hy = %g, hz = %g\n",
      grid->hx, grid->hy, grid->hzed);
    Vnm_print(1, "main:     xmin = %g, ymin = %g, zmin = %g\n",
      grid->xmin, grid->ymin, grid->zmin);
    Vnm_print(1, "main:  Constructing potential oracle...\n");
    opot = Vopot_ctor(grid, pbe, 2);
    fineLength = 5.0*VMAX2(VMAX2(hx,hy),hzed);
    Vnm_print(1, "main:  Setting maximum mesh resolution to %4.3f A\n",
      fineLength);

    /* *************** MC INITIALIZATION ******************* */
    Vnm_redirect(1);
    Vnm_print(1,"main:  Constructing PDE object.\n");
    /* potData should be a simple oracle object */
    pde = PDE_ctor();
    Vnm_print(1,"main:  Constructing (empty) GEM object;\n");
    gm = Gem_ctor(VNULL, pde);

    /* *************** DOMAIN INITIALIZATION ******************* */
    /* Build finite element mesh from finite difference mesh boundaries */
    Vnm_print(1, "main:  Building mesh boundaries...\n");
    Gem_makeCube(gm);
    xlen = (nx-1)*hx;
    ylen = (ny-1)*hy;
    zlen = (nz-1)*hzed;
    for (i=0; i<Gem_numVV(gm); i++) {
        vx = Gem_VV(gm, i);
        x = xlen*VV_coord(vx, 0) + xmin;
        y = ylen*VV_coord(vx, 1) + ymin;
        z = ylen*VV_coord(vx, 2) + zmin;
        VV_setCoord(vx, 0, x);
        VV_setCoord(vx, 1, y);
        VV_setCoord(vx, 2, z);
    }
    /* Set mesh boundaries to Dirichlet */
    for (i=0; i<Gem_numSS(gm); i++) {
        sm = Gem_SS(gm, i);
        for (j=0; j<Gem_dimVV(gm); j++) {
            if (VBOUNDARY(SS_faceType(sm,j))) {
                Vnm_print(1, "main:  Setting boundary face to Dirichlet!\n");
                SS_setFaceType(sm, j, 1);
            }
        }
    }
    Vnm_print(1,"main:  Checking mesh (this takes a while)...\n");
    Gem_formChk(gm,3);
    Vnm_print(1,"main:  Fixing mesh (this takes a while)...\n");
    Gem_formChk(gm,3);


    /* *************** OPERATOR ASSEMBLY ******************* */
    Vnm_print(1,"main:  Constructing Aprx object;\n");
    aprx = Aprx_ctor(VNULL, gm, pde);
    Vnm_print(1,"main:  Constructing AM object;\n");
    am = AM_ctor(VNULL, aprx);
    PDE_setDim(aprx->pde, Gem_dim(gm));
    PDE_setDimII(aprx->pde, Gem_dimII(gm));
    for (i=0; i<PDE_vec(aprx->pde); i++) {
        aprx->re[i]  = Re_ctor(0, PDE_dim(aprx->pde),
          aprx->pde->simplexBasisInit, aprx->pde->simplexBasisForm);
        aprx->reB[i] = Re_ctor(0, PDE_dim(aprx->pde),
          aprx->pde->simplexBasisInit, aprx->pde->simplexBasisForm);
    }
    level = 0;

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(1,"main:  Constructing VFETK and initializing PDE object.\n");
    fetk = Vfetk_ctor(pbe, gm, am);
    PDE_init(pde, opot, fetk, opFlag, fineLength);

    /* *************** MESH REFINEMENT ******************* */
    /* Uniformly refine mesh until all the longest edges are below the desired
     * length */
    doRefine = 1;
    Vnm_print(1, "main:  Bringing entire mesh down to desired coarse \
resolution (%4.3f A)...\n", coarseLength);
    while (doRefine) {
        AM_create(am); /* Is this necessary? */
        Gem_markRefine(gm, 0, -1);
        Gem_refine(gm, 2, 0);
        level++;
        doRefine = 0;
        for (i=0; i<Gem_numSS(gm); i++) {
            sm = Gem_SS(gm, i);
            Gem_longestEdge(gm, sm, &edgeLength);
            if (edgeLength > coarseLength) {
                doRefine = 1;
                break;
            }
        }
    }
    Vnm_print(1, "main:  Have %d simplices and %d vertices after %d levels \
of refinement\n", Gem_numSS(gm), Gem_numVV(gm), level);

    /* Refine mesh using user-defined markings until no more simplices are
     * marked */
    Vnm_print(1, "main:  Refining discontinuity boundaries to desired \
resolution (%4.3f A)...\n", fineLength);
    doRefine = 1;
    while (doRefine) {
        AM_create(am); /* Is this necessary? */
        if (Gem_markRefine(gm, 1, -1) == 0) break;
        Gem_refine(gm, 0, 0);
        level++;
        Vnm_print(0, "main:  Have %d simplices and %d vertices after %d \
levels of discontinuity refinement\n", Gem_numSS(gm), Gem_numVV(gm), level);
    }
    Vnm_print(1, "main:  Have %d simplices and %d vertices after %d levels \
of refinement\n", Gem_numSS(gm), Gem_numVV(gm), level);

    /* Refine mesh using user-defined markings until no more simplices are
     * marked */
    Vnm_print(1, "main:  Second derivative-based refinement to desired \
resolution (%4.3f A)...\n", fineLength);
    doRefine = 1;
    while (doRefine) {
        AM_create(am); /* Is this necessary? */
        /* 5th arg = 0 ==> Apply local error tolerances */
        if (AM_markRefine(am, 2, -1, 0, etol) == 0) break;
        Gem_refine(gm, 0, 0);
        level++;
        Vnm_print(0, "main:  Have %d simplices and %d vertices after %d \
levels of curvature refinement\n", Gem_numSS(gm), Gem_numVV(gm), level);
    }
    Vnm_print(1, "main:  Have %d simplices and %d vertices after %d levels \
of refinement\n", Gem_numSS(gm), Gem_numVV(gm), level);
    Vnm_print(1,"main:  Checking mesh (this takes a while)...\n");
    Gem_formChk(gm,3);
    Vnm_print(1,"main:  Fixing mesh (this takes a while)...\n");
    Gem_formChk(gm,3);

    /* *************** I/O **************** */
    sock = Vio_ctor("FILE", "ASC", "localhost", "mesh.m", "w");
    Gem_write(gm, 0, sock, 0);
    Vio_dtor(&sock);
    sock = Vio_ctor("FILE", "ASC", "localhost", "mesh.off", "w");
    Gem_writeGV(gm, sock, 0, 0, -1, 1.0, VNULL, 0);
    Vio_dtor(&sock);

    /* *************** MEM USAGE ********************* */
    Vnm_print(1, "main:  MEMORY USAGE BEFORE FACTORING:\n");
    Vnm_redirect(0);
    Vmem_print(VNULL);
    Vmem_printTotal();
    Vnm_redirect(1);
    bytesTotal = Vmem_bytesTotal();
    highWaterTotal    = Vmem_highWaterTotal();
    Vnm_print(1, "main: %4.3f MB TOTAL\n",  bytesTotal/(1024.0*1024.0));
    Vnm_print(1, "main: %4.3f MB HIGH WATER\n",
      highWaterTotal/(1024.0*1024.0));

    /* *************** BUILD/FACTOR/ln det for OPERATOR ******************* */
    /* The mypde.c file is responsible for specifying the actual operator that
     * we want to factor (i.e., the linearization around some solution), so
     * we can just go ahead and assemble ==> flag argument = 0
     */
    Vnm_print(1,"main:  Building, factoring, and evaluating ");
    Vnm_print(1,"ln det of operator.\n");
    fflush(stdout);
#if 0
    lndet = Vfetk_lnDet(fetk, -1, 0, 1);
#else
    lndet = Vfetk_lnDet(fetk, -1, 0, 0);
#endif
    Vnm_print(1, "main:  ln det(A) = %1.12E\n");

    /* *************** MEM USAGE ********************* */
    Vnm_print(1, "main:  MEMORY USAGE AFTER FACTORING:\n");
    Vnm_redirect(0);
    Vmem_print(VNULL);
    Vmem_printTotal();
    Vnm_redirect(1);
    bytesTotal = Vmem_bytesTotal();
    highWaterTotal    = Vmem_highWaterTotal();
    Vnm_print(1, "main: %4.3f MB TOTAL\n",  bytesTotal/(1024.0*1024.0));
    Vnm_print(1," main: %4.3f MB HIGH WATER\n",
      highWaterTotal/(1024.0*1024.0));

    /* *************** GARBAGE COLLECTION ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: NO GARBAGE COLLECTION: EXITING\n");

    /* *************** THE END ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STOPPING EXECUTION\n");
    return APBS_OK_RC;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Gem_approxOpot
//
//   Notes:  opFlag=0 ==> Laplace
//           opFlag=1 ==> Poisson
//           opFlag=2 ==> Poisson Boltzmann
//
//   THIS GUY SHOULD CONTAIN CALLS TO RESIDUAL AND USER-DEFINED ERROR
//   ESTIMATORS AND MIGHT HAVE THE FOLLOWING FLOW:
//      1. Build 8-vertex FE mesh as cube with boundaries on supplied FD mesh.
//         Use Delauney.  Refine mesh to desired coarse resolution.
//      2. Geometry-based refinement until no more simplices are marked.
//      3. "Residual"-based refinement (actually refines in areas of high
//          curvature) until no more simplices are marked.
//      4. [OPTIONAL] Mesh I/O.
//
// Authors:  Stephen Bond and Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE void Gem_approxOpot(Gem *gm, Vpbe *pbe, Vopot *opot, int opFlag)
{
    int ix, iy, iz, nx, ny, nz, k;
    double hx, hy, hzed, val;
    double pt[3];

    int *cindex;
    double *cval;

    VASSERT( gm != VNULL );

    nx = opot->grid->nx;
    ny = opot->grid->ny;
    nz = opot->grid->nz;
    hx = opot->grid->hx;
    hy = opot->grid->hy;
    hzed = opot->grid->hzed;

    cindex = Vmem_malloc( VNULL, nx*ny*nz, sizeof(int) );
    cval = Vmem_malloc( VNULL, nx*ny*nz, sizeof(double) );

    /* STEP 1:  tabulate the curvature for each vertex */
    k = 0;
    pt[2] = opot->grid->zmin;
    for( iz=0; iz<nz; iz++ ) {
        pt[1] = opot->grid->ymin;
        for( iy=0; iy<ny; iy++ ) {
            pt[0] = opot->grid->xmin;
            for( ix=0; ix<nx; ix++ ) {
                /* Check the curvature */
                VASSERT(Vopot_curvature( opot, pt, 0, &val));
#if 0
                Vnm_print(1,"%lf %lf %lf   %e \n",pt[0],pt[1],pt[2],val);
#endif
                cindex[k] = k;
                cval[k] = val;
                pt[0] += hx;
                k++;
            }
            pt[1] += hy;
        }
        pt[2] += hzed;
    }

    /* STEP 2:  sort the list of curvatures */
    HeapSort( cval, cindex, nx*ny*nz );

    for (k=0; k<(nx*ny*nz); k++) {
       Vnm_print(1,"%d  %e\n",cindex[k],cval[k]);
    }

    Vmem_free(VNULL, nx*ny*nz, sizeof(int), (void **)&(cindex));
    Vmem_free(VNULL, nx*ny*nz, sizeof(double), (void **)&(cval));

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  HeapSort
//
//   Notes:  Both worst and best case are order N log N
//
//  Author:  Stephen Bond
//           (adapted from Knuth's book on fundamental algorithms)
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE void HeapSort( double *data, int *idx, int N )
{
    int i, j, k, ir;
    int ridx;
    double rdata;

    k = ( N >> 1 ) + 1;

    ir = N;

    for ( ;; ) {
        if ( k > 1 ) {
            rdata = data[ --k ];
            ridx = idx[ k ];
        } else {
            rdata = data[ ir ];
            data[ ir ]  = data[ 1 ];
            ridx = idx[ ir ];
            idx[ ir ]  = idx[ 1 ];
            if ( --ir == 1 ) {
                data[1] = rdata;
                idx[1] = ridx;
                break;
            }
        }
        i = k;
        j = k + 1;
        while ( j <= ir ) {
            if ( j < ir && data[j] < data[j+1] ) j++;
            if ( rdata < data[j] ) {
                data[i] = data[j];
                idx[i] = idx[j];
                i = j;
                j <<= 1;
            } else j = ir + 1;
        }
        data[i] = rdata;
        idx[i] = ridx;
    }
}
