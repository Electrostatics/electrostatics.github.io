/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
////////////////////////////////////////////////////////////////////////////
/// rcsid="$Id: noshell.c,v 1.13 2001/10/04 22:34:47 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     noshell.c
//
// Purpose:  Test energy components of VPBE
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */

#include "apbscfg.h"
#include "mc/mc.h"  
#include "mcx/mcx.h"  
#include "apbs/apbs.h"  
#include "mypde.h"

VEMBED(rcsid="$Id: noshell.c,v 1.13 2001/10/04 22:34:47 apbs Exp $")

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    /* Objects for solver */
    PDE *myPde = VNULL;
    MCsh *vmc = VNULL;
    Gem *gm = VNULL;
    AM *am = VNULL;
    Vpbe *pbe = VNULL;
    Vfetk *fetk = VNULL;
    Valist *alist = VNULL;
    Vio *sock = VNULL;

    /* Information for I/O */
    char *mcsf_path;
    char *pqr_path;
    char filename[256];
    char *sepline =
      "--------------------------------------------------------";

    /* PBE parameters */
    double T = 298.15;
    double soluteDiel = 1.0;
    double solventDiel = 78.54;
    double solventRadius = 1.40;
    int nion = 2;
    double ionRadii[MAXION];
    double ionConc[MAXION];
    double ionQ[MAXION];

    /* Parameters for solving */
    int level;
    int isolve, maxsolve = 20;
    int lkey = 5;
    int lmax = 100;
    double ltol = 1.0e-07;
    double etol = 1.0e+00;
    int ekey = 1;
    int gues = 2;
    int pjac = 2;
    int akey = 2;
    int maxverts = 1000000;
    int targetNum = 10;
    int targetSize = 1.0;

    /* Counters, etc. */
    int bytesTotal, highWater;
    double energyS;
    int nsimps, nverts, marked;

    /* *************** CHECK INVOCATION ******************* */
    ionRadii[0] = 2.00;
    ionQ[0] = -1.00;
    ionConc[0] = 0.00;
    ionRadii[1] = 2.00;
    ionQ[1] = 1.00;
    ionConc[1] = 0.00;
    Vio_start();
    if (argc != 3) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected 3.\n",argc);
        Vnm_print(2,"*** Usage: noshell <mesh.m> <charge.pqr>\n\n");
        VASSERT(0);
    } else {
        mcsf_path = argv[1];
        pqr_path = argv[2];
    }

    /* *************** MC INITIALIZATION ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STARTING MC INITIALIZATION\n");
    Vnm_print(1,"main: Constructing PDE object.\n");
    myPde = myPDE_ctor();
    Vnm_print(1,"main: Constructing MCsh object.\n");
    vmc = MCsh_ctor(myPde,argc,argv);

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STARTING APBS INITIALIZATION\n");
    /* Get VGM and AM object */
    gm = vmc->gm;
    am = vmc->am;
    
    /* Build Valist and Vpbe -- these steps must occur before setting PBE
     * system parameters */
    Vnm_print(1,"main: Constructing VALIST object.\n");
    alist = Valist_ctor();
    Vnm_print(1,"main: Reading atom list from %s.\n",pqr_path);
    Valist_readPQR(alist, "FILE", "ASC", VNULL, pqr_path);
    Vnm_print(1,"main: Constructing VPBE object.\n");
    VASSERT(pbe != VNULL);

    /* Read mesh */
    Vnm_print(1,"main: Loading mesh from %s.\n",mcsf_path);
    sock = Vio_ctor("FILE", "ASC", VNULL, mcsf_path, "r");
    AM_getMesh(am, 0, sock);
    Vio_dtor(&sock);

    /* Set system parameters and build hash tables */
    Vnm_print(1,"main: Initializing VPBE parameters, hash tables, and charge-simplex map.\n");
    pbe = Vpbe_ctor(alist, nion, ionConc, ionRadii, ionQ, T, soluteDiel, solventDiel,
      solventRadius );
    Vnm_print(1,"main:        Temperature   %4.3f K\n",
      Vpbe_getTemperature(pbe));
    Vnm_print(1,"main:  Solute dielectric   %4.3f \n",
      Vpbe_getSoluteDiel(pbe));
    Vnm_print(1,"main:      Solute charge   %4.3f \n",
      Vpbe_getSoluteCharge(pbe));
    Vnm_print(1,"main: Solute eff. radius   %4.3f \n",
      Vpbe_getSoluteRadius(pbe));
    Vnm_print(1,"main:      Solute center   (%4.3f, %4.3f, %4.3f) \n",
      Vpbe_getSoluteCenter(pbe)[0], Vpbe_getSoluteCenter(pbe)[1],
      Vpbe_getSoluteCenter(pbe)[2]);
    Vnm_print(1,"main: Solvent dielectric   %4.3f \n",
      Vpbe_getSolventDiel(pbe));
    Vnm_print(1,"main:     Solvent radius   %4.3f A\n",
      Vpbe_getSolventRadius(pbe));
    Vnm_print(1,"main:             xkappa   %4.3f A^-1\n",
      Vpbe_getXkappa(pbe));

    Vnm_print(1,"main: Passing VFETK to PDE object.\n");
    fetk = Vfetk_ctor(pbe, gm, am);
    myPDE_init(myPde, fetk);

    /* *************** PRE-SOLVE TASKS ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STARTING PRE-SOLVER TASKS\n");
    Vnm_print(1,"main: Refining mesh to >%d vertices [",targetNum);
    nverts = Gem_numVV(gm);
    level = 0;
    myPDE_setRefineParam(myPde, 0, targetSize);
    while (nverts < targetNum) {
        AM_algInit(am, level);
        marked = AM_markRefine(am,level,1,-1,ekey,etol);
        if (marked == 0) {
          Vnm_print(1, "\nmain: User-defined estimator marked 0; marking all!\n");
          AM_markRefine(am,level,0,-1,ekey,etol);
        }
        Gem_refine(gm,0, 1);
        nverts = Gem_numVV(gm);
        Vnm_print(1,"%d ", nverts);
        level++;
    }
    Vnm_print(1,"]\n");

    /* *************** SOLVE-ESTIMATE-REFINE ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STARTING SOLVE-ESTIMATE-REFINE LOOP\n");
    /* Solve-estimate-refine */
    for (isolve=0; isolve<maxsolve; isolve++) {
        Vnm_print(1,"\nmain: Starting solve-estimate-refine #%d.\n",isolve);

        nsimps = Gem_numSS(gm);
        nverts = Gem_numVV(gm);
        /* Get the extra I/O */
        Vnm_print(1,"main: Have %d simplices and %d vertices\n", nsimps, nverts);
        Vnm_redirect(0);
        Gem_shapeChk(gm);
        Vnm_redirect(1);

        Vnm_print(1,"main: Initializing AM. \n");
        AM_algInit(am, level);

        Vnm_print(1,"main: Solving.\n");
        AM_lSolve(am, level, 0, lkey, lmax, ltol, gues, pjac);

        Vnm_print(1,"main: Finding solvation energy.\n");
        energyS = (Vunit_kb)*(298.15)*Vunit_Na*Vfetk_getLinearEnergy1(fetk, -1);
        Vnm_print(1,"main: Solvation energy = %e kJ/mol\n", energyS/1000.);

        sprintf(filename, "def-%d.off", level);
        sock = Vio_ctor("FILE", "ASC", "localhost", filename, "w");
        AM_writeGV(am, level, sock, 1, 1, -1, 1.0, -1, 0);
        Vio_dtor(&sock);

 
        if (nverts > maxverts) {
            Vnm_print(1,"main: Exceeded %d vertices, breaking...\n", maxverts);
            break;
        }

        Vnm_print(1,"main: Starting simplex refinement.\n");
        marked = AM_markRefine(am,level,akey,-1,ekey,etol);
        if (marked == 0) {
            Vnm_print(1, "main: Residual-based estimator marked 0.  Breaking!\n");
            break;
        }
        Vnm_print(1,"main: Marked %d/%d simps\n", marked, nsimps);
        Gem_refine(gm,0,1);

        bytesTotal = Vmem_bytesTotal();
        highWater    = Vmem_highWaterTotal();
        Vnm_print(1,"main: %g MB TOTAL\n",
          ((double)bytesTotal)/(1024.*1024.));
        Vnm_print(1,"main: %g MB HIGH WATER\n", 
          ((double)highWater)/(1024.*1024.));
      
        fflush(stdout);
        level++;
    }

    /* *************** POST-SOLVER TASKS ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STARTING POST-SOLVER TASKS\n");

    /* *************** GARBAGE COLLECTION ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STARTING GARBAGE COLLECTION\n");
    Vpbe_dtor(&pbe);
    Valist_dtor(&alist);
    MCsh_dtor(&vmc);
    myPDE_dtor(&myPde);
    bytesTotal = Vmem_bytesTotal();
    highWater    = Vmem_highWaterTotal();
    Vnm_print(1,"main: %d bytes TOTAL\n",  bytesTotal );
    Vnm_print(1,"main: %d bytes HIGH WATER\n",  highWater);

    /* *************** THE END ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STOPPING EXECUTION\n");
    return 0;
}

