/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
///
/// rcsid="$Id: pnoshell.c,v 1.25 2001/10/04 22:34:47 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     noshell.c
//
// Purpose:  APBS ``front end" without the shell for multigrid calculations
//
// Notes:    This driver program represents a mish-mash of instructions for
//           calculating electrostatic potentials, as well as free energies of 
//           binding and solvation.  It is invoked as:
//
//               noshell flag refMol.pqr [mol1.pqr mol2.pqr ...]
//
//           where flag tells the program what type of calculation to perform
//           (0 = solvation free energy, 1 = binding free energy), refMol.pqr 
//           is the PQR format molecule data for reference molecule (the
//           complex or the molecule whose solvation free energy you'd like to
//           calculate), and mol#.pqr are either the constituents of the
//           complex or, for solvation free energies, the same molecule as
//           refMol.pqr.
//
//           The total number of processors, np is distributed among the x, y,
//           and z directions according to user specification (set np{x,y,z}).
//           In other words, you should choose np such that npx*npy*npz = np
//           and no processors are wasted during computation.
//
// Author:   Nathan Baker
//
// rcsid="$Id: pnoshell.c,v 1.25 2001/10/04 22:34:47 apbs Exp $"
/////////////////////////////////////////////////////////////////////////// */

#include "apbscfg.h"
#include "apbs/apbs.h"  

/* Do we want to do some focusing before starting the parallel run? 
 * 1 => yes, 0 => no */
#define GFOCUS 0

VEMBED(rcsid="$Id: pnoshell.c,v 1.25 2001/10/04 22:34:47 apbs Exp $")

/* NOTE: We're going to invoke this in two different ways depending on whether
 * or not we've enabled MPI support */
#ifdef HAVE_MPI_H
int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    /* MPI parameters */
    Vcom *com;
    int nproc, rank, iounit, npx, npy, npz, np, ip, jp, kp, focus;
    double ofrac, xlenPart, ylenPart, zlenPart, xlenOlap, ylenOlap, zlenOlap;
    double xcentPart, ycentPart, zcentPart, xcentOlap, ycentOlap, zcentOlap;
    double xcentFOCUS, ycentFOCUS, zcentFOCUS, xlenFOCUS, ylenFOCUS, zlenFOCUS;
   

    /* Objects for each molecule */
    Vpbe *pbe[MAXMOL];
    Valist *alist[MAXMOL];
    int nmol, imol;
    double lEnergyMOL[MAXMOL], gEnergyMOL[MAXMOL], cEnergyMOL[MAXMOL];
    double sasa[MAXMOL];

    /* Objects for solver */
    Vpmg *pmg[2];
    Vpmgp *pmgp[2];

    /* Parameters for solver:  the indices of these arrays correspond to 
     *   0 => coarse global solve parameters
     *   1 => fine parallel solve parameters */
    int nx[2], ny[2], nz[2];
    int nlev[2], nonlin[2], bcfl, epsmeth;
    double hx[2], hy[2], hzed[2], epsparm;
    double xcent[2], ycent[2], zcent[2];

    /* PBE parameters */
    int ionNum; 
    double ionConc, ionRadii, ionQ;
    double T, soluteDiel, solventDiel, solventRadius;

    /* Parameters for I/O */
    int energyFlag;
    char *pqr_path[MAXMOL];
    char *sepline = "--------------------------------------------------------";

    /* Instructions: */
    char *usage = "\
    This driver program represents a mish-mash of instructions for\n\
    calculating electrostatic potentials, as well as free energies of\n\
    binding and solvation USING MULTIGRID.  It is invoked as:\n\n\
      noshell flag refMol.pqr [mol1.pqr mol2.pqr ...]\n\n\
    where flag tells the program what type of calculation to perform\n\
    (0 = no energies, 1 = solvation free energy, 2 = binding free energy),\n\
    mesh.m is the initial finite element mesh in MCSF format, refMol.pqr\n\
    is the PQR format molecule data for reference molecule (the complex or\n\
    the molecule whose solvation free energy you'd like to calculate),\n\
    and mol#.pqr are either the constituents of the complex or, for\n\
    solvation free energies, the same molecule as refMol.pqr.\n\n";

    /* ********************* COMMUNICATION INITIALIZATION ***************** */
    Vcom_init(&argc, &argv);

    /* ********************* START PARMETER SETTINGS ********************** */
    /* THE FOLLOWING PARAMETERS ONLY NEED TO BE SET ONCE */
    T = 298.15;                 /* temperature in K                        */
    soluteDiel = 2.00;          /* solute dielectric constant              */
    solventDiel = 78.54;        /* solvent diel. constant (78.54 = water)  */
    solventRadius = 1.40;       /* solvent sphere radius                   */
    ionNum = 2;              
    ionConc[0] = 0.050;         /* ion concentration in M                  */
    ionRadii[0] = 2.0;          /* ion radius in A                         */
    ionQ[0] = -1.0;             /* ion charge in e                         */
    ionConc[1] = 0.050;         /* ion concentration in M                  */
    ionRadii[1] = 2.0;          /* ion radius in A                         */
    ionQ[1] =  1.0;             /* ion charge in e                         */
    bcfl = 1;                   /* Boundary condition method :
                                 *  0 => zero BC
                                 *  1 => single DH sphere 
                                 *  2 => multiple DH spheres
                                 *  4 => focusing                          */
    epsmeth = 1;                /* Dielectric smoothing method: 
                                 *  0 => none
                                 *  1 => 3-pt harmonic avg
                                 *  2 => cubic spline (set epsparm)        */
    epsparm = 1.4;

    /* PARAMETERS FOR THE COARSE GLOBAL PROBLEM:  WHERE EACH PROCESSOR SOLVES
     * THE PBE ON THE ENTIRE MESH                                           */
    nx[0] =  97;                 /* number of mesh points for coarse global */
    ny[0] =  97;                 /* problem.  Note that each of these       */
    nz[0] =  97;                 /* values should be                        */
                                 /*      c1 2^(L+c2) + 1                    */
                                 /* where c1 > 0 and c2 >= 1 are integers.  */
    nlev[0] = 4;                 /* Number of levels                        */
    nonlin[0] = 0;               /* Linear (0) or nonlinear (1) PBE         */
    nonlin[1] = 0;
    hx[0] = 5.89;                /* mesh spacing in x direction             */
    hy[0] = 5.98;                /* mesh spacing in y direction             */
    hzed[0] = 11.03;             /* mesh spacing in z direction             */
    xcent[0] = 316.2;            /* center x-coordinate                     */
    ycent[0] = 282.7;            /* center y-coordinate                     */
    zcent[0] = 379.4;            /* center z-coordinate                     */

    /* PARAMETERS FOR THE FINE LOCAL PROBLEM:  WHERE EACH PROCESSOR SOLVES
     * THE PBE ITS PARTICULAR PIECE OF THE MESH                            */
    ofrac = 0.1;                 /* overlap fraction:  the fraction of the
                                  * partition is redundant between processes */
    nx[1] =   97;                /* number of mesh points for coarse global */
    ny[1] =   97;                /* problem.  Note that each of these       */
    nz[1] =   97;                /* values should be                        */
                                 /*      c1 2^(L+c2) + 1                    */
                                 /* where c1 > 0 and c2 >= 1 are integers.  */
    nlev[1] = 4;                 /* Number of levels                        */
    nonlin[1] = 0;               /* Linear (0) or nonlinear (1) PBE         */
    npx = 6;                     /* Specify the desired distribution of     *
                                  * processors over the problem domain      */
    npy = 6;
    npz = 10;
    focus = 1;                   /* The finer parallel run can be done on   *
                                  * a subset of the global domain.  If this *
                                  * behavior is desired, set this variable  *
                                  * to 1 and set the other *FOCUS variables */
    xlenFOCUS = 322;
    ylenFOCUS = 327;
    zlenFOCUS = 595;
    xcentFOCUS = 316.2;
    ycentFOCUS = 282.7;
    zcentFOCUS = 379.4;

    /* ********************* END PARMETER SETTINGS ********************** */

    /* *************** CHECK INVOCATION ******************* */
    com = Vcom_ctor(&argc, &argv, 1);  
    Vio_start();
    nproc = Vcom_size(com);
    rank = Vcom_rank(com);
    if (rank == 0) iounit = 1;
    else iounit = 0;

    if (argc < 3) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected >=3.\n\n",argc);
        Vnm_print(2,"%s\n", usage);
        return -1;
    } else if (argc > 3 + MAXMOL) {
        Vnm_print(2,"\n*** Maximum of %d molecules allowed!\n\n", MAXMOL);
        return -1;
    } else {
        sscanf(argv[1], "%d", &energyFlag);
        if (energyFlag == 0) {
            Vnm_print(iounit,"\nCalculating electrostatic potential only.\n");
        } else if (energyFlag == 1) {
            Vnm_print(iounit,"\nCalculating solvation free energy.\n");
        } else if (energyFlag == 2) {
            Vnm_print(iounit,"\nCalculating binding free energy.\n");
        } else {
            Vnm_print(2,"\n*** Syntax error: invalid flag = %d.\n\n", energyFlag);
            Vnm_print(2,"%s\n", usage);
            return -1;
        }
        nmol = 0;
        for (imol=0; imol<argc-2; imol++) {
            if (argv[2+imol][0] == '-') break;
            pqr_path[imol] = argv[2+imol];
            nmol++;
        }
        if (energyFlag == 1) {
            if (nmol > 1) Vnm_print(2,"\n*** Warning: only first of %d molecules used in solvation free energy calculations.\n\n", nmol);
            nmol = 2;
        }
    }

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(iounit,"\nmain: %s\n", sepline);
    Vnm_print(iounit,"main: APBS INITIALIZATION\n");
    Vnm_print(iounit,"main: Constructing %d VALIST objects.\n", nmol);
    for (imol=0; imol<MAXMOL; imol++) {
        alist[imol] = VNULL;
        pbe[imol] = VNULL;
    }
    if (energyFlag == 1) {
        alist[0] = Valist_ctor();
        Vnm_print(iounit, "main:    Reading molecule data from %s\n",
          pqr_path[0]);
        alist[1] = alist[0];
        if (Valist_readPQR(alist[0], "FILE", "ASC", VNULL, pqr_path[0]) != 1) {
            Vnm_print(2, "main:  Fatal error reading PQR!\n");
            return 666;
        }
        Vnm_print(iounit, "main:    Mol %d has %d atoms\n", imol, 
           Valist_getNumberAtoms(alist[0]));
    } else {
        for (imol=0; imol<nmol; imol++) {
            alist[imol] = Valist_ctor();
            Vnm_print(iounit, "main:    Reading molecule data from %s\n",
              pqr_path[imol]);
            if (Valist_readPQR(alist[imol], "FILE", "ASC", VNULL,
              pqr_path[imol]) != 1) {
                Vnm_print(2, "main:  Fatal error reading PQR!\n");
                return 666;
            }
            Vnm_print(iounit, "main:    Mol %d has %d atoms\n", imol, 
               Valist_getNumberAtoms(alist[imol]));
        }
    }
    Vnm_print(iounit,"main: Constructing %d VPBE objects.\n", nmol);

    /* Set PBE parameters and build hash tables */
    for (i=0; i<ionNum; i++) {
        Vnm_print(iounit,"main:       Ion #%d conc    %4.3f M\n", 
          i, ionConc[i]);
        Vnm_print(iounit,"main:       Ion #%d radius  %4.3f A\n", 
          i, ionRadii[i]);
        Vnm_print(iounit,"main:       Ion #%d charge  %4.3f e\n",
          i, ionQ[i]);
    }
    Vnm_print(iounit,"main:        Temperature   %4.3f K\n", T);
    Vnm_print(iounit,"main:  Solute dielectric   %4.3f \n", soluteDiel);
    Vnm_print(iounit,"main: Solvent dielectric   %4.3f \n", solventDiel);
    Vnm_print(iounit,"main:     Solvent radius   %4.3f A\n", solventRadius);

    /* *************** COMPUTE THE PARTITIONING PARAMETERS **************** */
    Vnm_print(iounit, "main: Calculating partitioning information for %d processors\n", nproc);
    /* Calculate the number of processors in each direction */
    np = npx*npy*npz;
    if (np > nproc) {
        Vnm_print(iounit, "main:  Error! Compiled for %d processors, invoked with only %d\n", np, nproc);
        VASSERT(0);
    }
    if (np < nproc) {
        Vnm_print(iounit, "main:  Warning! Only using %d of %d processors.\n",
          np, nproc);
        Vcom_resize(com, np);
        nproc = np;
        rank = Vcom_rank(com);
        if (rank == 0) iounit = 1;
        else iounit = 0;
    } 
    Vnm_print(iounit, "main:  Processors distributed in %d x %d x %d grid.\n",
      npx, npy, npz);

    /* The test of the code is only executed for processes which have not been
     * eliminated */ 
    if (rank != -1) { 
        /* Calculate the process' coordinates in the grid */
        kp = (int)floor(rank/(npx*npy));
        jp = (int)floor((rank-kp*npx*npy)/npx);
        ip = rank - kp*npx*npy - jp*npx;
        Vnm_print(1, "main:  Hello world from PE (%d, %d, %d)\n", ip, jp, kp);

	/* Calculate the region on which each processor will calculate energies
	 * (this is not the same as the actual problem domain since we'll leave
	 * a little overlap) */
        if (focus) {
            xlenPart = xlenFOCUS/((double)npx);
            ylenPart = ylenFOCUS/((double)npy);
            zlenPart = zlenFOCUS/((double)npz);
            xcentPart = (ip+0.5)*xlenPart - 0.5*xlenFOCUS + xcentFOCUS;
            ycentPart = (jp+0.5)*ylenPart - 0.5*ylenFOCUS + ycentFOCUS;
            zcentPart = (kp+0.5)*zlenPart - 0.5*zlenFOCUS + zcentFOCUS;
        } else {
            xlenPart = hx[0]*(nx[0]-1)/((double)npx);
            ylenPart = hy[0]*(ny[0]-1)/((double)npy);
            zlenPart = hzed[0]*(nz[0]-1)/((double)npz);
            xcentPart = (ip+0.5)*xlenPart - 0.5*hx[0]*(nx[0]-1) + xcent[0];
            ycentPart = (jp+0.5)*ylenPart - 0.5*hy[0]*(ny[0]-1) + ycent[0];
            zcentPart = (kp+0.5)*zlenPart - 0.5*hzed[0]*(nz[0]-1) + zcent[0];
        }

        Vnm_print(1, "main (PE %d): part cent = (%g, %g, %g)\n", 
          rank, xcentPart, ycentPart, zcentPart);

        /* Include the overlap and calculate the actual problem domain */
        xlenOlap = xlenPart;
        ylenOlap = ylenPart;
        zlenOlap = zlenPart;
        xcentOlap = xcentPart;
        ycentOlap = ycentPart;
        zcentOlap = zcentPart;
        if (ip != 0) { 
            xlenOlap += (ofrac*xlenPart);
            xcentOlap -= (0.5*ofrac*xlenPart);
        } 
        if (ip != (npx-1)) { 
            xlenOlap += (ofrac*xlenPart);
            xcentOlap += (0.5*ofrac*xlenPart);
        } 
        if (jp != 0) { 
            ylenOlap += (ofrac*ylenPart);
            ycentOlap -= (0.5*ofrac*ylenPart);
        } 
        if (jp != (npy-1)) { 
            ylenOlap += (ofrac*ylenPart);
            ycentOlap += (0.5*ofrac*ylenPart);
        } 
        if (kp != 0) { 
            zlenOlap += (ofrac*zlenPart);
            zcentOlap -= (0.5*ofrac*zlenPart);
        } 
        if (kp != (npz-1)) { 
            zlenOlap += (ofrac*zlenPart);
            zcentOlap += (0.5*ofrac*zlenPart);
        } 

        /* Set the problem dimensions for the parallel step */
        Vnm_print(1, "main (PE %d): Overlap dims = (%g, %g, %g)\n", 
          rank, xlenOlap, ylenOlap, zlenOlap);
        hx[1] = xlenOlap/((double)(nx[1]-1));
        hy[1] = ylenOlap/((double)(ny[1]-1));
        hzed[1] = zlenOlap/((double)(nz[1]-1));

        /* *************** PER-MOLECUE SOLUTION ******************* */
        for (imol=0; imol<nmol; imol++) {

            Vnm_print(iounit,"\nmain: %s\n", sepline);
            Vnm_print(iounit,"main: MOLECULE #%d\n", imol);
            Vnm_print(iounit,"main:    Constructing PBE and ACC objects for solute %d\n", imol);

            if ((imol == 1) && (energyFlag == 1)) {
                pbe[imol] = Vpbe_ctor(alist[imol], 0, ionConc, ionRadii, ionQ,
                  T, soluteDiel, soluteDiel, solventRadius);
            } else {
                pbe[imol] = Vpbe_ctor(alist[imol], ionNum, ionConc, ionRadii, 
                  ionQ, T, soluteDiel, solventDiel, solventRadius);
            }
            Vnm_print(iounit,"main:    Solute %d charge   %4.3f \n", imol,
              Vpbe_getSoluteCharge(pbe[imol]));
            Vnm_print(iounit,"main:     Charge scaling   %4.3f A^{-2}\n", 
              Vpbe_getZmagic(pbe[imol]));
            Vnm_print(iounit,"main: Mod. sq. DH coeff.   %4.3f A^{-2}\n", 
              Vpbe_getZkappa2(pbe[0]));
            Vnm_print(iounit,"main:    Solute %d center   (%4.3f, %4.3f, %4.3f) \n", imol,
              Vpbe_getSoluteCenter(pbe[imol])[0], 
              Vpbe_getSoluteCenter(pbe[imol])[1],
              Vpbe_getSoluteCenter(pbe[imol])[2]);
            Vnm_print(iounit,"main:    Solute %d radius   %4.3f \n", imol,
              Vpbe_getSoluteRadius(pbe[imol]));
            Vnm_print(iounit,"main:      Solute %d dims   (%4.3f, %4.3f, %4.3f) \n", 
	      imol, Vpbe_getSoluteXlen(pbe[imol]),
              Vpbe_getSoluteYlen(pbe[imol]), Vpbe_getSoluteZlen(pbe[imol]));
            fflush(stdout);

            Vnm_print(1, "main (PE %d):  Have %g MB total\n", rank, 
              ((double)Vmem_bytesTotal())/1024./1024.);

            /* The coarse global solve: */
            Vnm_print(iounit, "main:   COARSE GLOBAL SOLVE (MOL #%d)\n", imol);
            /* Set up solver parameters */
            Vnm_print(iounit, "main:     Setting up solver parameters...\n");
            Vnm_print(iounit, "main:         hx, hy, hz = (%g, %g, %g)\n", 
              hx[0], hy[0], hzed[0]);
            Vnm_print(iounit, "main:         nx, ny, nz = (%d, %d, %d)\n", 
              nx[0], ny[0], nz[0]);
            Vnm_print(iounit, "main:             center = (%g, %g, %g)\n", 
              xcent[0], ycent[0], zcent[0]);
            Vnm_print(iounit, "main:             nonlin = %d\n", nonlin[0]);
            Vnm_print(iounit, "main:               bcfl = %d\n", bcfl);
	    pmgp[0] = Vpmgp_ctor(nx[0], ny[0], nz[0], nlev[0], hx[0], hy[0],
              hzed[0], nonlin[0]);
            pmgp[0]->xcent = xcent[0];
            pmgp[0]->ycent = ycent[0];
            pmgp[0]->zcent = zcent[0];
            pmgp[0]->bcfl = bcfl;
            Vnm_print(iounit,"main:     Defining PDE...\n");
            pmg[0] = Vpmg_ctor(pmgp[0], pbe[imol]);
            Vpmg_fillco(pmg[0], epsmeth, epsparm);
            Vnm_print(iounit,"main:     Solving PDE...\n");
            Vpmg_solve(pmg[0]);
            if (energyFlag > 0) {
                Vnm_print(iounit,"main:     Evaluating energy...\n");
                cEnergyMOL[imol] = Vunit_kb*T*Vunit_Na 
                  * Vpmg_energy(pmg[0],0);
                Vnm_print(iounit, "main:     Global coarse solve energy of mol %d = %e kJ/mol\n", 
                  imol, cEnergyMOL[imol]/1000.0);
            }

/* If we want to focus the global results before parallel runs */
#if GFOCUS

            /* The focused global solve: */
            Vnm_print(iounit, "main:   FOCUSED GLOBAL SOLVE (MOL #%d)\n", imol);
            /* Set up solver parameters */
            Vnm_print(iounit, "main:     Setting up solver parameters...\n");
            Vnm_print(iounit, "main:         hx, hy, hz = (%g, %g, %g)\n",
              xlenFOCUS/(nx[0]-1), ylenFOCUS/(ny[0]-1), zlenFOCUS/(nz[0]-1));
            Vnm_print(iounit, "main:         nx, ny, nz = (%d, %d, %d)\n",
              nx[0], ny[0], nz[0]);
            Vnm_print(iounit, "main:             center = (%g, %g, %g)\n",
              xcent[0], ycent[0], zcent[0]);
            Vnm_print(iounit, "main:             nonlin = %d\n", nonlin[0]);
            pmgp[1] = Vpmgp_ctor(nx[0], ny[0], nz[0], nlev[0], 
              xlenFOCUS/(nx[0]-1), ylenFOCUS/(ny[0]-1), zlenFOCUS/(nz[0]-1),
              nonlin[0]);
            pmgp[1]->xcent = xcent[0];
            pmgp[1]->ycent = ycent[0];
            pmgp[1]->zcent = zcent[0];
            pmgp[1]->bcfl = 4;
            Vnm_print(iounit,"main:     Defining PDE...\n");
            pmg[1] = Vpmg_ctorFocus(pmgp[1], pbe[imol], pmg[0]);
            Vpmgp_dtor(&(pmgp[0]));
            Vpmg_fillco(pmg[1], epsmeth, epsparm);
            Vnm_print(iounit,"main:     Solving PDE...\n");
            Vpmg_solve(pmg[1]);
            if (energyFlag > 0) {
                Vnm_print(iounit,"main:     Evaluating energy...\n");
                cEnergyMOL[imol] = Vunit_kb*T*Vunit_Na
                  * Vpmg_energy(pmg[1], 1);
                Vnm_print(0,"main:     Global focused solve energy of mol %d = %e kJ/mol\n",
                  imol, cEnergyMOL[imol]/1000.0);
            }

            /* Pointer swapping */
            pmg[0] = pmg[1];
            pmgp[0] = pmgp[1];


#endif /* if GFOCUS */

            /* The fine parallel solve: */
            Vnm_print(iounit, "main:   PARALLEL SOLVE (MOL #%d)\n", imol);
            /* Set up solver parameters */
            Vnm_print(iounit, "main:     Setting up solver parameters...\n");
            Vnm_print(iounit, "main:         hx, hy, hz = (%g, %g, %g)\n", 
              hx[1], hy[1], hzed[1]);
            Vnm_print(iounit, "main:         nx, ny, nz = (%d, %d, %d)\n", 
              nx[1], ny[1], nz[1]);
            Vnm_print(iounit, "main:             center = (%g, %g, %g)\n", 
              xcentOlap, ycentOlap, zcentOlap);
            Vnm_print(iounit, "main:             nonlin = %d\n", nonlin[1]);
	    pmgp[1] = Vpmgp_ctor(nx[1], ny[1], nz[1], nlev[1], hx[1], hy[1],
              hzed[1], nonlin[1]);
            pmgp[1]->xcent = xcentOlap;
            pmgp[1]->ycent = ycentOlap;
            pmgp[1]->zcent = zcentOlap;
            pmgp[1]->bcfl = 4;
            Vnm_print(iounit,"main:     Defining PDE...\n");
            pmg[1] = Vpmg_ctorFocus(pmgp[1], pbe[imol], pmg[0]);
            Vpmgp_dtor(&(pmgp[0]));
            Vpmg_fillco(pmg[1], epsmeth, epsparm);
            Vnm_print(iounit,"main:     Solving PDE...\n");
            Vpmg_solve(pmg[1]);
            if (energyFlag > 0) {
                Vnm_print(iounit,"main:     Evaluating energy...\n");
                Vpmg_setPart(pmg[1],
                  (xcentPart-0.5*xlenPart), (ycentPart-0.5*ylenPart), 
                  (zcentPart-0.5*zlenPart), (xcentPart+0.5*xlenPart), 
                  (ycentPart+0.5*ylenPart), (zcentPart+0.5*zlenPart));
                lEnergyMOL[imol] = Vunit_kb*T*Vunit_Na 
                  * Vpmg_energy(pmg[1],0);
                Vnm_print(0,"main:     Local solve energy of mol %d = %e kJ/mol\n", 
                  imol, lEnergyMOL[imol]/1000.0);
            }
            Vnm_print(iounit,"main:     Evaluating surface area...\n");
            sasa[imol] = Vacc_totalSASA(Vpbe_getVacc(pbe[imol]), solventRadius);
            Vnm_print(iounit, "main:     Solvent-accessible surf. area = %e\n", 
              sasa[imol]);

            Vnm_print(iounit, "main:     Destroying PMG, PMGP, and PBE objects\n");
            Vpmg_dtor(&(pmg[1]));
            Vpmgp_dtor(&(pmgp[1]));
            Vpbe_dtor(&(pbe[imol]));
        }

        /* *************** LAST STUFF ******************* */
        Vnm_print(iounit,"\nmain: %s\n", sepline);
        Vnm_print(iounit,"main: POST-SOLVER STUFF\n");
        if (energyFlag == 1) {
            Vnm_print(iounit, "main: Coarse solve solvation energy = %e kJ/mol\n", 
              (cEnergyMOL[0] - cEnergyMOL[1])/1000.);
            /* Do a reduction to get the parallel solve energies */
            Vcom_reduce(com, lEnergyMOL, gEnergyMOL, nmol, 2, 0);
            Vnm_print(iounit, "main: Parallel solve solvation energy = %e kJ/mol\n", 
              (gEnergyMOL[0] - gEnergyMOL[1])/1000.);
        }
        if (energyFlag == 2) {
            for (imol=1; imol<nmol; imol++) {
                cEnergyMOL[0] -= cEnergyMOL[imol];
                sasa[0] -= sasa[imol];
            }
            Vnm_print(iounit, "main: Coarse solve binding energy = %e kJ/mol\n",
              cEnergyMOL[0]/1000.0);
            Vcom_reduce(com, lEnergyMOL, gEnergyMOL, nmol, 2, 0);
            for (imol=1; imol<nmol; imol++) gEnergyMOL[0] -= gEnergyMOL[imol];
            Vnm_print(iounit, "main: Parallel solve binding energy = %e kJ/mol\n", 
              gEnergyMOL[0]/1000.);
            Vnm_print(iounit, "main: Change in surface area upon binding = %e A^2\n", 
              sasa[0]);
        }

    } /* if (rank != -1) */

    /* *************** THE END ******************* */
    Vnm_print(iounit,"\nmain: %s\n", sepline);
    Vnm_print(iounit,"main: STOPPING EXECUTION\n");

    /* ********************* COMMUNICATION FINALIZATION ***************** */
    Vcom_finalize();

    return 0;
}

#else /* ifdef HAVE_MPI_H */
int main(int argc, char **argv) {
    fprintf(stderr, "\n\n\nDANGER WILL ROBINSON!\n\n");
    fprintf(stderr, "This code was not compiled with mpi support (./configure --enable-mpi),\n");
    fprintf(stderr, "however, you are trying to run the parallel executable.  Hmmm. Why don't you\n");
    fprintf(stderr, "recompile, get more coffee, and try it again.  Bailing...\n\n\n");

    return -1;
}
#endif
