/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
//////////////////////////////////////////////////////////////////////////// 
/// rcsid="$Id: mgautoparm.c,v 1.2 2001/10/24 23:31:49 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     mgautoparm.c
//
// Purpose:  Class MGAUTOparm: methods. 
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */

#include "apbscfg.h"
#include "apbs/apbs.h"
#include "apbs/mgparm.h"
#include "apbs/nosh.h"
#include "mgautoparm.h"

/* ///////////////////////////////////////////////////////////////////////////
// Class MGAUTOparm: Inlineable methods
/////////////////////////////////////////////////////////////////////////// */
#if !defined(VINLINE_MGAUTOPARM)

#endif /* if !defined(VINLINE_MGAUTOPARM) */

/* ///////////////////////////////////////////////////////////////////////////
// Class MGAUTOparm: Non-inlineable methods
/////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGAUTOparm_ctor
//
// Args:  Coarse and fine multigrid parameter objects
//
// Author: Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC MGAUTOparm* MGAUTOparm_ctor(MGparm *tcparm, MGparm *tfparm) {

    /* Set up the structure */
    MGAUTOparm *thee = VNULL;
    thee = Vmem_malloc(VNULL, 1, sizeof(MGAUTOparm));
    VASSERT( thee != VNULL);
    VASSERT( MGAUTOparm_ctor2(thee, tcparm, tfparm) );

    return thee;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGAUTOparm_ctor2
//
// Returns:  1 if sucessful, 0 otherwise
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int MGAUTOparm_ctor2(MGAUTOparm *thee, MGparm *tcparm, MGparm *tfparm) {

    if (thee == VNULL) return 0;

    thee->fparm = tfparm;
    thee->cparm = tcparm;

    return 1; 
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGAUTOparm_dtor
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void MGAUTOparm_dtor(MGAUTOparm **thee) {
    if ((*thee) != VNULL) {
        MGAUTOparm_dtor2(*thee);
        Vmem_free(VNULL, 1, sizeof(MGAUTOparm), (void **)thee);
        (*thee) = VNULL;
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGAUTOparm_dtor2
//
// Purpose:  Destroy the atom object
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void MGAUTOparm_dtor2(MGAUTOparm *thee) { ; }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGAUTOparm_check
//
// Purpose:  Check the parameter settings for internal consistency
//
// Returns:  1 if OK, 0 otherwise
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int MGAUTOparm_check(MGAUTOparm *thee) { 

    /* Check to see that everything was set */
    if (!MGparm_check(thee->fparm)) return 0;
    if (!MGparm_check(thee->cparm)) return 0;

    return 1;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MGAUTOparm_build
//
// Purpose:  Build up the appropriate number of MGparm objects
//
// Returns:  1 if OK, 0 otherwise
//
// Args:     nparm    Number of MGparm objects constructed
//           parm     Array of pointers to MGparm objects.  Allocated inside
//                    this routine, should be freed by user!!!
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int MGAUTOparm_build(MGAUTOparm *thee, int *nparm, 
  MGparm *parm[NOSH_MAXCALC]) { 

    MGparm *cparm, *fparm, *tparm;
    int i, j, ti, tdime[3], tnlev[3], nlev, tnfocus[3], nfocus;
    double td, redfrac, redrat[3];


    redfrac = 0.25;                  /* The fraction by which the domain is
				      * reduced at each round of focusing */

    /* Check internal state */
    if(!MGAUTOparm_check(thee)) {
        Vnm_print(2, "MGAUTOparm_build:  failed internal check!\n");
        return 0;
    }

    cparm = thee->cparm;
    fparm = thee->fparm;

    /* Calculate the actual number of grid points and nlev to satisfy the
     * formula:  n = c * 2^(l+1) + 1, where n is the number of grid points, c
     * is an integer, and l is the number of levels */
    for (i=0; i<3; i++) {
        tdime[i] = cparm->dime[i];
        ti = tdime[i] - 1;
        tnlev[i] = 0;
        /* Find the maximum number of times this dimension can be divided by
         * two */
        while (1) {
            if (VODD(ti)) break;
            (tnlev[i])++;
            ti = (int)ceil(0.5*ti);
        } 
        (tnlev[i])--;
        /* We'd like to have at least 4 levels in the multigrid hierarchy.
         * This means that the dimension needs to be c*32 + 1, where c is an
         * integer. */
        if (tnlev[i] < 4) { 
            Vnm_print(2, "NOsh:  Bad dime[%d]  = %d (%d nlev)!\n", 
              i, tdime[i], tnlev[i]);
            ti = (int)(tdime[i]/32.0);
            if (ti < 1) ti = 1;
            tdime[i] = ti*32 + 1;
            tnlev[i] = 4;
            Vnm_print(2, "NOsh:  Reset dime[%d] to %d.\n", i, tdime[i]);
        } 
    }
    /* The actual number of levels we'll be using is the smallest number of 
     * possible levels in any dimensions */
    nlev = VMIN2(tnlev[0], tnlev[1]);
    nlev = VMIN2(nlev, tnlev[2]);
    /* Set the number of levels and dimensions */
    Vnm_print(0, "NOsh:  nlev = %d, dime = (%d, %d, %d)\n", nlev, tdime[0],
      tdime[1], tdime[2]);
    cparm->nlev = nlev;
    fparm->nlev = nlev;
    for (i=0; i<3; i++) {
        cparm->dime[i] = tdime[i];
        fparm->dime[i] = tdime[i];
    }

    /* Calculate the grid spacing on the coarse and fine levels */
    for (i=0; i<3; i++) {
        cparm->grid[i] = cparm->glen[i]/((double)(cparm->dime[i]-1));
        fparm->grid[i] = fparm->glen[i]/((double)(fparm->dime[i]-1));
    }
    Vnm_print(0, "NOsh:  Coarse grid spacing = %g, %g, %g\n",
      cparm->grid[0], cparm->grid[1], cparm->grid[2]);
    Vnm_print(0, "NOsh:  Fine grid spacing = %g, %g, %g\n",
      fparm->grid[0], fparm->grid[1], fparm->grid[2]);

    /* Now calculate the number of focusing levels, never reducing the grid
     * spacing by more than redfrac at each level */
    for (i=0; i<3; i++) {
        if (fparm->grid[i]/cparm->grid[i] < redfrac) {
            td = log(fparm->grid[i]/cparm->grid[i])/log(redfrac);
            tnfocus[i] = (int)ceil(td) + 1;
        } else tnfocus[i] = 2;
    }
    nfocus = VMAX2(tnfocus[0], tnfocus[1]);
    nfocus = VMAX2(nfocus, tnfocus[2]);

    /* Now set redrat to the actual value by which the grid spacing is
     * reduced at each level of focusing */
    for (i=0; i<3; i++) {
        redrat[i] = VPOW((fparm->grid[i]/cparm->grid[i]), 
           1.0/((double)nfocus-1.0));
    }
    Vnm_print(0, "NOsh:  %d levels of focusing with %g, %g, %g reductions\n", 
      nfocus, redrat[0], redrat[1], redrat[2]);

    /* Now that we know how many focusing levels to use, we're ready to set up
     * the parameter objects */
    if (nfocus > NOSH_MAXCALC) {
        Vnm_print(2, "NOsh:  This calculation requires too many levels of \
focusing!\n");
        return 0;
    }
    *nparm = nfocus;
    for (i=0; i<nfocus; i++) parm[i] = MGparm_ctor();

    /* Set up the parameter objects */
    for (i=0; i<nfocus; i++) {
        tparm = parm[i];
        /* Most of the parameters are derived from the coarsest level */
        MGparm_copy(tparm, cparm);
        /* Finer levels inherit their grid spacing from coarser levels */
        if (i != 0) {
            for (j=0; j<3; j++) {
                tparm->grid[j] = redrat[j]*(parm[i-1]->grid[j]);
                tparm->glen[j] = redrat[j]*(parm[i-1]->glen[j]);
            }
        } 
        /* Finer levels inherit centering method from the finest level */
        if (i != 0) {
            tparm->cmeth = fparm->cmeth;
            for (j=0; j<3; j++) tparm->center[j] = fparm->center[j];
            tparm->centmol = fparm->centmol;
        } 
        /* Finer levels inherit their nonlinearity from the finest level */
        if (i != 0) tparm->nonlin = fparm->nonlin;
        /* Finer levels have focusing boundary conditions */
        if (i != 0) tparm->bcfl = 4;
        /* Only the finest level handles I/O */
        if (i != (nfocus-1)) {
            tparm->writepot = 0;
            tparm->setwritepot = 1;
            tparm->writepotfmt = 0;
            tparm->writeacc = 0;
            tparm->setwriteacc = 1;
            tparm->writeaccfmt = 0;
        }
        tparm->parsed = 1;

    }

    return 1;
}
