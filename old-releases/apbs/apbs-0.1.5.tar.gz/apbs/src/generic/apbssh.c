/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
//////////////////////////////////////////////////////////////////////////// */
/// rcsid="$Id: apbssh.c,v 1.1 2001/05/16 17:14:01 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     apbssh.c
//
// Purpose:  Class APBSsh: methods.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */

#include "apbscfg.h"

VEMBED(rcsid="$Id: apbssh.c,v 1.1 2001/05/16 17:14:01 apbs Exp $")

/* builtin APBSsh commands */
typedef enum APBSsh_command {
    apbsc_none,
    apbsc_help
} APBSsh_command;

/* ///////////////////////////////////////////////////////////////////////////
// Class APBSsh: Inlineable methods
/////////////////////////////////////////////////////////////////////////// */
#if !defined(VINLINE_APBSSH)

#endif /* if !defined(VINLINE_APBSSH) */
/* ///////////////////////////////////////////////////////////////////////////
// Class MCsh: Non-inlineable methods
/////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  APBSsh_ctor
//
// Purpose:  The MCsh constructor.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC APBSsh* APBSsh_ctor(int argc, char **argv) {

    APBSsh *thee = VNULL;

    VDEBUGIO("APBSsh_ctor: CREATING object..");

    thee = Vmem_malloc( VNULL, 1, sizeof(APBSsh) );
    thee->vmem = Vmem_ctor( "APBSsh" );

    VDEBUGIO("..done.\n");

    /* the environment and shell object */
    thee->PR[0] = '\0';
    thee->vsh = Vsh_ctor(VNULL, argc, argv);

    return thee;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  APBSsh_dtor
//
// Purpose:  The APBSsh destructor.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void APBSsh_dtor(APBSsh **thee)
{
    VASSERT( (*thee) != VNULL );
    if ((*thee) != VNULL) {

        VDEBUGIO("APBSsh_dtor: DESTROYING object..");
        Vmem_dtor( &((*thee)->vmem) );
        Vmem_free( VNULL, 1, sizeof(APBSsh), (void**)thee );
        VDEBUGIO("..done.\n");

        (*thee) = VNULL;
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  APBSsh_publishVars
//
// Purpose:  Publish a set of environment variables with Vsh.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE void APBSsh_publishVars(APBSsh *thee)
{
    int i, numVars = 1;
    typedef struct mcVars {
        char envi[80];
        char valu[80];
        char info[80];
    } mcVars;
    mcVars envVars[] = {
        /* --------   -----       ----------- */
        /* VARIABLE   VALUE       EXPLANATION */
        /* --------   -----       ----------- */
        { "DUMVAR",     "0",      "dummy variable for APBSsh shell layer" },
    };

    for (i=0; i<numVars; i++) {
        Vsh_putenv(     thee->vsh, envVars[i].envi, envVars[i].valu );
        Vsh_putenvInfo( thee->vsh, envVars[i].envi, envVars[i].info );
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  APBSsh_getCmd
//
// Purpose:  Get (decode) the command.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE APBSsh_command APBSsh_getCmd(APBSsh *thee, int argc, char **argv)
{
    APBSsh_command theCmd = apbsc_none;
    if (!strcmp(argv[0],"")) {
        theCmd = apbsc_none;
    } else if (!strcmp(argv[0],"help")) { 
        theCmd = mccom_help;
    } else {
        theCmd = mccom_none;
    }
    return theCmd;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  APBSsh_ioSetup
//
// Purpose:  Setup for an I/O command.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE void APBSsh_ioSetup(APBSsh *thee,
    char *key, char *iodev, char *iofmt, char *iohost, char *iofile)
{
    /* setup for a read */
    if (!strcmp("r",key)) {

        strncpy(iohost,Vsh_getenv(thee->vsh,"IHVAL"),VMAX_BUFSIZE);

        if (!strcmp("sdio",Vsh_getenv(thee->vsh,"ISKEY"))) {
            strncpy(iodev,"SDIO",VMAX_BUFSIZE);
            strncpy(iofile,"console",VMAX_BUFSIZE);
        } else if (!strcmp("file",Vsh_getenv(thee->vsh,"ISKEY"))) {
            strncpy(iodev,"FILE",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"IFNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("buff",Vsh_getenv(thee->vsh,"ISKEY"))) {
            strncpy(iodev,"BUFF",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"ISNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("unix",Vsh_getenv(thee->vsh,"ISKEY"))) {
            strncpy(iodev,"UNIX",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"ISNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("inet",Vsh_getenv(thee->vsh,"ISKEY"))) {
            strncpy(iodev,"INET",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"ISNAM"),VMAX_BUFSIZE);
        } else Vnm_print(2,"MCsh_ioSetup: Internal logic error.\n");

        if (!strcmp("asc",Vsh_getenv(thee->vsh,"ISFMT"))) {
            strncpy(iofmt,"ASC", VMAX_BUFSIZE);
        } else if (!strcmp("xdr",Vsh_getenv(thee->vsh,"ISFMT"))) {
            strncpy(iofmt,"XDR", VMAX_BUFSIZE);
        } else Vnm_print(2,"MCsh_ioSetup: Internal logic error.\n");

    /* setup for a write */
    } else if (!strcmp("w",key)) {

        strncpy(iohost,Vsh_getenv(thee->vsh,"OHVAL"),VMAX_BUFSIZE);
        if (!strcmp("sdio",Vsh_getenv(thee->vsh,"OSKEY"))) {
            strncpy(iodev,"SDIO",VMAX_BUFSIZE);
            strncpy(iofile,"console",VMAX_BUFSIZE);
        } else if (!strcmp("file",Vsh_getenv(thee->vsh,"OSKEY"))) {
            strncpy(iodev,"FILE",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"OFNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("buff",Vsh_getenv(thee->vsh,"OSKEY"))) {
            strncpy(iodev,"BUFF",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"OSNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("unix",Vsh_getenv(thee->vsh,"OSKEY"))) {
            strncpy(iodev,"UNIX",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"OSNAM"),VMAX_BUFSIZE);
        } else if (!strcmp("inet",Vsh_getenv(thee->vsh,"OSKEY"))) {
            strncpy(iodev,"INET",VMAX_BUFSIZE);
            strncpy(iofile,Vsh_getenv(thee->vsh,"OSNAM"),VMAX_BUFSIZE);
        } else Vnm_print(2,"APBSsh_ioSetup: Internal logic error.\n");

        if (!strcmp("asc",Vsh_getenv(thee->vsh,"OSFMT"))) {
            strncpy(iofmt,"ASC", VMAX_BUFSIZE);
        } else if (!strcmp("xdr",Vsh_getenv(thee->vsh,"OSFMT"))) {
            strncpy(iofmt,"XDR", VMAX_BUFSIZE);
        } else Vnm_print(2,"APBSsh_ioSetup: Internal logic error.\n");

    } else Vnm_print(2,"APBSsh_ioSetup: Internal logic error.\n");

    Vnm_print(0,"APBSsh_ioSetup: iodev =<%s>\n", iodev);
    Vnm_print(0,"APBSsh_ioSetup: iofmt =<%s>\n", iofmt);
    Vnm_print(0,"APBSsh_ioSetup: iohost=<%s>\n", iohost);
    Vnm_print(0,"MAPBSh_ioSetup: iofile=<%s>\n", iofile);
}


/* ///////////////////////////////////////////////////////////////////////////
// Routine:  APBSsh_builtIn
//
// Purpose:  Deal with a builtin command.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE int APBSsh_builtIn(void *pthee, int argc, char **argv)
{
    APBSsh *thee = (APBSsh*)pthee;

    int i,rc,defKey,ncolor,ilev;
    int block, numPts, marks[6];
    char iodev[VMAX_BUFSIZE], iofmt[VMAX_BUFSIZE];
    char iohost[VMAX_BUFSIZE], iofile[VMAX_BUFSIZE];
    double *defX[3] = { VNULL, VNULL, VNULL };
    double pts[6*3], vals[6];
    APBSsh_command theCmd;

    static int  init=0, marked=0;
    static char num[VMAX_BUFSIZE], mesh[VMAX_BUFSIZE], solv[VMAX_BUFSIZE];
    const char *stmp;

    /* one-time intialization */
    if (!init) {
        init=1;

        /* make the general message (%s slots = 1) */
        stmp = "%s: General commands: \n"
               "    fem      --> invoke the FEM solver sub-shell\n"
               "    mg       --> invoke the MG solver sub-shell\n";
               "    help     --> get help\n";
        sprintf(num,stmp,thee->PR);

    }

    /* the user-defined shell gets first shot at the command */
    if (thee->USER_shell != VNULL) {
        rc = (*(thee->USER_shell))(thee,argc,argv);
        if (rc != 0) return rc;
    }

    /* default return code (success) */
    rc = 1;

    /* get the command */
    theCmd = APBSsh_getCmd(thee, argc, argv);

    /* decode and execute the command */
    switch (theCmd) {

      case mccom_mark:
        marked = Gem_markRefine(thee->gm,
            Vsh_getenvInt(thee->vsh,"AKEY"),
            Vsh_getenvInt(thee->vsh,"RCOL"));
        break;

      case mccom_inita:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        break;

      case mccom_lsolve:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_lSolve(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            0,
            Vsh_getenvInt(thee->vsh,"LKEY"),
            Vsh_getenvInt(thee->vsh,"LMAX"),
            Vsh_getenvReal(thee->vsh,"LTOL"),
            Vsh_getenvInt(thee->vsh,"GUES"),
            Vsh_getenvInt(thee->vsh,"PJAC"));
        break;

      case mccom_dsolve:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_lSolve(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            1,
            Vsh_getenvInt(thee->vsh,"LKEY"),
            Vsh_getenvInt(thee->vsh,"LMAX"),
            Vsh_getenvReal(thee->vsh,"LTOL"),
            Vsh_getenvInt(thee->vsh,"GUES"),
            Vsh_getenvInt(thee->vsh,"PJAC"));
        break;

      case mccom_nsolve:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_nSolve(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            Vsh_getenvInt(thee->vsh,"NKEY"),
            Vsh_getenvInt(thee->vsh,"NMAX"),
            Vsh_getenvReal(thee->vsh,"NTOL"),
            Vsh_getenvInt(thee->vsh,"LKEY"),
            Vsh_getenvInt(thee->vsh,"LMAX"),
            Vsh_getenvReal(thee->vsh,"LTOL"),
            Vsh_getenvInt(thee->vsh,"GUES"),
            Vsh_getenvInt(thee->vsh,"PJAC"));
        break;

      case mccom_estimate:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        marked = AM_markRefine(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            Vsh_getenvInt(thee->vsh,"AKEY"),
            Vsh_getenvInt(thee->vsh,"RCOL"),
            Vsh_getenvInt(thee->vsh,"BKEY"),
            Vsh_getenvReal(thee->vsh,"ETOL"));
        break;

      case mccom_refine:
        if (marked) {
            (void)AM_refine(thee->am, Vsh_getenvInt(thee->vsh,"RKEY"));
            ilev = Vsh_getenvInt(thee->vsh,"LEV");
            ilev++;
            Vsh_putenvInt(thee->vsh,"LEV",ilev);
            marked = 0;
        }
        break;

      case mccom_part:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        (void)AM_part(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            Vsh_getenvInt(thee->vsh,"PKEY"),
            Vsh_getenvInt(thee->vsh,"PWHT"),
            Vsh_getenvInt(thee->vsh,"PPOW"));
        break;

      case mccom_partsmooth:
        ncolor = AM_partSmooth(thee->am,Vsh_getenvInt(thee->vsh,"LEV"));
        break;

      case mccom_partset:
        ncolor = 0;
        ncolor = AM_partSet(thee->am,Vsh_getenvInt(thee->vsh,"LEV"),ncolor);
        break;

      case mccom_evall2:
        (void)AM_evalError(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            Vsh_getenvInt(thee->vsh,"RCOL"),
            0);
        break;

      case mccom_evall8:
        (void)AM_evalError(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            Vsh_getenvInt(thee->vsh,"RCOL"),
            1);
        break;

      case mccom_evalh1:
        (void)AM_evalError(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            Vsh_getenvInt(thee->vsh,"RCOL"),
            2);
        break;

      case mccom_makebnd:
        Gem_makeBnd(thee->gm,0);
        break;

      case mccom_makebndd:
        Gem_makeBnd(thee->gm,1);
        break;

      case mccom_makebndn:
        Gem_makeBnd(thee->gm,2);
        break;

      case mccom_gen:
        Gem_delaunay(thee->gm);
        break;

      case mccom_reordersv:
        Gem_reorderSV(thee->gm);
        break;

      case mccom_smooth:
        Gem_smoothMesh(thee->gm);
        break;

      case mccom_smoothb:
        Gem_smoothMeshBnd(thee->gm);
        break;

      case mccom_smootho:
        Gem_smoothMeshOpt(thee->gm);
        break;

      case mccom_formfix:
        Gem_formFix(thee->gm,0);
        break;

      case mccom_eval:
#if 0
        pts[0]  =  1.; pts[1]  =  0.; pts[2]  =  0.; 
        pts[3]  =  0.; pts[4]  =  1.; pts[5]  =  0.; 
        pts[6]  =  0.; pts[7]  =  0.; pts[8]  =  1.; 
        pts[9]  = -1.; pts[10] =  0.; pts[11] =  0.; 
        pts[12] =  0.; pts[13] = -1.; pts[14] =  0.; 
        pts[15] =  0.; pts[16] =  0.; pts[17] = -1.; 
#else
        pts[0]  =  0.0; pts[1]  =  0.0; pts[2]  =  2.1; 
        pts[3]  =  0.0; pts[4]  =  2.1; pts[5]  =  0.0; 
        pts[6]  =  2.1; pts[7]  =  0.0; pts[8]  =  0.0; 
        pts[9]  =  0.0; pts[10] =  0.0; pts[11] = -2.1; 
        pts[12] =  0.0; pts[13] = -2.1; pts[14] =  0.0; 
        pts[15] = -2.1; pts[16] =  0.0; pts[17] =  0.0; 
#endif
        block  = 0;
        numPts = 6;
        AM_evalFunc(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            Vsh_getenvInt(thee->vsh,"PVEC"),
            block, numPts, pts, vals, marks);
        for (i=0; i<numPts; i++) {
            Vnm_print(0,"MCsh_builtIn: W_{%d}(%g,%g,%g)=<%g>\n",
                Vsh_getenvInt(thee->vsh,"PVEC"),
                pts[i*3+0],pts[i*3+1],pts[i*3+2],vals[i]);
        }
        break;

      case mccom_evalbint:
        AM_bndIntegral(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        break;

      case mccom_buildcharts:
        Gem_buildCharts(thee->gm);
        break;

      case mccom_read:
        MCsh_ioSetup(thee,"r",iodev,iofmt,iohost,iofile);
        AM_reset(thee->am);
        Vsh_putenvInt(thee->vsh,"LEV", 0);
        AM_getMesh(thee->am, 
            Vsh_getenvInt(thee->vsh,"TKEY"),
            iodev, iofmt, iohost, iofile);
        marked = 0;
        break;

      case mccom_write:
        MCsh_ioSetup(thee,"w",iodev,iofmt,iohost,iofile);
        Gem_write(thee->gm,
            Vsh_getenvInt(thee->vsh,"TKEY"),
            iodev, iofmt, iohost, iofile,
            Vsh_getenvInt(thee->vsh,"FKEY"));
        break;

      case mccom_writebrep:
        MCsh_ioSetup(thee,"w",iodev,iofmt,iohost,iofile);
        Gem_writeBrep(thee->gm, iodev, iofmt, iohost, iofile);
        break;

      case mccom_writeoff:
        MCsh_ioSetup(thee,"w",iodev,iofmt,iohost,iofile);
        defKey = 0;
        Gem_writeGV(thee->gm, iodev, iofmt, iohost, iofile,
            defKey,
            Vsh_getenvInt(thee->vsh,"CKEY"),
            Vsh_getenvInt(thee->vsh,"DKEY"),
            Vsh_getenvReal(thee->vsh,"GVAL"),
            defX,
            Vsh_getenvInt(thee->vsh,"FKEY"));
        break;

      case mccom_writeoffdef:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        MCsh_ioSetup(thee,"w",iodev,iofmt,iohost,iofile);
        defKey = 1;
        AM_writeGV(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            iodev, iofmt, iohost, iofile,
            defKey,
            Vsh_getenvInt(thee->vsh,"CKEY"),
            Vsh_getenvInt(thee->vsh,"DKEY"),
            Vsh_getenvReal(thee->vsh,"GVAL"),
            Vsh_getenvInt(thee->vsh,"PVEC"),
            Vsh_getenvInt(thee->vsh,"FKEY"));
        break;

      case mccom_writeoffdis:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        MCsh_ioSetup(thee,"w",iodev,iofmt,iohost,iofile);
        defKey = 2;
        AM_writeGV(thee->am, 
            Vsh_getenvInt(thee->vsh,"LEV"),
            iodev, iofmt, iohost, iofile,
            defKey,
            Vsh_getenvInt(thee->vsh,"CKEY"),
            Vsh_getenvInt(thee->vsh,"DKEY"),
            Vsh_getenvReal(thee->vsh,"GVAL"),
            Vsh_getenvInt(thee->vsh,"PVEC"),
            Vsh_getenvInt(thee->vsh,"FKEY"));
        break;

      case mccom_writegmv:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        MCsh_ioSetup(thee,"w",iodev,iofmt,iohost,iofile);
        AM_writeGMV(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            iodev, iofmt, iohost, iofile,
            Vsh_getenvInt(thee->vsh,"PVEC"));
        break;

      case mccom_printa:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_printA(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        break;

      case mccom_printasp:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_printAsp(thee->am, Vsh_getenvInt(thee->vsh,"LEV"), "jac.m");
        break;

      case mccom_printanod:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_printAnoD(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        break;

      case mccom_printaspnod:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_printAspNoD(thee->am, Vsh_getenvInt(thee->vsh,"LEV"), "jac.m");
        break;

      case mccom_printc:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV")-1);
        AM_printA(thee->am, Vsh_getenvInt(thee->vsh,"LEV")-1);
        break;

      case mccom_printcsp:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV")-1);
        AM_printAsp(thee->am, Vsh_getenvInt(thee->vsh,"LEV")-1, "jacc.m");
        break;

      case mccom_printcnod:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV")-1);
        AM_printAnoD(thee->am, Vsh_getenvInt(thee->vsh,"LEV")-1);
        break;

      case mccom_printcspnod:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV")-1);
        AM_printAspNoD(thee->am, Vsh_getenvInt(thee->vsh,"LEV")-1, "jacc.m");
        break;

      case mccom_printp:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_printP(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        break;

      case mccom_printpsp:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_printPsp(thee->am, Vsh_getenvInt(thee->vsh,"LEV"), "pro.m");
        break;

      case mccom_printv:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_printV(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            Vsh_getenvInt(thee->vsh,"PVEC"));
        break;

      case mccom_printvsp:
        AM_algInit(thee->am, Vsh_getenvInt(thee->vsh,"LEV"));
        AM_printVsp(thee->am,
            Vsh_getenvInt(thee->vsh,"LEV"),
            Vsh_getenvInt(thee->vsh,"PVEC"),
            "sol.m");
        break;

      case mccom_typechk:
        Vnm_typeChk();
        break;

      case mccom_memchk:
        MCsh_memChk(thee);
        break;

      case mccom_formchk:
        /* check ringed vertex: 0=[v+s],1=[.+sRing],2=[.+eRing],3=[.+conform] */
        Gem_formChk(thee->gm,2);
        break;

      case mccom_formchkf:
        /* check ringed vertex: 0=[v+s],1=[.+sRing],2=[.+eRing],3=[.+conform] */
        Gem_formChk(thee->gm,3);
        break;

      case mccom_shapechk:
        Gem_shapeChk(thee->gm);
        break;

      case mccom_contentchk:
        Gem_contentChk(thee->gm);
        break;

      case mccom_speedchk:
        Gem_speedChk(thee->gm);
        break;

      case mccom_free:
        Gem_ramClear(thee->gm,2);
        Gem_ramClear(thee->gm,1);
        Gem_ramClear(thee->gm,0);
        break;

      case mccom_help:
        if (argc==1) {
            Vnm_print(1,"MCsh: MCsh-layer Help Menu:\n");
            Vnm_print(1,
                "    help num  --> Help on %s general numerical commands\n",
                thee->PR);
            Vnm_print(1,
                "    help mesh --> Help on %s mesh manipulation commands\n",
                thee->PR);
            Vnm_print(1,
                "    help solv --> Help on %s solver control commands\n",
                thee->PR);
            rc = 0;  /* pretend we didn't see it so subshell can help too */
        } else {
            if (!strcmp(argv[1],"num")) { 
                Vnm_print(1, "%s", num);
            } else if (!strcmp(argv[1],"mesh")) { 
                Vnm_print(1, "%s", mesh);
            } else if (!strcmp(argv[1],"solv")) { 
                Vnm_print(1, "%s", solv);
            } else {
                rc = 0;  /* pretend we didn't it so subshell can help too */
            }
        }
        break;                                                              

      default:
        rc = 0;
        break;
    }
    return rc;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MCsh_shell
//
// Purpose:  The actual shell.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int MCsh_shell(MCsh *thee, 
    int (*USER_shell)(void *thee, int argc, char **argv))
{
    thee->USER_shell = USER_shell;
    strcpy(thee->PR,"MCsh");
    MCsh_publishVars(thee);
    return Vsh_shell(thee->vsh, thee->PR, (void*)thee, &MCsh_builtIn);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  MCsh_memChk
//
// Purpose:  Print the exact current malloc usage.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void MCsh_memChk(MCsh *thee)
{
    Vnm_print(0,"mc_vertex  = %d;\n", Gem_numVV(thee->gm));
    Vnm_print(0,"mc_simplex = %d;\n", Gem_numSS(thee->gm));
    Vnm_print(0,"mc_memory  = [\n");
    Vnm_print(0,"%% --------------------------------------"
                "--------------------------------------\n");
    Vnm_print(0,"%%  Footprint        Areas       Malloc         Free"
                "    Highwater   Class\n"),
    Vnm_print(0,"%% --------------------------------------"
                "--------------------------------------\n");
    if (thee->gm != VNULL) Gem_memChk(thee->gm);
    if (thee->am != VNULL) AM_memChk(thee->am);
    Vmem_print(VNULL);
    Vnm_print(0,"%% --------------------------------------"
                "--------------------------------------\n");
    Vmem_printTotal();
    Vnm_print(0,"%% --------------------------------------"
                "--------------------------------------\n");
    Vnm_print(0,"];\n");
    if (thee->gm != VNULL) Gem_memChkMore(thee->gm);
}

