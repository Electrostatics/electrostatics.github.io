/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
//////////////////////////////////////////////////////////////////////////// 
/// rcsid="$Id: mgautoparm.h,v 1.2 2001/10/24 23:31:49 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     mgautoparm.h    
//
// Purpose:  A set of useful parameters for a generic multigrid calculation
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */

#ifndef _MGAUTOPARM_H_
#define _MGAUTOPARM_H_

#include "apbs/apbs.h"
#include "apbs/mgparm.h"
#include "maloc/maloc.h"

/* ///////////////////////////////////////////////////////////////////////////
// Class MGAUTOparm: Definition
/////////////////////////////////////////////////////////////////////////// */
typedef struct MGAUTOparm {
   
    MGparm *fparm;         /* Fine level parameters   */
    MGparm *cparm;         /* Coarse level parameters */

} MGAUTOparm;

/* ///////////////////////////////////////////////////////////////////////////
// Class NOsh: Non-inlineable methods (mcsh.c)
/////////////////////////////////////////////////////////////////////////// */

VEXTERNC MGAUTOparm* MGAUTOparm_ctor(MGparm *cparm, MGparm *fparm);
VEXTERNC int     MGAUTOparm_ctor2(MGAUTOparm *thee,
  MGparm *cparm, MGparm *fparm);
VEXTERNC void    MGAUTOparm_dtor(MGAUTOparm **thee);
VEXTERNC void    MGAUTOparm_dtor2(MGAUTOparm *thee);
VEXTERNC int     MGAUTOparm_check(MGAUTOparm *thee);
VEXTERNC int     MGAUTOparm_build(MGAUTOparm *thee, int *nparm, 
  MGparm *parm[NOSH_MAXCALC]);

#endif 

