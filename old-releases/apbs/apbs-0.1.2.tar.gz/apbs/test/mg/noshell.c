/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
///
/// rcsid="$Id: noshell.c,v 1.78 2001/08/29 19:30:47 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     noshell.c
//
// Purpose:  APBS ``front end" without the shell for multigrid calculations
//
// Notes:    This driver program represents a mish-mash of instructions for
//           calculating electrostatic potentials, as well as free energies of 
//           binding and solvation.  It is invoked as:
//
//               noshell flag refMol.pqr [mol1.pqr mol2.pqr ...]
//
//           where flag tells the program what type of calculation to perform
//           (0 = solvation free energy, 1 = binding free energy), refMol.pqr 
//           is the PQR format molecule data for reference molecule (the
//           complex or the molecule whose solvation free energy you'd like to
//           calculate), and mol#.pqr are either the constituents of the
//           complex or, for solvation free energies, the same molecule as
//           refMol.pqr.
//
// Author:   Nathan Baker
//
// rcsid="$Id: noshell.c,v 1.78 2001/08/29 19:30:47 apbs Exp $"
/////////////////////////////////////////////////////////////////////////// */

#include "apbscfg.h"
#include "apbs/apbs.h"  

VEMBED(rcsid="$Id: noshell.c,v 1.78 2001/08/29 19:30:47 apbs Exp $")

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    /* MPI parameters */

    /* Objects for each molecule */
    Vpbe *pbe[MAXMOL];
    Valist *alist[MAXMOL];
    int i, nmol, imol;
    double qfEnergy[MAXMOL][MAXFOCUS], qmEnergy[MAXMOL][MAXFOCUS];
    double dielEnergy[MAXMOL][MAXFOCUS], totEnergy[MAXMOL][MAXFOCUS];

    /* Objects for solver */
    Vpmg *pmg[MAXFOCUS];
    Vpmgp *pmgp[MAXFOCUS];

    /* Parameters for solver */
    int nfocus, ifocus, nx[MAXFOCUS], ny[MAXFOCUS], nz[MAXFOCUS];
    int nlev[MAXFOCUS], nonlin[MAXFOCUS], bcfl, surfMeth;
    double hx[MAXFOCUS], hy[MAXFOCUS], hzed[MAXFOCUS], splineWin;
    double xcent[MAXFOCUS], ycent[MAXFOCUS], zcent[MAXFOCUS];
    double dbForce[3], qfForce[3], npForce[3], ibForce[3], gamma;

    /* PBE parameters */
    double ionConc, T, soluteDiel, solventDiel, solventRadius, ionRadius;

    /* Parameters for I/O */
    int iatom, energyFlag, writepot, writeacc, writeforce;
    char *writepotstem = "potential";        /* Stem for potential file */
    char *writeaccstem = "accessiblity";     /* Stem for accessibility file */
    char writepotpath[120];
    char writeaccpath[120];
    char *pqr_path[MAXMOL];
    char *sepline = "--------------------------------------------------------";

    /* Instructions: */
    char *usage = "\
    This driver program represents a mish-mash of instructions for\n\
    calculating electrostatic potentials, as well as free energies of\n\
    binding and solvation USING MULTIGRID.  It is invoked as:\n\n\
      noshell flag refMol.pqr [mol1.pqr mol2.pqr ...]\n\n\
    where flag tells the program what type of calculation to perform\n\
    (0 = no energies, 1 = solvation free energy, 2 = binding free energy),\n\
    mesh.m is the initial finite element mesh in MCSF format, refMol.pqr\n\
    is the PQR format molecule data for reference molecule (the complex or\n\
    the molecule whose solvation free energy you'd like to calculate),\n\
    and mol#.pqr are either the constituents of the complex or, for\n\
    solvation free energies, the same molecule as refMol.pqr.\n\n";
 

    /* ********************* START PARMETER SETTINGS ********************** */
    /* THE FOLLOWING PARAMETERS ONLY NEED TO BE SET ONCE */
    ionConc = 0.000;            /* ion concentration in M                  */
    T = 298.15;                 /* temperature in K                        */
    soluteDiel = 1.00;          /* solute dielectric constant              */
    solventDiel = 78.54;        /* solvent diel. constant (78.54 = water)  */
    solventRadius = 1.40;       /* solvent sphere radius                   */
    ionRadius = 2.0;            /* ion sphere radius                       */
    nfocus = 0;                 /* The number of times you want to focus 
                                 * the PBE calculation.  Set to zero for a
                                 * standard calculation */
    gamma = 5.02e-2;            /* Apolar coeff in kT/A^2                  */
    bcfl = 2;                   /* Boundary condition method for non-focused
                                 * calc:
                                 *  0 => zero BC
                                 *  1 => single DH sphere 
                                 *  2 => multiple DH spheres
                                 *  4 => focusing                          */
    surfMeth = 2;               /* Surface definition:
                                 *  0 => molecular/inflated VdW; no smooth
                                 *  1 => as 0, but with simple 3-pt harm avg
                                 *  2 => cubic spline  */
    splineWin = 0.3;            /* Window for spline-based dielectric
                                 * assignment */
    writepot = 0;               /* Write the potential in DX format?       */
    writeacc = 0;               /* Write the solvent accessibility in DX 
                                 * format?                                 */
    writeforce = 1;             /* Write out the forces on the atoms? */

    /* NOTE THAT (nfocus+1) VALUES MUST BE SET FOR THE FOLLOWING PARAMS    */
    nx[0] =  65;               /* number of mesh points in each direction */
    ny[0] =  65;               /* including boundaries.  Note that each   */
    nz[0] =  65;               /* of these values should be               */
    nx[1] =  65;               /*      c1 2^(L+c2) + 1                    */
    ny[1] =  65;               /* where c1 > 0 and c2 >= 1 are integers.  */
    nz[1] =  65;
    nlev[0] = 4;                /* Number of levels                        */
    nlev[1] = 4;
    nonlin[0] = 0;              /* Linear (0) or nonlinear (1) PBE         */
    nonlin[1] = 0;
    hx[0] =  0.21;              /* mesh spacing in x direction             */
    hy[0] =  0.21;              /* mesh spacing in y direction             */
    hzed[0] = 0.21;             /* mesh spacing in z direction             */
    hx[1] = 5.7;
    hy[1] = 5.7;
    hzed[1] = 10.1;
    xcent[0] = 0.00;        /* center x-coordinate                     */
    ycent[0] = 0.00;        /* center y-coordinate                     */
    zcent[0] = 0.00;        /* center z-coordinate                     */
    xcent[1] = 316.184;
    ycent[1] = 282.745;
    zcent[1] = 382.322;
    /* ********************* END PARMETER SETTINGS ********************** */

    /* *************** CHECK INVOCATION ******************* */
    Vio_start();
    if (argc < 3) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected >=3.\n\n",argc);
        Vnm_print(2,"%s\n", usage);
        return -1;
    } else if (argc > 3 + MAXMOL) {
        Vnm_print(2,"\n*** Maximum of %d molecules allowed!\n\n", MAXMOL);
        return -1;
    } else {
        sscanf(argv[1], "%d", &energyFlag);
        if (energyFlag == 0) {
            Vnm_print(1,"\nCalculating electrostatic potential only.\n");
        } else if (energyFlag == 1) {
            Vnm_print(1,"\nCalculating solvation free energy.\n");
        } else if (energyFlag == 2) {
            Vnm_print(1,"\nCalculating binding free energy.\n");
        } else {
            Vnm_print(2,"\n*** Syntax error: invalid flag = %d.\n\n", energyFlag);
            Vnm_print(2,"%s\n", usage);
            return -1;
        }
        nmol = 0;
        for (imol=0; imol<argc-2; imol++) {
            if (argv[2+imol][0] == '-') break;
            pqr_path[imol] = argv[2+imol];
            nmol++;
        }
        if (energyFlag == 1) {
            if (nmol > 1) Vnm_print(2,"\n*** Warning: only first of %d molecules used in solvation free energy calculations.\n\n", nmol);
            nmol = 2;
        }
    }

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: APBS INITIALIZATION\n");
    Vnm_print(1,"main: Constructing %d VALIST objects.\n", nmol);
    for (imol=0; imol<MAXMOL; imol++) {
        alist[imol] = VNULL;
        pbe[imol] = VNULL;
    }
    if (energyFlag == 1) {
        alist[0] = Valist_ctor();
        Vnm_print(1, "main:    Reading molecule data from %s\n",
          pqr_path[0]);
        alist[1] = alist[0];
        if (Valist_readPQR(alist[0], "FILE", "ASC", VNULL, pqr_path[0]) != 1) {
            Vnm_print(2, "main:  Fatal error reading PQR!\n");
            return 666;
        }
        Vnm_print(1, "main:    Mol %d has %d atoms\n", 0, 
           Valist_getNumberAtoms(alist[0]));
    } else {
        for (imol=0; imol<nmol; imol++) {
            alist[imol] = Valist_ctor();
            Vnm_print(1, "main:    Reading molecule data from %s\n",
              pqr_path[imol]);
            if (Valist_readPQR(alist[imol], "FILE", "ASC", VNULL,
              pqr_path[imol]) != 1) {
                Vnm_print(2, "main:  Fatal error reading PQR!\n");
                return 666;
            }
            Vnm_print(1, "main:    Mol %d has %d atoms\n", imol, 
               Valist_getNumberAtoms(alist[imol]));
        }
    }
    Vnm_print(1,"main: Constructing %d VPBE objects.\n", nmol);

    /* Set PBE parameters and build hash tables */
    Vnm_print(1,"main:      Ionic stregth   %4.3f M\n", ionConc);
    Vnm_print(1,"main:       Ionic radius   %4.3f A\n", ionRadius);
    Vnm_print(1,"main:        Temperature   %4.3f K\n", T);
    Vnm_print(1,"main:  Solute dielectric   %4.3f \n", soluteDiel);
    Vnm_print(1,"main: Solvent dielectric   %4.3f \n", solventDiel);
    Vnm_print(1,"main:     Solvent radius   %4.3f A\n", solventRadius);
    if (energyFlag == 1) {
        pbe[0] = Vpbe_ctor(alist[0], ionConc, ionRadius, T, soluteDiel, 
          solventDiel, solventRadius);
        pbe[1] = Vpbe_ctor(alist[0], 0.0, ionRadius, T, soluteDiel, 
          soluteDiel, solventRadius);
        Vnm_print(1,"main:     Charge scaling   %4.3f A^{-2}\n", 
          Vpbe_getZmagic(pbe[0]));
        Vnm_print(1,"main: Mod. sq. DH coeff.   %4.3f A^{-2}\n", 
          Vpbe_getZkappa2(pbe[0]));
        Vnm_print(1,"main:      Solute charge   %4.3f \n", 
          Vpbe_getSoluteCharge(pbe[0]));
        Vnm_print(1,"main:      Solute center   (%4.3f, %4.3f, %4.3f) \n", 
          Vpbe_getSoluteCenter(pbe[0])[0], 
          Vpbe_getSoluteCenter(pbe[0])[1],
          Vpbe_getSoluteCenter(pbe[0])[2]);
        Vnm_print(1,"main:      Solute radius   %4.3f \n", 
          Vpbe_getSoluteRadius(pbe[0]));
        Vnm_print(1,"main:        Solute dims   (%4.3f, %4.3f, %4.3f) \n", 
          Vpbe_getSoluteXlen(pbe[0]), Vpbe_getSoluteYlen(pbe[0]),
          Vpbe_getSoluteZlen(pbe[0]));
    } else {
        for (imol=0; imol<nmol; imol++) {
	    pbe[imol] = Vpbe_ctor(alist[imol], ionConc, ionRadius, T,
              soluteDiel, solventDiel, solventRadius);
            Vnm_print(1,"main:    Solute %d charge   %4.3f \n", imol,
              Vpbe_getSoluteCharge(pbe[imol]));
            Vnm_print(1,"main:     Charge scaling   %4.3f A^{-2}\n", 
              Vpbe_getZmagic(pbe[imol]));
            Vnm_print(1,"main: Mod. sq. DH coeff.   %4.3f A^{-2}\n", 
              Vpbe_getZkappa2(pbe[0]));
            Vnm_print(1,"main:    Solute %d center   (%4.3f, %4.3f, %4.3f) \n", imol,
              Vpbe_getSoluteCenter(pbe[imol])[0], 
              Vpbe_getSoluteCenter(pbe[imol])[1],
              Vpbe_getSoluteCenter(pbe[imol])[2]);
            Vnm_print(1,"main:    Solute %d radius   %4.3f \n", imol,
              Vpbe_getSoluteRadius(pbe[imol]));
            Vnm_print(1,"main:      Solute %d dims   (%4.3f, %4.3f, %4.3f) \n", 
	      imol, Vpbe_getSoluteXlen(pbe[imol]),
              Vpbe_getSoluteYlen(pbe[imol]), Vpbe_getSoluteZlen(pbe[imol]));
        }
    }


    /* *************** PER-MOLECUE SOLUTION ******************* */
    for (imol=0; imol<nmol; imol++) {
        Vnm_print(1,"\nmain: %s\n", sepline);
        Vnm_print(1,"main: MOLECULE #%d\n", imol);
        /* Focusing, if requested */
        for (ifocus=0; ifocus<=nfocus; ifocus++) {
            if (nfocus > 0) Vnm_print(2, "main:   FOCUSING #%d\n", ifocus);
            Vnm_tstart(27, "Setup timer");
            /* Set up solver parameters */
            Vnm_print(1, "main:     Setting up solver parameters...\n");
            Vnm_print(1, "main:         hx, hy, hzed = (%g, %g, %g)\n", 
              hx[ifocus], hy[ifocus], hzed[ifocus]);
            Vnm_print(1, "main:         nx, ny, nz = (%d, %d, %d)\n", 
              nx[ifocus], ny[ifocus], nz[ifocus]);
            Vnm_print(1, "main:             center = (%g, %g, %g)\n", 
              xcent[ifocus], ycent[ifocus], zcent[ifocus]);
            Vnm_print(1, "main:             nonlin = %d\n", nonlin[ifocus]);
            if (ifocus == 0) Vnm_print(1, "main:               bcfl = %d\n", bcfl);
            pmgp[ifocus] = Vpmgp_ctor(nx[ifocus], ny[ifocus], nz[ifocus],
              nlev[ifocus], hx[ifocus], hy[ifocus], hzed[ifocus], 
              nonlin[ifocus]);
            pmgp[ifocus]->xcent = xcent[ifocus];
            pmgp[ifocus]->ycent = ycent[ifocus];
            pmgp[ifocus]->zcent = zcent[ifocus];
            if (ifocus == 0) pmgp[ifocus]->bcfl = bcfl;
            else pmgp[ifocus]->bcfl = 4;
            Vnm_print(1,"main:     Constructing PDE...\n");
            fflush(stdout);
            if (ifocus > 0) {
                pmg[ifocus] = Vpmg_ctorFocus(pmgp[ifocus], pbe[imol], 
                  pmg[ifocus-1], 2);
                Vpmgp_dtor(&(pmgp[ifocus-1]));
            } else {
                pmg[ifocus] = Vpmg_ctor(pmgp[ifocus], pbe[imol]);
            }
            Vnm_print(1,"main:     Filling PDE coefficient arrays...\n");
            fflush(stdout);
            Vpmg_fillco(pmg[ifocus], surfMeth, splineWin);
            Vnm_redirect(0);
            Vnm_tstop(27, "Setup timer");
            Vnm_redirect(1);
            fflush(stdout);
            Vnm_print(1,"main:     Solving PDE...\n");
            fflush(stdout);
            Vnm_tstart(27, "Solver timer");
            Vpmg_solve(pmg[ifocus]);
            Vnm_redirect(0);
            Vnm_tstop(27, "Solver timer");
            Vnm_redirect(1);
            if (energyFlag > 0) {
                Vnm_print(1,"main:     Energies for mol %d at focus lev %d:\n",
                  imol, ifocus);
                qfEnergy[imol][ifocus] =
                  Vunit_kb*T*Vunit_Na*Vpmg_qfEnergy(pmg[ifocus],1)/1000.0;
                Vnm_print(1,
                  "main:         Fixed charges (local dom.)  = %g kJ/mol\n",
                  qfEnergy[imol][ifocus]);
                if (nonlin[ifocus]) {
                    qmEnergy[imol][ifocus] = 
                      Vunit_kb*T*Vunit_Na*Vpmg_qmEnergy(pmg[ifocus],1)/1000.0;
                    Vnm_print(1,
                      "main:         Mobile charges (local dom.) = %g kJ/mol\n",
                        qmEnergy[imol][ifocus]);
                    dielEnergy[imol][ifocus] = 
                      Vunit_kb*T*Vunit_Na*Vpmg_dielEnergy(pmg[ifocus],1)/1000.0;
                    Vnm_print(1,
                      "main:            Dielectric (local dom.) = %g kJ/mol\n",
                      dielEnergy[imol][ifocus]);
                }
                totEnergy[imol][ifocus] = 
                  Vunit_kb*T*Vunit_Na*Vpmg_energy(pmg[ifocus],1)/1000.0;
                Vnm_print(1,
                  "main:                     TOTAL (global) = %g kJ/mol\n",
                  totEnergy[imol][ifocus]);
                
            }
            if (writeforce) {
		for (iatom=0; iatom<Valist_getNumberAtoms(alist[imol]);
                  iatom++) { 
                    Vpmg_qfForce(pmg[ifocus], qfForce, iatom);
                    Vpmg_ibForce(pmg[ifocus], ibForce, iatom);
                    Vpmg_dbnpForce(pmg[ifocus], dbForce, npForce, gamma, iatom);
                    Vnm_print(1, "main:  Forces on atom #%d:\n", iatom);
                    Vnm_print(1, "main: \tqf = (%g, %g, %g)\n", 
                      qfForce[0], qfForce[1], qfForce[2]);
                    Vnm_print(1, "main: \tib = (%g, %g, %g)\n", 
                      ibForce[0], ibForce[1], ibForce[2]);
                    Vnm_print(1, "main: \tdb = (%g, %g, %g)\n", 
                      dbForce[0], dbForce[1], dbForce[2]);
                    Vnm_print(1, "main: \tnp = (%g, %g, %g)\n", 
                      npForce[0], npForce[1], npForce[2]);
                }
            }
            fflush(stdout);
        }

        /* *************** I/O ******************* */
        if (writepot) {
            sprintf(writepotpath, "%s-%d.dx", writepotstem, imol);
            Vnm_print(1, "main: Writing potential for mol %d to %s\n",
              imol, writepotpath);
            Vpmg_writeDX(pmg[ifocus-1], "FILE", "ASC", VNULL, writepotpath,
              "POTENTIAL", pmg[ifocus-1]->u);
        }
        if (writeacc) {
            sprintf(writeaccpath, "%s-%d.dx", writeaccstem, imol);
            Vnm_print(1, "main: Writing solvent accessiblity for mol %d to %s\n",
              imol, writeaccpath);
/* 
            Vpmg_fillAcc(pmg[ifocus-1], pmg[ifocus-1]->rwork, 0, solventRadius);
*/
            Vpmg_fillAcc(pmg[ifocus-1], pmg[ifocus-1]->rwork,3,splineWin);
            Vpmg_writeDX(pmg[ifocus-1], "FILE", "ASC", VNULL, writeaccpath,
              "SOLVENT ACCESSIBLITY", pmg[ifocus-1]->rwork);
        }

        /* *************** GARBAGE COLLECTION ******************* */
        Vpmg_dtor(&pmg[ifocus-1]);
        Vpmgp_dtor(&pmgp[ifocus-1]);
    }


    /* *************** LAST STUFF ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: POST-SOLVER STUFF\n");
    if (energyFlag == 1) {
        Vnm_print(1, "main: Solvation energy contributions:\n");
    } else if (energyFlag == 2) {
        Vnm_print(1, "main: Binding energy contributions:\n");
    }
    if (energyFlag != 0) {
        for (ifocus=0; ifocus<=nfocus; ifocus++) {
            for (imol=1; imol<nmol; imol++) {
                qfEnergy[0][ifocus] -= qfEnergy[imol][ifocus];
                if (nonlin[ifocus]) {
                    qmEnergy[0][ifocus] -= qmEnergy[imol][ifocus];
                    dielEnergy[0][ifocus] -= dielEnergy[imol][ifocus];
                }
                totEnergy[0][ifocus] -= totEnergy[imol][ifocus];
            }
            Vnm_print(1, "main: Binding energy contributions at focusing level %d\n",
              ifocus);
            Vnm_print(1, "main:     Fixed charges (local dom.)  = %g kJ/mol\n", 
              qfEnergy[0][ifocus]);
            if (nonlin[ifocus]) {
                Vnm_print(1, "main:     Mobile charges (local dom.) = %g kJ/mol\n", 
                  qmEnergy[0][ifocus]);
                Vnm_print(1, "main:     Dielectric (local dom.)     = %g kJ/mol\n", 
                  dielEnergy[0][ifocus]);
                Vnm_print(1, "main:     ALTERNATE TOTAL             = %g kJ/mol\n", 
                  qfEnergy[0][ifocus]-dielEnergy[0][ifocus]-qmEnergy[0][ifocus]);
            }
            Vnm_print(1, "main:     TOTAL (global)              = %g kJ/mol\n", 
              totEnergy[0][ifocus]);
        }
    }

    /* *************** THE END ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STOPPING EXECUTION\n");

    return 0;
}
