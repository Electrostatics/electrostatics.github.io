/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
////////////////////////////////////////////////////////////////////////////
/// rcsid="$Id: mypde.c,v 1.16 2001/02/08 16:22:57 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     mypde.c    (use e.g. with mcin.m)
//
// Purpose:  Class PDE: methods.
//
//     Problem type:          Classic linearized Poisson-Boltzmann equation
//     Spatial dimension:     3   (works also in 2D)
//     Product dimension:     1
//     Boundary conditions:   zero or nonzero Dirichlet conditions
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */

#include "mypde.h"

VEMBED(rcsid="$Id: mypde.c,v 1.16 2001/02/08 16:22:57 apbs Exp $")

/* ///////////////////////////////////////////////////////////////////////////
// Local data
/////////////////////////////////////////////////////////////////////////// */

/* We want to allow the state of the PDE object to be variable, in other words,  * we'd like to have several different PDE objects for different molecules. 
 * However, since the local data is static and might need to persist from 
 * molecule to molecule, we're going to encapsulate it and explicitly switch
 * the internal state of this object each time we switch molecules. 
 *
 * The following structure contains all private variables for this class.  
 * You should not use a private variable without placing it in this struct. */
typedef struct LocalVars {
    double nvec[3];               /* Normal vector for a simplex face */
    double vx[4][3];              /* Vertex coordinates */
    double U[MAXV];               /* Solution value */
    double dU[MAXV][3];           /* Solution gradient */
    int sType;                    /* Simplex type */
    int fType;                    /* Face type */
    double A;                     /* Dielectric value */
    double B;                     /* Entire ionic strength term */
    double jumpDiel;              /* Dielectric value on one side of a simplex
                                   * face */
    double refineParm;            /* Additional parameter for the user-defined
                                   * error estimator */
    int refineCrit;               /* What should we refine? 0 => dielectric
                                   * surface and charges, 1 => charges only, 2
                                   * => dielectric surface only */
    Vfetk *fetk;                  /* Pointer to the VFETK object */
    SS   *simp;                   /* Pointer to the latest simplex object; set
                                   * in initElement() and delta() */
    VV   *verts[4];               /* Pointer to the latest vertices; set in
                                   * initElement */
    int  nverts;                  /* number of vertices in the simplex */
} LocalVars;

/* These are the only permissible non-encapsulated variables. currentMol is an
 * important variable because it toggles the accessibility bitfield to read. */
VPRIVATE LocalVars *var, varMOLS[MAXMOL];
VPRIVATE int currentMol, nMol;
VPRIVATE int pointAccessibility(int dim, double coord[]);

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  myPDE_setMol(PDE *thee, int imol)
//
// Purpose:  A hack to set the ``scope" inside the PDE ``object" which has a 
//           bunch of associated static variables that differ from molecule to
//           molecule...
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void myPDE_setMol(PDE *thee, int imol) {

    /* Make sure we're referring to a legitimate molecule */
    VASSERT(imol < MAXMOL);
    var = &(varMOLS[imol]);
    currentMol = imol;
    if (currentMol+1 > nMol) nMol = currentMol + 1;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  myPDE_setRefineParam(PDE *thee, int imol, double param)
//
// Purpose:  Set a refinement parameter for the specified molecule
//
// Args:     pde     -- The PDE object
//           refMol  -- The molecule on which to base the geometry-based
//                      refinement
//           refCrit -- What should we refine:
//                        0 => dielectric surface and charges
//                        1 => charges only
//                        2 => dielectric surface only
//           parame  -- The size where we should stop
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void myPDE_setRefineParam(PDE *thee, int imol, int refCrit, 
  double param) {

    /* Make sure we're referring to a legitimate molecule */
    VASSERT(imol < MAXMOL);
    (varMOLS[imol]).refineParm = param;
    (varMOLS[imol]).refineCrit = refCrit;

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  pointAccessibility
//
// Purpose:  Call VHASH code to determine the point's accessibility
//
// Arguments: dim    = Dimension of point
//            coord  = Point coordinates
//
// Returns:  A bitfield for the set of molecules.  Each molecule has two bits
//           associatied with it.  
//               low bit  = accessibility with respect to solvent
//               high bit = accessibility with respect to ions
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE int pointAccessibility(int dim, double coord[]) {

    int accBit = 0;
    double srad, irad;
    int currentBit;
    int imol;
    Vpbe *vpbe;

    for (imol=0; imol<nMol; imol++) {
        vpbe = varMOLS[imol].fetk->pbe;
        srad = Vpbe_getSolventRadius(vpbe);
        irad = Vpbe_getIonRadius(vpbe);
        currentBit = (int)VPOW(2, 2*imol);
        if (Vacc_molAcc(Vpbe_getVacc(vpbe), coord, srad) == 1) 
          accBit += currentBit;
        currentBit = (int)VPOW(2, 2*imol+1);
        if (Vacc_ivdwAcc(Vpbe_getVacc(vpbe), coord, irad) == 1) 
          accBit += currentBit;
    }

    return accBit;
}


/* ///////////////////////////////////////////////////////////////////////////
// Routine:  my_A
//
// Purpose:  The dielectric coefficient in the Poisson-Boltzmann equation.
//
// Notes:    A rudimentary smoothing scheme is implemented (this is sort of a
//           stab at a more accurate quadrature in simplices containing
//           coefficient discontinuities).  Assuming there are N vertices in
//           the simplex, each with coeff value a_i and distance d_i from
//           the quad pt, the quad pt coeff value a is assigned by a harmonic
//           average:
//              (\sum_i^N d_i)/a = \sum d_i/a_i
//              a = (\sum_i^N d_i)/(\sum d_i/a_i)
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE double my_A(int d, int accBit, double x[]) {

    int bit = (int)VPOW(2, 2*currentMol);
    int i,j;
    double dist, coeff;
    double totdist = 0;
    double totcoeff = 0;

    for (i=0; i<var->nverts; i++) {
        /* Compute the distance from this vertex to the quad pt */
        dist = 0;
        for (j=0; j<(var->nverts-1); j++) 
          dist += (var->vx[i][j] - x[j])*(var->vx[i][j] - x[j]);
        dist = VSQRT(dist);
        /* Increment the total distance */
        totdist += dist;
        /* Evaluate the coefficient for this vertex */
        if ((VV_chart(var->verts[i]) & bit) != 0) {
            coeff = Vpbe_getSolventDiel(var->fetk->pbe);
        } else coeff = Vpbe_getSoluteDiel(var->fetk->pbe);
        totcoeff += (dist/coeff);
    }
    totcoeff = totdist/totcoeff;

    return totcoeff;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  my_B
//
// Purpose:  The linearized ion term in the Poisson-Boltzmann equation.
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE double my_B(int d, int accBit, double x[], double u[]) {

    int bit = (int)VPOW(2, 2*currentMol+1);
    int i,j;
    double dist, coeff;
    double totdist = 0;
    double totcoeff = 0;

    for (i=0; i<var->nverts; i++) {
        /* Compute the distance from this vertex to the quad pt */
        dist = 0;
        for (j=0; j<(var->nverts-1); j++)
          dist += (var->vx[i][j] - x[j])*(var->vx[i][j] - x[j]);
        dist = VSQRT(dist);
        /* Increment the total distance */
        totdist += dist;
        /* Evaluate the coefficient for this vertex */
        if ((VV_chart(var->verts[i]) & bit) != 0) {
            coeff = Vpbe_getZkappa2(var->fetk->pbe);
            totcoeff += (dist/coeff);
        } else coeff = 0.0;
    }
    if (totcoeff != 0.0) totcoeff = totdist/totcoeff;

    return totcoeff;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  my_U
//
// Purpose:  Dirichlet boundary function and initial approximation function.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double my_U(int d, double x[]) {

/* This is a simple boundary condition: the enzyme is treated like a single
 * Debye-Huckel sphere */
#if 1

     const double e_c = 1.602e-19; /* in C */
     const double k_B = 1.380662000e-23; /* in J/K */
     const double eps0 = 8.854e-12; /* in F/m */
     const double pi = 3.1415927;
     double size, *position, charge, xkappa, eps_w, dist, T, val;
     int i;

     /* Get the solute radius in meters and position in angstroms */
     size = (1.0e-10)*Vpbe_getSoluteRadius(var->fetk->pbe);
     position = Vpbe_getSoluteCenter(var->fetk->pbe);

     /* We keep the charge relative to units of ec that are factored out;
      * this term should be dimensionless. The dielectric is unitless. */
     charge = e_c*Vpbe_getSoluteCharge(var->fetk->pbe);
     eps_w = Vpbe_getSolventDiel(var->fetk->pbe);

     /* Get xkappa in units of inverse meters */
     xkappa = (1.0e10)*Vpbe_getXkappa(var->fetk->pbe);

     /* The temperature is in units of K */
     T = Vpbe_getTemperature(var->fetk->pbe);

     /* Compute the distance (in units of m) */
     dist = 0;
     for (i=0; i<d; i++) dist += ((position[i] - x[i])*(position[i] - x[i]));
     dist = (1.0e-10)*VSQRT(dist);
    
     /* Compute the potential in J/electron */
     val = (charge)/(4*pi*eps0*eps_w*dist);
     if (xkappa != 0.0) val = val*(exp(-xkappa*(dist-size))/(1+xkappa*size));
     /* Scale the potential to be dimensionless */
     val = val*e_c/(k_B*T);
     
     return val;

/* This is a more complicated boundary condition: each atom in the enzyme is
 * treated like a Debye-Huckel sphere */
#else

    double size, *position, charge, xkappa, eps_w, dist, T, pot, val;
    int iatom, i;
    Valist *alist;
    Vatom *atom;

    eps_w = Vpbe_getSolventDiel(var->fetk->pbe);
    xkappa = (1.0e10)*Vpbe_getXkappa(var->fetk->pbe);
    T = Vpbe_getTemperature(var->fetk->pbe);
    alist = Vpbe_getValist(var->fetk->pbe);
    val = 0;
    pot = 0;

    for (iatom=0; iatom<Valist_getNumberAtoms(alist); iatom++) {
        atom = Valist_getAtom(alist, iatom);
        position = Vatom_getPosition(atom);
        charge = Vunit_ec*Vatom_getCharge(atom);
        size = (1e-10)*Vatom_getRadius(atom);
        dist = 0;
        for (i=0; i<d; i++)
          dist += ((position[i] - x[i])*(position[i] - x[i]));
        dist = (1.0e-10)*VSQRT(dist);
        val = (charge)/(4*VPI*Vunit_eps0*eps_w*dist);
        if (xkappa != 0.0)
          val = val*(exp(-xkappa*(dist-size))/(1+xkappa*size));
        val = val*Vunit_ec/(Vunit_kb*T);
        pot = pot + val;
    }

    return pot;

#endif

}


/* ///////////////////////////////////////////////////////////////////////////
// Routine:  initAssemble
//
// Purpose:  Do once-per-assembly initialization.
//
// Input:    PDE = pointer to the PDE object
//           ip  = integer parameters for the assembly
//           rp  = real parameters for the assembly
//
// Output:   None
//
// Speed:    This function is called by MC just before a full assembly,
//           and does not have to be particularly fast.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void initAssemble(PDE *thee, int ip[], double rp[]) { }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  initElement
//
// Purpose:  Do once-per-element initialization.
//
// Input:    PDE         = pointer to the PDE object
//           elementType = type of this element (various material types)
//           chart       = chart in which vertex coordinates are provided
//           tvx[][3]    = coordinates of all the vertices of the element
//
// Output:   None
//
// Speed:    This function is called by MC just before assembling a single
//           element, and needs to be a fast as possible.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void initElement(PDE *thee, int elementType, int chart, 
  double tvx[][3], void *data) {

    int i, j;
    int bit = (int)VPOW(2, 2*currentMol);

    /* We assume that the simplex has been passed in as the void *data 
     * argument.  Store it */
    VASSERT(data != NULL);
    var->simp = (SS *)data;

    /* save the element type */
    var->sType = elementType;

    /* Grab the vertices from this simplex */
    var->nverts = thee->dim+1;
    for (i=0; i<thee->dim+1; i++) var->verts[i] = SS_vertex(var->simp, i);

    /* Vertex locations of this simplex */
    for (i=0; i<thee->dim+1; i++) 
        for (j=0; j<thee->dim; j++) var->vx[i][j] = tvx[i][j];

    /* Set the dielectric constant for this element for use in the jump term
     * of the residual-based error estimator.  The value is set to the average
     * value of the vertices */
    var->jumpDiel = 0;
    for (i=0; i<thee->dim+1; i++) {
        if ((VV_chart(var->verts[i]) & bit) != 0) {
            var->jumpDiel += Vpbe_getSoluteDiel(var->fetk->pbe);
        } else var->jumpDiel += Vpbe_getSoluteDiel(var->fetk->pbe);
    }
    var->jumpDiel = var->jumpDiel/((double)(var->nverts));

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  initFace
//
// Purpose:  Do once-per-face initialization.
//
// Input:    PDE      = pointer to the PDE object
//           faceType = type of this face (interior or various boundary types)
//           chart    = chart in which normal vector coordinates are provided
//           tnvec[]  = coordinates of the outward normal vector to this face
//
// Output:   None
//
// Speed:    This function is called by MC just before assembling a single
//           element face, and needs to be a fast as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void initFace(PDE *thee, int faceType, int chart, double tnvec[]) {
    int i;

    /* unit normal vector of this face */
    for (i=0; i<thee->dim; i++) var->nvec[i] = tnvec[i];

    /* save the face type */
    var->fType = faceType;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  initPoint
//
// Purpose:  Do once-per-point initialization.
//
// Input:    PDE       = pointer to the PDE object
//           pointType = type of this point (interior or boundary)
//           chart     = chart in which the point coordinates are provided
//           txq[]     = coordinates of the point
//           tU[]      = current solution at the point
//           tdU[]     = current solution gradient at the point
//
// Output:   None
//
// Speed:    This function is called by MC for every quadrature point
//           during an assmebly, and needs to be a fast as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void initPoint(PDE *thee, int pointType, int chart, double txq[],
    double tU[], double tdU[][3])
{
    int   i, j;

    /* the point, and the solution value and gradient at the point */
    for (i=0; i<thee->vec; i++) {
        var->U[i] = tU[i];
        for (j=0; j<thee->dim; j++) {
            var->dU[i][j] = tdU[i][j];
        }
    }

    /* interior form case */
    if (pointType == 0) {

        var->A  = my_A(thee->dim,  chart, txq);
        var->B  = my_B(thee->dim,  chart, txq, var->U);

    /* boundary form case */
    /* (pointType == 1) */
    } else VASSERT(0);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Fu
//
// Purpose:  Evaluate the strong form of the differential operator F(u)
//           at the single point x.  This is your nonlinear strong form:
//              
//            [   b(u)^i - a(u)^{iq}_{~;q},   if t = 0
//     F(u) = [   c(u)^i + a(u)^{iq} n_q,     if t = 1
//            [   0      + a(u)^{iq} n_q,     if t = 2 
//
// Input:    PDE   = pointer to the PDE object
//           key   = piece to evaluate (0=interior, 1=boundary, 2=int-bndry)
//
// Output:   F[]   = operator piece evaluated at the point given to initPoint
//
// Speed:    This function is called by MC only when using error
//           estimation based on strong residuals.  The speed of this
//           function will impact the speed of the error estimator.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Fu(PDE *thee, int key, double F[])
{
    int i, testAcc, refBit;
    int dielBit = (int)VPOW(2, 2*currentMol);
    double vol, area, charge, ugrad, epsp, epsw;
    TT t;
    Vcsm *csm;

    F[0] = 0;

    /* Element residual case.  We need to evaluate: 
     *    || -\nabla \cdot \epsilon \nabla u + \kappa^2 \sinh u - f ||_{L^2(s)}
     * for this simplex */
    if (key == 0) {
        /* There are a few cases to consider and most of them depend on whether
         * or not this simplex is inside the molecular surface.  We check that
         * here. */
        testAcc = 0;
        for (i=0; i<var->nverts; i++) {
            /* Check whether we're inside the molecular surface */
            if ((VV_chart(var->verts[i]) & dielBit) == 0) {
                testAcc = 1;
                break;
            }
        }

        /* Case 1.  We are completely outside of the molecular surface and
         * therefore away from all charges and discontinuities in the
         * dielectric coeff.   In this case, the differential term is zero 
         * for piecewise linear functions, so the simplex residual is simply: 
         *   || \kappa^2 \sinh u ||_{L^2} */
        if (testAcc == 0) {
            F[0] = var->B * var->U[0];

        /* Case 2. We are inside or on the molecular surface.  The following
         * sub-cases need to be considered (we don't have to worry about the
         * \kappa term because it is zero inside the molecular surface): */
        } else {
            Gem_buildVolumeTrans(Vfetk_getGem(var->fetk),var->simp,&t);
            vol = t.D;
            epsw = Vpbe_getSolventDiel(var->fetk->pbe);
            epsp = Vpbe_getSoluteDiel(var->fetk->pbe);

            /* See if we have a dielectric discontinuity */
            testAcc = 0;
            refBit = VV_chart(var->verts[0]);
            for (i=1; i<var->nverts; i++) {
                if (VV_chart(var->verts[i]) != refBit) {
                    testAcc = 1;
                    break;
                }
            }
            if (testAcc == 1) {
		/* Case 2a.  We have a dielectric discontinuity.  This is going
		 * to be approximated (somewhat poorly) by De*A_f/V_s, where De
		 * is the jump in the dielectric value, A_f is the area of the
		 * largest face of the simplex, and V_s is the volume of the
		 * simplex. */
                /* Find the largest face */
                area = t.faceD[0];
                for (i=1; i<var->nverts; i++) {
                    if (t.faceD[i] > area) area = t.faceD[i];
                } 
                /* Find the norm of the solution gradient */
                ugrad = 0.0;
                for (i=0; i<(var->nverts-1); i++) {
                    ugrad += (var->dU[0][i]*var->dU[0][i]);
                }
                /* Compute the contribution to the error estimator */
                F[0] = F[0] + VABS(epsw-epsp)*area*VSQRT(ugrad)/vol;
            }

            /* Case 2b.  We contain charge(s).  The delta charge distribution
             * functions will be approximated as Q/V_s, where Q is the total
             * charge in the simplex and V_s is the simplex volume. */
            charge = 0;
            csm = Vfetk_getVcsm(var->fetk);
            for (i=0; i<Vcsm_getNumberAtoms(csm, SS_id(var->simp)); i++) {
                charge += Vatom_getCharge(Vcsm_getAtom(csm, i, 
                  SS_id(var->simp)));
            }
            F[0] = F[0] + VABS(Vpbe_getZmagic(var->fetk->pbe)*charge/vol);

        }

    /* Neumann face residual case.  This case does not occur for the PBE. */
    } else if (key == 1)  VASSERT(0);

    /* Interior face residual case.  We need to evaluate the jump in 
     *   \epsilon \nabla u
     * over the simplex face */
    else { /* (key == 2) */
        F[0] = 0.;
        for (i=0; i<thee->dim; i++)
            /* \vec{n} \cdot \epsilon \nabla u */
            F[0] += var->jumpDiel * var->dU[0][i] * var->nvec[i]; 
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Fu_v
//
// Purpose:  Evaluate the integrand F(u)(v) of the functional <F(u),v>
//           at the single point x.  This is your nonlinear weak form:
//
//                /\                 /\
//     <F(u),v> = \  F_0(u)(v) dx +  \  F_1(u)(v) ds
//               \/m                \/dm
//
//                /\
//              = \  g_{ij} ( a(u)^{iq} v^j_{~;q} + b(u)^i v^j ) dx
//               \/m
//
//                /\
//              + \  g_{ij} c(u)^i v^j ds
//               \/dm
//
// Input:    PDE   = pointer to the PDE object
//           key   = integrand to evaluate (0=F_0, 1=F_1)
//           tV[]  = test function at the current point
//           tdV[] = test function gradient at the current point
//
// Output:   Value of the integrand is returned
//
// Speed:    This function is called by MC multiple times for a single
//           quadrature point during assembly, and needs to be a fast
//           as possible.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double Fu_v(PDE *thee, int key,
    double V[], double dV[][3])
{
    int i;
    double value = 0.;

    /* interior form case */
    if (key == 0) {
        value = var->B * var->U[0] * V[0];
        for (i=0; i<thee->dim; i++)
            value += ( var->A * var->dU[0][i] * dV[0][i] );

    /* boundary form case */
    } else { /* (key == 1) */
        VASSERT(0);
    }

    return value;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  DFu_wv
//
// Purpose:  Evaluate the integrand DF(u)(w,v) of the functional <DF(u)w,v>
//           at the single point x.  This is your bilinear weak form:
//
//                  /\                    /\
//     <DF(u)w,v> = \  DF_0(u)(w,v) dx +  \  DF_1(u)(w,v) ds
//                 \/m                   \/dm
//
//                  /\
//                = \  d/dt F_0(u+tw)(v)|_{t=0} dx
//                 \/m
//
//                  /\
//                + \  d/dt F_1(u+tw)(v)|_{t=0} ds
//                 \/dm
//
// Input:    PDE   = pointer to the PDE object
//           key   = integrand to evaluate (0=F_0, 1=F_1)
//           tW[]  = trial function at the current point
//           tdW[] = trial function gradient at the current point
//           tV[]  = test function at the current point
//           tdV[] = test function gradient at the current point
//
// Output:   Value of the integrand is returned
//
// Speed:    This function is called by MC multiple times for a single
//           quadrature point during assembly, and needs to be a fast
//           as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double DFu_wv(PDE *thee, int key,
    double W[], double dW[][3],
    double V[], double dV[][3])
{
    int i;
    double value = 0.;

    /* interior form case */
    if (key == 0) {
        value = var->B * W[0] * V[0];
        for (i=0; i<thee->dim; i++)
            value += ( var->A * dW[0][i] * dV[0][i] );

    /* boundary form case */
    } else { /* (key == 1) */
        VASSERT(0);
    }

    return value;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  delta
//
// Purpose:  At the single given point x, evaluate a delta function
//           source term (if one is present): delta = g(x).
//
// Input:    PDE   = pointer to the PDE object
//           chart = chart in which the point coordinates are provided
//           txq[] = coordinates of the point
//
// Output:   F[]   = resulting function values
//
// Speed:    This function is called by MC once for each node in the mesh,
//           just after a full element-wise assembly, so it should be fast.
//
// Author:   Michael Holst and Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
#define VRINGMAX 1000
#define VATOMMAX 1000000
VPUBLIC void delta(PDE *thee, int type, int chart, double txq[], void *user, 
    double F[]) {

    int iatom, jatom, natoms;
    Vatom *atom;
    double *position, charge;

    int atomIndex, atomList[VATOMMAX], nAtomList, gotAtom;

    int numSring, isimp, ivert, sid;
    SS *sring[VRINGMAX];
    VV *vertex = (VV *)user;
    double phi[4], phix[4][3];
    double value;

    /* Assemble the simplex ring around this vertex */
    VASSERT( vertex != VNULL);
    numSring = 0;
    sring[numSring] = VV_firstSS(vertex);
    while (sring[numSring] != VNULL) {
        numSring++;
        sring[numSring] = SS_link(sring[numSring-1], vertex);
    }
    VASSERT( numSring > 0 );
    VASSERT( numSring <= VRINGMAX );

    /* Move around the simplex ring and determine the charge locations */
    F[0] = 0.;
    charge = 0.;
    nAtomList = 0;
    for (isimp=0; isimp<numSring; isimp++) {
        sid = SS_id(sring[isimp]);
        natoms = Vcsm_getNumberAtoms(Vfetk_getVcsm(var->fetk), sid);

        for (iatom=0; iatom<natoms; iatom++) {

            /* Get the delta function information */
            atomIndex = Vcsm_getAtomIndex(Vfetk_getVcsm(var->fetk), iatom, sid);
            gotAtom = 0;
            for (jatom=0; jatom<nAtomList; jatom++) {
                if (atomList[jatom] == atomIndex) {
                    gotAtom = 1;
                    break;
                }
            }
            if (!gotAtom) {
           
                VASSERT(nAtomList < VATOMMAX);
                atomList[nAtomList] = atomIndex;
                nAtomList++;

                atom = Vcsm_getAtom(Vfetk_getVcsm(var->fetk), iatom, sid);
                charge = Vatom_getCharge(atom);
                position = Vatom_getPosition(atom);


                /* Get the test function value at the delta function 
                 * 
                 * I used to do a VASSERT to make sure the point was in the 
                 * simplex (i.e., make sure round-off error isn't an issue), 
                 * but round off errors became an issue */
                if (!Gem_pointInSimplexVal(Vfetk_getGem(var->fetk), 
                  sring[isimp], position, phi, phix)) {
                    if (!Gem_pointInSimplex(Vfetk_getGem(var->fetk), 
                      sring[isimp], position)) {
                         Vnm_print(2, "delta: Both Gem_pointInSimplexVal and Gem_pointInSimplex detected misplaced point charge!\n");
                        Vnm_print(2, "delta: I think you have problems: phi = {");
                        for (ivert=0; ivert<Gem_dimVV(Vfetk_getGem(var->fetk)); 
                          ivert++) Vnm_print(2, "%e ", phi[ivert]);
                        Vnm_print(2, "}\n");
                    }
                }
                value = 0;
                for (ivert=0; ivert<Gem_dimVV(Vfetk_getGem(var->fetk)); ivert++) {
                    if (VV_id(SS_vertex(sring[isimp], ivert)) ==
                       VV_id(vertex)) value += phi[ivert];
                }


                F[0] += (value * Vpbe_getZmagic(var->fetk->pbe) * charge);
            }
        }
    }

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  u_D
//
// Purpose:  At the single given point x, evaluate the dirichlet boundary
//           function: u_D = g(x).
//
// Input:    PDE   = pointer to the PDE object
//           chart = chart in which the point coordinates are provided
//           txq[] = coordinates of the point
//
// Output:   F[]   = resulting function values
//
// Speed:    This function is called by MC just before a full assembly,
//           and does not have to be particularly fast.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void u_D(PDE *thee, int type, int chart, double txq[], double F[])
{ F[0] = my_U(thee->dim, txq); }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  u_T
//
// Purpose:  At the single given point x, evaluate the true solution
//           function (if you have one for your problem): u_T = u(x).
//
// Input:    PDE   = pointer to the PDE object
//           chart = chart in which the point coordinates are provided
//           txq[] = coordinates of the point
//
// Output:   F[]   = resulting function values
//
// Speed:    This function is called by MC just before a full assembly,
//           and does not have to be particularly fast.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void u_T(PDE *thee, int type, int chart, double txq[], double F[])
{ F[0] = my_U(thee->dim, txq); }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  bisectEdge
//
// Purpose:  Define the way manifold edges are bisected.
//
// Input:    The input parameters have the following interpretations:
//
//               dim                  = intrinsic dimension of the manifold
//               dimII                = imbedding dimension of the manifold
//               edgeType             = edge type being refined
//               chart[0]             = manifold chart for 0th vertex of edge
//               chart[1]             = manifold chart for 1st vertex of edge
//               vx[0][0,...,dimII-1] = 1st vertex coordinates w.r.t. chart[0]
//               vx[1][0,...,dimII-1] = 2nd vertex coordinates w.r.t. chart[1]
//
// Output:   The output parameters have the following interpretations:
//
//               chart[2]             = manifold chart for NEW 3rd vertex
//               vx[2][0,...,dimII-1] = 3rd vertex coordinates w.r.t. chart[2]
//
// Speed:    This function is called by MC every time an edge must be
//           bisected for simplex refinement, and needs to be as fast as
//           possible.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void bisectEdge(int dim, int dimII, int edgeType, int chart[], 
  double vx[][3]) {
    int i;
    for (i=0; i<dimII; i++) vx[2][i] = .5 * (vx[0][i] + vx[1][i]);
    chart[2] = pointAccessibility(dim, vx[2]);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  mapBoundary
//
// Purpose:  Define the way the boundary is mapped to some shape
//
// Author: Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void mapBoundary(int dim, int dimII, int vertexType, int chart, 
  double vx[3]) { }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  markSimplex
//
// Purpose:  User-provided error estimator which allows the user to define
//           his own refinement strategies rather than using the builtin
//           a posteriori error estimators.
//
// Input:    The input parameters have the following interpretations:
//
//               dim                  = intrinsic dimension of the manifold
//               dimII                = imbedding dimension of the manifold
//               simplexType          = simplex type being refined
//               chart[0,...,d+1]     = manifold charts for all d+1 vertices
//               vx[0][0,...,dimII-1] = vx[0] coordinates w.r.t. chart
//                       ...
//               vx[d][0,...,dimII-1] = vx[d] coordinates w.r.t. chart
//              *simplex              = a pointer to the simplex (or
//                                      nothing).  This is of void * type
//                                      and needs to be cast.
//
// Output:   The output parameters have the following interpretations:
//
//               return value         = 0 if the simplex is not to be refined
//                                    = 1 if the simplex is to be refined
//
// Speed:    This function is called by MC for every element during error
//           estimation, if the user-provided error estimator is requested.
//           Therefore, it should be pretty fast or the error estimation
//           phase will be slow.
//
// Notes:    The user can use this routine to define, for example,
//           a completely geometry-based error estimator.
//
// Example:  In the case that the user-provided error estimator is never
//           requested, then this routine can simply return any value.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int markSimplex(int dim, int dimII,
    int simplexType, int faceType[4], int vertexType[4],
    int chart[], double vx[][3], void *simplex) {

    /* This refines simplces with charges in them and simplices which straddle
     * the solvent-solute dielectric discontinuity.  */

    int i, accBit, natoms, refAcc;
    SS *simp; 
    Vcsm *csm;
    double edgeLength;
    simp = (SS *)simplex;

    /* Check to see if this simplex is smaller than the target size */
    Gem_longestEdge(var->fetk->gm, simp, &edgeLength);
    if (edgeLength < var->refineParm) return 0;

    /* Check to see if this simplex contains an atom.  If so, then it gets
     * marked for refinement */
    if ((var->refineCrit == 1) || (var->refineCrit == 0)) {
        csm = Vfetk_getVcsm(var->fetk);
        natoms = Vcsm_getNumberAtoms(csm, SS_id(simp));
        if (natoms > 0) return 1;
    }

    /* Check to see if this simplex lies on the molecular surface */
    if ((var->refineCrit == 2) || (var->refineCrit == 0)) {
        accBit = (int)VPOW(2, 2*currentMol);
        refAcc = ((chart[0] & accBit) != 0);
        for (i=1; i<dim+1; i++) {
            if (((chart[i] & accBit) != 0) != refAcc) return 1;
        }
    }

    return 0;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  oneChart
//
// Purpose:  Select a single unified chart for a set of two or more vertices
//           whose coordinates may be given with respect to different charts.
//           Then transform all of the coordinates of the vertex set to be
//           with respect to the single selected "unified" chart.
//
// Notes:    We use the chart to store the solvent accessiblity of the protein.
//           However, the routines which use the chart values use the values
//           from the individual vertices.  Therefore, for our application,
//           there is never any need to unify the chart.
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void oneChart(int dim, int dimII, int objType, int chart[], 
  double vx[][3], int dimV) { }

/* ///////////////////////////////////////////////////////////////////////////
// Class PDE: Inlineable methods
/////////////////////////////////////////////////////////////////////////// */
#if !defined(VINLINE_VMC)
#endif /* if !defined(VINLINE_VMC) */

/* ///////////////////////////////////////////////////////////////////////////
// Class PDE: Non-inlineable methods
/////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_ctor
//
// Purpose:  Construct the differential equation object.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC PDE* myPDE_ctor(void) {

    PDE *thee = VNULL;

    int i, imol;

    VDEBUGIO("PDE_ctor: CREATING object..");

    /* create some space for the pde object */
    thee = Vmem_malloc(VNULL, 1, sizeof(PDE) );

    /* PDE-specific parameters and function pointers */
    thee->initAssemble = initAssemble;  /* once-per-assembly initialization */
    thee->initElement  = initElement;   /* once-per-element initialization  */
    thee->initFace     = initFace;      /* once-per-face initialization     */
    thee->initPoint    = initPoint;     /* once-per-point initialization    */
    thee->Fu           = Fu;            /* nonlinear strong form            */
    thee->Fu_v         = Fu_v;          /* nonlinear weak form              */
    thee->DFu_wv       = DFu_wv;        /* bilinear linearization weak form */
    thee->delta        = delta;         /* delta function source term       */
    thee->u_D          = u_D;           /* dirichlet func and initial guess */
    thee->u_T          = u_T;           /* analytical soln for testing      */
    thee->vec          = 1; /* FIX! */  /* unknowns per spatial point;      */
    thee->sym[0][0]    = 1;             /* symmetries of bilinear form      */
    thee->est[0]       = 1.0;           /* error estimator weights          */
    for (i=0; i<VMAX_BDTYPE; i++)       /* boundary type remappings         */
        thee->bmap[0][i] = i;

    /* Manifold-specific function pointers */
    thee->bisectEdge  = bisectEdge;  /* edge bisection rule                 */
    thee->mapBoundary = mapBoundary; /* boundary recovery rule              */
    thee->markSimplex = markSimplex; /* simplex marking rule                */
    thee->oneChart    = oneChart;    /* coordinate transformations          */

    /* Element-specific function pointers */
    thee->simplexBasisInit = simplexBasisInit; /* initialization of bases   */
    thee->simplexBasisForm = simplexBasisForm; /* form trial & test bases   */

    /* Initialize the LocalVars array */
    for (imol=0; imol<MAXMOL; imol++) (varMOLS[imol]).fetk = VNULL;

    VDEBUGIO("..done.\n");

    /* return the new pde object */
    return thee;
}
/* ///////////////////////////////////////////////////////////////////////////
// Routine:  myPDE_init
//
// Purpose:  Initialize problem-specific details of the differential 
//           equation object.
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void myPDE_init(PDE* thee, Vfetk *tfetk) {

    int i, j, dim;
    double coord[4]; 
    VV *vert;

    /* Set local PBE object */
    var->fetk = tfetk;

    /* Set up the external Gem subdivision hook */
    Gem_setExternalUpdateFunction(var->fetk->gm, Gem_externalUpdateFunction);

    /* Get spatial dimension */
    dim = Gem_dim(var->fetk->gm);

    /* Map problem data to the mesh; i.e., reset the vertex charts */
    for (i=0; i<Gem_numVV(var->fetk->gm); i++) {
        vert = Gem_VV(var->fetk->gm,i);
        for (j=0; j<dim; j++) coord[j] = VV_coord(vert,j);
        VV_setChart(vert, pointAccessibility(dim, coord));
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_dtor
//
// Purpose:  Destroy the differential equation object.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void myPDE_dtor(PDE **thee)
{
    VASSERT( (*thee) != VNULL );
    if ((*thee) != VNULL) {

        VDEBUGIO("PDE_dtor: DESTROYING object..");
        Vmem_free(VNULL, 1, sizeof(PDE), (void **)thee);
        VDEBUGIO("..done.\n");

        (*thee) = VNULL;
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Gem_externalUpdateFunction
//
// Purpose:  The external hook to the simplex subdivision routines in Gem
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Gem_externalUpdateFunction(SS **simps, int num) { 
    int i;
    for (i=0; i<nMol; i++) {
        VASSERT( Vcsm_update(Vfetk_getVcsm(varMOLS[i].fetk), simps, num) ); 
    }
}
