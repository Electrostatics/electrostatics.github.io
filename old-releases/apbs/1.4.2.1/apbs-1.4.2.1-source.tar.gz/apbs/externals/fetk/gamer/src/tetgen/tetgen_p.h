/*
 * ***************************************************************************
 * File:     tetgen_p.h
 *
 * Purpose:  PRIVATE header.
 *
 * Author:   Michael Holst
 * ***************************************************************************
 */

#ifndef _TETGEN_P_H_
#define _TETGEN_P_H_

#include <gamer/tetgen.h>
#include "gamercf.h"

#endif /* _TETGEN_P_H_ */

