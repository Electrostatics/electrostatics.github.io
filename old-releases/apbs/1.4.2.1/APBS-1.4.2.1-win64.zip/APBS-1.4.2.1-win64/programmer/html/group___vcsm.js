var group___vcsm =
[
    [ "vcsm.c", "vcsm_8c.html", null ],
    [ "vcsm.h", "vcsm_8h.html", null ],
    [ "sVcsm", "structs_vcsm.html", [
      [ "alist", "structs_vcsm.html#ae0b1ff92bae2d15bb71adebfe53bbc17", null ],
      [ "gm", "structs_vcsm.html#a47e3990f869cc9afbc7c5ef756dd6236", null ],
      [ "initFlag", "structs_vcsm.html#a1fa18df106a71df86f7ce9780b65e88b", null ],
      [ "msimp", "structs_vcsm.html#a8ba04ef2735b51fa03bd1958c130609e", null ],
      [ "natom", "structs_vcsm.html#a681d92e8045df3ba705e04a70af0e9d5", null ],
      [ "nqsm", "structs_vcsm.html#a5f074ea44eaf3cbab23592e00e8254c2", null ],
      [ "nsimp", "structs_vcsm.html#a4c0bcf292fae096806030ce251a5de2c", null ],
      [ "nsqm", "structs_vcsm.html#ab7162641d0ac2f5dccb2b09c9b08389f", null ],
      [ "qsm", "structs_vcsm.html#acdc0286469f2269e057d386c0c756595", null ],
      [ "sqm", "structs_vcsm.html#a158de1853ad80a4df58be371723eca77", null ],
      [ "vmem", "structs_vcsm.html#adfacdf16f7a3cf04b35f4821208b5bdd", null ]
    ] ],
    [ "Vcsm", "group___vcsm.html#ga03db177f1f93081210039a71717ae1aa", null ],
    [ "Gem_setExternalUpdateFunction", "group___vcsm.html#ga7b9f8299d766954417fbe7b1e32a0cd7", null ],
    [ "Vcsm_ctor", "group___vcsm.html#ga1d66725c4983189360c728b9631a8eff", null ],
    [ "Vcsm_ctor2", "group___vcsm.html#ga2ebb21fbbab1e6289cbef4be2a1c7eee", null ],
    [ "Vcsm_dtor", "group___vcsm.html#gaad0c0e7464a412e83048e4429e0aa2f5", null ],
    [ "Vcsm_dtor2", "group___vcsm.html#ga0e901ff6e278e30b2e123988617e069d", null ],
    [ "Vcsm_getAtom", "group___vcsm.html#ga40138cd1d313a5c2c5084281711d5840", null ],
    [ "Vcsm_getAtomIndex", "group___vcsm.html#ga0e3fde08a6e77a09b189c15ff6150a70", null ],
    [ "Vcsm_getNumberAtoms", "group___vcsm.html#ga0cfc90d86ca9b99dae23a3695d182a0f", null ],
    [ "Vcsm_getNumberSimplices", "group___vcsm.html#ga76a4d5253b31f56e7425e447345e90af", null ],
    [ "Vcsm_getSimplex", "group___vcsm.html#ga3da427dd08b3966b7bf8748eaa8f8176", null ],
    [ "Vcsm_getSimplexIndex", "group___vcsm.html#gab29d4d56ce1a4c4aea7e4101058d1aa4", null ],
    [ "Vcsm_getValist", "group___vcsm.html#ga15bd9f7f5b439ddf2d49e3fdf6da2df3", null ],
    [ "Vcsm_init", "group___vcsm.html#ga30738e6aee65c9270cb08d8f0d3ddd79", null ],
    [ "Vcsm_memChk", "group___vcsm.html#ga88a368f4db53d7f440aa1cdefa15c143", null ],
    [ "Vcsm_update", "group___vcsm.html#ga1f198d23c919576813ec2f401ada0f18", null ]
];