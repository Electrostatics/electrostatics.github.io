var group___vstring =
[
    [ "vstring.c", "vstring_8c.html", null ],
    [ "vstring.h", "vstring_8h.html", null ],
    [ "Vstring_isdigit", "group___vstring.html#ga5ba567dcaf3c6ebfcc735cd101d96776", null ],
    [ "Vstring_strcasecmp", "group___vstring.html#ga8dd2348150c70288ebb00c8eb0b847e0", null ],
    [ "Vstring_wrappedtext", "group___vstring.html#ga3d6acf41ade32cfb9e14bc1b98a861e7", null ]
];