var searchData=
[
  ['radius',['radius',['../structs_vatom.html#a3f67c53b80389c5f53961936edba04c9',1,'sVatom::radius()'],['../structs_vparam___atom_data.html#a3f67c53b80389c5f53961936edba04c9',1,'sVparam_AtomData::radius()']]],
  ['readdata',['readdata',['../structs_vgrid.html#abf20537e721ce04919fff8b3cf6f780b',1,'sVgrid']]],
  ['readflatfileline',['readFlatFileLine',['../group___vparam.html#gaa7d2b71a92ebdbe0b847aec3de8669b4',1,'vparam.c']]],
  ['readxmlfileatom',['readXMLFileAtom',['../group___vparam.html#ga8b35934af27637a90fb419cdfe6f8fb5',1,'vparam.c']]],
  ['refsphere',['refSphere',['../structs_vacc.html#aeeef392d16dcd45b5781780ab5afd6d2',1,'sVacc']]],
  ['resdata',['resData',['../struct_vparam.html#a5ee9c6fcb7a45d6f227051a1f99f9ec1',1,'Vparam']]],
  ['resname',['resName',['../structs_vatom.html#a03835e9d9625128793923b9efeb9f5b8',1,'sVatom::resName()'],['../structs_vparam___atom_data.html#a2d2cbf6fa6927c7cd4fde3f2ec13690c',1,'sVparam_AtomData::resName()']]],
  ['returnenergy',['returnEnergy',['../group___frontend.html#ga2f46746dcc961b22df843ce5b779e9f2',1,'returnEnergy(Vcom *com, NOsh *nosh, double totEnergy[NOSH_MAXCALC], int iprint):&#160;routines.c'],['../group___frontend.html#ga2f46746dcc961b22df843ce5b779e9f2',1,'returnEnergy(Vcom *com, NOsh *nosh, double totEnergy[NOSH_MAXCALC], int iprint):&#160;routines.c']]],
  ['routines_2ec',['routines.c',['../routines_8c.html',1,'']]],
  ['routines_2eh',['routines.h',['../routines_8h.html',1,'']]],
  ['rparm',['rparm',['../structs_vpmg.html#a00cb02d8b9719e9574fc04283450b6be',1,'sVpmg']]],
  ['rwork',['rwork',['../structs_vpmg.html#a1ac4dfbbeb3bd0680998c80dee6e8e6a',1,'sVpmg']]]
];
