var searchData=
[
  ['readflatfileline',['readFlatFileLine',['../group___vparam.html#gaa7d2b71a92ebdbe0b847aec3de8669b4',1,'vparam.c']]],
  ['readxmlfileatom',['readXMLFileAtom',['../group___vparam.html#ga8b35934af27637a90fb419cdfe6f8fb5',1,'vparam.c']]],
  ['returnenergy',['returnEnergy',['../group___frontend.html#ga2f46746dcc961b22df843ce5b779e9f2',1,'returnEnergy(Vcom *com, NOsh *nosh, double totEnergy[NOSH_MAXCALC], int iprint):&#160;routines.c'],['../group___frontend.html#ga2f46746dcc961b22df843ce5b779e9f2',1,'returnEnergy(Vcom *com, NOsh *nosh, double totEnergy[NOSH_MAXCALC], int iprint):&#160;routines.c']]]
];
