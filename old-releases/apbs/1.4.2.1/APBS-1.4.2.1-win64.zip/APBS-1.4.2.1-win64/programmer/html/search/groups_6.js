var searchData=
[
  ['high_2dlevel_20front_2dend_20routines',['High-level front-end routines',['../group___frontend.html',1,'']]]
];
