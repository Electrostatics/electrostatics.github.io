var searchData=
[
  ['u',['U',['../structs_vfetk___local_var.html#a61a973a5933dea8ad6f9e2c83e649d2d',1,'sVfetk_LocalVar::U()'],['../structs_vpmg.html#a3b6b999a764f1e2ea94bb5f28c7a558c',1,'sVpmg::u()']]],
  ['u_5fd',['u_D',['../structs_vfetk___local_var.html#a19080d8a43cfe3397093cf14db07cfac',1,'sVfetk_LocalVar']]],
  ['u_5ft',['u_T',['../structs_vfetk___local_var.html#a99111d00163d60c22f50474da56f7ad2',1,'sVfetk_LocalVar']]],
  ['upper_5fcorner',['upper_corner',['../structs_vclist.html#a25cde36b526ca3f79228e79af1abfc47',1,'sVclist']]],
  ['useaqua',['useAqua',['../structs_m_gparm.html#a92fda61574f2e4d114e339f25924d9f2',1,'sMGparm']]],
  ['usechargemap',['useChargeMap',['../structs_p_b_eparm.html#a3e7c8b5aba81f00256dc7f302ed73722',1,'sPBEparm::useChargeMap()'],['../structs_vpmg.html#a3e7c8b5aba81f00256dc7f302ed73722',1,'sVpmg::useChargeMap()']]],
  ['usedielmap',['useDielMap',['../structs_p_b_eparm.html#acca699370036e8afa7b27284110ac7b9',1,'sPBEparm']]],
  ['usedielxmap',['useDielXMap',['../structs_vpmg.html#aabc9813d7bb766c5361e421db6efabb2',1,'sVpmg']]],
  ['usedielymap',['useDielYMap',['../structs_vpmg.html#a96d6eb86ab769d22e762da608c518190',1,'sVpmg']]],
  ['usedielzmap',['useDielZMap',['../structs_vpmg.html#a1735e6924b92c76dc0b4eb3f2501ee33',1,'sVpmg']]],
  ['usekappamap',['useKappaMap',['../structs_p_b_eparm.html#ad5f2fc675c0c6d12488dc6d02e599ade',1,'sPBEparm::useKappaMap()'],['../structs_vpmg.html#ad5f2fc675c0c6d12488dc6d02e599ade',1,'sVpmg::useKappaMap()']]],
  ['usemesh',['useMesh',['../structs_f_e_mparm.html#a07dd757a95d733e070ebf954b2ab36c7',1,'sFEMparm']]],
  ['usepotmap',['usePotMap',['../structs_p_b_eparm.html#a479180ef03324b15ca9b83f11fff70c5',1,'sPBEparm::usePotMap()'],['../structs_vpmg.html#a479180ef03324b15ca9b83f11fff70c5',1,'sVpmg::usePotMap()']]]
];
