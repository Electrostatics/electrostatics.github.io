/**
 *  @file    mypde.c
 *  @author  Nathan Baker
 *  @brief   FEtk PDE definition for Poisson-Boltzmann equation
 *  @version $Id: mypde.c,v 1.10 2002/01/04 17:20:51 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (nbaker@wasabi.ucsd.edu)
 * Dept. of Chemistry and Biochemistry
 * University of California, San Diego 
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 1999-2002. The Regents of the University of California
 *                          (Regents).  All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
 * TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 * @endverbatim
 */

#include "mypde.h"

VEMBED(rcsid="$Id: mypde.c,v 1.10 2002/01/04 17:20:51 apbs Exp $")

/* ///////////////////////////////////////////////////////////////////////////
// Local data
/////////////////////////////////////////////////////////////////////////// */

VPRIVATE double xq[3], nvec[3], vx[4][3], U[MAXV], dU[MAXV][3];
VPRIVATE double diam;
VPRIVATE int sType, fType, mycolor = 0;
VPRIVATE double A, B, DB;
VPRIVATE Vfetk *fetk;



/* ///////////////////////////////////////////////////////////////////////////
// Routine:  pointAccessibility
//
// Purpose:  Call VHASH code to determine the point's accessibility
//
// Arguments: dim    = Dimension of point
//            coord  = Point coordinates
//
// Returns:  The sum of accessibility bits (just like chmod):
//               #000b = 0 = the point is not accessibile to anything
//               #010b = 1 = the point is accessibile to the solvent
//               #100b = 2 = the point is accessibile to ions
//               #110b = 3 = the point is accessibile to ions and solvent
//               #100b = 4 = not used... 
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE int pointAccessibility(int dim, double coord[]) { 
    int accBit = 0;
    double srad = Vpbe_getSolventRadius(fetk->pbe);
    double irad = Vpbe_getMaxIonRadius(fetk->pbe);

    if (Vacc_molAcc(Vpbe_getVacc(fetk->pbe), coord, srad) == 1) accBit += 1;
    if (Vacc_ivdwAcc(Vpbe_getVacc(fetk->pbe), coord, irad) == 1) accBit += 2;

    return accBit;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  myPDE_setColor
//
// Purpose:  Set color of local partition
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void myPDE_setColor(int color) { mycolor = color; }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  my_A
//
// Purpose:  The dielectric coefficient in the Poisson-Boltzmann equation.
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE double my_A(int d, int accBit, double x[])
{
    if ( (accBit==1) || (accBit==3) ) return Vpbe_getSolventDiel(fetk->pbe);
    else return Vpbe_getSoluteDiel(fetk->pbe);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  my_B
//
// Purpose:  The linearized ion term in the Poisson-Boltzmann equation.
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE double my_B(int d, int accBit, double x[], double u[])
{
    if ( (accBit==2) || (accBit==3) ) return Vpbe_getZkappa2(fetk->pbe) * u[0];
    else return 0.;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  my_DB
//
// Purpose:  Derivative of the nonlinear source term in the
//           Poisson-Boltzmann equation.
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE double my_DB(int d, int accBit, double x[], double u[])
{
    if ( (accBit==2) || (accBit==3) ) return Vpbe_getZkappa2(fetk->pbe);
    else return 0.;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  my_U
//
// Purpose:  Dirichlet boundary function and initial approximation function.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double my_U(int d, double x[]) {

     const double e_c = 1.602e-19; /* in C */
     const double k_B = 1.380662000e-23; /* in J/K */
     const double eps0 = 8.854e-12; /* in F/m */
     const double pi = 3.1415927;
     double size, *position, charge, xkappa, eps_w, dist, T, val;
     int i;

     /* Get the solute radius in meters and position in angstroms */
     size = (1.0e-10)*Vpbe_getSoluteRadius(fetk->pbe);
     position = Vpbe_getSoluteCenter(fetk->pbe);

     /* We keep the charge relative to units of ec that are factored out;
      * this term should be dimensionless. The dielectric is unitless. */
     charge = e_c*Vpbe_getSoluteCharge(fetk->pbe);
     eps_w = Vpbe_getSolventDiel(fetk->pbe);

     /* Get xkappa in units of inverse meters */
     xkappa = (1.0e10)*Vpbe_getXkappa(fetk->pbe);

     /* The temperature is in units of K */
     T = Vpbe_getTemperature(fetk->pbe);

     /* Compute the distance (in units of m) */
     dist = 0;
     for (i=0; i<d; i++) dist += ((position[i] - x[i])*(position[i] - x[i]));
     dist = (1.0e-10)*VSQRT(dist);
    
     /* Compute the potential in J/electron */
     val = (charge)/(4*pi*eps0*eps_w*dist);
     if (xkappa != 0.0) val = val*(exp(-xkappa*(dist-size))/(1+xkappa*size));
     /* Scale the potential to be dimensionless */
     val = val*e_c/(k_B*T);
     
     return val;

}


/* ///////////////////////////////////////////////////////////////////////////
// Routine:  initAssemble
//
// Purpose:  Do once-per-assembly initialization.
//
// Input:    PDE = pointer to the PDE object
//           ip  = integer parameters for the assembly
//           rp  = real parameters for the assembly
//
// Output:   None
//
// Speed:    This function is called by MC just before a full assembly,
//           and does not have to be particularly fast.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void initAssemble(PDE *thee, int ip[], double rp[])
{
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  initElement
//
// Purpose:  Do once-per-element initialization.
//
// Input:    PDE         = pointer to the PDE object
//           elementType = type of this element (various material types)
//           chart       = chart in which vertex coordinates are provided
//           tvx[][3]    = coordinates of all the vertices of the element
//
// Output:   None
//
// Speed:    This function is called by MC just before assembling a single
//           element, and needs to be a fast as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void initElement(PDE *thee, int elementType, int chart, double
tvx[][3], void *data) {

    int i, j, k;
    double dx;

    /* vertex locations of this simplex */
    for (i=0; i<thee->dim+1; i++)
        for (j=0; j<thee->dim; j++)
            vx[i][j] = tvx[i][j];

    /* diameter (longest edge length) of this simplex */
    diam = 0.0;
    for (i=0; i<thee->dim; i++) {
        for (j=i+1; j<thee->dim+1; j++) {
            dx = 0.0;
            for (k=0; k<thee->dim; k++)
                dx += VSQR( vx[i][k] - vx[j][k] );
            dx = VSQRT( dx );
            diam = VMAX2( diam, dx );
        }
    }

    /* save the element type */
    sType = elementType;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  initFace
//
// Purpose:  Do once-per-face initialization.
//
// Input:    PDE      = pointer to the PDE object
//           faceType = type of this face (interior or various boundary types)
//           chart    = chart in which normal vector coordinates are provided
//           tnvec[]  = coordinates of the outward normal vector to this face
//
// Output:   None
//
// Speed:    This function is called by MC just before assembling a single
//           element face, and needs to be a fast as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void initFace(PDE *thee, int faceType,
    int chart, double tnvec[])
{
    int i;

    /* unit normal vector of this face */
    for (i=0; i<thee->dim; i++)
        nvec[i] = tnvec[i];

    /* save the face type */
    fType = faceType;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  initPoint
//
// Purpose:  Do once-per-point initialization.
//
// Input:    PDE       = pointer to the PDE object
//           pointType = type of this point (interior or boundary)
//           chart     = chart in which the point coordinates are provided
//           txq[]     = coordinates of the point
//           tU[]      = current solution at the point
//           tdU[]     = current solution gradient at the point
//
// Output:   None
//
// Speed:    This function is called by MC for every quadrature point
//           during an assmebly, and needs to be a fast as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void initPoint(PDE *thee, int pointType,
    int chart, double txq[],
    double tU[], double tdU[][3])
{
    int   i, j;

    /* the point, and the solution value and gradient at the point */
    for (i=0; i<thee->vec; i++) {
        U[i] = tU[i];
        for (j=0; j<thee->dim; j++) {
            if (i==0) xq[j] = txq[j];
            dU[i][j] = tdU[i][j];
        }
    }

    /* interior form case */
    if (pointType == 0) {

        A  = my_A(thee->dim,  chart, xq);
        B  = my_B(thee->dim,  chart, xq, U);
        DB = my_DB(thee->dim, chart, xq, U);

    /* boundary form case */
    } else { /* (pointType == 1) */
        VASSERT(0);
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Fu
//
// Purpose:  Evaluate the strong form of the differential operator F(u)
//           at the single point x.  This is your nonlinear strong form:
//              
//            [   b(u)^i - a(u)^{iq}_{~;q},   if t = 0
//     F(u) = [   c(u)^i + a(u)^{iq} n_q,     if t = 1
//            [   0      + a(u)^{iq} n_q,     if t = 2 
//
// Input:    PDE   = pointer to the PDE object
//           key   = piece to evaluate (0=interior, 1=boundary, 2=int-bndry)
//
// Output:   F[]   = operator piece evaluated at the point given to initPoint
//
// Speed:    This function is called by MC only when using error
//           estimation based on strong residuals.  The speed of this
//           function will impact the speed of the error estimator.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Fu(PDE *thee, int key, double F[])
{
    int j;

    /* element residual case */
    if (key == 0) {
        F[0] = 0.;

    /* neumann face residual case */
    } else if (key == 1) {
        F[0] = 0.;
        for (j=0; j<thee->dim; j++)
            F[0] += dU[0][j] * nvec[j];

    /* interior face residual case */
    } else { /* (key == 2) */
        F[0] = 0.;
        for (j=0; j<thee->dim; j++)
            F[0] += dU[0][j] * nvec[j];
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Fu_v
//
// Purpose:  Evaluate the integrand F(u)(v) of the functional <F(u),v>
//           at the single point x.  This is your nonlinear weak form:
//
//                /\                 /\
//     <F(u),v> = \  F_0(u)(v) dx +  \  F_1(u)(v) ds
//               \/m                \/dm
//
//                /\
//              = \  g_{ij} ( a(u)^{iq} v^j_{~;q} + b(u)^i v^j ) dx
//               \/m
//
//                /\
//              + \  g_{ij} c(u)^i v^j ds
//               \/dm
//
// Input:    PDE   = pointer to the PDE object
//           key   = integrand to evaluate (0=F_0, 1=F_1)
//           tV[]  = test function at the current point
//           tdV[] = test function gradient at the current point
//
// Output:   Value of the integrand is returned
//
// Speed:    This function is called by MC multiple times for a single
//           quadrature point during assembly, and needs to be a fast
//           as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double Fu_v(PDE *thee, int key,
    double V[], double dV[][3])
{
    int i;
    double value = 0.;

    /* interior form case */
    if (key == 0) {
        value = B * V[0];
        for (i=0; i<thee->dim; i++)
            value += ( A * dU[0][i] * dV[0][i] );

    /* boundary form case */
    } else { /* (key == 1) */
        VASSERT(0);
    }

    return value;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  DFu_wv
//
// Purpose:  Evaluate the integrand DF(u)(w,v) of the functional <DF(u)w,v>
//           at the single point x.  This is your bilinear weak form:
//
//                  /\                    /\
//     <DF(u)w,v> = \  DF_0(u)(w,v) dx +  \  DF_1(u)(w,v) ds
//                 \/m                   \/dm
//
//                  /\
//                = \  d/dt F_0(u+tw)(v)|_{t=0} dx
//                 \/m
//
//                  /\
//                + \  d/dt F_1(u+tw)(v)|_{t=0} ds
//                 \/dm
//
// Input:    PDE   = pointer to the PDE object
//           key   = integrand to evaluate (0=F_0, 1=F_1)
//           tW[]  = trial function at the current point
//           tdW[] = trial function gradient at the current point
//           tV[]  = test function at the current point
//           tdV[] = test function gradient at the current point
//
// Output:   Value of the integrand is returned
//
// Speed:    This function is called by MC multiple times for a single
//           quadrature point during assembly, and needs to be a fast
//           as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double DFu_wv(PDE *thee, int key,
    double W[], double dW[][3],
    double V[], double dV[][3])
{
    int i;
    double value = 0.;

    /* interior form case */
    if (key == 0) {
        value = DB * W[0] * V[0];
        for (i=0; i<thee->dim; i++)
            value += ( A * dW[0][i] * dV[0][i] );

    /* boundary form case */
    } else { /* (key == 1) */
        VASSERT(0);
    }

    return value;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  delta
//
// Purpose:  At the single given point x, evaluate a delta function
//           source term (if one is present): delta = g(x).
//
// Input:    PDE   = pointer to the PDE object
//           chart = chart in which the point coordinates are provided
//           txq[] = coordinates of the point
//
// Output:   F[]   = resulting function values
//
// Speed:    This function is called by MC once for each node in the mesh,
//           just after a full element-wise assembly, so it should be fast.
//
// Author:   Michael Holst and Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
#define VRINGMAX 1000
#define VATOMMAX 1000000
VPUBLIC void delta(PDE *thee, int type, int chart, double txq[], void *user, 
    double F[]) {

    int iatom, jatom, natoms;
    Vatom *atom;
    double *position, charge;

    int atomIndex, atomList[VATOMMAX], nAtomList, gotAtom;

    int numSring, isimp, ivert, sid;
    SS *sring[VRINGMAX];
    VV *vertex = (VV *)user;
    double phi[4], phix[4][3];
    double value;

    /* Assemble the simplex ring around this vertex */
    VASSERT( vertex != VNULL);
    numSring = 0;
    sring[numSring] = VV_firstSS(vertex);
    while (sring[numSring] != VNULL) {
        numSring++;
        sring[numSring] = SS_link(sring[numSring-1], vertex);
    }
    VASSERT( numSring > 0 );
    VASSERT( numSring <= VRINGMAX );

    /* Move around the simplex ring and determine the charge locations */
    F[0] = 0.;
    charge = 0.;
    nAtomList = 0;
    for (isimp=0; isimp<numSring; isimp++) {
        sid = SS_id(sring[isimp]);
        natoms = Vcsm_getNumberAtoms(Vfetk_getVcsm(fetk), sid);

        for (iatom=0; iatom<natoms; iatom++) {

            /* Get the delta function information */
            atomIndex = Vcsm_getAtomIndex(Vfetk_getVcsm(fetk), iatom, sid);
            gotAtom = 0;
            for (jatom=0; jatom<nAtomList; jatom++) {
                if (atomList[jatom] == atomIndex) {
                    gotAtom = 1;
                    break;
                }
            }
            if (!gotAtom) {
           
                VASSERT(nAtomList < VATOMMAX);
                atomList[nAtomList] = atomIndex;
                nAtomList++;

                atom = Vcsm_getAtom(Vfetk_getVcsm(fetk), iatom, sid);
                charge = Vatom_getCharge(atom);
                position = Vatom_getPosition(atom);


                /* Get the test function value at the delta function */
                VASSERT(Gem_pointInSimplexVal(Vfetk_getGem(fetk), 
                    sring[isimp], position, phi, phix));
                value = 0;
                for (ivert=0; ivert<Gem_dimVV(Vfetk_getGem(fetk)); ivert++) {
                    if (VV_id(SS_vertex(sring[isimp], ivert)) ==
                       VV_id(vertex)) value += phi[ivert];
                }

                F[0] += (value * Vpbe_getZmagic(fetk->pbe) * charge);
            }
        }
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  u_D
//
// Purpose:  At the single given point x, evaluate the dirichlet boundary
//           function: u_D = g(x).
//
// Input:    PDE   = pointer to the PDE object
//           chart = chart in which the point coordinates are provided
//           txq[] = coordinates of the point
//
// Output:   F[]   = resulting function values
//
// Speed:    This function is called by MC just before a full assembly,
//           and does not have to be particularly fast.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void u_D(PDE *thee, int type,
    int chart, double txq[], double F[])
{
    F[0] = my_U(thee->dim, txq);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  u_T
//
// Purpose:  At the single given point x, evaluate the true solution
//           function (if you have one for your problem): u_T = u(x).
//
// Input:    PDE   = pointer to the PDE object
//           chart = chart in which the point coordinates are provided
//           txq[] = coordinates of the point
//
// Output:   F[]   = resulting function values
//
// Speed:    This function is called by MC just before a full assembly,
//           and does not have to be particularly fast.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void u_T(PDE *thee, int type,
    int chart, double txq[], double F[])
{
    F[0] = my_U(thee->dim, txq);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  bisectEdge
//
// Purpose:  Define the way manifold edges are bisected.
//
// Input:    The input parameters have the following interpretations:
//
//               dim                  = intrinsic dimension of the manifold
//               dimII                = imbedding dimension of the manifold
//               edgeType             = edge type being refined
//               chart[0]             = manifold chart for 0th vertex of edge
//               chart[1]             = manifold chart for 1st vertex of edge
//               vx[0][0,...,dimII-1] = 1st vertex coordinates w.r.t. chart[0]
//               vx[1][0,...,dimII-1] = 2nd vertex coordinates w.r.t. chart[1]
//
// Output:   The output parameters have the following interpretations:
//
//               chart[2]             = manifold chart for NEW 3rd vertex
//               vx[2][0,...,dimII-1] = 3rd vertex coordinates w.r.t. chart[2]
//
// Speed:    This function is called by MC every time an edge must be
//           bisected for simplex refinement, and needs to be as fast as
//           possible.
//
// Notes:    The chart number indicates the accessibility of the vertex and is
//           assigned by summing accessibility bits (like chmod) in the
//           following fashion:
// 
//               #000b = 0 = the point is not accessibile to anything
//               #010b = 1 = the point is accessibile to the solvent
//               #100b = 2 = the point is accessibile to ions
//               #110b = 3 = the point is accessibile to ions and solvent
//               #100b = 4 = not used... 
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void bisectEdge(int dim, int dimII,
    int edgeType, int chart[], double vx[][3])
{
    int i;
    for (i=0; i<dimII; i++) vx[2][i] = .5 * (vx[0][i] + vx[1][i]);
    chart[2] = pointAccessibility(dim,vx[2]);
}

VPUBLIC void mapBoundary(int dim, int dimII,
    int vertexType, int chart, double vx[3])
{
    /* for the 2D test problem -- just return */
    if (dim==2) return;

    if (vertexType == 0) {
        /* do nothing */
    } else if (vertexType == 1) {
        /* handle outer boundary */
    } else { VASSERT(0); }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  markSimplex
//
// Purpose:  User-provided error estimator which allows the user to define
//           his own refinement strategies rather than using the builtin
//           a posteriori error estimators.
//
// Input:    The input parameters have the following interpretations:
//
//               dim                  = intrinsic dimension of the manifold
//               dimII                = imbedding dimension of the manifold
//               simplexType          = simplex type being refined
//               chart[0,...,d+1]     = manifold charts for all d+1 vertices
//               vx[0][0,...,dimII-1] = vx[0] coordinates w.r.t. chart
//                       ...
//               vx[d][0,...,dimII-1] = vx[d] coordinates w.r.t. chart
//              *simplex              = a pointer to the simplex (or
//                                      nothing).  This is of void * type
//                                      and needs to be cast.
//
// Output:   The output parameters have the following interpretations:
//
//               return value         = 0 if the simplex is not to be refined
//                                    = 1 if the simplex is to be refined
//
// Speed:    This function is called by MC for every element during error
//           estimation, if the user-provided error estimator is requested.
//           Therefore, it should be pretty fast or the error estimation
//           phase will be slow.
//
// Notes:    The user can use this routine to define, for example,
//           a completely geometry-based error estimator.
//
// Example:  In the case that the user-provided error estimator is never
//           requested, then this routine can simply return any value.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int markSimplex(int dim, int dimII,
    int simplexType, int faceType[4], int vertexType[4],
    int chart[], double vx[][3], void *simplex)
{

#if 0
    int i, j, natoms, refAcc;
    SS *simp;
    Vacc *acc;
    Vcsm *csm;
    double coord[3];
    double edgeLength;
    int color = 0;

    simp = (SS *)simplex;

    natoms = Vcsm_getNumberAtoms(Vfetk_getVcsm(fetk), SS_id((SS *)simplex));
    color = SS_chart((SS *)simplex);

    if ((natoms > 0) && (color == mycolor)) return 1;
    acc = Vpbe_getVacc(fetk->pbe);
    for (j=0; j<dimII; j++) coord[j] = vx[0][j];
    refAcc = Vacc_vdwAcc(acc, coord);
    for (i=1; i<dim+1; i++) {
        for (j=0; j<dimII; j++) coord[j] = vx[i][j];
        if ((Vacc_vdwAcc(acc, coord) != refAcc) && (color == mycolor)) return 1;
    }
#else
    int color = 0;
    color = SS_chart((SS *)simplex);
    if (color == mycolor) return 1;
#endif

    return 0;


}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  oneChart
//
// Purpose:  Select a single unified chart for a set of two or more vertices
//           whose coordinates may be given with respect to different charts.
//           Then transform all of the coordinates of the vertex set to be
//           with respect to the single selected "unified" chart.
//
// Input:    The input parameters have the following interpretations:
//
//               dim     = intrinsic dimension of the manifold
//               dimII   = imbedding dimension of the manifold
//               dimV    = number of vertices in the simplex
//                           dimV=1 ==> v is a single vertex
//                           dimV=2 ==> v is part of an edge
//                           dimV=3 ==> v is part of a triangle (or face)
//                           dimV=4 ==> v is part of a tetrahedron
//               objType = object type of the simplex
//                   dimV=1:
//                       type=?        ==> any interpretation
//                   dimV=2:
//                       type=0        ==> object is an interior edge
//                       type>0 & ODD  ==> object is a dirichlet edge
//                       type>0 & EVEN ==> object is a neumann edge
//                   dimV=3:
//                       dim=2
//                           type=anything ==> material type of triangle
//                       dim=3
//                           type=0        ==> object is an interior face
//                           type>0 & ODD  ==> object is a dirichlet face
//                           type>0 & EVEN ==> object is a neumann face
//                   dimV=4:
//                       type=anything ==> material type of tetrahedron
//               chart[] = current manifold chart numbers for input vertices
//               vx[][3] = original vertex coordinates w.r.t. charts in chart[]
//
// Output:   The output parameters have the following interpretations:
//
//               chart[] = selected (unified) output charts (all the same)
//               vx[][3] = new vertex coordinates w.r.t. new unified char
//
// Speed:    This function is called by MC whenever it encounters an element
//           with vertices having coordinates in different charts.  If you
//           many charts and thus many elements which stradle chart
//           boundaries, then you will want to make this as fast as possible.
//
// Notes:    In this routine, you define how to move from one chart to
//           another, which means you implicitly define how to change
//           coordinate systems.  The code allows the user to select the
//           appropriate chart for the vertices of an object in order to give
//           the user maximal control over how he uses coordinate systems to
//           represent a manifold.
//
//           The caller gives the user a set of vertex coordinates for two or
//           more vertices that are a part of some simplex (edge, triangle,
//           or tet).  The vertex coordinates may be given with respect to
//           different charts if the simplex happens to stradle two charts.
//
//           Our job is to select the most appropriate chart based on the
//           simplex class (edge, tri, or tet) and the simplex type (interior
//           or boundary for edges, or triangular boundary faces, or some
//           material type for triangles or tets), and then transform all
//           of the vertex coordinates to the single coordinate system
//           you have selected.  You then pass back the chart number that you
//           have selected, along with the new coordinates.
//
// Example:  In the simple case of a single chart covering the manifold,
//           this routine can simply return without modifying either
//           chart or vx.
//
// Author:   Michael Holst and Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void oneChart(int dim, int dimII,
    int objType, int chart[], double vx[][3], int dimV)
{


    int i, ichart;

    VASSERT( (2 <= dim)   && (dim   <= 3) );
    VASSERT( (2 <= dimII) && (dimII <= 3) );
    VASSERT( (1 <= dimV)  && (dimV  <= 4) );
    VASSERT( (0 <= objType) );

    if (dimV == 1) ichart = pointAccessibility(dim,vx[0]);
    else {
        ichart = 0; 
        for (i=0; i<dimV; i++) {
            if (chart[i] > 0) ichart = chart[i];
        }
    }
    for (i=0; i<dimV; i++) chart[i] = ichart;
}

/* ///////////////////////////////////////////////////////////////////////////
// Class PDE: Inlineable methods
/////////////////////////////////////////////////////////////////////////// */
#if !defined(VINLINE_VMC)
#endif /* if !defined(VINLINE_VMC) */

/* ///////////////////////////////////////////////////////////////////////////
// Class PDE: Non-inlineable methods
/////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_ctor
//
// Purpose:  Construct the differential equation object.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC PDE* myPDE_ctor(void)
{
    PDE *thee = VNULL;

    int i;

    VDEBUGIO("PDE_ctor: CREATING object..");

    /* create some space for the pde object */
    thee = Vmem_malloc(VNULL, 1, sizeof(PDE) );

    /* PDE-specific parameters and function pointers */
    thee->initAssemble = initAssemble;  /* once-per-assembly initialization */
    thee->initElement  = initElement;   /* once-per-element initialization  */
    thee->initFace     = initFace;      /* once-per-face initialization     */
    thee->initPoint    = initPoint;     /* once-per-point initialization    */
    thee->Fu           = Fu;            /* nonlinear strong form            */
    thee->Fu_v         = Fu_v;          /* nonlinear weak form              */
    thee->DFu_wv       = DFu_wv;        /* bilinear linearization weak form */
    thee->delta        = delta;         /* delta function source term       */
    thee->u_D          = u_D;           /* dirichlet func and initial guess */
    thee->u_T          = u_T;           /* analytical soln for testing      */
    thee->vec          = 1; /* FIX! */  /* unknowns per spatial point;      */
    thee->sym[0][0]    = 1;             /* symmetries of bilinear form      */
    thee->est[0]       = 1.0;           /* error estimator weights          */
    for (i=0; i<VMAX_BDTYPE; i++)       /* boundary type remappings         */
        thee->bmap[0][i] = i;

    /* Manifold-specific function pointers */
    thee->bisectEdge  = bisectEdge;  /* edge bisection rule                 */
    thee->mapBoundary = mapBoundary; /* boundary recovery rule              */
    thee->markSimplex = markSimplex; /* simplex marking rule                */
    thee->oneChart    = oneChart;    /* coordinate transformations          */

    /* Element-specific function pointers */
    thee->simplexBasisInit = simplexBasisInit; /* initialization of bases   */
    thee->simplexBasisForm = simplexBasisForm; /* form trial & test bases   */

    VDEBUGIO("..done.\n");

    /* return the new pde object */
    return thee;
}
/* ///////////////////////////////////////////////////////////////////////////
// Routine:  myPDE_init
//
// Purpose:  Initialize problem-specific details of the differential 
//           equation object.
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void myPDE_init(PDE* thee, Vfetk *tfetk)
{
    VASSERT(tfetk != VNULL);
    fetk = tfetk;
    /* Set up the external Gem subdivision hook */
    Gem_setExternalUpdateFunction(fetk->gm, Gem_externalUpdateFunction);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_dtor
//
// Purpose:  Destroy the differential equation object.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void myPDE_dtor(PDE **thee)
{
    VASSERT( (*thee) != VNULL );
    if ((*thee) != VNULL) {

        VDEBUGIO("PDE_dtor: DESTROYING object..");
        Vmem_free(VNULL, 1, sizeof(PDE), (void **)thee);
        VDEBUGIO("..done.\n");

        (*thee) = VNULL;
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Gem_externalUpdateFunction
//
// Purpose:  The external hook to the simplex subdivision routines in Gem
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Gem_externalUpdateFunction(SS **simps, int num) 
{ VASSERT( Vcsm_update(Vfetk_getVcsm(fetk), simps, num) ); }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  AM_smoothEstimate
//
// Purpose:  Smooth per-simplex error estimates before partitioning
//
//    Args:  level -- current level of the algebra manager
//           gm    -- geometry manager
//           alpha -- smoothing parameter (>0), try 0.2
//
//  Author:  Nathan Baker and Dave Sept
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void AM_smoothEstimate(AM *thee, int level, Gem *gm, double alpha) {

    Bvec *nevec, *evec;
    double currEst, nborEst;
    Alg *alg; 
    SS *currSS, *nborSS;
    int i, j, nnbor;
  

    VASSERT(thee != VNULL); 
    VASSERT(gm != VNULL); 
    VASSERT(alpha > 0);

    alg = AM_alg(thee,level);
    VASSERT(alg != VNULL);
    evec = alg->WE[WE_err];
    nevec = Bvec_ctor(VNULL, evec->name, evec->numB, evec->numR);

    for (i=0; i<Gem_numSS(gm); i++) {
        currSS = Gem_SS(gm,i);
        currEst = Bvec_val(evec, 0, i);
        nborEst = 0;
        nnbor = 0;
        for (j=0; j<Gem_dimVV(gm); j++) {
            nborSS = SS_nabor(currSS, j);
            if (nborSS != VNULL) {
                nborEst += Bvec_val(evec, 0, SS_id(nborSS));
                nnbor++;
            }
        }
        VASSERT(nnbor > 0);
        nborEst = nborEst/((double)nnbor);
        currEst = currEst + alpha*(nborEst - currEst);
        Bvec_set(nevec, 0, i, currEst);
    }

    Bvec_dtor(&(alg->WE[WE_err]));
    alg->WE[WE_err] = nevec;
    
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  AM_writeSimplexGV
//
// Purpose:  Write out a simplex-valued function in "Geomview OFF" format to a
//           file or socket
//
// Notes:    A shameless rip-off of other I/O routines written by Mike Holst
//
// Author:   Nathan Baker and Mike Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void AM_writeSimplexGV(AM *thee, int lev, const char *iodev, 
  const char *iofmt, const char *theHost, const char *theSock, int number) {

    int tstOk = ((lev >= thee->minLevel) && (lev <= thee->maxLevel));
    if (!tstOk) {
        Vnm_print(2,"AM_writeUCD: lev=<%d> is incorrect.\n",lev);
        return;
    } else {
        if (number == -WE_err) number = WE_err;
        Vnm_print(0,"AM_writeSimplexGV: printing <%s>\n", WE_name[number]);
        Alg_writeSimplexGV( AM_alg(thee,lev), iodev, iofmt, theHost, theSock,
          number );
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Alg_writeSimplexGV
//
// Purpose:  Plot a simplex-valued function over the finite element mesh
//
// Note:     This routine is a shameless rip-off of other I/O routines written
//           by Mike Holst
//
// Author:   Nathan Baker and Mike Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Alg_writeSimplexGV(Alg *thee, const char *iodev, const char
  *iofmt, const char *theHost, const char *theSock, int number) {

    int i,fldKey;
    double *defX[MAXV];
    fldKey = Alg_vec(thee);
    for (i=0; i<MAXV; i++)
        defX[i] = VNULL;
    for (i=0; i<fldKey; i++)
        defX[i] = Bvec_data(thee->WE[number],i);
    Gem_writeSimplexGV(thee->gm,iodev,iofmt,theHost,theSock, number, -1, defX);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Gem_writeSimplexGV
//
// Purpose:  Plot a simplex-valued function over the finite element mesh
      defKey, -1, 1.0, defX, 0);
//
// Note:     This routine is a shameless rip-off of other I/O routines written 
//           by Mike Holst
//
// Author:   Nathan Baker and Mike Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Gem_writeSimplexGV(Gem *thee, const char *iodev, 
  const char *iofmt, const char *thost, const char *fname, int number, 
  int chartKey, double *defX[MAXV]) {

    int i, ii, numVV, numSS, face, fType, theDim;
    int numVVchart, numSSchart;
    double theColor[3], y[3];
    double maxVal, minVal;
    VV *vx;
    SS *sm;
    Vio *sock;

    /* some error checking */
    VJMPERR2( (Gem_numVV(thee) > 0) && (Gem_numSS(thee) > 0) );

    /* deal with socket or file setup */
    Vnm_print(0,"Gem_writeGV: Started writing file <%s>\n", fname);
    if ( VNULL == (sock=Vio_ctor(iodev,iofmt,thost,fname,"w")) ) {
        Vnm_print(2,"Gem_writeGV: Problem opening file <%s>\n", fname);
        VJMPERR2( 0 );
    }

    /* START WRITE (blocking connect) */
    if ( 0 > Vio_connect(sock,0) ) {
        Vnm_print(2,"Gem_writeGV: Problem connecting file <%s>\n", fname);
        VJMPERR1( 0 );
    }

    /* Get the max/min values from the defX */
    maxVal = defX[number][0];
    minVal = defX[number][0];
    for (i=0; i<Gem_numSS(thee); i++) {
        if (maxVal > defX[number][i]) maxVal = defX[number][i];
        if (minVal < defX[number][i]) minVal = defX[number][i];
    }
    

    theDim = Gem_dim(thee);
    /* count how many simplices we will actually deal with */
    numSSchart = 0;
    for (i=0; i<Gem_numSS(thee); i++) {
        sm = Gem_SS(thee,i);
        if ((chartKey < 0) || (SS_chart(sm) == chartKey))
            numSSchart++;
    }
    numVVchart = Gem_numVV(thee);

    /* determine the correct number of vertices and simplices */
    if (theDim==2) {
        numSS = numSSchart;
        numVV = numVVchart;
    } else {
        numSS = 4 * numSSchart;
        numVV = 1 * numVVchart;
    }

    /* write the volume header */
    Gem_writeVolHeaderOFF(thee, sock);

    /* write out the "OFF" header */
    Vio_printf(sock,"%s\n","OFF");
    Vio_printf(sock,"%d %d %d\n", numVV, numSS, 0);

    /* write out the vertex data */
    for (vx=Gem_firstVV(thee);vx!=VNULL;vx=Gem_nextVV(thee)) {
        for (i=0;i<3;i++) y[i]=VV_coord(vx,i);
        Vio_printf(sock,"%10.3e %10.3e %10.3e\n", y[0], y[1], y[2]);
    }

    /* write out the simplex data */
    ii=0;
    for (sm=Gem_firstSS(thee);sm!=VNULL;sm=Gem_nextSS(thee)) {
        if ((chartKey < 0) || (SS_chart(sm) == chartKey)) {
            if (theDim==2) {
                fType = 0;
                theColor[0] = 1.0-(defX[number][SS_id(sm)]-minVal)/(maxVal-minVal);
                theColor[1] = 1.0-(defX[number][SS_id(sm)]-minVal)/(maxVal-minVal);
                theColor[2] = 1.0-(defX[number][SS_id(sm)]-minVal)/(maxVal-minVal);
                Vio_printf(sock,
                    "%d %d %d %d %4.2f %4.2f %4.2f\n",
                    3,
                    VV_id( SS_vertex(sm,0) ),
                    VV_id( SS_vertex(sm,1) ),
                    VV_id( SS_vertex(sm,2) ),
                    theColor[0], theColor[1], theColor[2]
                );
                ii++;
            } else {
                for (face=0; face<4; face++) {
                    fType = 0;
                    theColor[0] = 1.0-(defX[number][SS_id(sm)]-minVal)/(maxVal-minVal);
                    theColor[1] = 1.0-(defX[number][SS_id(sm)]-minVal)/(maxVal-minVal);
                    theColor[2] = 1.0-(defX[number][SS_id(sm)]-minVal)/(maxVal-minVal);
                    Vio_printf(sock,
                        "%d %d %d %d %4.2f %4.2f %4.2f\n",
                        3,
                        VV_id( SS_vertex(sm,vmapF[face][0]) ),
                        VV_id( SS_vertex(sm,vmapF[face][1]) ),
                        VV_id( SS_vertex(sm,vmapF[face][2]) ),
                        theColor[0], theColor[1], theColor[2]
                    );
                    ii++;
                }
            }
        }
    }
    VASSERT( ii == numSS );


    /* write the last line and flush any buffers */
    Vio_printf(sock,"\n");

    /* write the trailer */
    Gem_writeTrailerOFF(thee, sock);

    /* FINISH WRITE */
    Vio_connectFree(sock);

    /* finish up */
    Vio_dtor(&sock);
    Vnm_print(0,"Gem_writeGV: Finished writing file <%s>\n", fname);

    /* return with no errors */
    return;

  VERROR1:
    Vio_dtor(&sock);

  VERROR2:
    Vnm_print(2,"Gem_writeGV: Detected a problem (bailing out).\n");
    return;


}



