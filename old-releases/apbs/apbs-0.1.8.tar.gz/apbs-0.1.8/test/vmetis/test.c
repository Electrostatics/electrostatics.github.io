/**
 *  @file    test.c
 *  @author  Nathan Baker
 *  @brief   Test code for Vmetis class
 *  @version $Id: test.c,v 1.23 2002/01/04 17:20:51 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (nbaker@wasabi.ucsd.edu)
 * Dept. of Chemistry and Biochemistry
 * University of California, San Diego 
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 1999-2002. The Regents of the University of California
 *                          (Regents).  All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
 * TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 * @endverbatim
 */

#define BADPART 1

#include "mc/mc.h"  
#include "mcx/mcx.h"  
#include "apbscfg.h"
#include "apbs/vpbe.h"  
#include "apbs/vfetk.h"  
#include "apbs/vpee.h"  
#include "apbs/vunit.h"  
#include "mypde.h"

VEMBED(rcsid="$Id: test.c,v 1.23 2002/01/04 17:20:51 apbs Exp $")

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    /* Objects for solver */
    PDE *pde = VNULL;
    AM *am = VNULL;
    MCsh *vmc = VNULL;
    Gem *gm = VNULL;
    Vpbe *pbe = VNULL;
    Vfetk *fetk = VNULL;
    Vatom *atom = VNULL;
    SS *simp = VNULL;
    Valist *alist = VNULL;
    Vmetis *metis = VNULL;

    /* Information for I/O */
    Vio *sock;
    char *mcsf_path;
    char *pqr_path;
    char *sepline =
      "--------------------------------------------------------";

    /* PBE parameters */
    double T = 298.15;
    double soluteDiel = 1.0;
    double solventDiel = 78.54;
    double solventRadius = 1.40;
    int nion = 2;
    double ionConc[MAXION];
    double ionRadii[MAXION];
    double ionQ[MAXION];

    /* Parameters for solving */
    int level = 0;
    int akey = 0;
    int lkey = 5;
    int lmax = 100;
    double ltol = 1.0e-07;
    double etol = 1.0;
    int gues = 2;
    int pjac = 2;
    int partsimps = 10;
    int i,nsimps, marked;
    int nsmooth = 10;
    double alpha = 0.5;

    /* Parameters for (simulation of) parallel evaluation */
    int npart = 16;
    int *pcount, *acount, ppow, iatom, ipart, isimp, ivert, idim, *weights;
    double coord[MAXV];
    int partWeight = 1;

    /* *************** CHECK INVOCATION ******************* */
    ionConc[0] = 0.000;
    ionRadii[0] = 2.000;
    ionQ[0] = -1.000;
    ionConc[1] = 0.000;
    ionRadii[1] = 2.000;
    ionQ[1] = 1.000;
    Vio_start();
    if (argc != 3) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected 3.\n",argc);
        Vnm_print(2,"*** Usage: test <mesh.m> <charge.pqr>\n\n");
        VASSERT(0);
    } else {
        mcsf_path = argv[1];
        pqr_path = argv[2];
    }

    /* *************** MC INITIALIZATION ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STARTING MC INITIALIZATION\n");
    Vnm_print(1,"main: Constructing PDE object.\n");
    pde = myPDE_ctor();
    Vnm_print(1,"main: Constructing MCsh object.\n");
    vmc = MCsh_ctor(pde,argc,argv);

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STARTING APBS INITIALIZATION\n");
    /* Get VGM and AM object */
    Vnm_print(1,"main: Retrieving GM and AM from VMC.\n");
    gm = vmc->gm;
    am = vmc->am;
    /* Read mesh */
    Vnm_print(1,"main: AM reading mesh from %s.\n",mcsf_path);
    sock = Vio_ctor("FILE", "ASC", VNULL, mcsf_path, "r");
    AM_getMesh(am, 0, sock);
    Vio_dtor(&sock);
    
    /* Build Valist and Vpbe -- these steps must occur before setting PBE
     * system parameters */
    Vnm_print(1,"main: Constructing VALIST object.\n");
    alist = Valist_ctor();
    Vnm_print(1,"main: Reading atom list from %s.\n",pqr_path);
    Valist_readPQR(alist, "FILE", "ASC", VNULL, pqr_path);
    Vnm_print(1,"main: Constructing VPBE object.\n");
    pbe = Vpbe_ctor(alist, nion, ionConc, ionRadii, ionQ, T, 
      soluteDiel, solventDiel, solventRadius);
    VASSERT(pbe != VNULL);
    for (i=0; i<nion; i++) {
        Vnm_print(1,"main:   Ion #%d conc   %4.3f M\n", i, ionConc[i]);
        Vnm_print(1,"main:   Ion #%d radius %4.3f A\n", i, ionRadii[i]);
        Vnm_print(1,"main:   Ion #%d charge %4.3f e\n", i, ionQ[i]);
    }
    Vnm_print(1,"main:        Temperature   %4.3f K\n",
      Vpbe_getTemperature(pbe));
    Vnm_print(1,"main:  Solute dielectric   %4.3f \n",
      Vpbe_getSoluteDiel(pbe));
    Vnm_print(1,"main:      Solute charge   %4.3f \n",
      Vpbe_getSoluteCharge(pbe));
    Vnm_print(1,"main: Solute eff. radius   %4.3f \n",
      Vpbe_getSoluteRadius(pbe));
    Vnm_print(1,"main:      Solute center   (%4.3f, %4.3f, %4.3f) \n",
      Vpbe_getSoluteCenter(pbe)[0], Vpbe_getSoluteCenter(pbe)[1],
      Vpbe_getSoluteCenter(pbe)[2]);
    Vnm_print(1,"main: Solvent dielectric   %4.3f \n",
      Vpbe_getSolventDiel(pbe));
    Vnm_print(1,"main:     Solvent radius   %4.3f A\n",
      Vpbe_getSolventRadius(pbe));
    Vnm_print(1,"main:             xkappa   %4.3f A^-1\n",
      Vpbe_getXkappa(pbe));

    /* Construct/initialize solver-related objects */
    fetk = Vfetk_ctor(pbe, gm, am);
    myPDE_init(pde, fetk);
    metis = Vmetis_ctor(gm);

    AM_algInit(am, level);
    sock = Vio_ctor("FILE", "ASC", "localhost", "initm.off", "w");
    AM_writeGV(am, level, sock, 0, 1, -1, 1.0, -1, 0);
    Vio_dtor(&sock);

    /* *************** PRE-SOLVE TASKS ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STARTING PRE-SOLVER TASKS\n");
    myPDE_setColor(0);
    level = 0;
    AM_algInit(am, level);
    sock = Vio_ctor("FILE", "ASC", "localhost", "initm.off", "w");
    AM_writeGV(am, level, sock, 0, 1, -1, 1.0, -1, 0);
    Vio_dtor(&sock);
    Vnm_print(1,"main: Refining mesh to >%d simplices [",partsimps*npart);
    nsimps = Gem_numSS(gm);
    while (nsimps < partsimps*npart) {
        AM_algInit(am, level);
        /* Error-based refinement requires a solution */
        if (akey == 2) AM_lSolve(am, level, 0, lkey, lmax, ltol, gues, pjac);
        marked = AM_markRefine(am,level,akey,-1,1,etol);
        if (marked == 0) AM_markRefine(am,level,0,-1,1,etol);
        Gem_refine(gm, 0, 1);
        nsimps = Gem_numSS(gm);
        Vnm_print(1,"%d ",nsimps);
        level++;
    }
    Vnm_print(1,"]\n");

    AM_algInit(am, level);
    if (partWeight == 0) {
        Vnm_print(1,"main: Unweighted partitioning the mesh into %d pieces...\n", npart);
    } else if (partWeight == 1) {
        Vnm_print(1,"main: Error-weighted partitioning the mesh into %d pieces...\n", npart);
        sock = Vio_ctor("FILE", "ASC", "localhost", "pre-part.off", "w");
        AM_writeGV(am, level, sock, 0, 1, -1, 1.0, -1, 0);
        Vio_dtor(&sock);
        AM_lSolve(am, level, 0, lkey, lmax, ltol, gues, pjac);
        AM_markRefine(am,level,2,-1,1,etol);
        AM_writeSimplexGV(am, level, "FILE", "ASC", "localhost", 
          "error-init.off", 0);
        Vnm_print(1, "main: Smoothing estimate %d times (alpha = %g)\n", 
          nsmooth, alpha);
        for (i=0; i<nsmooth; i++) AM_smoothEstimate(am, level, gm, alpha);
        AM_writeSimplexGV(am, level, "FILE", "ASC", "localhost", 
          "error-smooth.off", 0);
        for (i=0; i<Gem_numSS(gm); i++) {
            VASSERT(Bvec_val((AM_alg(am, level))->WE[WE_err], 0, i) >= 0);
        }
#ifndef BADPART
        Vmetis_partition(metis, npart, am, level, partWeight, VNULL);
#else
        ppow = rint(log(npart)/log(2.0));
        npart = (int)VPOW(2,(double)ppow);
        Vnm_print(1, "main: Using FEtk to partition into %d (=2^%d) pieces\n", 
          npart, ppow);
        AM_part(am, level, 1, 1, ppow);
#endif
    } else if (partWeight == 2) {
        Vnm_print(1,"main: Accesibility-weighted partitioning the mesh into %d pieces...\n", npart);
        weights = (int *)Vmem_malloc(VNULL, Gem_numSS(gm), sizeof(int));
        Vnm_print(1, "main: Gem_dimVV(gm) = %d\n", Gem_dimVV(gm));
        coord[0] = 0;
        coord[1] = 0;
        coord[2] = 0;
        for (isimp=0; isimp<Gem_numSS(gm); isimp++) {
            weights[isimp] = 1;
            simp = Gem_SS(gm, isimp);
            for (ivert=0; ivert<Gem_dimVV(gm); ivert++) {
                for (idim=0; idim<(Gem_dimVV(gm)-1); idim++) {
                    coord[idim] = VV_coord(SS_vertex(simp, ivert), idim);
                }
                if (Vacc_ivdwAcc(Vpbe_getVacc(pbe), coord, 
                  Vpbe_getMaxIonRadius(pbe))==0) {
                    weights[isimp] = Gem_numSS(gm);
                    break;
                }
            }
        }
        Vmetis_partition(metis, npart, am, level, partWeight, weights);
        Vmem_free(VNULL, Gem_numSS(gm), sizeof(int), (void **)&weights);
    }
    AM_algInit(am, level);
    sock = Vio_ctor("FILE", "ASC", "localhost", "part.off", "w");
    AM_writeGV(am, level, sock, 0, 1, -1, 1.0, -1, 0);
    Vio_dtor(&sock);
    Vfetk_setAtomColors(fetk);

    pcount = Vmem_malloc(VNULL, npart, sizeof(int));
    acount = Vmem_malloc(VNULL, npart, sizeof(int));
    for (ipart=0; ipart<npart; ipart++) {
      pcount[ipart] = 0;
      acount[ipart] = 0;
    }
    for (isimp=0; isimp<Gem_numSS(gm); isimp++) {
        pcount[SS_chart(Gem_SS(gm, isimp))]++;
    }
    for (iatom=0; iatom<Valist_getNumberAtoms(Vpbe_getValist(pbe)); iatom++) {
        atom = Valist_getAtom(Vpbe_getValist(pbe), iatom);
        (acount[Vatom_getPartID(atom)])++;
    }
    for (ipart=0; ipart<npart; ipart++) {
        Vnm_print(1, "main: Partition #%d has %d simplices and %d atoms\n", 
          ipart, pcount[ipart], acount[ipart]);
    }

    /* *************** GARBAGE COLLECTION ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STARTING GARBAGE COLLECTION\n");
    VASSERT(pbe != VNULL);
    Vnm_print(1,"main: Destroying VPBE\n");
    Vpbe_dtor(&pbe);
    VASSERT(alist != VNULL);
    Vnm_print(1,"main: Destroying VALIST\n");
    Valist_dtor(&alist);
    VASSERT(vmc != VNULL);
    Vnm_print(1,"main: Destroying VFETK\n");
    Vfetk_dtor(&fetk);
    VASSERT(vmc != VNULL);
    Vnm_print(1,"main: Destroying VMC\n");
    MCsh_dtor(&vmc);
    VASSERT(pde != VNULL); 
    Vnm_print(1,"main: Destroying PDE\n");
    myPDE_dtor(&pde);

    /* *************** THE END ******************* */
    Vnm_print(1,"\nmain: %s\n", sepline);
    Vnm_print(1,"main: STOPPING EXECUTION\n");
    return 0;
}
