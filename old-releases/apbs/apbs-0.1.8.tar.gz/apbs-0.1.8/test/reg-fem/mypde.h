/**
 *  @file    mypde.h
 *  @author  Nathan Baker
 *  @brief   FEtk PDE definition for Poisson-Boltzmann equation
 *  @version $Id: mypde.h,v 1.4 2002/01/04 17:20:51 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (nbaker@wasabi.ucsd.edu)
 * Dept. of Chemistry and Biochemistry
 * University of California, San Diego 
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 1999-2002. The Regents of the University of California
 *                          (Regents).  All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
 * TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 * @endverbatim
 */

#include "apbscfg.h"
#include "mc/mc.h"
#include "mcx/mcx.h"
#include "apbs/apbs.h"

VEMBED(rcsid="$Id: mypde.h,v 1.4 2002/01/04 17:20:51 apbs Exp $")

/* ///////////////////////////////////////////////////////////////////////////
// Required prototypes
/////////////////////////////////////////////////////////////////////////// */

VEXTERNC PDE* myPDE_ctor();
VEXTERNC void myPDE_dtor(PDE **thee);
VEXTERNC void myPDE_init(PDE* thee, Vfetk *fetk);

VEXTERNC void initAssemble(PDE *thee, int ip[], double rp[]);
VEXTERNC void initElement(PDE *thee, int elementType, int chart, 
    double tvx[][3], void *data);
VEXTERNC void initFace(PDE *thee, int faceType, int chart, double tnvec[]);
VEXTERNC void initPoint(PDE *thee, int pointType, int chart, double txq[], 
    double tU[], double tdU[][3]);

VEXTERNC void Fu(PDE *thee, int key, double F[]);
VEXTERNC double Fu_v(PDE *thee, int key, double V[], double dV[][3]);
VEXTERNC double DFu_wv(PDE *thee, int key, double W[], double dW[][3],
    double V[], double dV[][3]);

VEXTERNC void delta(PDE *thee, int type, int chart, double txq[], 
    void *data, double F[]);
VEXTERNC void u_D(PDE *thee, int type, int chart, double txq[], double F[]);
VEXTERNC void u_T(PDE *thee, int type, int chart, double txq[], double F[]);

VEXTERNC void bisectEdge(int dim, int dimII, int edgeType, int chart[], 
    double vx[][3]);
VEXTERNC void mapBoundary(int dim, int dimII, int vertexType, int chart, 
    double vx[3]);
VEXTERNC int markSimplex(int dim, int dimII, int simplexType, 
    int faceType[4], int vertexType[4], int chart[], double vx[][3], 
    void *data);
VEXTERNC void oneChart(int dim, int dimII, int objType, int chart[], 
    double vx[][3], int dimV);

VEXTERNC int simplexBasisInit(int key, int dim, int comp, int *ndof, 
    int dof[]);
VEXTERNC void simplexBasisForm(int key, int dim, int comp, int pdkey, 
    double xq[], double basis[]);

VEXTERNC double my_U(int d, double x[]);

VEXTERNC void Gem_setExternalUpdateFunction(Gem *thee,
    void (*externalUpdate)(SS **simps, int num));

/* ///////////////////////////////////////////////////////////////////////////
// Problem-specific
/////////////////////////////////////////////////////////////////////////// */
VEXTERNC void Gem_externalUpdateFunction(SS **simps, int num);
VPUBLIC void myPDE_setRefineParam(PDE *thee, int refCrit, double param);
