/**
 *  @file    read.c
 *  @author  Nathan Baker
 *  @brief   Sample program that illustrates OpenDX data I/O
 *  @version $Id: read.c,v 1.9 2002/01/04 17:20:52 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (nbaker@wasabi.ucsd.edu)
 * Dept. of Chemistry and Biochemistry
 * University of California, San Diego 
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 1999-2002. The Regents of the University of California
 *                          (Regents).  All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
 * TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 * @endverbatim
 */

#include "apbscfg.h"
#include "apbs/apbs.h"  

#define NMAX 5
#define IJK(i,j,k)  (((k)*(nx)*(ny))+((j)*(nx))+(i))

VEMBED(rcsid="$Id: read.c,v 1.9 2002/01/04 17:20:52 apbs Exp $")

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    int nx, ny, nz, u, ilo, ihi, jlo, jhi, klo, khi, ipt, npt;
    double *data = VNULL;
    double hy, hx, hzed, xmin, ymin, zmin, ifloat, jfloat, kfloat, dx, dy, dz;
    double xpt[NMAX], ypt[NMAX], zpt[NMAX];
    char *inpath = VNULL;
    char *outpath = "check.dx";
    char *usage = "\n  read file.dx\n"; 
 
    /* *************** CHECK INVOCATION ******************* */
    Vio_start();
    if (argc != 2) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected 2.\n\n",argc);
        Vnm_print(2,"%s\n", usage);
        return -1;
    } else {
        inpath = argv[1];
    }

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(1, "main:  Reading data from %s...\n", inpath);
    Vpmg_readDX("FILE", "ASC", VNULL, inpath, 
      &nx, &ny, &nz, &hx, &hy, &hzed, &xmin, &ymin, &zmin, &data);
    Vnm_print(1, "main:     nx = %d, ny = %d, nz = %d\n", 
      nx, ny, nz);
    Vnm_print(1, "main:     hx = %g, hy = %g, hz = %g\n", 
      hx, hy, hzed);
    Vnm_print(1, "main:     xmin = %g, ymin = %g, zmin = %g\n", 
      xmin, ymin, zmin);

    /* Check the values at some points */
    npt = 6;
    xpt[0] = 32.402; ypt[0] = 20.739; zpt[0] = 25.609;
    xpt[1] = 18.718; ypt[1] = 49.129; zpt[1] = 25.947;
    xpt[2] = 41.165; ypt[2] = 70.764; zpt[2] = 25.929;
    xpt[3] = 68.612; ypt[3] = 55.623; zpt[3] = 25.428;
    xpt[4] = 68.612; ypt[4] = 24.951; zpt[4] = 25.386;
    xpt[5] = 63.584; ypt[5] = 31.834; zpt[5] = 32.842;
    for (ipt=0; ipt<npt; ipt++) {
        ifloat = (xpt[ipt] - xmin)/hx;
        jfloat = (ypt[ipt] - ymin)/hy;
        kfloat = (zpt[ipt] - zmin)/hzed;
        ihi = (int)ceil(ifloat);
        ilo = (int)floor(ifloat);
        jhi = (int)ceil(jfloat);
        jlo = (int)floor(jfloat);
        khi = (int)ceil(kfloat);
        klo = (int)floor(kfloat);

        if ((ihi<nx) && (jhi<ny) && (khi<nz) &&
            (ilo>=0) && (jlo>=0) && (klo>=0)) {

            /* Now get trilinear interpolation constants */
            dx = ifloat - (double)(ilo);
            dy = jfloat - (double)(jlo);
            dz = kfloat - (double)(klo);
            Vnm_print(1, "dx = %g, dy = %g, dz = %g\n", dx, dy, dz);
            u = dx*dy*dz *(data[IJK(ihi,jhi,khi)])
            + dx*(1.0-dy)*dz *(data[IJK(ihi,jlo,khi)])
            + dx*dy*(1.0-dz) *(data[IJK(ihi,jhi,klo)])
            + dx*(1.0-dy)*(1.0-dz) *(data[IJK(ihi,jlo,klo)])
            + (1.0-dx)*dy*dz *(data[IJK(ilo,jhi,khi)])
            + (1.0-dx)*(1.0-dy)*dz *(data[IJK(ilo,jlo,khi)])
            + (1.0-dx)*dy*(1.0-dz) *(data[IJK(ilo,jhi,klo)])
            + (1.0-dx)*(1.0-dy)*(1.0-dz) *(data[IJK(ilo,jlo,klo)]);
            Vnm_print(1, "main:  data(%g, %g, %g) = %g\n",
                xpt[ipt], ypt[ipt], zpt[ipt], u);
        } else Vnm_print(1, "main:  Point (%g, %g, %g) off mesh, ignoring\n",
                xpt[ipt], ypt[ipt], zpt[ipt]);
    }

    Vnm_print(1, "main:  Writing data to %s for check...\n", outpath);
    Vpmg_writeDX2("FILE", "ASC", VNULL, outpath, "TEST", data, VNULL,
      hx, hy, hzed, nx, ny, nz, xmin, ymin, zmin);

    return 0;
}
