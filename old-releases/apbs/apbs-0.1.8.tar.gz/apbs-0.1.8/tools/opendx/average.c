/**
 *  @file    average.c
 *  @author  Nathan Baker
 *  @brief   Sample program that illustrates OpenDX data I/O
 *  @version $Id: average.c,v 1.7 2002/01/04 17:20:52 apbs Exp $
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (nbaker@wasabi.ucsd.edu)
 * Dept. of Chemistry and Biochemistry
 * University of California, San Diego 
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 1999-2002. The Regents of the University of California
 *                          (Regents).  All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 * REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
 * ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
 * TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 *
 * @endverbatim
 */


#include "apbscfg.h"
#include "apbs/apbs.h"  

VEMBED(rcsid="$Id: average.c,v 1.7 2002/01/04 17:20:52 apbs Exp $")

int main(int argc, char **argv) {

    /* *************** VARIABLES ******************* */
    int u, i, j, k, nx, ny, nz, imin, imax, jmin, jmax, kmin, kmax, navg;
    double avg;
    double *data = VNULL;
    double hy, hx, hzed, xmin, ymin, zmin;
    double xminAVG, xmaxAVG, yminAVG, ymaxAVG, zminAVG, zmaxAVG;
    double xcentAVG, ycentAVG, zcentAVG, xlenAVG, ylenAVG, zlenAVG;
    char *inpath = VNULL;
    char *usage = "\n  average file.dx\n"; 

 
    /* *************** CHECK INVOCATION ******************* */
    Vio_start();
    if (argc != 2) {
        Vnm_print(2,"\n*** Syntax error: got %d arguments, expected 2.\n\n",argc);
        Vnm_print(2,"%s\n", usage);
        return -1;
    } else {
        inpath = argv[1];
    }

    /* *************** APBS INITIALIZATION ******************* */
    Vnm_print(1, "#  Reading data from %s...\n", inpath);
    Vpmg_readDX("FILE", "ASC", VNULL, inpath, 
      &nx, &ny, &nz, &hx, &hy, &hzed, &xmin, &ymin, &zmin, &data);
    Vnm_print(1, "#     nx = %d, ny = %d, nz = %d\n", 
      nx, ny, nz);
    Vnm_print(1, "#     hx = %g, hy = %g, hz = %g\n", 
      hx, hy, hzed);
    Vnm_print(1, "#     xmin = %g, ymin = %g, zmin = %g\n", 
      xmin, ymin, zmin);

    /* *************** SETTINGS ******************** */
    xcentAVG = 112.160;
    ycentAVG = 63.5;
    zcentAVG = 137.245;
    xlenAVG = 70.0;
    zlenAVG = 70.0;
    ylenAVG = hy*(ny-1);

    /* *************** AVERAGE ********************** */
    xminAVG = xcentAVG - 0.5*xlenAVG;
    xmaxAVG = xcentAVG + 0.5*xlenAVG;
    yminAVG = ycentAVG - 0.5*ylenAVG;
    ymaxAVG = ycentAVG + 0.5*ylenAVG;
    zminAVG = zcentAVG - 0.5*zlenAVG;
    zmaxAVG = zcentAVG + 0.5*zlenAVG;
    imin = (int)floor((xminAVG - xmin)/hx);
    imin = VMAX2(imin, 0);
    jmin = (int)floor((yminAVG - ymin)/hy);
    jmin = VMAX2(jmin, 0);
    kmin = (int)floor((zminAVG - zmin)/hzed);
    kmin = VMAX2(kmin, 0);
    imax = (int)ceil((xmaxAVG - xmin)/hx);
    imax = VMIN2(imax, nx-1);
    jmax = (int)ceil((ymaxAVG - ymin)/hy);
    jmax = VMIN2(jmax, ny-1);
    kmax = (int)ceil((zmaxAVG - zmin)/hzed);
    kmax = VMIN2(kmax, nz-1);

    Vnm_print(1, "#  \tY POS\t\tAVERAGE\n");
    for (j=jmin; j<jmax; j++) {
        avg = 0.0;
        navg = 0;
        for (k=kmin; k<kmax; k++) {
            for (i=imin; i<imax; i++) {
                u = nx*ny*k + nx*j + i;
                avg += data[u];
                navg++;
            }
        }
        avg = avg/((double)navg);
        Vnm_print(1, "   \t%e\t\t%e\n", hy*j + ymin, avg);
    }

    return 0;
}
