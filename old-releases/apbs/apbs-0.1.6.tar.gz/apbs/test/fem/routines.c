/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
////////////////////////////////////////////////////////////////////////////
/// rcsid="$Id: routines.c,v 1.14 2001/10/02 16:16:42 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     routines.c    
//
// Purpose:  Useful chunks of code from noshell.c rolled into functions.
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */

#include "routines.h"

VPRIVATE void unifyMarkings(AM *am[MAXMOL], Gem *gm, int nmol, int *level); 
VPRIVATE int markSimplices(Gem *gm, Bvec *evec, int color, double etol);
VPRIVATE int refPctLast = 0;

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  unifyMarkings
//
// Purpose:  Take the per-simplex maximum of the pre-calculated error 
//           estimates for several (nmol) PBE systems and place it in am[0]. 
//
// Args:     am          An array of AM objects, each associated with a
//                       particular physical component of the system
//           nmol        Number of systems (i.e., # valid entries in am[])
//           level       The level of refinement.  
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE void unifyMarkings(AM *am[MAXMOL], Gem *gm, int nmol, int *level) {

#define MAXBINS 100

    int i, smid;
    Alg *alg[MAXMOL];
    SS *sm;
    double maxEst, currEst;

    /* Get the Alg objects from AM */
    for (i=0; i<nmol; i++) {
        VASSERT((*level>=am[i]->minLevel) && (*level<=am[i]->maxLevel));
        alg[i] = AM_alg(am[i], *level);
        VASSERT(alg[i] != VNULL);
    }
    smid = 0;
    while (smid < Gem_numSS(gm)) {
        sm = Gem_SS(gm,smid);
        maxEst = Bvec_val( alg[0]->WE[ WE_err ], 0, smid);
        for (i=1; i<nmol; i++) {
            currEst = Bvec_val( alg[i]->WE[ WE_err ], 0, smid);
            if (currEst > maxEst) maxEst = currEst;
        }
        Bvec_set( alg[0]->WE[ WE_err ], 0, smid, maxEst );
        smid++;
    }

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  refineToSize
//
// Purpose:  Refine the mesh by using the user-defined error estimator on
//           simplices associated with refMol that have longest edges greater
//           than the specifed size.
//
// Args:     pde         An array of PDE objects, each associated with a
//                       particular physical component of the system
//           nmol        Number of systems (i.e., # valid entries in pde[])
//           refMol      Index of the system you want to use as a reference
//           refCrit     Criterion for refinement: 0 => dielectric jumps and
//                       charges, 1 => charges only, 2 => diel jumps only
//           gm          The grid manager
//           size        The target size of the longest edge of the subset of
//                       refined simplices. 
//           partID      The ID of the partition out of which to base
//                       refinement
//           level       The level of refinement.  This will be set during the
//                       routine
//           pkey        Prolongation key passed to Gem_refine
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void refineToSize(PDE *pde[MAXMOL], AM *am[MAXMOL], Gem *gm,
  int nmol, int refMol, int refCrit, double size, int partID, int *level, 
  int pkey) {

    int imol;
    int marked;

    /* Here's the refine step */
    for (imol=0; imol<nmol; imol++) {
      myPDE_setMol(pde[imol], imol);
      AM_algInit(am[imol], *level);
    }
    myPDE_setMol(pde[refMol], refMol);
    myPDE_setRefineParam(pde[refMol], refMol, refCrit, size);
    marked = AM_markRefine(am[refMol], *level, 1, partID, 0, 0);

    Vnm_print(1, "refineToSize: N = [%d ", Gem_numVV(gm));

    while (marked > 0) {
        Gem_refine(gm, 0, pkey);
        Vnm_print(1, "%d ", Gem_numVV(gm));
 
        Vnm_print(1, "\nrefineToSize: marked %d\n", marked);
        
        
        (*level)++;

        for (imol=0; imol<nmol; imol++) {
            myPDE_setMol(pde[imol], imol);
            AM_algInit(am[imol], *level);
        }

        myPDE_setMol(pde[refMol], refMol);
        myPDE_setRefineParam(pde[refMol], refMol, refCrit, size);
        marked = AM_markRefine(am[refMol], *level, 1, partID, 0, 0);
    }
    Vnm_print(1, "]\n");
}



/* ///////////////////////////////////////////////////////////////////////////
// Routine:  writeToFile
//
// Purpose:  Write interesting things about the specified system (theMol) to
//           files in various formats
//
// Args:     pde         An array of PDE objects, each associated with a
//                       particular physical component of the system
//           nmol        Number of systems (i.e., # valid entries in pde[])
//           theMol      Index of the system you want write out
//           gm          The grid manager
//           am          An array of AM objects, each associated with a
//                       particular physical component of the system
//           funcKey     What to write.  0 = solution, 1 = mesh, 2 = solvent
//                       accessible volume
//           fmtKey      A bit field indicating what to write. 
//                       1st bit = GMV, 2nd bit = AVS UCD, 
//                       3rd bit = Geomview OFF
//           level       The level of refinement.  
//           stem        The stem of the filename; a description of the file
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void writeToFile(PDE *pde[MAXMOL], Vpbe *pbe[MAXMOL], int nmol, 
  int theMol, Gem *gm, AM *am[MAXMOL], int funcKey, int fmtKey, int level, 
  char *stem) {

    Vio *sock;
    char filename[256];

    myPDE_setMol(pde[theMol], theMol);
    if (funcKey == 0) {
        if ((fmtKey & 1) != 0) {
            sprintf(filename, "%s.gmv", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeGMV(am[theMol], level, sock, -1);
            Vio_dtor(&sock);
        }
        if ((fmtKey & 2) != 0) {
#if 0
            sprintf(filename, "%s.ucd", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeUCD(am[theMol], level, sock, -1);
            Vio_dtor(&sock);
#else
            Vnm_print(2, "writeToFile: UCD format data currently broken!\n");
#endif
        }
        if ((fmtKey & 4) != 0) {
            Vnm_print(2, "writeToFile: OFF format solution data not supported!\n");
        }
        if ((fmtKey & 8) != 0) {
#if 0
            sprintf(filename, "%s.dx", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeDX(am[theMol], level, sock, -1);
            Vio_dtor(&sock);
#else
            Vnm_print(2, "writeToFile: DX format data currently broken!\n");
#endif
        }
    } else if (funcKey == 1) {
        if ((fmtKey & 1) != 0) {
            sprintf(filename, "%s.gmv", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeGMV(am[theMol], level, sock, -1);
            Vio_dtor(&sock);
        }
        if ((fmtKey & 2) != 0) {
#if 0
            sprintf(filename, "%s.ucd", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeUCD(am[theMol], level, sock, -1);
            Vio_dtor(&sock);
#else
            Vnm_print(2, "writeToFile: UCD format data currently broken!\n");
#endif
        }
        if ((fmtKey & 4) != 0) {
            sprintf(filename, "%s.off", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeGV(am[theMol], level, sock, 0, 1, -1, 1.0, -1, 0);
            Vio_dtor(&sock);
        }
        if ((fmtKey & 8) != 0) {
#if 0
            sprintf(filename, "%s.dx", stem);
            sock = Vio_ctor("FILE", "ASC", VNULL, filename, "w");
            AM_writeDX(am[theMol], level, sock, -1);
            Vio_dtor(&sock);
#else
            Vnm_print(2, "writeToFile: DX format data currently broken!\n");
#endif
        }
    } else if (funcKey == 2) {
        if ((fmtKey & 1) != 0) {
            sprintf(filename, "%s.gmv", stem);
            Vacc_writeGMV(Vpbe_getVacc(pbe[theMol]), 
              Vpbe_getSolventRadius(pbe[theMol]), 0, gm, "FILE", "ASC", 
              "localhost", filename);
        }
        if ((fmtKey & 2) != 0) {
            Vnm_print(2, "writeToFile: UCD format accessiblity data not supported!\n");
        }
        if ((fmtKey & 4) != 0) {
            Vnm_print(2, "writeToFile: OFF format accessiblity data not supported!\n");
        }
        if ((fmtKey & 8) != 0) {
            Vnm_print(2, "writeToFile: DX format accessiblity data not supported!\n");
        }
    } else VASSERT(0);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  refineOnce
//
// Purpose:  Mark the mesh according to the specified error estimator and 
//           refine to conformity.  Return 0 if no simplices were
//           marked/refined; return 1 otherwise.
//
// Args:     pde         An array of PDE objects, each associated with a
//                       particular physical component of the system
//           nmol        Number of systems (i.e., # valid entries in pde[])
//           refMol      Index of the system you want to use as a reference.
//           gm          The grid manager
//           am          An array of AM objects, each associated with a
//                       particular physical component of the system
//           refKey      How to refine the mesh.  0 = uniform, 1 =
//                       user-defined (see markSimplex), 2 = residual-based
//                       adaptive (if this is used an solve must have recently
//                       occurred)
//           partID      The ID of the partition in which to constrain
//                       refinement or -1 if refinement happens everywhere
//           level       The level of refinement.  This will be set during the
//                       routine
//           ekey        How etol is interpreted 
//                          0 => etol is a local error tolerance applied to 
//                               each simplex 
//                          1 => etol is a global error tolerance from which
//                               the per-simplex tolerances are derived
//                          2 => etol is the fraction of simplices that we want
//                               to see refined each time
//           etol        The error criterion to use for error-based refinement
//                       schemes (see ekey).  This is ignored for uniform and
//                       user-defined refinement.
//           solveVars   Variables for the MC solver.  Ignored unless
//                       error-based partitioning is used.
//           pkey        Prolongation operator key
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int refineOnce(PDE *pde[MAXMOL], int nmol, int refMol, Gem *gm, 
  AM *am[MAXMOL], int refKey, int partID, int *level, int ekey, 
  double etol, SolveVars solveVars, int pkey) {

    int i, nsimp, marked;
    double myEtol;
    Alg *alg[MAXMOL];

    /* Grab the Alg objects */
    for (i=0; i<nmol; i++) {
        myPDE_setMol(pde[i], i);
        AM_algInit(am[i], *level);
        alg[i] = AM_alg(am[i], *level);
    }

    /* Determine what we'll be doing */
    if ((refKey == 0) || (refKey == 1)) {
        /* Mark simplices for refinement */
        Vnm_print(1, "refineOnce: Geometry-based simplex marking for mol #%d\n",
          refMol);
        AM_markRefine(am[refMol], *level, refKey, partID, 0, etol);
    } else if (refKey == 2) {
        if (ekey == 0) {
            Vnm_print(1, "refineOnce: Error-based simplex marking for mol #%d with LOCAL tolerance %g\n",
              refMol, etol);
            AM_markRefine(am[refMol], *level, refKey, partID, ekey, etol);
        } else if (ekey == 1) {
            Vnm_print(1, "refineOnce: Error-based simplex marking for mol #%d with GLOBAL tolerance %g\n",
              refMol, etol);
            AM_markRefine(am[refMol], *level, refKey, partID, ekey, etol);
        } else if (ekey == 2) { 
            /* This method can't be applied every time or some regions of the
             * mesh which need to be refined don't get it.  Therefore we will
             * alternate it with uniform refinement. */
            if (refPctLast == 0) {
                refPctLast = 1;
                Vnm_print(1, "refineOnce: Evaluating per-simplex errors for mol #%d \n", 
                   refMol);
                AM_markRefine(am[refMol], *level, refKey, partID, 0, 0);
                nsimp = VRINT((1.0-etol)*(double)(Gem_numSS(gm)));
                Vnm_print(1, "refineOnce: Looking for the %d-th largest error\n",
                   nsimp);
                myEtol = VSQRT(Bvec_select(alg[refMol]->WE[ WE_err ], nsimp, 0));
                Vnm_print(1, "refineOnce: %g%% of simplices have error greater than %g\n", 
                  etol, myEtol);
                /* Mark the simplices */
                marked = markSimplices(gm, alg[refMol]->WE[ WE_err], partID, 
                  myEtol);
                Vnm_print(1, "refineOnce: marked %d simplices\n", marked);
            } else {
                refPctLast = 0;
                AM_markRefine(am[refMol], *level, 0, partID, 0, 0);
            }
        } else Vnm_print(2, "refineOnce: Invalid ekey (%d) -- ignoring!\n",
                 ekey);
    } else Vnm_print(2, "refineOnce: Invalid refKey (%d) -- ignoring!\n",
             refKey);

    /* Refine, increment the level, and return */
    Gem_refine(gm,0,pkey);
    (*level)++;
    return 1;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  markSimplices
//
// Purpose:  Given pre-calculated per-simplex errors, clear the refinement
//           queue and re-mark simplices with errors above the given tolerance
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE int markSimplices(Gem *gm, Bvec *evec, int color, double etol) {

    int i, smid, currentQ;
    int count = 1;
    int marked = 0;
    double barrier = etol*etol;
    double errEst;
    SS *sm;

    /* Clear the queues */
    currentQ = 0;
    if (Gem_numSQ(gm,currentQ) > 0) Gem_resetSQ(gm,currentQ);
    if (Gem_numSQ(gm,!currentQ) > 0) Gem_resetSQ(gm,!currentQ);

    VASSERT( Gem_numSQ(gm,currentQ)  == 0 );
    VASSERT( Gem_numSQ(gm,!currentQ) == 0 );

    /* clear everyone's refinement flags */
    for (i=0; i<Gem_numSS(gm); i++) {
        sm = Gem_SS(gm,i);
        SS_setRefineKey(sm,currentQ,0);
        SS_setRefineKey(sm,!currentQ,0);
        SS_setRefinementCount(sm,0); /* refine X many times? */
    }
    
    smid = 0;
    while (smid < Gem_numSS(gm)) {

        sm = Gem_SS(gm,smid);

        /* produce an error estimate for this element if it is in the set */
        if ( (SS_chart(sm)==color) || (color<0) ) {

            errEst = Bvec_val(evec, 0, smid);
            VASSERT( errEst >= 0. );

            /* if error estimate above tol, mark element for refinement */
            if ( errEst > barrier ) {
                marked++;
                Gem_appendSQ(gm,currentQ, sm); /*add to refinement Q*/
                SS_setRefineKey(sm,currentQ,1);      /* note now on refine Q */
                SS_setRefinementCount(sm,count);     /* refine X many times? */
            }
        }
        smid++;
    }
    return marked;
}


/* ///////////////////////////////////////////////////////////////////////////
// Routine:  printE
//
// Purpose:  Print out information about the energeis
//
// Args:     pde         An array of PDE objects, each associated with a
//                       particular physical component of the system
//           nmol        Number of systems (i.e., # valid entries in pde[])
//           refMol      Index of the system you want to use as a reference
//           com         The communications objevt
//           myrank      The rank of this process
//                       refinement or -1 if refinement happens everywhere
//           level       The level of refinement.  
//           iounit      Where to print out the information (0 = io.mc, 1 =
//                       stdout, 2 = stderr)
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void printE(PDE *pde[MAXMOL], Vfetk *fetk[MAXMOL], int nmol, 
  int refMol, Vcom *com, int myrank, int level, int iounit) {

    int imol;
    double rEnergy, lEnergy[MAXMOL], gEnergy[MAXMOL];

    for (imol=0; imol<nmol; imol++) {
        myPDE_setMol(pde[imol], imol);
        rEnergy = Vfetk_getLinearEnergy1(fetk[imol], myrank);
        Vnm_print(1, "mol %d, energy1 = %g, energy2 = %g\n",
          imol, rEnergy, Vfetk_getLinearEnergy2(fetk[imol], myrank));
        lEnergy[imol] = (Vunit_kb)*(298.15)*Vunit_Na*rEnergy;
    }
    fflush(stdout);


#if defined(HAVE_MPI_H)
    Vcom_reduce(com, lEnergy, gEnergy, nmol, 2, 0);
#else
    for (imol=0; imol<nmol; imol++) gEnergy[imol] = lEnergy[imol];
#endif
    for (imol=0; imol<nmol; imol++) {
        Vnm_print(iounit, "main:    Abs. energy of mol %d = %e kJ/mol\n",
          imol, gEnergy[imol]/1000.);
    }
    rEnergy = gEnergy[refMol];
    for (imol=0; imol<nmol; imol++) {
        if (imol != refMol) rEnergy = rEnergy - gEnergy[imol];
    }
    Vnm_print(iounit, "main:    Rel. energy of mol %d = %e kJ/mol\n",
      refMol, rEnergy/1000.);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  prefineOnce
//
// Purpose:  Mark the mesh according to the specified error estimator and 
//           refine to conformity.  Return 0 if no simplices were
//           marked/refined; return 1 otherwise.
//
// Args:     pde         An array of PDE objects, each associated with a
//                       particular physical component of the system
//           nmol        Number of systems (i.e., # valid entries in pde[])
//           refMol      Index of the system you want to use as a reference.
//           pee         The parallel error estimator
//           gm          The grid manager
//           am          An array of AM objects, each associated with a
//                       particular physical component of the system
//           refKey      How to refine the mesh.  0 = uniform, 1 =
//                       user-defined (see markSimplex), 2 = residual-based
//                       adaptive (if this is used an solve must have recently
//                       occurred)
//           partID      The ID of the partition in which to constrain
//                       refinement or -1 if refinement happens everywhere
//           level       The level of refinement.  This will be set during the
//                       routine
//           ekey        How etol is interpreted 
//                          0 => etol is a local error tolerance applied to 
//                               each simplex 
//                          1 => etol is a global error tolerance from which
//                               the per-simplex tolerances are derived
//                          2 => etol is the fraction of simplices that we want
//                               to see refined each time
//           etol        The error criterion to use for error-based refinement
//                       schemes (see ekey).  This is ignored for uniform and
//                       user-defined refinement.
//           solveVars   Variables for the MC solver.  Ignored unless
//                       error-based partitioning is used.
//           pkey        Prolongation operator key
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int prefineOnce(PDE *pde[MAXMOL], int nmol, int refMol, Vpee *pee, 
  Gem *gm, AM *am[MAXMOL], int refKey, int partID, int *level, int ekey,
  double etol, SolveVars solveVars, int pkey) {

    int i;
    Alg *alg[MAXMOL];

    /* Grab the Alg objects */
    for (i=0; i<nmol; i++) {
        myPDE_setMol(pde[i], i);
        AM_algInit(am[i], *level);
        alg[i] = AM_alg(am[i], *level);
    }

    /* Determine what we'll be doing */
    if ((refKey == 0) || (refKey == 1)) {
        /* Mark simplices for refinement */
        Vnm_print(1, "refineOnce: Geometry-based simplex marking for mol #%d\n",
          refMol);
        Vpee_markRefine(pee, am[refMol], *level, refKey, partID, etol, 0);
    } else if (refKey == 2) {
        if (ekey == 0) {
            Vnm_print(1, "refineOnce: Error-based simplex marking for mol #%d with LOCAL tolerance %g\n",
              refMol, etol);
            Vpee_markRefine(pee, am[refMol], *level, refKey, partID, etol, 1);
        } else if (ekey == 1) {
            Vnm_print(1, "refineOnce: Error-based simplex marking for mol #%d with GLOBAL tolerance %g\n",
              refMol, etol);
            Vpee_markRefine(pee, am[refMol], *level, refKey, partID, etol, 1);
        } 
    } else Vnm_print(2, "refineOnce: Invalid refKey (%d) -- ignoring!\n",
             refKey);

    /* Refine, increment the level, and return */
    Gem_refine(gm,0,pkey);
    (*level)++;
    return 1;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Bvec_select
//
// Purpose:  Select the k^th largest entry of the data[m] entries of Bvec 
//
// Author:   Nathan Baker -- adapted from algorithm in Numerical Recipes
/////////////////////////////////////////////////////////////////////////// */
#define BSSWAP(a,b) temp=(a); (a)=(b); (b)=temp;
VPUBLIC double Bvec_select(Bvec *thee, int k, int m) {

    int i, lo, hi, med, mid, ll, hh;
    double a, temp, *arr;
    Bvec *tvec;

    VASSERT(thee != VNULL);
    VASSERT(m <= thee->numB); 
    VASSERT(k < thee->numR[m]); 

    Vnm_print(1, "Have thee->numB = %d, thee->numR[%d] = %d\n", thee->numB, 
      m, thee->numR[m]);

    tvec = Bvec_ctor(VNULL, "APBSTMP", thee->numB, thee->numR);
    VASSERT(tvec != VNULL);
    Bvec_copy(tvec, thee);

    arr = tvec->data[m];

    lo = 0;
    hi = tvec->numR[m] - 1;
    med = (lo+hi)/2;

    while (1) {
        if (hi <= lo) break;
        if (hi == lo + 1) {
            if (arr[lo] > arr[hi]) {
                BSSWAP(arr[lo], arr[hi]);
            }
            break;
        }
        mid = (lo + hi)/2;
        if (arr[mid] > arr[hi]) {
            BSSWAP(arr[mid], arr[hi]);
        }
        if (arr[lo] > arr[hi]) {
            BSSWAP(arr[lo], arr[hi]);
        }
        if (arr[mid] > arr[lo]) {
            BSSWAP(arr[mid], arr[lo]);
        }
        BSSWAP(arr[mid], arr[lo+1])
        ll = lo + 1;
        hh = hi;
        while (1) {
            do ll++; while (arr[lo] > arr[ll]);
            do hh--; while (arr[hh] > arr[lo]);
            if (hh < ll) break;
            BSSWAP(arr[ll], arr[hh]);
        }
        BSSWAP(arr[lo], arr[hh]);
        if (hh <= k) lo = ll;
        if (hh >= k) hi = hh - 1;
    }

    a = arr[k];
    med = 0;
    for (i=0; i<thee->numR[m] - 1; i++) {
        if (thee->data[m][i] > a) med++;
    }
    Vnm_print(1, "GOT %d greater entries than %g\n", med, a);
    Bvec_dtor(&tvec);
    return a;
}
#undef BSSWAP
