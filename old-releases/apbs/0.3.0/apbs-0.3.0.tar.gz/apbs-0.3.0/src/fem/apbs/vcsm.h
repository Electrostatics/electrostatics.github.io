/** @defgroup Vcsm Vcsm class
 *  @brief  A charge-simplex map for evaluating integrals of delta functions
 *          in a finite element setting
 */

/**
 *  @file      vcsm.h
 *  @brief     Contains declarations for the Vcsm class
 *  @ingroup   Vcsm
 *  @version   $Id: vcsm.h,v 2.15 2004/01/19 21:01:36 apbs Exp $
 *  @author    Nathan A. Baker
 *
 *  @attention
 *  @verbatim
 *
 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (baker@biochem.wustl.edu)
 * Dept. of Biochemistry and Molecular Biophysics
 * Center for Computational Biology
 * Washington University in St. Louis
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 2002-2004.  Washington University in St. Louis.
 * All Rights Reserved.
 * Portions Copyright (c) 1999-2002.  The Regents of the University of
 * California.  
 * Portions Copyright (c) 1995.  Michael Holst.
 *
 * This file is part of APBS.
 *
 * APBS is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * APBS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with APBS; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
 *
 * @endverbatim
 */

#ifndef _VCSM_H_
#define _VCSM_H_

/* Generic headers */
#include "maloc/maloc.h"
#include "apbs/vhal.h"
#include "apbs/valist.h"

/* Specific headers */
#include "mc/mc.h"

/** @brief   External function for FEtk Gem class to use during mesh refinement
 *  @ingroup Vcsm
 *  @author  Nathan Baker
 *  @param   thee   Gem (FEtk geometry manager) object
 *  @param   externalUpdate  Function pointer for function to call during 
 *           mesh refinement
 */
VEXTERNC void Gem_setExternalUpdateFunction(Gem *thee,
    void (*externalUpdate)(SS **simps, int num));

/** @brief   Charge-simplex map class
 *  @ingroup Vcsm
 *  @author  Nathan Baker
 */
struct sVcsm { 

  Valist *alist;      /**< Atom (charge) list */
  int natom;          /**< Size of thee->alist; redundant, but useful for
                       * convenience */
  Gem *gm;            /**< Grid manager (container class for master vertex
                       * and simplex lists as well as prolongation
                       * operator for updating after refinement ) */
  int **sqm;          /**< The map which gives the list charges associated with
                       * each simplex in gm->simplices.  The indices of
                       * the first dimension are associated with the
                       * simplex ID's in Vgm.  Each charge list (second 
                       * dimension) contains entries corresponding to
                       * indicies in thee->alist with lengths given in 
                       * thee->nsqm */
  int *nsqm;          /**< The length of the charge lists in thee->sqm */
  int nsimp;          /**< The _currently used) length of sqm, nsqm -- may not 
                       * always be up-to-date with Gem */
  int msimp;          /**< The maximum number of entries that can be 
                       * accomodated by sqm or nsqm  -- saves on realloc's */
  int **qsm;          /**< The inverse of sqm; the list of simplices
                       * associated with a given charge */
  int *nqsm;          /**< The length of the simplex lists in thee->qsm */
  int initFlag;       /**< Indicates whether the maps have been initialized
                       * yet */
  Vmem *vmem;         /**< Memory management object */

};

/** 
 *  @ingroup Vcsm
 *  @brief   Declaration of the Vcsm class as the Vcsm structure
 */
typedef struct sVcsm Vcsm;

/* ///////////////////////////////////////////////////////////////////////////
// Class Vcsm: Inlineable methods (vcsm.c)
/////////////////////////////////////////////////////////////////////////// */

#if !defined(VINLINE_VCSM)

    /** @brief   Get atom list
     *  @ingroup Vcsm
     *  @author  Nathan Baker
     *  @param   thee  Vcsm object
     *  @return  Pointer to Valist atom list
     */
    VEXTERNC Valist* Vcsm_getValist(Vcsm *thee);

    /** @brief   Get number of atoms associated with a simplex
     *  @ingroup Vcsm
     *  @author  Nathan Baker
     *  @param   thee  Vcsm object
     *  @param   isimp Simplex ID
     *  @return  Number of atoms associated with a simplex
     */
    VEXTERNC int     Vcsm_getNumberAtoms(Vcsm *thee, int isimp);

    /** @brief   Get particular atom associated with a simplex
     *  @ingroup Vcsm
     *  @author  Nathan Baker
     *  @param   thee  Vcsm object
     *  @param   iatom Index of atom in Vcsm list for this simplex
     *  @param   isimp Simplex ID
     *  @return  Array of atoms associated with a simplex
     */
    VEXTERNC Vatom*  Vcsm_getAtom(Vcsm *thee, int iatom, int isimp);

    /** @brief   Get ID of particular atom in a simplex
     *  @ingroup Vcsm
     *  @author  Nathan Baker
     *  @param   thee  Vcsm object
     *  @param   isimp Simplex ID
     *  @param   iatom Index of atom in Vcsm list for this simplex
     *  @return  Index of atom in Valist object
     */
    VEXTERNC int Vcsm_getAtomIndex(Vcsm *thee, int iatom, int isimp);

    /** @brief   Get number of simplices associated with an atom
     *  @ingroup Vcsm
     *  @author  Nathan Baker
     *  @param   thee  Vcsm object
     *  @param   iatom  Valist atom index
     *  @return  Number of simplices associated with an atom
     */
    VEXTERNC int     Vcsm_getNumberSimplices(Vcsm *thee, int iatom);

    /** @brief   Get particular simplex associated with an atom
     *  @ingroup Vcsm
     *  @author  Nathan Baker
     *  @param   thee  Vcsm object
     *  @param   iatom  Valist atom index
     *  @param   isimp  Index of simplex in Vcsm list
     *  @return  Pointer to simplex object
     */ 
    VEXTERNC SS*     Vcsm_getSimplex(Vcsm *thee, int isimp, int iatom);

    /** @brief   Get index particular simplex associated with an atom
     *  @ingroup Vcsm
     *  @author  Nathan Baker
     *  @param   thee  Vcsm object
     *  @param   iatom  Valist atom index
     *  @param   isimp  Index of simplex in Vcsm list
     *  @return  Gem index of specified simplex
     */ 
    VEXTERNC int     Vcsm_getSimplexIndex(Vcsm *thee, int isimp, int iatom);

    /** @brief   Return the memory used by this structure (and its contents)
     *           in bytes
     *  @ingroup Vcsm
     *  @author  Nathan Baker
     *  @param   thee  Vcsm object
     *  @return  The memory used by this structure and its contents in bytes
     */
    VEXTERNC int     Vcsm_memChk(Vcsm *thee);

#else /* if defined(VINLINE_VCSM) */
#   define Vcsm_getValist(thee) ((thee)->alist)
#   define Vcsm_getNumberAtoms(thee, isimp) ((thee)->nsqm[isimp])
#   define Vcsm_getAtom(thee, iatom, isimp) (Valist_getAtom((thee)->alist, ((thee)->sqm)[isimp][iatom]))
#   define Vcsm_getAtomIndex(thee, iatom, isimp) (((thee)->sqm)[isimp][iatom])
#   define Vcsm_getNumberSimplices(thee, iatom) (((thee)->nqsm)[iatom])
#   define Vcsm_getSimplex(thee, isimp, iatom) (Gem_SS((thee)->gm, ((thee)->qsm)[iatom][isimp]))
#   define Vcsm_getSimplexIndex(thee, isimp, iatom) (((thee)->qsm)[iatom][isimp])
#   define Vcsm_memChk(thee) (Vmem_bytes((thee)->vmem))
#endif /* if !defined(VINLINE_VCSM) */

/* ///////////////////////////////////////////////////////////////////////////
// Class Vcsm: Non-Inlineable methods (vcsm.c)
/////////////////////////////////////////////////////////////////////////// */

/** @brief   Construct Vcsm object
 *  @ingroup Vcsm 
 *  @author  Nathan Baker
 *  @note    \li The initial mesh must be sufficiently coarse for the assignment
 *             procedures to be efficient
 *           \li The map is not built until Vcsm_init is called
 *  @param   alist  List of atoms
 *  @param   gm     FEtk geometry manager (defines mesh)
 *  @return  Pointer to newly allocated Vcsm object 
 */
VEXTERNC Vcsm*   Vcsm_ctor(Valist *alist, Gem *gm);

/** @brief   FORTRAN stub to construct Vcsm object
 *  @ingroup Vcsm 
 *  @author  Nathan Baker
 *  @note    \li The initial mesh must be sufficiently coarse for the assignment
 *             procedures to be efficient
 *           \li The map is not built until Vcsm_init is called
 *  @param   thee   Pointer to space for Vcsm object
 *  @param   alist  List of atoms
 *  @param   gm     FEtk geometry manager (defines mesh)
 *  @return  1 if successful, 0 otherwise 
 */
VEXTERNC int     Vcsm_ctor2(Vcsm *thee, Valist *alist, Gem *gm);

/** @brief   Destroy Vcsm object
 *  @ingroup Vcsm
 *  @author  Nathan Baker
 *  @param   thee Pointer to memory location for Vcsm object
 */
VEXTERNC void    Vcsm_dtor(Vcsm **thee);

/** @brief   FORTRAN stub to destroy Vcsm object
 *  @ingroup Vcsm
 *  @author  Nathan Baker
 *  @param   thee Pointer to Vcsm object
 */
VEXTERNC void    Vcsm_dtor2(Vcsm *thee);

/** @brief   Initialize charge-simplex map with mesh and atom data
 *  @ingroup Vcsm
 *  @author  Nathan Baker
 *  @param   thee Vcsm object to be initialized
 *  @note    The initial mesh must be sufficiently coarse for the assignment
 *            procedures to be efficient
 */
VEXTERNC void    Vcsm_init(Vcsm *thee);

/** @brief   Update the charge-simplex and simplex-charge maps after
 *           refinement
 *  @ingroup Vcsm
 *  @author  Nathan Baker
 *  @param   thee  Vcsm object to be updated
 *  @param   simps List of pointer to newly created (by refinement) simplex
 *           objects.  The first simplex is expected to be derived from the
 *           parent simplex and therefore have the same ID.  The remaining
 *           simplices are the children and should represent new entries in the
 *           charge-simplex map.
 *  @param   num   Number of simplices in simps list
 *  @return  1 if successful, 0 otherwise 
 */
VEXTERNC int     Vcsm_update(Vcsm *thee, SS **simps, int num);

#endif /* ifndef _VCSM_H_ */
