#!/bin/bash
#
#
## ##########################################################################
#  APBS -- Adaptive Poisson-Boltzmann Solver
# 
#  Nathan A. Baker (baker@biochem.wustl.edu)
#  Dept. of Biochemistry and Molecular Biophysics
#  Washington University in St. Louis
# 
#  Additional contributing authors listed in the code documentation.
#
#  Copyright (c) 2002-2004  Washington University in St. Louis
#  All Rights Reserved.
#  Portions Copyright (c) 1999-2002.  The Regents of the University of
#  California.  
#  Portions Copyright (c) 1995.  Michael Holst.
#
#  This file is part of APBS.
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
## ##########################################################################
#
# Shell script to convert one mg-para input file into asynchronous ones
#
# Author:  Todd Dolinsky
# Version:  $Id: asynchronize.sh,v 1.2 2004/01/19 21:01:39 apbs Exp $
# 
## ##########################################################################

stem="$(echo | awk '{print substr("'"${1}"'",0,match("'"${1}"'","[.]") - 1)}')"
if [ -z $stem ]
then
stem=$1
fi

pdime="$(grep -m 1 pdime $1)"
num="$(echo | awk '
{split("'"${pdime}"'",args," ") 
print int(args[2])*int(args[3])*int(args[4])}')"

i=0
while [ $i -lt $num ]
do
  cat $1 \
  | sed -e "s/fgcent mol 1/fgcent mol 1\n    async ${i}/g" > ${stem}-PE${i}.in
  i=`expr $i + 1`
done
