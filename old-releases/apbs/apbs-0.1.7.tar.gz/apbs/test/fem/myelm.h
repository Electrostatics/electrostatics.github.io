/* ///////////////////////////////////////////////////////////////////////////
//  MC = < Manifold Code >
//  Copyright (C) 1994--2000  Michael Holst
// 
//  This program is free software; you can redistribute it and/or modify it
//  under the terms of the GNU General Public License as published by the
//  Free Software Foundation; either version 2 of the License, or (at your
//  option) any later version.
// 
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU General Public License for more details.
// 
//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  675 Mass Ave, Cambridge, MA 02139, USA.
// 
//  rcsid="$Id: myelm.h,v 1.1 2001/11/20 17:41:31 apbs Exp $"
// //////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     myelm.h
//
// Purpose:  Define the trial and test elements, as well as bump-function
//           variations for a posteriori error estimation.
//
//     Element number:        1
//     Spatial dimension:     2 or 3
//     Quadrature order:      1, 2, or 3
//     Trial space:           continuous piecewise linear or quadratic
//     Test space:            continuous piecewise linear or quadratic
//     Trial bump space:      continuous piecewise bumps of next order
//     Test bump space:       continuous piecewise bumps of next order
//
// Notes:    The user must provide:
//
//               VEXTERNC int simplexBasisInit(int key, int dim, int comp,
//                   int *ndof, int dof[]);
//               VEXTERNC void simplexBasisForm(int key, int dim, int comp,
//                   int pdkey, double xq[], double basis[]);
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */

#include "mc/mc.h"
VEMBED(rcsid="$Id: myelm.h,v 1.1 2001/11/20 17:41:31 apbs Exp $")

#ifndef _MYELM_H
#define _MYELM_H

/* ///////////////////////////////////////////////////////////////////////////
// Required prototypes
/////////////////////////////////////////////////////////////////////////// */

VEXTERNC int simplexBasisInit(int key, int dim, int comp,
    int *ndof, int dof[]);
VEXTERNC void simplexBasisForm(int key, int dim, int comp,
    int pdkey, double xq[], double basis[]);

#endif
