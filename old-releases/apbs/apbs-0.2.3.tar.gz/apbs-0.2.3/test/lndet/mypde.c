/**
 *  @file    PDE.h
 *  @author  Nathan Baker
 *  @brief   FEtk PDE definition for Poisson-Boltzmann equation
 *  @version $Id: mypde.c,v 1.9 2002/07/29 12:19:38 apbs Exp $
 *  @attention
 *  @verbatim
 *

 * APBS -- Adaptive Poisson-Boltzmann Solver
 *
 * Nathan A. Baker (baker@biochem.wustl.edu)
 * Dept. of Biochemistry and Molecular Biophysics
 * Washington University in St. Louis
 *
 * Additional contributing authors listed in the code documentation.
 *
 * Copyright (c) 2002.  Washington University in St. Louis.
 * All Rights Reserved.
 *
 * Portions Copyright (c) 1999-2002.  The Regents of the University of
 * California.  
 * Portions Copyright (c) 1995.  Michael Holst.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research, and not-for-profit purposes,
 * without fee and without a signed licensing agreement, is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following two paragraphs appear in all copies, modifications, and
 * distributions.
 *
 * IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 * SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
 * ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE
 * AUTHORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHORS SPECIFICALLY DISCLAIM ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED
 * HEREUNDER IS PROVIDED "AS IS".  THE AUTHORS HAVE NO OBLIGATION TO PROVIDE
 * MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.

 * @endverbatim
 */

#include "mypde.h"

/* If you want a fast way to evaluate epsilon and kappa, define the following.
 * Otherwise, comment it out */
/* #define FASTCOEF 1 */

VEMBED(rcsid="$Id: mypde.c,v 1.9 2002/07/29 12:19:38 apbs Exp $")

/* ///////////////////////////////////////////////////////////////////////////
// Local data
/////////////////////////////////////////////////////////////////////////// */

/* We want to allow the state of the PDE object to be variable, in other words,  * we'd like to have several different PDE objects for different molecules. 
 * However, since the local data is static and might need to persist from 
 * molecule to molecule, we're going to encapsulate it and explicitly switch
 * the internal state of this object each time we switch molecules. 
 *
 * The following structure contains all private variables for this class.  
 * You should not use a private variable without placing it in this struct. */
typedef struct LocalVars {
    double nvec[3];               /* Normal vector for a simplex face */
    double vx[4][3];              /* Vertex coordinates */
    double U[MAXV];               /* Current solution value */
    double dU[MAXV][3];           /* Current solution gradient */
    double U_t;                   /* True solution value */
    double xq[3];                 /* Current point */
    int sType;                    /* Simplex type */
    int fType;                    /* Face type */
    double diel;                  /* Dielectric value */
    double kappa2;                /* Kappa^2 value */
    double A;                     /* Second-order differential term */
    double B;                     /* Entire ionic strength term */
    double DB;                    /* Entire ionic strength term derivative */
    double jumpDiel;              /* Dielectric value on one side of a simplex
                                   * face */
    Vfetk *fetk;                  /* Pointer to the VFETK object */
    Vopot *opot;                  /* Pointer to the VOPOT object */
    SS   *simp;                   /* Pointer to the latest simplex object; set
                                   * in initElement() and delta() */
    VV   *verts[4];               /* Pointer to the latest vertices; set in
                                   * initElement */
    int  nverts;                  /* number of vertices in the simplex */
    int pdeKey;                   /* what PDE are we solving?
                                   *   0 => Laplacian
                                   *   1 => Poisson
                                   *   2 => NPBE */
    double ionConc[MAXION];       /* Counterion species' concentrations */
    double ionQ[MAXION];          /* Counterion species' valencies */
    double ionRadii[MAXION];      /* Counterion species' radii */
    double zkappa2, zks2, ionstr; /* Ionic strength parameters */
    double minLongEdge;           /* Parameter indicating longest edge
				   * threshold for user-defined simplex
				   * marking.  Simplices with longest edges
				   * below this threshold will not be 
                                   * refined.  */
    int nion;
} LocalVars;

/* These are the only permissible non-encapsulated variables. */
VPRIVATE LocalVars var;
VPRIVATE int pointAccessibility(int dim, double coord[]);
VPRIVATE double diel(int d, int accBit, double x[]);
VPRIVATE double kappa2(int d, int accBit, double x[]);
VPRIVATE double smooth(int d, double dist[4], double coef[4], int meth);

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  pointAccessibility
//
// Purpose:  Call VHASH code to determine the point's accessibility
//
// Arguments: dim    = Dimension of point
//            coord  = Point coordinates
//
// Returns:  A bitfield for the set of molecules.  Each molecule has two bits
//           associatied with it.  
//               low bit  = accessibility with respect to solvent
//               high bit = accessibility with respect to ions
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE int pointAccessibility(int dim, double coord[]) {

    int accBit = 0;
    double srad, irad;
    int currentBit;
    Vpbe *vpbe;

    vpbe = var.fetk->pbe;
    srad = Vpbe_getSolventRadius(vpbe);
    irad = Vpbe_getMaxIonRadius(vpbe);
    currentBit = 1;
    if (Vacc_molAcc(Vpbe_getVacc(vpbe), coord, srad) == 1) 
      accBit += currentBit;
    currentBit = 2;
    if (Vacc_ivdwAcc(Vpbe_getVacc(vpbe), coord, irad) == 1) 
      accBit += currentBit;

    return accBit;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  smooth
//
// Purpose:  Smooth a coefficient at the quadrature point
//
// Args:     dist    Distances to each vertex
//           coeff   Coefficient value at each vertex
//           meth    Averaging method
//                     0 =>  Normal average, weighted by inverse distance
//                     1 =>  Harmonic average, weighted by inverse distance
//           
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE double smooth(int d, double dist[4], double coeff[4], int meth) {


    int i;
    double weight;
    double num = 0;
    double den = 0;

    for (i=0; i<var.nverts; i++) {
 
        if (dist[i] < VSMALL) return coeff[i];

        weight = 1.0/dist[i];

        if (meth == 0) {

           num += (weight * coeff[i]);
           den += weight;

        } else if (meth == 1) {

            if (coeff[i] < VSMALL) VASSERT(0);

            num += weight;
            den += (weight/coeff[i]);

        } else VASSERT(0);
    }

    return (num/den);

}


/* ///////////////////////////////////////////////////////////////////////////
// Routine:  diel
//
// Purpose:  The dielectric coefficient in the Poisson-Boltzmann equation.
//
// Notes:    A rudimentary smoothing scheme is implemented (this is sort of a
//           stab at a more accurate quadrature in simplices containing
//           coefficient discontinuities).  Assuming there are N vertices in
//           the simplex, each with coeff value a_i and distance d_i from
//           the quad pt, the quad pt coeff value a is assigned by a harmonic
//           average:
//              (\sum_i^N d_i)/a = \sum d_i/a_i
//              a = (\sum_i^N d_i)/(\sum d_i/a_i)
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE double diel(int d, int accBit, double x[]) {

#ifdef FASTCOEF

    int bit = 1;
    int i,j;
    double epsp, epsw, dist[5], coeff[5];

    epsp = Vpbe_getSoluteDiel(var.fetk->pbe);
    epsw = Vpbe_getSolventDiel(var.fetk->pbe);

    if (VABS(epsp - epsw) < VSMALL) return epsp;

    for (i=0; i<var.nverts; i++) {

        /* Compute the distance from this vertex to the quad pt */
        dist[i] = 0;
        for (j=0; j<(var.nverts-1); j++) 
          dist[i] += (var.vx[i][j] - x[j])*(var.vx[i][j] - x[j]);
        dist[i] = VSQRT(dist[i]);

        /* Evaluate the coefficient for this vertex */
        if ((VV_chart(var.verts[i]) & bit) != 0) {
            coeff[i] = epsw;
        } else coeff[i] = epsp;

    }

    return smooth(d, dist, coeff, 1);

#else 

    double epsp, epsw, srad;

    srad = Vpbe_getSolventRadius(var.fetk->pbe);
    epsp = Vpbe_getSoluteDiel(var.fetk->pbe);
    epsw = Vpbe_getSolventDiel(var.fetk->pbe);

    if (VABS(epsp - epsw) < VSMALL) return epsp;    
    if (Vacc_molAcc(Vpbe_getVacc(var.fetk->pbe),x,srad)==1) return epsw;
    else return epsp;

#endif


}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  kappa2
//
// Purpose:  The mobile ion term 
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPRIVATE double kappa2(int d, int accBit, double x[]) {

#ifdef FASTCOEF

    int bit = 2;
    int i,j;
    double dist[4], coeff[4];


    if (var.zks2 < VSMALL) return 0;
 
    for (i=0; i<var.nverts; i++) {
        /* Compute the distance from this vertex to the quad pt */
        dist[i] = 0;
        for (j=0; j<(var.nverts-1); j++)
          dist[i] += (var.vx[i][j] - x[j])*(var.vx[i][j] - x[j]);
        dist[i] = VSQRT(dist[i]);

        /* Evaluate the coefficient for this vertex */
        if ((VV_chart(var.verts[i]) & bit) != 0) {
            coeff[i] = (var.zks2);
        } else coeff[i] = 0.0;
    }

    return smooth(d, dist, coeff, 0);

#else

    double irad;

    irad = Vpbe_getMaxIonRadius(var.fetk->pbe);
    if (var.zks2 < VSMALL) return 0.0;
    if (Vacc_ivdwAcc(Vpbe_getVacc(var.fetk->pbe),x,irad)==1) return var.zks2;
    else return 0.0;

#endif


}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_U
//
// Purpose:  Dirichlet boundary function and initial approximation function.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double PDE_U(int d, double x[]) {

    double val;

    Vopot_pot(var.opot, x, &val);

    return val;

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_initAssemble
//
// Purpose:  Do once-per-assembly initialization.
//
// Input:    PDE = pointer to the PDE object
//           ip  = integer parameters for the assembly
//           rp  = real parameters for the assembly
//
// Output:   None
//
// Speed:    This function is called by MC just before a full assembly,
//           and does not have to be particularly fast.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_initAssemble(PDE *thee, int ip[], double rp[]) { }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_initElement
//
// Purpose:  Do once-per-element initialization.
//
// Input:    PDE         = pointer to the PDE object
//           elementType = type of this element (various material types)
//           chart       = chart in which vertex coordinates are provided
//           tvx[][3]    = coordinates of all the vertices of the element
//
// Output:   None
//
// Speed:    This function is called by MC just before assembling a single
//           element, and needs to be a fast as possible.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_initElement(PDE *thee, int elementType, int chart, 
  double tvx[][3], void *data) {

    int i, j;
    int bit = 1;
    double epsp, epsw;

    /* We assume that the simplex has been passed in as the void *data 
     * argument.  Store it */
    VASSERT(data != NULL);
    var.simp = (SS *)data;

    /* save the element type */
    var.sType = elementType;

    /* Grab the vertices from this simplex */
    var.nverts = thee->dim+1;
    for (i=0; i<thee->dim+1; i++) var.verts[i] = SS_vertex(var.simp, i);

    /* Vertex locations of this simplex */
    for (i=0; i<thee->dim+1; i++) 
        for (j=0; j<thee->dim; j++) var.vx[i][j] = tvx[i][j];

    /* Set the dielectric constant for this element for use in the jump term
     * of the residual-based error estimator.  The value is set to the average
     * value of the vertices */
    epsp = Vpbe_getSoluteDiel(var.fetk->pbe);
    epsw = Vpbe_getSolventDiel(var.fetk->pbe);
    if (VABS(epsw-epsp) > VSMALL) {
        var.jumpDiel = 0;
        for (i=0; i<thee->dim+1; i++) {
            if ((VV_chart(var.verts[i]) & bit) != 0) {
                var.jumpDiel += epsw;
            } else var.jumpDiel += epsp;
        }
        var.jumpDiel = var.jumpDiel/((double)(var.nverts));
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_initFace
//
// Purpose:  Do once-per-face initialization.
//
// Input:    PDE      = pointer to the PDE object
//           faceType = type of this face (interior or various boundary types)
//           chart    = chart in which normal vector coordinates are provided
//           tnvec[]  = coordinates of the outward normal vector to this face
//
// Output:   None
//
// Speed:    This function is called by MC just before assembling a single
//           element face, and needs to be a fast as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_initFace(PDE *thee, int faceType, int chart, 
  double tnvec[]) {
    int i;

    /* unit normal vector of this face */
    for (i=0; i<thee->dim; i++) var.nvec[i] = tnvec[i];

    /* save the face type */
    var.fType = faceType;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_initPoint
//
// Purpose:  Do once-per-point initialization.
//
// Input:    PDE       = pointer to the PDE object
//           pointType = type of this point (interior or boundary)
//           chart     = chart in which the point coordinates are provided
//           txq[]     = coordinates of the point
//           tU[]      = current solution at the point
//           tdU[]     = current solution gradient at the point
//
// Output:   None
//
// Speed:    This function is called by MC for every quadrature point
//           during an assmebly, and needs to be a fast as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_initPoint(PDE *thee, int pointType, int chart, double txq[],
    double tU[], double tdU[][3]) {

    int   i, j, ichop;
    double u2, coef2;

    /* the point, and the solution value and gradient at the point */
    for (i=0; i<thee->vec; i++) {
        var.U[i] = tU[i];
        for (j=0; j<thee->dim; j++) {
            var.xq[j] = txq[j];
            var.dU[i][j] = tdU[i][j];
        }
    }
  
    /* The true solution value */
    Vopot_pot(var.opot, var.xq, &(var.U_t));

    /* interior form case */
    if (pointType == 0) {

        var.diel  = diel(thee->dim,  chart, txq);
        var.kappa2  = kappa2(thee->dim,  chart, txq);

        
        if (var.pdeKey == 0) { /* Laplacian */
        
            var.A = Vpbe_getSolventDiel(var.fetk->pbe);
            var.B  = 0.0;
            var.DB  = 0.0;

        } else if (var.pdeKey == 1) { /* Poisson */
        
            var.A  = var.diel;
            var.B  = 0;
            var.DB = 0;

        } else if (var.pdeKey == 2) { /* NPBE */

            var.A = var.diel;

            if (var.kappa2 > VSMALL) {
                var.B = 0;
                var.DB = 0;
                for (i=0; i<var.nion; i++) {
                    /* NPBE linearized around provided solution */
                    coef2 = var.kappa2 * var.ionConc[i] * var.ionQ[i];
                    u2 = -1.0 * var.U_t * var.ionQ[i];
                    var.B += (coef2 * Vcap_exp(u2, &ichop));
                    var.DB += (coef2 * Vcap_exp(u2, &ichop));
                }

            } else {
                var.B = 0;
                var.DB = 0;
            }

        } else VASSERT(0);

    /* boundary form case */
    /* (pointType == 1) */
    } else VASSERT(0);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_Fu
//
// Purpose:  THIS IS SUPPOSED TO evaluate the strong form of the differential
//           operator F(u) at the single point x.  HOWEVER, we're using it to
//           evaluate the curvature of a diagonal term of the operator.
//
// Input:    PDE   = pointer to the PDE object
//           key   = piece to evaluate (0=interior, 1=boundary, 2=int-bndry)
//
// Output:   F[]   = operator piece evaluated at the point given to initPoint
//
// Speed:    This function is called by MC only when using error
//           estimation based on strong residuals.  The speed of this
//           function will impact the speed of the error estimator.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_Fu(PDE *thee, int key, double F[]) { 

    int i; 
    double d2U, dU[3], dU2, edgeLength;

    /* First, we'll set a lower bound for the size of the simplices.  Simplices
     * below this bound do not get refined. */
    Gem_longestEdge(var.fetk->gm, var.simp, &edgeLength);
    if (edgeLength < var.minLongEdge) { 
        F[0] = 0;
        return; 
    }


    /* Refine if the local curvature of the potential (weighted by the
     * exponential factors, etc.) is above a given threshold value.  We've now
     * taken care of all cases where the first or second derivatives of \kappa
     * could be non-zero.  The remaining portion of the second derivative of
     * the sum term is therefore:
     *
     *    \kappa(x) \sum_i q_i^4 c_i \exp( -q_i u^*)
     *       \times [ (\nabla u^*)^2 - \nabla^2 u^* ]
     *
     */
     VASSERT(Vopot_curvature(var.opot, var.xq, 1, &(d2U)));
     VASSERT(Vopot_gradient(var.opot, var.xq, dU));

     dU2 = 0;
     for (i=0; i<3; i++) dU2 += (dU[i]*dU[i]);

     if (var.B > VSMALL) {
         F[0] = 0.0;
         for (i=0; i<var.nion; i++) 
           F[0] += var.B*(VSQR(var.ionQ[i])*dU2 - var.ionQ[i]*d2U);
     } else F[0] = 0;

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  pbePDE_Fu_v
//
// Purpose:  Evaluate the integrand F(u)(v) of the functional <F(u),v>
//           at the single point x.  This is your nonlinear weak form:
//
//                /\                 /\
//     <F(u),v> = \  F_0(u)(v) dx +  \  F_1(u)(v) ds
//               \/m                \/dm
//
//                /\
//              = \  g_{ij} ( a(u)^{iq} v^j_{~;q} + b(u)^i v^j ) dx
//               \/m
//
//                /\
//              + \  g_{ij} c(u)^i v^j ds
//               \/dm
//
// Input:    PDE   = pointer to the PDE object
//           key   = integrand to evaluate (0=F_0, 1=F_1)
//           tV[]  = test function at the current point
//           tdV[] = test function gradient at the current point
//
// Output:   Value of the integrand is returned
//
// Speed:    This function is called by MC multiple times for a single
//           quadrature point during assembly, and needs to be a fast
//           as possible.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double PDE_Fu_v(PDE *thee, int key, double V[], double dV[][3]) {

    int i;
    double value = 0.;

    /* interior form case */
    if (key == 0) {
        value = var.B * V[0];
        for (i=0; i<thee->dim; i++)
            value += ( var.A * var.dU[0][i] * dV[0][i] );

    /* boundary form case */
    } else { /* (key == 1) */
        VASSERT(0);
    }

    return value;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_DFu_wv
//
// Purpose:  Evaluate the integrand DF(u)(w,v) of the functional <DF(u)w,v>
//           at the single point x.  This is your bilinear weak form:
//
//                  /\                    /\
//     <DF(u)w,v> = \  DF_0(u)(w,v) dx +  \  DF_1(u)(w,v) ds
//                 \/m                   \/dm
//
//                  /\
//                = \  d/dt F_0(u+tw)(v)|_{t=0} dx
//                 \/m
//
//                  /\
//                + \  d/dt F_1(u+tw)(v)|_{t=0} ds
//                 \/dm
//
// Input:    PDE   = pointer to the PDE object
//           key   = integrand to evaluate (0=F_0, 1=F_1)
//           tW[]  = trial function at the current point
//           tdW[] = trial function gradient at the current point
//           tV[]  = test function at the current point
//           tdV[] = test function gradient at the current point
//
// Output:   Value of the integrand is returned
//
// Speed:    This function is called by MC multiple times for a single
//           quadrature point during assembly, and needs to be a fast
//           as possible.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double PDE_DFu_wv(PDE *thee, int key, double W[], double dW[][3],
    double V[], double dV[][3]) {

    int i;
    double value = 0.;

    /* interior form case */
    if (key == 0) {
        value = var.DB * W[0] * V[0];
        for (i=0; i<thee->dim; i++)
            value += ( var.A * dW[0][i] * dV[0][i] );

    /* boundary form case */
    } else { /* (key == 1) */
        VASSERT(0);
    }

    return value;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_delta
//
// Purpose:  At the single given point x, evaluate a delta function
//           source term (if one is present): delta = g(x).
//
// Input:    PDE   = pointer to the PDE object
//           chart = chart in which the point coordinates are provided
//           txq[] = coordinates of the point
//
// Output:   F[]   = resulting function values
//
// Speed:    This function is called by MC once for each node in the mesh,
//           just after a full element-wise assembly, so it should be fast.
//
// Author:   Michael Holst and Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
#define VRINGMAX 1000
#define VATOMMAX 1000000
VPUBLIC void PDE_delta(PDE *thee, int type, int chart, double txq[], 
  void *user, double F[]) {

    int iatom, jatom, natoms;
    Vatom *atom;
    double *position, charge;

    int atomIndex, atomList[VATOMMAX], nAtomList, gotAtom;

    int numSring, isimp, ivert, sid;
    SS *sring[VRINGMAX];
    VV *vertex = (VV *)user;
    double phi[4], phix[4][3];
    double value;

    /* Assemble the simplex ring around this vertex */
    VASSERT( vertex != VNULL);
    numSring = 0;
    sring[numSring] = VV_firstSS(vertex);
    while (sring[numSring] != VNULL) {
        numSring++;
        sring[numSring] = SS_link(sring[numSring-1], vertex);
    }
    VASSERT( numSring > 0 );
    VASSERT( numSring <= VRINGMAX );

    /* Move around the simplex ring and determine the charge locations */
    F[0] = 0.;
    charge = 0.;
    nAtomList = 0;
    for (isimp=0; isimp<numSring; isimp++) {
        sid = SS_id(sring[isimp]);
        natoms = Vcsm_getNumberAtoms(Vfetk_getVcsm(var.fetk), sid);

        for (iatom=0; iatom<natoms; iatom++) {

            /* Get the delta function information */
            atomIndex = Vcsm_getAtomIndex(Vfetk_getVcsm(var.fetk), iatom, sid);
            gotAtom = 0;
            for (jatom=0; jatom<nAtomList; jatom++) {
                if (atomList[jatom] == atomIndex) {
                    gotAtom = 1;
                    break;
                }
            }
            if (!gotAtom) {
           
                VASSERT(nAtomList < VATOMMAX);
                atomList[nAtomList] = atomIndex;
                nAtomList++;

                atom = Vcsm_getAtom(Vfetk_getVcsm(var.fetk), iatom, sid);
                charge = Vatom_getCharge(atom);
                position = Vatom_getPosition(atom);


                /* Get the test function value at the delta function 
                 * 
                 * I used to do a VASSERT to make sure the point was in the 
                 * simplex (i.e., make sure round-off error isn't an issue), 
                 * but round off errors became an issue */
                if (!Gem_pointInSimplexVal(Vfetk_getGem(var.fetk), 
                  sring[isimp], position, phi, phix)) {
                    if (!Gem_pointInSimplex(Vfetk_getGem(var.fetk), 
                      sring[isimp], position)) {
                         Vnm_print(2, "delta: Both Gem_pointInSimplexVal and Gem_pointInSimplex detected misplaced point charge!\n");
                        Vnm_print(2, "delta: I think you have problems: phi = {");
                        for (ivert=0; ivert<Gem_dimVV(Vfetk_getGem(var.fetk)); 
                          ivert++) Vnm_print(2, "%e ", phi[ivert]);
                        Vnm_print(2, "}\n");
                    }
                }
                value = 0;
                for (ivert=0; ivert<Gem_dimVV(Vfetk_getGem(var.fetk)); ivert++) {
                    if (VV_id(SS_vertex(sring[isimp], ivert)) ==
                       VV_id(vertex)) value += phi[ivert];
                }


                F[0] += (value * Vpbe_getZmagic(var.fetk->pbe) * charge);
            }
        }
    }

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_u_D
//
// Purpose:  At the single given point x, evaluate the dirichlet boundary
//           function: u_D = g(x).
//
// Input:    PDE   = pointer to the PDE object
//           chart = chart in which the point coordinates are provided
//           txq[] = coordinates of the point
//
// Output:   F[]   = resulting function values
//
// Speed:    This function is called by MC just before a full assembly,
//           and does not have to be particularly fast.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_u_D(PDE *thee, int type, int chart, double txq[], 
  double F[]) { 

    F[0] = PDE_U(thee->dim, txq); 

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_u_T
//
// Purpose:  At the single given point x, evaluate the true solution
//           function (if you have one for your problem): u_T = u(x).
//
// Input:    PDE   = pointer to the PDE object
//           chart = chart in which the point coordinates are provided
//           txq[] = coordinates of the point
//
// Output:   F[]   = resulting function values
//
// Speed:    This function is called by MC just before a full assembly,
//           and does not have to be particularly fast.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_u_T(PDE *thee, int type, int chart, double txq[], 
  double F[]) { 

    F[0] = PDE_U(thee->dim, txq); 

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_bisectEdge
//
// Purpose:  Define the way manifold edges are bisected.
//
// Input:    The input parameters have the following interpretations:
//
//               dim                  = intrinsic dimension of the manifold
//               dimII                = imbedding dimension of the manifold
//               edgeType             = edge type being refined
//               chart[0]             = manifold chart for 0th vertex of edge
//               chart[1]             = manifold chart for 1st vertex of edge
//               vx[0][0,...,dimII-1] = 1st vertex coordinates w.r.t. chart[0]
//               vx[1][0,...,dimII-1] = 2nd vertex coordinates w.r.t. chart[1]
//
// Output:   The output parameters have the following interpretations:
//
//               chart[2]             = manifold chart for NEW 3rd vertex
//               vx[2][0,...,dimII-1] = 3rd vertex coordinates w.r.t. chart[2]
//
// Speed:    This function is called by MC every time an edge must be
//           bisected for simplex refinement, and needs to be as fast as
//           possible.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_bisectEdge(int dim, int dimII, int edgeType, int chart[], 
  double vx[][3]) {
    int i;
    for (i=0; i<dimII; i++) vx[2][i] = .5 * (vx[0][i] + vx[1][i]);
    chart[2] = pointAccessibility(dim, vx[2]);
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_mapBoundary
//
// Purpose:  Define the way the boundary is mapped to some shape
//
// Author: Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_mapBoundary(int dim, int dimII, int vertexType, int chart, 
  double vx[3]) { }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_markSimplex
//
// Purpose:  User-provided error estimator which allows the user to define
//           his own refinement strategies rather than using the builtin
//           a posteriori error estimators.
//
// Input:    The input parameters have the following interpretations:
//
//               dim                  = intrinsic dimension of the manifold
//               dimII                = imbedding dimension of the manifold
//               simplexType          = simplex type being refined
//               chart[0,...,d+1]     = manifold charts for all d+1 vertices
//               vx[0][0,...,dimII-1] = vx[0] coordinates w.r.t. chart
//                       ...
//               vx[d][0,...,dimII-1] = vx[d] coordinates w.r.t. chart
//              *simplex              = a pointer to the simplex (or
//                                      nothing).  This is of void * type
//                                      and needs to be cast.
//
// Output:   The output parameters have the following interpretations:
//
//               return value         = 0 if the simplex is not to be refined
//                                    = 1 if the simplex is to be refined
//
// Speed:    This function is called by MC for every element during error
//           estimation, if the user-provided error estimator is requested.
//           Therefore, it should be pretty fast or the error estimation
//           phase will be slow.
//
// Notes:    The user can use this routine to define, for example,
//           a completely geometry-based error estimator.
//
// Example:  In the case that the user-provided error estimator is never
//           requested, then this routine can simply return any value.
//
// Author:   Nathan Baker and Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC int PDE_markSimplex(int dim, int dimII,
    int simplexType, int faceType[4], int vertexType[4],
    int chart[], double vx[][3], void *simplex) { 

    int i, accBit, natoms, refAcc;
    SS *simp;
    double edgeLength;
    simp = (SS *)simplex;


    /* We are interested in accurately representing the (strong form) operator:
     * 
     *   DA(u^*) v =   \nabla \cdot \epsilon \nabla v 
     *               + \kappa \sum_i q_i^4 c_i \exp( -q_i u^*)
     *
     * which means we want to accurately represent the behavior of \epsilon,
     * \kappa, and u^*.  We will assume that \epsilon and \kappa are piecewise
     * constant and jump over different surfaces.  Furthermore, \kappa is
     * either 0 or non-zero and we (obviously) will only be interested in the
     * behavior of the summed term where \kappa is nonzero.
     */

    /* First, we'll set a lower bound for the size of the simplices.  Simplices
     * below this bound do not get refined. */
    Gem_longestEdge(var.fetk->gm, simp, &edgeLength);
    if (edgeLength < var.minLongEdge) { return 0; }

    /* If the simplex lies on a discontinuity in \epsilon, mark.  The epsilon
     * characteristic function is stored in the first bit of a bitmap (chart)
     * associated with each vertex. */
    accBit = 1;
    refAcc = ((chart[0] & accBit) != 0);
    for (i=1; i<dim+1; i++) {
        if (((chart[i] & accBit) != 0) != refAcc) return 1;
    }

    /* If the simplex lies on a discontinuity in \kappa, mark.  The epsilon
     * characteristic function is stored in the second bit of a bitmap (chart)
     * associated with each vertex. */
    accBit = 2;
    refAcc = ((chart[0] & accBit) != 0);
    for (i=1; i<dim+1; i++) {
        if (((chart[i] & accBit) != 0) != refAcc) return 1;
    }
   
    /* Refine if the local curvature of the potential (weighted by the
     * exponential factors, etc.) is above a given threshold value.  We've now
     * taken care of all cases where the first or second derivatives of \kappa
     * could be non-zero.  The remaining portion of the second derivative of
     * the sum term is therefore: 
     *
     *    \kappa(x) \sum_i q_i^4 c_i \exp( -q_i u^*) 
     *       \times [ (\nabla u^*)^2 - \nabla^2 u^* ]
     *
     */
    /* See the PDE_Fu() routine for this treatment; PDE_Fu() gets called after
     * initPoint, so it's much easier to calculate this kind of estimate in
     * that routine. */

    /* Do not mark this simplex for refinement (by default) */
    return 0; 

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_oneChart
//
// Purpose:  Select a single unified chart for a set of two or more vertices
//           whose coordinates may be given with respect to different charts.
//           Then transform all of the coordinates of the vertex set to be
//           with respect to the single selected "unified" chart.
//
// Notes:    We use the chart to store the solvent accessiblity of the protein.
//           However, the routines which use the chart values use the values
//           from the individual vertices.  Therefore, for our application,
//           there is never any need to unify the chart.
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_oneChart(int dim, int dimII, int objType, int chart[], 
  double vx[][3], int dimV) { }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_Ju
//
// Purpose:  Evaluate the integrand J_k(u) of the energy functional J(u)
//           at the single point x.  This is your nonlinear energy
//           functional for which your weak form PDE below in Fu_v() is the
//           Euler condition.  (There may not be such a J(u) in all cases.)
//
//            /\              /\
//     J(u) = \  J_0(u) dx +  \  J_1(u) ds
//           \/m             \/dm
//
// Input:    PDE   = pointer to the PDE object
//           key   = integrand to evaluate (0=J_0, 1=J_1)
//
// Output:   Value of the integrand is returned
//
// Speed:    This function is called by MC once times for a single
//           quadrature point during assembly, and needs to be fast.
// 
// Note:     THIS ENERGY FUNCTIONAL WILL NEVER INCLUDE DELTA FUNCTION TERMS
//           INSTEAD, IT WILL HAVE THE FORM:
//
//           c^{-1}/2 \int (\epsilon (\nabla u)^2 + \kappa^2 (cosh u - 1)) dx
//
//           where c is the Vpbe_getZmagic output
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double PDE_Ju(PDE *thee, int key) { return 0.0; }

/* ///////////////////////////////////////////////////////////////////////////
// Class PDE: Inlineable methods
/////////////////////////////////////////////////////////////////////////// */
#if !defined(VINLINE_VMC)
#endif /* if !defined(VINLINE_VMC) */

/* ///////////////////////////////////////////////////////////////////////////
// Class PDE: Non-inlineable methods
/////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_ctor
//
// Purpose:  Construct the differential equation object.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC PDE* PDE_ctor() {

    PDE *thee = VNULL;

    int i;

    VDEBUGIO("PDE_ctor: CREATING object..");

    /* create some space for the pde object */
    thee = Vmem_malloc(VNULL, 1, sizeof(PDE) );

    /* PDE-specific parameters and function pointers */
    thee->initAssemble = PDE_initAssemble; 
    thee->initElement  = PDE_initElement;
    thee->initFace     = PDE_initFace;  
    thee->initPoint    = PDE_initPoint;
    thee->Fu           = PDE_Fu;      
    thee->Fu_v         = PDE_Fu_v;   
    thee->DFu_wv       = PDE_DFu_wv;
    thee->delta        = PDE_delta;
    thee->u_D          = PDE_u_D; 
    thee->u_T          = PDE_u_T;
    thee->Ju           = PDE_Ju;
    thee->vec          = 1; /* FIX! */
    thee->sym[0][0]    = 1;        
    thee->est[0]       = 1.0;     
    for (i=0; i<VMAX_BDTYPE; i++) thee->bmap[0][i] = i;

    /* Manifold-specific function pointers */
    thee->bisectEdge  = PDE_bisectEdge; 
    thee->mapBoundary = PDE_mapBoundary;
    thee->markSimplex = PDE_markSimplex;
    thee->oneChart    = PDE_oneChart;   

    /* Element-specific function pointers */
    thee->simplexBasisInit = simplexBasisInit;
    thee->simplexBasisForm = simplexBasisForm;

    /* Initialize the LocalVars array */
    var.fetk = VNULL;

    VDEBUGIO("..done.\n");

    /* return the new pde object */
    return thee;
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_init
//
// Purpose:  Initialize problem-specific details of the differential 
//           equation object.
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_init(PDE* thee, Vopot *topot, Vfetk *tfetk, int tpdeKey, 
  double minLongEdge) {

    int i, j, dim;
    double coord[4];
    VV *vert;

    /* Set local PBE object */
    var.fetk = tfetk;

    /* Set potential oracle */
    var.opot = topot;

    /* Set PDE key */
    var.pdeKey = tpdeKey;
 
    var.minLongEdge = minLongEdge;

    /* Set up the external Gem subdivision hook */
    Gem_setExternalUpdateFunction(var.fetk->gm, PDE_externalUpdateFunction);

    /* Get spatial dimension */
    dim = Gem_dim(var.fetk->gm);

    /* Map problem data to the mesh; i.e., reset the vertex charts */
    for (i=0; i<Gem_numVV(var.fetk->gm); i++) {
        vert = Gem_VV(var.fetk->gm,i);
        for (j=0; j<dim; j++) coord[j] = VV_coord(vert,j);
        VV_setChart(vert, pointAccessibility(dim, coord));
    }

    /* Set up ionic strength stuff */
    var.zkappa2 = Vpbe_getZkappa2(var.fetk->pbe);
    var.ionstr = Vpbe_getBulkIonicStrength(var.fetk->pbe);
    if (var.ionstr > 0.0) var.zks2 = 0.5*var.zkappa2/var.ionstr;
    else var.zks2 = 0.0;
    Vpbe_getIons(var.fetk->pbe, &(var.nion), var.ionConc, var.ionRadii,
      var.ionQ);
    for (i=0; i<var.nion; i++) {
        var.ionConc[i] = var.zks2 * var.ionConc[i] * var.ionQ[i];
    }

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_dtor
//
// Purpose:  Destroy the differential equation object.
//
// Author:   Michael Holst
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_dtor(PDE **thee)
{
    VASSERT( (*thee) != VNULL );
    if ((*thee) != VNULL) {

        VDEBUGIO("PDE_dtor: DESTROYING object..");
        Vmem_free(VNULL, 1, sizeof(PDE), (void **)thee);
        VDEBUGIO("..done.\n");

        (*thee) = VNULL;
    }
}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  PDE_externalUpdateFunction
//
// Purpose:  The external hook to the simplex subdivision routines in Gem
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void PDE_externalUpdateFunction(SS **simps, int num) { 
    VASSERT( Vcsm_update(Vfetk_getVcsm(var.fetk), simps, num) ); 
}
