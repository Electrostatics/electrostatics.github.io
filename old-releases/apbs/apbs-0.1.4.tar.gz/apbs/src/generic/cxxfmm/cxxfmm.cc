/* ///////////////////////////////////////////////////////////////////////////
/// APBS -- Adaptive Poisson-Boltzmann Solver
///
///  Nathan A. Baker (nbaker@wasabi.ucsd.edu)
///  Dept. of Chemistry and Biochemistry
///  Dept. of Mathematics, Scientific Computing Group
///  University of California, San Diego 
///
///  Additional contributing authors listed in the code documentation.
///
/// Copyright � 1999. The Regents of the University of California (Regents).
/// All Rights Reserved. 
/// 
/// Permission to use, copy, modify, and distribute this software and its
/// documentation for educational, research, and not-for-profit purposes,
/// without fee and without a signed licensing agreement, is hereby granted,
/// provided that the above copyright notice, this paragraph and the
/// following two paragraphs appear in all copies, modifications, and
/// distributions.
/// 
/// IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
/// SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS,
/// ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
/// REGENTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
/// 
/// REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
/// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
/// PARTICULAR PURPOSE.  THE SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF
/// ANY, PROVIDED HEREUNDER IS PROVIDED "AS IS".  REGENTS HAS NO OBLIGATION
/// TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
/// MODIFICATIONS. 
//////////////////////////////////////////////////////////////////////////// 
/// rcsid="$Id: cxxfmm.cc,v 1.2 2001/01/30 18:06:37 apbs Exp $"
//////////////////////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////////////////////////
// File:     cxxfmm.cc
//
// Purpose:  Class Vgreen: C++ Fast multipole methods. 
//
// Author:   Gary Huber (adapted to APBS by Nathan Baker)
/////////////////////////////////////////////////////////////////////////// */

#include "apbscfg.h"

#if defined(USE_CXX_FMM)

#include "apbs/vgreen.h"
#include "apbs/vatom.h"
#include "Coulombic_Cell_Multipole_Calculator_Vatom.hh"

VPUBLIC Coulombic_Cell_Multipole_Calculator_Vatom *ccmc;

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Vgreen_dtorCXXFMM
//
// Purpose:  Kill the C++ FMM object
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Vgreen_dtorCXXFMM(Vgreen *thee) { delete ccmc; }

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Vgreen_initCXXFMM
//
// Purpose:  Initialize C++ FMM object
//
// Args:     spacing   FMM cell spacings
//           n[xyz]    Number of FMM cells in the specified directions
//           [xyz]low  Lower cordner of the mesh
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Vgreen_initCXXFMM(Vgreen *thee, double spacing, int nx, int ny,
  int nz, double xlow, double ylow, double zlow) {

    /* Construct the CCMC object */
    ccmc = new Coulombic_Cell_Multipole_Calculator_Vatom;

    /* Initialize the object */
    ccmc->Set_list(thee->alist->atoms, Valist_getNumberAtoms(thee->alist));
    ccmc->Set_cell_spacing(spacing);
    ccmc->Set_dimensions(nx, ny, nz);
    ccmc->Set_low_corner(xlow, ylow, zlow);
    ccmc->Update_geometry();
    ccmc->Update_particles();
    ccmc->Compute_far_fields();

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Vgreen_updateCXXFMM
//
// Purpose:  Update the C++ FMM object to reflect a change in atomic positions
//           or properties
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Vgreen_updateCXXFMM(Vgreen *thee) {

    ccmc->Update_geometry();
    ccmc->Update_particles();
    ccmc->Compute_far_fields();

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Vgreen_potentialCXXFMM
//
// Purpose:  Get the potential at the specified position
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC double Vgreen_potentialCXXFMM(Vgreen *thee, double x[3]) {

    return ccmc->potential(x);

}

/* ///////////////////////////////////////////////////////////////////////////
// Routine:  Vgreen_fieldCXXFMM
//
// Purpose:  Get the field at the specified position
//
// Author:   Nathan Baker
/////////////////////////////////////////////////////////////////////////// */
VPUBLIC void Vgreen_fieldCXXFMM(Vgreen *thee, double x[3], 
  double F[3]) {

    ccmc->Get_electric_field(x, F);

}

#endif
